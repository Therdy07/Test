import React, { useState } from "react";
import Stats from "./Stats";
import { RiArrowLeftSLine, RiArrowRightSLine } from "react-icons/ri";
import { GrBookmark } from "react-icons/gr";
import { BsSortDownAlt, BsSortUpAlt } from "react-icons/bs";
import { FaSearch } from "react-icons/fa";
import { FiRefreshCw } from "react-icons/fi";
import Soccer from "./Soccer";
import Basketball from "./Basketball";
import Baseball from "./Baseball";
import IceHockey from "./IceHockey";
import Tennis from "./Tennis";
import Handball from "./Handball";
import Boxing from "./Boxing";
import Rugby from "./Rugby";
import Aussie from "./Aussie";
import AmericanFootball from "./AmericanFootball";

function League() {
  const [toggleState, setToggleState] = useState(1);

  const toggleTab = (index) => {
    setToggleState(index);
  };
  return (
    <>
      <div data-v-47fb79fe="" className="prematch scrollable-auto column">
        <div
          data-v-296bd5a2=""
          data-v-47fb79fe=""
          className="scroll-menu row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-296bd5a2=""
            className="left row"
            style={{ flexDirection: "row" }}
          >
            <button data-v-296bd5a2="" className="button" />
          </div>
          <div
            data-v-05849275=""
            data-v-296bd5a2=""
            className="list scrollable-auto events row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 1 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(1)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/1.e26e720.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Soccer
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 2 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(2)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/2.dba1d03.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Basketball
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 3 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(3)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/3.2b24d6d.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Baseball
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 4 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(4)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="data:image/svg+xml;base64,PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA2NCA2NCIgdmlld0JveD0iMCAwIDY0IDY0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Im0xIDI3LjR2OS4yYzAgMy40IDEzLjkgNi4xIDMxIDYuMXMzMS0yLjcgMzEtNi4xdi05LjJ6IiBmaWxsPSIjMWMxYjFiIi8+PHBhdGggZD0ibTMyIDQyLjNjLTE3LjEgMC0zMS0yLjctMzEtNi4xdi40YzAgMy40IDEzLjkgNi4xIDMxIDYuMXMzMS0yLjcgMzEtNi4xdi0uNGMwIDMuNC0xMy45IDYuMS0zMSA2LjF6IiBmaWxsPSIjMzgzODM4Ii8+PGVsbGlwc2UgY3g9IjMyIiBjeT0iMjcuNCIgZmlsbD0iIzFlMWUxZSIgcng9IjMxIiByeT0iNi4xIi8+PHBhdGggZD0ibTMyIDMyLjljLTE2LjYgMC0zMC4yLTIuNi0zMS01Ljh2LjNjMCAzLjQgMTMuOSA2LjEgMzEgNi4xczMxLTIuNyAzMS02LjFjMC0uMSAwLS4yIDAtLjMtLjggMy4yLTE0LjQgNS44LTMxIDUuOHoiIGZpbGw9IiMyZDJkMmQiLz48cGF0aCBkPSJtMzIgMjYuNmM1IDAgOS45LjIgMTMuNy43LjQgMCAuOC4xIDEuMi4xLS40IDAtLjguMS0xLjIuMS0zLjguNS04LjcuNy0xMy43LjdzLTkuOS0uMi0xMy43LS43Yy0uNCAwLS44LS4xLTEuMi0uMS40IDAgLjgtLjEgMS4yLS4xIDMuOC0uNSA4LjctLjcgMTMuNy0uN20wLTIuMWMtMTIuMSAwLTIxLjggMS4zLTIxLjggMi45czkuOCAyLjkgMjEuOCAyLjkgMjEuOC0xLjMgMjEuOC0yLjktOS43LTIuOS0yMS44LTIuOXoiIGZpbGw9IiNmZmYiLz48L3N2Zz4="
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Ice Hockey
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 5 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(5)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/5.7ac0dec.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Tennis
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 6 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(6)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/6.7318639.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Handball
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 7 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(7)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/10.6f5a821.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Boxing
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 8 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(8)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/12.75e2172.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Rugby
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 9 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(9)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/13.846bd68.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Aussie Rules
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 10 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(10)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/16.98844f6.svg"
                    className="sports-icon"
                    alt=""
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    American Football
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 11 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(11)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/19.18bcff6.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Snooker
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 12 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(12)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/20.b28de01.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Table Tennis
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 13 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(13)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/21.e247a0b.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Cricket
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 14 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(14)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/22.cadabff.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Darts
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 15 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(15)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/23.7105815.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Volleyball
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 16 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(16)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/26.311a058.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Waterpolo
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 17 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(17)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/29.0f8768e.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Futsal
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 18 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(18)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="data:image/svg+xml;base64,PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA2NCA2NCIgdmlld0JveD0iMCAwIDY0IDY0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjMyIiBjeT0iMzIiIGZpbGw9IiM0ZDRkNGQiIHI9IjMxIi8+PGNpcmNsZSBjeD0iMjEuMyIgY3k9IjQzLjEiIGZpbGw9IiNmOWQ3MGQiIHI9IjIuMSIvPjxjaXJjbGUgY3g9IjE2LjciIGN5PSI0Ny4zIiBmaWxsPSIjZjlkNzBkIiByPSIxLjYiLz48cGF0aCBkPSJtNDMuMyAzLjFjMS40IDMuNSAyLjEgNy4zIDIuMSAxMS4zIDAgMTcuMS0xMy45IDMxLTMxIDMxLTQgMC03LjgtLjctMTEuMy0yLjEgNC41IDExLjUgMTUuOCAxOS43IDI4LjkgMTkuNyAxNy4xIDAgMzEtMTMuOSAzMS0zMSAwLTEzLjEtOC4yLTI0LjQtMTkuNy0yOC45eiIgb3BhY2l0eT0iLjA1Ii8+PHBhdGggZD0ibTQ5LjEgNi4xYzMuMiA0LjkgNS4xIDEwLjggNS4xIDE3LjEgMCAxNy4xLTEzLjkgMzEtMzEgMzEtNi4zIDAtMTIuMi0xLjktMTcuMS01LjEgNS42IDguNCAxNS4xIDEzLjkgMjUuOSAxMy45IDE3LjEgMCAzMS0xMy45IDMxLTMxIDAtMTAuOC01LjUtMjAuMy0xMy45LTI1Ljl6IiBvcGFjaXR5PSIuMDUiLz48L3N2Zz4="
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Squash
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 19 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(19)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/117.c06a79e.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    MMA
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 20 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(20)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/135.f111c33.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Gaelic Football
                  </span>
                </div>
              </button>
            </div>
            <div
              data-v-296bd5a2=""
              className={
                toggleState === 21 ? "event column active" : "event column"
              }
              onClick={() => toggleTab(21)}
            >
              <button data-v-296bd5a2="" className="button">
                <div
                  data-v-296bd5a2=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-296bd5a2=""
                    src="https://assets.dashboard-yes.bet/img/136.272b296.svg"
                    className="sports-icon"
                  />
                </div>
                <div
                  data-v-296bd5a2=""
                  className="margin-top-5 desc-text row"
                  style={{ flexDirection: "row" }}
                >
                  <span data-v-296bd5a2="" className="text">
                    Gaelic Hurling
                  </span>
                </div>
              </button>
            </div>
          </div>
          <div
            data-v-296bd5a2=""
            className="right row"
            style={{ flexDirection: "row" }}
          >
            <button data-v-296bd5a2="" className="button" />
          </div>
        </div>
        <div
          data-v-0e50b22a=""
          data-v-47fb79fe=""
          className="column"
          style={{ flexShrink: 0 }}
        >
          <div
            data-v-0e50b22a=""
            className="search row"
            style={{ flexDirection: "row" }}
          >
            <input
              data-v-5b7f4dd8=""
              data-v-0e50b22a=""
              type="text"
              placeholder="Please enter team name or league name."
              inputMode="text"
              className="input"
              style={{
                width: "100%",
                backgroundColor: "rgb(37, 46, 72)",
              }}
            />
            <button
              data-v-0e50b22a=""
              className="search-button button"
              style={{
                background: "rgb(37, 46, 72)",
                width: 40,
                height: 40,
              }}
            >
              <FaSearch
                data-v-e56d064c=""
                data-v-0e50b22a=""
                className="fa-solid fa-magnifying-glass"
              />
            </button>
          </div>
          <div
            data-v-0e50b22a=""
            className="settings row"
            style={{
              height: 40,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <div
              data-v-58b5c95e=""
              data-v-0e50b22a=""
              className="row"
              style={{ flexDirection: "row" }}
            >
              <div
                className="row"
                style={{ width: "100%", flexDirection: "row" }}
              >
                <button
                  data-v-0e50b22a=""
                  className="select-tournament margin-right-10 button"
                  style={{ height: 35 }}
                >
                  <span data-v-0e50b22a="" className="text">
                    <GrBookmark
                      data-v-e56d064c=""
                      data-v-0e50b22a=""
                      className="margin-right-5 fa-regular fa-bookmark"
                    />
                    Select league
                  </span>
                </button>
              </div>
            </div>
            <button
              data-v-0e50b22a=""
              className="sort-time margin-right-10 button text active"
              style={{ background: "transparent" }}
            >
              <span data-v-0e50b22a="" className="text">
                <BsSortDownAlt
                  size="1rem"
                  data-v-e56d064c=""
                  data-v-0e50b22a=""
                  className="margin-right-5 fa-light fa-arrow-down-short-wide"
                />
                Sort time
              </span>
            </button>
            <button
              data-v-0e50b22a=""
              className="sort-league button text"
              style={{ background: "transparent" }}
            >
              <span data-v-0e50b22a="" className="text">
                <BsSortUpAlt
                  size="1rem"
                  data-v-e56d064c=""
                  data-v-0e50b22a=""
                  className="margin-right-5 fa-light fa-arrow-up-short-wide"
                />
                Sort league
              </span>
            </button>
            <div data-v-0e50b22a="" className="spacer" />
            <button
              data-v-0e50b22a=""
              className="refresh margin-left-10 button"
              style={{
                background: "rgb(37, 46, 72)",
                width: 40,
                height: "100%",
              }}
            >
              <FiRefreshCw
                data-v-e56d064c=""
                data-v-0e50b22a=""
                className="fa-solid fa-arrows-rotate"
              />
            </button>
          </div>
          <div
            data-v-0e50b22a=""
            className="viewSettingWrap row"
            style={{ height: 40, flexDirection: "row" }}
          >
            <button
              data-v-0e50b22a=""
              className="margin-right-10 button text active"
              style={{ background: "transparent" }}
            >
              <span data-v-0e50b22a="" className="text">
                Modern View
              </span>
            </button>
            <button
              data-v-0e50b22a=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-0e50b22a="" className="text">
                Asian View
              </span>
            </button>
            <div data-v-0e50b22a="" className="spacer" />
            <div
              data-v-0e50b22a=""
              dir="auto"
              className="v-select vs--single vs--unsearchable"
            >
              <div
                id="vs2__combobox"
                aria-controls=""
                role="combobox"
                aria-expanded="false"
                aria-owns="vs2__listbox"
                aria-label="Search for option"
                className="vs__dropdown-toggle"
              >
                <div className="vs__selected-options">
                  <span className="vs__selected">Winner</span>
                  <input
                    readOnly="readonly"
                    aria-autocomplete="list"
                    aria-labelledby="vs2__combobox"
                    aria-controls="vs2__listbox"
                    type="search"
                    autoComplete="off"
                    className="vs__search"
                  />
                </div>
                <div className="vs__actions">
                  <button
                    type="button"
                    title="Clear Selected"
                    aria-label="Clear Selected"
                    className="vs__clear"
                    style={{ display: "none" }}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={10}
                      height={10}
                    >
                      <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                    </svg>
                  </button>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={14}
                    height={10}
                    role="presentation"
                    className="vs__open-indicator"
                  >
                    <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                  </svg>
                  <div className="vs__spinner" style={{ display: "none" }}>
                    Loading...
                  </div>
                </div>
              </div>
              <ul
                id="vs2__listbox"
                role="listbox"
                style={{ display: "none", visibility: "hidden" }}
              />
            </div>
          </div>
        </div>
        <div data-v-47fb79fe="" className="prematch-list column modern">
          {toggleState === 1 && <Soccer />}
          {toggleState === 2 && <Basketball />}
          {toggleState === 3 && <Baseball />}
          {toggleState === 4 && <IceHockey />}
          {toggleState === 5 && <Tennis />}
          {toggleState === 6 && <Handball />}
          {toggleState === 7 && <Boxing />}
          {toggleState === 8 && <Rugby />}
          {toggleState === 9 && <Aussie />}
          {toggleState === 10 && <AmericanFootball />}
        </div>
        <div data-v-72e289f4="" data-v-47fb79fe="" className="pagination row">
          <div
            data-v-72e289f4=""
            className="row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-72e289f4=""
              dir="auto"
              className="v-select vs--single vs--unsearchable"
              style={{ marginRight: 5 }}
            >
              <div
                id="vs3__combobox"
                role="combobox"
                aria-controls=""
                aria-expanded="false"
                aria-owns="vs3__listbox"
                aria-label="Search for option"
                className="vs__dropdown-toggle"
                style={{ height: 40 }}
              >
                <div className="vs__selected-options">
                  <span className="vs__selected">10</span>
                  <input
                    readOnly="readonly"
                    aria-autocomplete="list"
                    aria-labelledby="vs3__combobox"
                    aria-controls="vs3__listbox"
                    type="search"
                    autoComplete="off"
                    className="vs__search"
                  />
                </div>
                <div className="vs__actions">
                  <button
                    type="button"
                    title="Clear Selected"
                    aria-label="Clear Selected"
                    className="vs__clear"
                    style={{ display: "none" }}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={10}
                      height={10}
                    >
                      <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                    </svg>
                  </button>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={14}
                    height={10}
                    role="presentation"
                    className="vs__open-indicator"
                  >
                    <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                  </svg>
                  <div className="vs__spinner" style={{ display: "none" }}>
                    Loading...
                  </div>
                </div>
              </div>
              <ul
                id="vs3__listbox"
                role="listbox"
                style={{ display: "none", visibility: "hidden" }}
              />
            </div>
          </div>
          <div
            data-v-72e289f4=""
            className="row"
            style={{ flexDirection: "row", alignItems: "center" }}
          >
            <span
              data-v-72e289f4=""
              className="text"
              style={{ opacity: "0.6" }}
            >
              Show respectively
            </span>
          </div>
          <div data-v-72e289f4="" className="spacer" />
          <div
            data-v-72e289f4=""
            className="row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-72e289f4=""
              dir="auto"
              className="v-select vs--single vs--unsearchable"
              style={{ marginRight: 5 }}
            >
              <div
                id="vs4__combobox"
                role="combobox"
                aria-controls=""
                aria-expanded="false"
                aria-owns="vs4__listbox"
                aria-label="Search for option"
                className="vs__dropdown-toggle"
                style={{ height: 40 }}
              >
                <div className="vs__selected-options">
                  <span className="vs__selected">1</span>
                  <input
                    readOnly="readonly"
                    aria-autocomplete="list"
                    aria-labelledby="vs4__combobox"
                    aria-controls="vs4__listbox"
                    type="search"
                    autoComplete="off"
                    className="vs__search"
                  />
                </div>
                <div className="vs__actions">
                  <button
                    type="button"
                    title="Clear Selected"
                    aria-label="Clear Selected"
                    className="vs__clear"
                    style={{ display: "none" }}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width={10}
                      height={10}
                    >
                      <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                    </svg>
                  </button>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={14}
                    height={10}
                    role="presentation"
                    className="vs__open-indicator"
                  >
                    <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                  </svg>
                  <div className="vs__spinner" style={{ display: "none" }}>
                    Loading...
                  </div>
                </div>
              </div>
              <ul
                id="vs4__listbox"
                role="listbox"
                style={{ display: "none", visibility: "hidden" }}
              />
            </div>
          </div>
          <div
            data-v-72e289f4=""
            className="row"
            style={{ flexDirection: "row" }}
          >
            <button
              data-v-72e289f4=""
              className="button icon"
              disabled="disabled"
              style={{ background: "rgb(37, 46, 72)" }}
            >
              <RiArrowLeftSLine
                size="1.1rem"
                data-v-e56d064c=""
                data-v-72e289f4=""
                className="fa-solid fa-chevron-left"
              />
            </button>
          </div>
          <div
            data-v-72e289f4=""
            className="row"
            style={{ flexDirection: "row" }}
          >
            <button
              data-v-72e289f4=""
              className="button icon"
              style={{ background: "rgb(37, 46, 72)" }}
            >
              <RiArrowRightSLine
                size="1.1rem"
                data-v-e56d064c=""
                data-v-72e289f4=""
                className="fa-solid fa-chevron-right"
              />
            </button>
          </div>
        </div>
      </div>
      <Stats />
    </>
  );
}

export default League;
