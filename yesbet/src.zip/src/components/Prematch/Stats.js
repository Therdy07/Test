import React from "react";
import { CgTimer } from "react-icons/cg";

function Stats() {
  return (
    <div
      data-v-4fd76316=""
      data-v-47fb79fe=""
      className="markets scrollable-auto column prematch-markets"
    >
      <div
        data-v-4fd76316=""
        className="header row"
        style={{ flexDirection: "row", height: 40, alignItems: "center" }}
      >
        <div
          data-v-4fd76316=""
          className="league-detail row"
          style={{ flexDirection: "row" }}
        >
          <span data-v-4fd76316="" className="event text">
            <img
              data-v-4fd76316=""
              src="https://assets.dashboard-yes.bet/img/1.e26e720.svg"
              className="sports-icon margin-right-5"
              alt=""
            />
            Soccer
          </span>{" "}
          <span data-v-4fd76316="" className="dia text" />
          <span data-v-4fd76316="" className="league text">
            <div
              data-v-78fee962=""
              data-v-4fd76316=""
              className="tournament-icon row"
              style={{ flexDirection: "row" }}
            >
              <img
                data-v-78fee962=""
                src="https://mt-sportradar.com/assets/images/regions/4.png"
                alt=""
              />
            </div>
            European Championship Qualification
          </span>
        </div>
      </div>
      <div
        data-v-4fd76316=""
        className="match-detail row"
        style={{ flexDirection: "row" }}
      >
        <span data-v-4fd76316="" className="time margin-right-10 text">
          <CgTimer
            size="1rem"
            data-v-e56d064c=""
            data-v-4fd76316=""
            className="margin-right-5 fa-regular fa-timer"
          />
          06/17 03:45
        </span>
        <div
          data-v-4fd76316=""
          className="team row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-cc68f3fe=""
            data-v-4fd76316=""
            className="team-icon row"
            style={{ flexDirection: "row" }}
          >
            <img
              data-v-cc68f3fe=""
              src="https://img.mt-sportradar.com/ls/crest/big/4818.png"
              className=""
              alt=""
              style={{ height: 16 }}
            />
          </div>{" "}
          <span data-v-4fd76316="" className="text">
            Andorra
          </span>
        </div>{" "}
        <span
          data-v-4fd76316=""
          className="margin-horizontal-10 text"
          style={{ color: "rgb(255, 229, 136)" }}
        >
          vs
        </span>
        <div
          data-v-4fd76316=""
          className="team row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-cc68f3fe=""
            data-v-4fd76316=""
            className="team-icon row"
            style={{ flexDirection: "row" }}
          >
            <img
              data-v-cc68f3fe=""
              src="https://img.mt-sportradar.com/ls/crest/big/4699.png"
              className=""
              alt=""
              style={{ height: 16 }}
            />
          </div>{" "}
          <span data-v-4fd76316="" className="text">
            Switzerland
          </span>
        </div>
      </div>
      <div
        data-v-4fd76316=""
        className="widget row"
        style={{ flexDirection: "row" }}
      >
        <div
          data-v-183c8283=""
          data-v-4fd76316=""
          className="iframe-view row"
          style={{ height: "193.875px", flexDirection: "row" }}
        >
          <iframe
            title="stats"
            data-v-183c8283=""
            src="https://mt-sportradar.com/headtohead/?matchId=36604345&lang=en&theme=yesbet"
            scrolling="no"
            style={{
              transform: "scale(1.03125)",
              transformOrigin: "0px 0px 0px",
              width: 800,
              height: 188,
            }}
          />
        </div>
      </div>
      <div
        data-v-318c83ff=""
        data-v-4fd76316=""
        className="market-select-slider row"
        style={{ flexDirection: "row" }}
      >
        <div
          data-v-05849275=""
          data-v-318c83ff=""
          className="list scrollable-auto slider row"
          style={{ flexDirection: "row" }}
        >
          <span data-v-318c83ff="" className="text active">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                All
              </span>
            </button>
          </span>{" "}
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Main
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Score
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                First-half
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Second-half
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Corner
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Card
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Special
              </span>
            </button>
          </span>
          <span data-v-318c83ff="" className="text">
            <button
              data-v-318c83ff=""
              className="button text"
              style={{ background: "transparent" }}
            >
              <span data-v-318c83ff="" className="text">
                Etc.
              </span>
            </button>
          </span>
        </div>
      </div>
      <div
        data-v-4fd76316=""
        className="market-wrap row"
        style={{ flexDirection: "row" }}
      >
        <div
          data-v-4fd76316=""
          className="market-list row"
          style={{ flexDirection: "row" }}
        >
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1x2
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        41.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        11.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.05
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Handicap
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (+3)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.73
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (-3)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.05
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (+2.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.15
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (-2.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.65
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Handicap 2:0
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (2:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.90
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw (2:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.10
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (2:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.61
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        11.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        5.20
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.20
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Total
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.56
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.30
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 3.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.96
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 3.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.78
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.60
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.46
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Last goal
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        7.50
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        none
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        23.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.07
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Exact goals
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        31.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        8.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.60
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.90
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        6.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        6+
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        5.60
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Highest scoring half
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1st half
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.10
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2nd half
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.91
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        equal
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.10
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Both halves over 1.5
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        yes
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.05
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        no
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.33
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Both halves under 1.5
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        yes
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.80
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        no
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.22
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Odd/even
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        odd
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.86
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        even
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.88
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Correct score
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        23.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        67.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        6.80
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        26.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        13.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.10
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        13.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        81.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3:3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4:3
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        5.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        16.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        3:4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        4:4
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        other
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.05
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Halftime/fulltime
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        81.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        51.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        19.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.90
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        81.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.30
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                Halftime/fulltime &amp; total
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/Andorra &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/draw &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Andorra &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/draw &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        23.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Switzerland &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        8.50
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/draw &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/Switzerland &amp; under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        6.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/Andorra &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/draw &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra/Switzerland &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        51.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Andorra &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/draw &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw/Switzerland &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        9.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/Andorra &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/draw &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland/Switzerland &amp; over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.67
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - 1x2
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        26.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.30
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - handicap
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (+1.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.53
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (-1.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.38
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (+1)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.15
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (-1)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.61
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - handicap 1:0
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.15
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.70
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.38
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - total
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 0.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.20
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 0.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.00
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 1.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 1.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.73
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.20
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - odd/even
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        odd
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.92
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        even
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.78
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                1st half - correct score
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        21.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        29.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.80
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.90
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        29.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        other
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.80
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - 1x2
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        29.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.60
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.18
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - handicap
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (+1.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.91
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (-1.5)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.80
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - handicap 1:0
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Andorra (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        4.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        draw (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.05
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-3 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        Switzerland (1:0)
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.80
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - total
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 1.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.56
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 1.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.30
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.05
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.68
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        over 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        2.75
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        under 2.5
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.40
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - odd/even
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        odd
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.88
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-2 row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        even
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        1.83
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-v-6ad470db="" data-v-4fd76316="" className="column">
            <div data-v-6ad470db="" className="market column">
              <div
                data-v-6ad470db=""
                className="market-title row"
                style={{ flexDirection: "row" }}
              >
                2nd half - correct score
              </div>
              <div
                data-v-6ad470db=""
                className="outcomes row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        6.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.40
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        0:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.50
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        41.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        19.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        1:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        21.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:0
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:1
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        2:2
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        101.00
                      </span>
                    </button>
                  </div>
                </div>
                <div
                  data-v-6ad470db=""
                  className="odds-other row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-6bf0219c=""
                    data-v-6ad470db=""
                    className="outcome row"
                    style={{ flexDirection: "row" }}
                  >
                    <button data-v-6bf0219c="" className="button">
                      <span data-v-6bf0219c="" className="name text">
                        other
                      </span>
                      <div data-v-6bf0219c="" className="spacer" />
                      <span data-v-6bf0219c="" className="odd text">
                        3.05
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Stats;
