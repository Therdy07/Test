import React from "react";

function Test() {
  return (
    <div data-v-5fa80d04="" className="content column">
      <div data-v-5fa80d04="" className="column">
        <div
          data-v-47fb79fe=""
          data-v-5fa80d04=""
          className="wrap scrollable-auto row"
          style={{ flexDirection: "row" }}
        >
          <div data-v-47fb79fe="" className="prematch scrollable-auto column">
            <div
              data-v-296bd5a2=""
              data-v-47fb79fe=""
              className="scroll-menu row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-296bd5a2=""
                className="left row"
                style={{ flexDirection: "row" }}
              >
                <button data-v-296bd5a2="" className="button" />
              </div>
              <div
                data-v-05849275=""
                data-v-296bd5a2=""
                className="list scrollable-auto events row"
                style={{ flexDirection: "row" }}
              >
                <div data-v-296bd5a2="" className="event column active">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/1.e26e720.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Soccer
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/2.dba1d03.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Basketball
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/3.2b24d6d.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Baseball
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="data:image/svg+xml;base64,PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA2NCA2NCIgdmlld0JveD0iMCAwIDY0IDY0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Im0xIDI3LjR2OS4yYzAgMy40IDEzLjkgNi4xIDMxIDYuMXMzMS0yLjcgMzEtNi4xdi05LjJ6IiBmaWxsPSIjMWMxYjFiIi8+PHBhdGggZD0ibTMyIDQyLjNjLTE3LjEgMC0zMS0yLjctMzEtNi4xdi40YzAgMy40IDEzLjkgNi4xIDMxIDYuMXMzMS0yLjcgMzEtNi4xdi0uNGMwIDMuNC0xMy45IDYuMS0zMSA2LjF6IiBmaWxsPSIjMzgzODM4Ii8+PGVsbGlwc2UgY3g9IjMyIiBjeT0iMjcuNCIgZmlsbD0iIzFlMWUxZSIgcng9IjMxIiByeT0iNi4xIi8+PHBhdGggZD0ibTMyIDMyLjljLTE2LjYgMC0zMC4yLTIuNi0zMS01Ljh2LjNjMCAzLjQgMTMuOSA2LjEgMzEgNi4xczMxLTIuNyAzMS02LjFjMC0uMSAwLS4yIDAtLjMtLjggMy4yLTE0LjQgNS44LTMxIDUuOHoiIGZpbGw9IiMyZDJkMmQiLz48cGF0aCBkPSJtMzIgMjYuNmM1IDAgOS45LjIgMTMuNy43LjQgMCAuOC4xIDEuMi4xLS40IDAtLjguMS0xLjIuMS0zLjguNS04LjcuNy0xMy43LjdzLTkuOS0uMi0xMy43LS43Yy0uNCAwLS44LS4xLTEuMi0uMS40IDAgLjgtLjEgMS4yLS4xIDMuOC0uNSA4LjctLjcgMTMuNy0uN20wLTIuMWMtMTIuMSAwLTIxLjggMS4zLTIxLjggMi45czkuOCAyLjkgMjEuOCAyLjkgMjEuOC0xLjMgMjEuOC0yLjktOS43LTIuOS0yMS44LTIuOXoiIGZpbGw9IiNmZmYiLz48L3N2Zz4="
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Ice Hockey
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/5.7ac0dec.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Tennis
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/6.7318639.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Handball
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/10.6f5a821.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Boxing
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/12.75e2172.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Rugby
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/13.846bd68.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Aussie Rules
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/19.18bcff6.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Snooker
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/20.b28de01.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Table Tennis
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/21.e247a0b.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Cricket
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/22.cadabff.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Darts
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/23.7105815.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Volleyball
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/26.311a058.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Waterpolo
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/29.0f8768e.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Futsal
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="data:image/svg+xml;base64,PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA2NCA2NCIgdmlld0JveD0iMCAwIDY0IDY0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxjaXJjbGUgY3g9IjMyIiBjeT0iMzIiIGZpbGw9IiM0ZDRkNGQiIHI9IjMxIi8+PGNpcmNsZSBjeD0iMjEuMyIgY3k9IjQzLjEiIGZpbGw9IiNmOWQ3MGQiIHI9IjIuMSIvPjxjaXJjbGUgY3g9IjE2LjciIGN5PSI0Ny4zIiBmaWxsPSIjZjlkNzBkIiByPSIxLjYiLz48cGF0aCBkPSJtNDMuMyAzLjFjMS40IDMuNSAyLjEgNy4zIDIuMSAxMS4zIDAgMTcuMS0xMy45IDMxLTMxIDMxLTQgMC03LjgtLjctMTEuMy0yLjEgNC41IDExLjUgMTUuOCAxOS43IDI4LjkgMTkuNyAxNy4xIDAgMzEtMTMuOSAzMS0zMSAwLTEzLjEtOC4yLTI0LjQtMTkuNy0yOC45eiIgb3BhY2l0eT0iLjA1Ii8+PHBhdGggZD0ibTQ5LjEgNi4xYzMuMiA0LjkgNS4xIDEwLjggNS4xIDE3LjEgMCAxNy4xLTEzLjkgMzEtMzEgMzEtNi4zIDAtMTIuMi0xLjktMTcuMS01LjEgNS42IDguNCAxNS4xIDEzLjkgMjUuOSAxMy45IDE3LjEgMCAzMS0xMy45IDMxLTMxIDAtMTAuOC01LjUtMjAuMy0xMy45LTI1Ljl6IiBvcGFjaXR5PSIuMDUiLz48L3N2Zz4="
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Squash
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/117.c06a79e.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        MMA
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/135.f111c33.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Gaelic Football
                      </span>
                    </div>
                  </button>
                </div>
                <div data-v-296bd5a2="" className="event column">
                  <button data-v-296bd5a2="" className="button">
                    <div
                      data-v-296bd5a2=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <img
                        alt=""
                        data-v-296bd5a2=""
                        src="https://assets.dashboard-yes.bet/img/136.272b296.svg"
                        className="sports-icon"
                      />
                    </div>
                    <div
                      data-v-296bd5a2=""
                      className="margin-top-5 desc-text row"
                      style={{ flexDirection: "row" }}
                    >
                      <span data-v-296bd5a2="" className="text">
                        Gaelic Hurling
                      </span>
                    </div>
                  </button>
                </div>
              </div>
              <div
                data-v-296bd5a2=""
                className="right row"
                style={{ flexDirection: "row" }}
              >
                <button data-v-296bd5a2="" className="button" />
              </div>
            </div>
            <div
              data-v-0e50b22a=""
              data-v-47fb79fe=""
              className="column"
              style={{ flexShrink: 0 }}
            >
              <div
                data-v-0e50b22a=""
                className="search row"
                style={{ flexDirection: "row" }}
              >
                <input
                  data-v-5b7f4dd8=""
                  data-v-0e50b22a=""
                  type="text"
                  placeholder="Please enter team name or league name."
                  inputMode="text"
                  className="input"
                  style={{ width: "100%", backgroundColor: "rgb(37, 46, 72)" }}
                />
                <button
                  data-v-0e50b22a=""
                  className="search-button button"
                  style={{
                    background: "rgb(37, 46, 72)",
                    width: 40,
                    height: 40,
                  }}
                >
                  <i
                    data-v-e56d064c=""
                    data-v-0e50b22a=""
                    className="fa-solid fa-magnifying-glass"
                  />
                </button>
                
              </div>
              <div
                data-v-0e50b22a=""
                className="settings row"
                style={{
                  height: 40,
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                <div
                  data-v-58b5c95e=""
                  data-v-0e50b22a=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    className="row"
                    style={{ width: "100%", flexDirection: "row" }}
                  >
                    <button
                      data-v-0e50b22a=""
                      className="select-tournament margin-right-10 button"
                      style={{ height: 35 }}
                    >
                      <span data-v-0e50b22a="" className="text">
                        <i
                          data-v-e56d064c=""
                          data-v-0e50b22a=""
                          className="margin-right-5 fa-regular fa-bookmark"
                        />
                        Select league
                      </span>
                    </button>
                  </div>
                  
                </div>
                <button
                  data-v-0e50b22a=""
                  className="sort-time margin-right-10 button text active"
                  style={{ background: "transparent" }}
                >
                  <span data-v-0e50b22a="" className="text">
                    <i
                      data-v-e56d064c=""
                      data-v-0e50b22a=""
                      className="margin-right-5 fa-light fa-arrow-down-short-wide"
                    />
                    Sort time
                  </span>
                </button>
                <button
                  data-v-0e50b22a=""
                  className="sort-league button text"
                  style={{ background: "transparent" }}
                >
                  <span data-v-0e50b22a="" className="text">
                    <i
                      data-v-e56d064c=""
                      data-v-0e50b22a=""
                      className="margin-right-5 fa-light fa-arrow-up-short-wide"
                    />
                    Sort league
                  </span>
                </button>
                <div data-v-0e50b22a="" className="spacer" />
                <button
                  data-v-0e50b22a=""
                  className="refresh margin-left-10 button"
                  style={{
                    background: "rgb(37, 46, 72)",
                    width: 40,
                    height: "100%",
                  }}
                >
                  <i
                    data-v-e56d064c=""
                    data-v-0e50b22a=""
                    className="fa-solid fa-arrows-rotate"
                  />
                </button>
              </div>
              <div
                data-v-0e50b22a=""
                className="viewSettingWrap row"
                style={{ height: 40, flexDirection: "row" }}
              >
                <button
                  data-v-0e50b22a=""
                  className="margin-right-10 button text active"
                  style={{ background: "transparent" }}
                >
                  <span data-v-0e50b22a="" className="text">
                    Modern View
                  </span>
                </button>
                <button
                  data-v-0e50b22a=""
                  className="button text"
                  style={{ background: "transparent" }}
                >
                  <span data-v-0e50b22a="" className="text">
                    Asian View
                  </span>
                </button>
                <div data-v-0e50b22a="" className="spacer" />
                <div
                  data-v-0e50b22a=""
                  dir="auto"
                  className="v-select vs--single vs--unsearchable"
                >
                  <div
                    id="vs2__combobox"
                    role="combobox"
                    aria-controls=""
                    aria-expanded="false"
                    aria-owns="vs2__listbox"
                    aria-label="Search for option"
                    className="vs__dropdown-toggle"
                  >
                    <div className="vs__selected-options">
                      <span className="vs__selected">
                        Winner
                        
                      </span>
                      <input
                        readOnly="readonly"
                        aria-autocomplete="list"
                        aria-labelledby="vs2__combobox"
                        aria-controls="vs2__listbox"
                        type="search"
                        autoComplete="off"
                        className="vs__search"
                      />
                    </div>
                    <div className="vs__actions">
                      <button
                        type="button"
                        title="Clear Selected"
                        aria-label="Clear Selected"
                        className="vs__clear"
                        style={{ display: "none" }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={10}
                          height={10}
                        >
                          <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                        </svg>
                      </button>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={14}
                        height={10}
                        role="presentation"
                        className="vs__open-indicator"
                      >
                        <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                      </svg>
                      <div className="vs__spinner" style={{ display: "none" }}>
                        Loading...
                      </div>
                    </div>
                  </div>
                  <ul
                    id="vs2__listbox"
                    role="listbox"
                    style={{ display: "none", visibility: "hidden" }}
                  />
                </div>
              </div>
            </div>
            <div data-v-47fb79fe="" className="prematch-list column modern">
              <div
                data-v-47fb79fe=""
                className="match-title row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="league row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-78fee962=""
                    data-v-47fb79fe=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/291.png"
                    />
                  </div>
                  <div
                    data-v-47fb79fe=""
                    className="league-name text-ellipsis row"
                    style={{ flexDirection: "row", display: "block" }}
                  >
                    K-League 1
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="desc-title row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="title-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Home Team
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Draw
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Away Team
                    </span>
                  </div>
                  
                  
                </div>
              </div>
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      16:30
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/7648.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Incheon United FC
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/7652.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Suwon Bluewings
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          2.25
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.10
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.20
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text active"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +85
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div
                data-v-47fb79fe=""
                className="match-title row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="league row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-78fee962=""
                    data-v-47fb79fe=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/21.png"
                    />
                  </div>
                  <div
                    data-v-47fb79fe=""
                    className="league-name text-ellipsis row"
                    style={{ flexDirection: "row", display: "block" }}
                  >
                    Youth League
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="desc-title row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="title-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Home Team
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Draw
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Away Team
                    </span>
                  </div>
                  
                  
                </div>
              </div>
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      17:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49731.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FK Spartak Moscow
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49725.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FK Rostov
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="odds-none row"
                      style={{ flexDirection: "row" }}
                    >
                      -
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +79
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      17:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/108405.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Ural Ekaterinburg
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/744835.png"
                          className="blank-away"
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Chertanovo Moscow
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="odds-none row"
                      style={{ flexDirection: "row" }}
                    >
                      -
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +79
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      18:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49730.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Samara Kryliya Sovetov
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49733.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FC Akhmat Grozny
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="odds-none row"
                      style={{ flexDirection: "row" }}
                    >
                      -
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +79
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      18:30
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49721.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        PFC CSKA 모스크바 (Youth)
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49724.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FC 크라스노다르 (Youth)
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          2.75
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.50
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          2.00
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +80
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div
                data-v-47fb79fe=""
                className="match-title row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="league row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-78fee962=""
                    data-v-47fb79fe=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/34.png"
                    />
                  </div>
                  <div
                    data-v-47fb79fe=""
                    className="league-name text-ellipsis row"
                    style={{ flexDirection: "row", display: "block" }}
                  >
                    A-League
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="desc-title row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="title-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Home Team
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Draw
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Away Team
                    </span>
                  </div>
                  
                  
                </div>
              </div>
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      18:45
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/2946.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Adelaide United FC
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/7568.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Wellington Phoenix FC
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          1.78
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          4.10
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.80
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +114
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div
                data-v-47fb79fe=""
                className="match-title row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="league row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-78fee962=""
                    data-v-47fb79fe=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/21.png"
                    />
                  </div>
                  <div
                    data-v-47fb79fe=""
                    className="league-name text-ellipsis row"
                    style={{ flexDirection: "row", display: "block" }}
                  >
                    Youth League
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="desc-title row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="title-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Home Team
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Draw
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Away Team
                    </span>
                  </div>
                  
                  
                </div>
              </div>
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      19:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/817928.png"
                          className="blank-home"
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FK Nizhny Novgorod
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/734599.png"
                          className="blank-away"
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FK Khimki
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          2.38
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.30
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          2.30
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +1
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      19:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/166144.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Torpedo Moscow
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/591317.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        PFK Sochi
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.05
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          3.25
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          1.95
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +80
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      19:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/744839.png"
                          className="blank-home"
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Strogino Moscow
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/49728.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        Lokomotiv Moscow
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          4.60
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          4.10
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          1.44
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +80
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div
                data-v-47fb79fe=""
                className="match-title row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="league row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-78fee962=""
                    data-v-47fb79fe=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/270.png"
                    />
                  </div>
                  <div
                    data-v-47fb79fe=""
                    className="league-name text-ellipsis row"
                    style={{ flexDirection: "row", display: "block" }}
                  >
                    Erovnuli Liga
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="desc-title row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="title-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Home Team
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Draw
                    </span>
                    <span data-v-47fb79fe="" className="text-level-11 text">
                      Away Team
                    </span>
                  </div>
                  
                  
                </div>
              </div>
              
              <div
                data-v-47fb79fe=""
                className="match row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-47fb79fe=""
                  className="match-info row"
                  style={{ flexDirection: "row" }}
                >
                  <div data-v-47fb79fe="" className="date column">
                    <div
                      data-v-47fb79fe=""
                      className="day row"
                      style={{ flexDirection: "row" }}
                    >
                      05/05
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="time row"
                      style={{ flexDirection: "row" }}
                    >
                      19:00
                    </div>
                  </div>
                  <div data-v-47fb79fe="" className="team column">
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/78961.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FC Shukura Kobuleti
                      </span>
                    </div>
                    <div
                      data-v-47fb79fe=""
                      className="row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-cc68f3fe=""
                        data-v-47fb79fe=""
                        className="team-icon row"
                        style={{ flexDirection: "row" }}
                      >
                        <img
                          alt=""
                          data-v-cc68f3fe=""
                          src="https://img.mt-sportradar.com/ls/crest/big/116312.png"
                          className=""
                          style={{ height: 14 }}
                        />
                      </div>
                      <span data-v-47fb79fe="" className="text">
                        FC Saburtalo Tbilisi
                      </span>
                    </div>
                  </div>
                </div>
                <div
                  data-v-47fb79fe=""
                  className="odds row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    data-v-47fb79fe=""
                    className="odds-1x2 row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          4.80
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          4.10
                        </span>
                      </button>
                    </div>
                    <div
                      data-v-6bf0219c=""
                      data-v-47fb79fe=""
                      className="outcome row"
                      style={{ flexDirection: "row" }}
                    >
                      <button data-v-6bf0219c="" className="button">
                        
                        
                        <span data-v-6bf0219c="" className="odd text">
                          
                          1.61
                        </span>
                      </button>
                    </div>
                  </div>
                  
                  
                  <div
                    data-v-47fb79fe=""
                    className="detail-wrap row"
                    style={{ flexDirection: "row" }}
                  >
                    <div
                      data-v-47fb79fe=""
                      className="detail row"
                      style={{ flexDirection: "row" }}
                    >
                      <button
                        data-v-47fb79fe=""
                        className="button text"
                        style={{ background: "transparent" }}
                      >
                        <span data-v-47fb79fe="" className="text">
                          +78
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div
              data-v-72e289f4=""
              data-v-47fb79fe=""
              className="pagination row"
              style={{ flexDirection: "row", alignItems: "center" }}
            >
              <div
                data-v-72e289f4=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-72e289f4=""
                  dir="auto"
                  className="v-select vs--single vs--unsearchable"
                  style={{ marginRight: 5 }}
                >
                  <div
                    id="vs3__combobox"
                    role="combobox"
                    aria-controls=""
                    aria-expanded="false"
                    aria-owns="vs3__listbox"
                    aria-label="Search for option"
                    className="vs__dropdown-toggle"
                  >
                    <div className="vs__selected-options">
                      <span className="vs__selected">
                        10
                        
                      </span>
                      <input
                        readOnly="readonly"
                        aria-autocomplete="list"
                        aria-labelledby="vs3__combobox"
                        aria-controls="vs3__listbox"
                        type="search"
                        autoComplete="off"
                        className="vs__search"
                      />
                    </div>
                    <div className="vs__actions">
                      <button
                        type="button"
                        title="Clear Selected"
                        aria-label="Clear Selected"
                        className="vs__clear"
                        style={{ display: "none" }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={10}
                          height={10}
                        >
                          <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                        </svg>
                      </button>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={14}
                        height={10}
                        role="presentation"
                        className="vs__open-indicator"
                      >
                        <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                      </svg>
                      <div className="vs__spinner" style={{ display: "none" }}>
                        Loading...
                      </div>
                    </div>
                  </div>
                  <ul
                    id="vs3__listbox"
                    role="listbox"
                    style={{ display: "none", visibility: "hidden" }}
                  />
                </div>
              </div>
              <div
                data-v-72e289f4=""
                className="row"
                style={{ flexDirection: "row", alignItems: "center" }}
              >
                <span
                  data-v-72e289f4=""
                  className="text"
                  style={{ opacity: "0.6" }}
                >
                  Show respectively
                </span>
              </div>
              <div data-v-72e289f4="" className="spacer" />
              <div
                data-v-72e289f4=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-72e289f4=""
                  dir="auto"
                  className="v-select vs--single vs--unsearchable"
                  style={{ marginRight: 5 }}
                >
                  <div
                    id="vs4__combobox"
                    role="combobox"
                    aria-controls=""
                    aria-expanded="false"
                    aria-owns="vs4__listbox"
                    aria-label="Search for option"
                    className="vs__dropdown-toggle"
                  >
                    <div className="vs__selected-options">
                      <span className="vs__selected">1</span>
                      <input
                        readOnly="readonly"
                        aria-autocomplete="list"
                        aria-labelledby="vs4__combobox"
                        aria-controls="vs4__listbox"
                        type="search"
                        autoComplete="off"
                        className="vs__search"
                      />
                    </div>
                    <div className="vs__actions">
                      <button
                        type="button"
                        title="Clear Selected"
                        aria-label="Clear Selected"
                        className="vs__clear"
                        style={{ display: "none" }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={10}
                          height={10}
                        >
                          <path d="M6.895455 5l2.842897-2.842898c.348864-.348863.348864-.914488 0-1.263636L9.106534.261648c-.348864-.348864-.914489-.348864-1.263636 0L5 3.104545 2.157102.261648c-.348863-.348864-.914488-.348864-1.263636 0L.261648.893466c-.348864.348864-.348864.914489 0 1.263636L3.104545 5 .261648 7.842898c-.348864.348863-.348864.914488 0 1.263636l.631818.631818c.348864.348864.914773.348864 1.263636 0L5 6.895455l2.842898 2.842897c.348863.348864.914772.348864 1.263636 0l.631818-.631818c.348864-.348864.348864-.914489 0-1.263636L6.895455 5z" />
                        </svg>
                      </button>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width={14}
                        height={10}
                        role="presentation"
                        className="vs__open-indicator"
                      >
                        <path d="M9.211364 7.59931l4.48338-4.867229c.407008-.441854.407008-1.158247 0-1.60046l-.73712-.80023c-.407008-.441854-1.066904-.441854-1.474243 0L7 5.198617 2.51662.33139c-.407008-.441853-1.066904-.441853-1.474243 0l-.737121.80023c-.407008.441854-.407008 1.158248 0 1.600461l4.48338 4.867228L7 10l2.211364-2.40069z" />
                      </svg>
                      <div className="vs__spinner" style={{ display: "none" }}>
                        Loading...
                      </div>
                    </div>
                  </div>
                  <ul
                    id="vs4__listbox"
                    role="listbox"
                    style={{ display: "none", visibility: "hidden" }}
                  />
                </div>
              </div>
              <div
                data-v-72e289f4=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <button
                  data-v-72e289f4=""
                  className="button icon"
                  disabled="disabled"
                  style={{ background: "rgb(37, 46, 72)" }}
                >
                  <i
                    data-v-e56d064c=""
                    data-v-72e289f4=""
                    className="fa-solid fa-chevron-left"
                  />
                </button>
              </div>
              <div
                data-v-72e289f4=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <button
                  data-v-72e289f4=""
                  className="button icon"
                  style={{ background: "rgb(37, 46, 72)" }}
                >
                  <i
                    data-v-e56d064c=""
                    data-v-72e289f4=""
                    className="fa-solid fa-chevron-right"
                  />
                </button>
              </div>
            </div>
          </div>
          <div
            data-v-4fd76316=""
            data-v-47fb79fe=""
            className="markets scrollable-auto column prematch-markets"
          >
            <div
              data-v-4fd76316=""
              className="header row"
              style={{ flexDirection: "row", height: 40, alignItems: "center" }}
            >
              
              <div
                data-v-4fd76316=""
                className="league-detail row"
                style={{ flexDirection: "row" }}
              >
                <span data-v-4fd76316="" className="event text">
                  <img
                    alt=""
                    data-v-4fd76316=""
                    src="https://assets.dashboard-yes.bet/img/1.e26e720.svg"
                    className="sports-icon margin-right-5"
                  />
                  Soccer
                </span>
                <span data-v-4fd76316="" className="dia text" />
                <span data-v-4fd76316="" className="league text">
                  <div
                    data-v-78fee962=""
                    data-v-4fd76316=""
                    className="tournament-icon row"
                    style={{ flexDirection: "row" }}
                  >
                    <img
                      alt=""
                      data-v-78fee962=""
                      src="https://mt-sportradar.com/assets/images/regions/291.png"
                    />
                  </div>
                  K-League 1
                </span>
              </div>
            </div>
            <div
              data-v-4fd76316=""
              className="match-detail row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4fd76316="" className="time margin-right-10 text">
                <i
                  data-v-e56d064c=""
                  data-v-4fd76316=""
                  className="margin-right-5 fa-regular fa-timer"
                />
                05/05 16:30
              </span>
              <div
                data-v-4fd76316=""
                className="team row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-cc68f3fe=""
                  data-v-4fd76316=""
                  className="team-icon row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-cc68f3fe=""
                    src="https://img.mt-sportradar.com/ls/crest/big/7648.png"
                    className=""
                    style={{ height: 16 }}
                  />
                </div>
                <span data-v-4fd76316="" className="text">
                  Incheon United FC
                </span>
              </div>
              <span
                data-v-4fd76316=""
                className="margin-horizontal-10 text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <div
                data-v-4fd76316=""
                className="team row"
                style={{ flexDirection: "row" }}
              >
                <div
                  data-v-cc68f3fe=""
                  data-v-4fd76316=""
                  className="team-icon row"
                  style={{ flexDirection: "row" }}
                >
                  <img
                    alt=""
                    data-v-cc68f3fe=""
                    src="https://img.mt-sportradar.com/ls/crest/big/7652.png"
                    className=""
                    style={{ height: 16 }}
                  />
                </div>
                <span data-v-4fd76316="" className="text">
                  Suwon Bluewings
                </span>
              </div>
            </div>
            <div
              data-v-4fd76316=""
              className="widget row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-50f6e118=""
                data-v-4fd76316=""
                className="iframe-view row"
                style={{ height: "193.875px", flexDirection: "row" }}
              >
                <iframe
                title="live"
                  data-v-50f6e118=""
                  src="https://mt-sportradar.com/headtohead/?matchId=38707051&lang=en&theme=yesbet"
                  scrolling="no"
                  style={{
                    transform: "scale(1.03125)",
                    transformOrigin: "0px 0px 0px",
                    width: 800,
                    height: 188,
                  }}
                />
              </div>
            </div>
            <div
              data-v-318c83ff=""
              data-v-4fd76316=""
              className="market-select-slider row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-05849275=""
                data-v-318c83ff=""
                className="list scrollable-auto slider row"
                style={{ flexDirection: "row" }}
              >
                <span data-v-318c83ff="" className="text active">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      
                      All
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Main
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Score
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      First-half
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Second-half
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Corner
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Card
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Special
                    </span>
                  </button>
                </span>
                <span data-v-318c83ff="" className="text">
                  <button
                    data-v-318c83ff=""
                    className="button text"
                    style={{ background: "transparent" }}
                  >
                    <span data-v-318c83ff="" className="text">
                      Etc.
                    </span>
                  </button>
                </span>
              </div>
            </div>
            <div
              data-v-4fd76316=""
              className="market-wrap row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4fd76316=""
                className="market-list row"
                style={{ flexDirection: "row" }}
              >
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1x2
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.25
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.20
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Handicap
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.58
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.25
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (-0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (+0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.60
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (-1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (+1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.26
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Handicap 1:0
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.33
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.61
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              11.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.18
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.36
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.85
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.61
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.15
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.15
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.61
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.29
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.25
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.38
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.52
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.13
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.44
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.60
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.32
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              7.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.06
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Both teams to score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.88
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.82
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Which team to score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              none
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              only Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              only Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              both teams
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.88
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st goal
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.86
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              none
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.30
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Last goal
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.86
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              none
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.30
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Exact goals
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.15
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              6+
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              23.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC exact goals
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.15
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3+
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.50
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings exact goals
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.45
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.30
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3+
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Highest scoring half
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1st half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.30
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2nd half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              equal
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.25
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.44
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.25
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.29
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC to score in both halves
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.70
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.24
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings to score in both halves
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.14
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Both halves over 1.5
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.08
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Both halves under 1.5
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.67
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC highest scoring half
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1st half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2nd half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              equal
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.38
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings highest scoring half
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1st half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2nd half
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.85
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              equal
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Odd/even
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              odd
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.92
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              even
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.78
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Incheon United FC odd/even
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              odd
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.98
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              even
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.75
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Suwon Bluewings odd/even
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              odd
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.05
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              even
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.67
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Correct score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              19.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              51.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              7.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              17.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              51.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              10.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              34.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              34.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              29.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3:3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              81.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4:3
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              3:4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              4:4
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              other
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Halftime/fulltime
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.75
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              16.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              7.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              34.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              16.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.80
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1x2 &amp; total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              7.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.85
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.33
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.80
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; under 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.70
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; over 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; under 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; over 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; under 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.70
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; over 3.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1x2 &amp; both teams to score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC &amp; no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw &amp; no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings &amp; no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      Halftime/fulltime &amp; total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/Incheon United FC &amp; under
                              2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/draw &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              26.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Incheon United FC &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/draw &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Suwon Bluewings &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              12.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/draw &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              26.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/Suwon Bluewings &amp; under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/Incheon United FC &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/draw &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC/Suwon Bluewings &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              51.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Incheon United FC &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              15.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/draw &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw/Suwon Bluewings &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              21.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/Incheon United FC &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              34.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/draw &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              51.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings/Suwon Bluewings &amp; over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              11.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - 1x2
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.05
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - handicap
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (+0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.24
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (-0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.70
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.64
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.15
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (-0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.85
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (+0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.36
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - handicap 1:0
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.24
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              17.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              11.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.38
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              41.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              9.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.05
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.48
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.50
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.65
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.15
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.32
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - Incheon United FC total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.65
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.09
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              12.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - Suwon Bluewings total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.45
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.48
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.05
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              12.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - both teams to score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.80
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.14
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - Incheon United FC clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.48
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.45
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - Suwon Bluewings clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.65
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - odd/even
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              odd
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              even
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.64
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      1st half - correct score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.50
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              101.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.10
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              29.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              21.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              34.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              other
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              23.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - 1x2
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.63
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.50
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - handicap
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (+0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.29
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (-0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.30
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.64
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.15
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (-0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.55
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (+0.5)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.46
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - handicap 1:0
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.30
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (1:0)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              12.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              26.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:2)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.08
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              8.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              draw (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.70
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings (0:1)
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.46
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.29
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.40
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.54
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.30
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.30
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.54
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - Incheon United FC total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.76
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.95
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.15
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              10.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.01
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - Suwon Bluewings total
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.05
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 0.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.68
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              6.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 1.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.09
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div data-v-6ad470db="" className="market column">
                    
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              over 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              12.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              under 2.5
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.01
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - both teams to score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.24
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - Incheon United FC clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.68
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.05
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - Suwon Bluewings clean sheet
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              yes
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.95
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              no
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.76
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - odd/even
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              odd
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.96
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-2 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              even
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              1.75
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - 1st goal
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Incheon United FC
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.25
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              none
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.60
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-3 row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              Suwon Bluewings
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              2.80
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-6ad470db="" data-v-4fd76316="" className="column">
                  <div data-v-6ad470db="" className="market column">
                    <div
                      data-v-6ad470db=""
                      className="market-title row"
                      style={{ flexDirection: "row" }}
                    >
                      2nd half - correct score
                    </div>
                    <div
                      data-v-6ad470db=""
                      className="outcomes row"
                      style={{ flexDirection: "row" }}
                    >
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              3.40
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              5.20
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              0:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              17.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              4.33
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              7.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              1:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              23.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:0
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              11.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:1
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              19.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              2:2
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              67.00
                            </span>
                          </button>
                        </div>
                      </div>
                      <div
                        data-v-6ad470db=""
                        className="odds-other row"
                        style={{ flexDirection: "row" }}
                      >
                        <div
                          data-v-6bf0219c=""
                          data-v-6ad470db=""
                          className="outcome row"
                          style={{ flexDirection: "row" }}
                        >
                          <button data-v-6bf0219c="" className="button">
                            <span data-v-6bf0219c="" className="name text">
                              other
                            </span>
                            <div data-v-6bf0219c="" className="spacer" />
                            
                            <span data-v-6bf0219c="" className="odd text">
                              
                              13.00
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Test;
