var a5_0x17320c = a5_0x31ca;
function a5_0xb00d() {
  var _0x48940c = [
    "toString",
    "marginTop",
    "stop",
    "getTime",
    "255,\x2070,\x2040",
    "pre_rownum",
    "hex5",
    "#FF013E",
    "amounts",
    "yellow",
    "#a81a00",
    "changeAutocount",
    "then",
    "table100",
    "stopAutoBet",
    "#a94700",
    "audioCtx",
    "innerHTML",
    "stopLoss",
    "margin-right-0",
    ".game-content{flex-direction:column;overflow:hidden;position:relative;flex-grow:2;flex-shrink:0}.gradient-overlay.svelte-1kij38k{z-index:2;position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(90deg,var(--grey-900),transparent,var(--grey-900))}.wrap.svelte-1fpkf13{position:relative;top:1em;right:1em;display:flex}.wrap.svelte-1fpkf13>*+*{margin-left:var(--spacing-0-25)}@keyframes\x20svelte-1fpkf13-slideOdd{0%{transform:translate(100%)}}@keyframes\x20svelte-1fpkf13-slideEven{0%{transform:translate(100%)}}@keyframes\x20svelte-1fpkf13-slideOut{0%{transform:translate(100%)}to{transform:translate(0);opacity:0;pointer-events:none}}.past-bets.svelte-1fpkf13{width:100%;display:flex;flex-direction:row-reverse}.past-bets.svelte-1fpkf13>:nth-child(odd){animation-name:svelte-1fpkf13-slideOdd}.past-bets.svelte-1fpkf13>:nth-child(2n){animation-name:svelte-1fpkf13-slideEven}.past-bets.full.svelte-1fpkf13>:last-child{animation-name:svelte-1fpkf13-slideOut}.past-bets.svelte-1fpkf13>*{min-width:8ch;font-feature-settings:\x22tnum\x22;font-variant-numeric:tabular-nums;will-change:transform;animation-fill-mode:forwards;animation-duration:.5s;animation-timing-function:ease-out}.past-bets.svelte-1fpkf13>*+*{margin-right:var(--spacing-0-25)}button.variant-success.svelte-oho9kj{color:var(--variant-success-color);background:var(--variant-success-background)}.wrap.svelte-1kij38k{z-index:1;display:flex;justify-content:space-between;align-items:center;flex-direction:column;flex-grow:1;width:100%}.others-wrap.svelte-1kij38k{z-index:3;width:100%}.wrap.svelte-1ybg266{position:absolute;bottom:calc(10px\x20+\x201rem);left:1rem;display:flex;align-items:center}.indicator.online.svelte-12bg4or{background:#00e449}.indicator.svelte-12bg4or:not(.online){background:#f10260}.indicator.svelte-12bg4or{display:inline-block;width:.5em;height:.5em;border-radius:.25em}.wrap.svelte-1ybg266>*+*{margin-left:var(--spacing-0-5)}.wrap.svelte-nc3u35.svelte-nc3u35:not(.mobile-view){text-align:center}.wrap.svelte-nc3u35.svelte-nc3u35{width:100%;position:relative;font-weight:600;display:grid;grid-gap:var(--spacingEm-1);font-size:var(--font-size-base)}.wrap.svelte-nc3u35.svelte-nc3u35:before{content:\x22\x22;position:absolute;height:10px;left:0;bottom:0;right:0;background:var(--grey-400)}.wrap.svelte-nc3u35\x20span.svelte-nc3u35{margin-right:var(--spacing-1)}.progress-bar.svelte-nc3u35.svelte-nc3u35{height:10px;transition:.1s;background:var(--blue-400);transition-timing-function:linear;z-index:100;width:0}.center-wrap.svelte-om7jij{width:100%;height:100%;display:flex;align-items:center;justify-content:center;position:relative;flex:1}.pointer.svelte-1ovq9jb{position:absolute;bottom:50%;left:50%;width:var(--spacing-1-5)}.centered-infinite-width.svelte-om7jij{position:absolute;display:flex;left:0}.infinite-width-wrap.svelte-om7jij{position:relative;display:flex;justify-content:space-between;will-change:transform}.roll.svelte-8g0vkn.svelte-8g0vkn{position:relative;font-size:var(--font-size-xl);color:--grey-100}.roll.is-winner.with-font-color.svelte-8g0vkn\x20.multiplier.svelte-8g0vkn>span{color:var(--roll-font-color);font-feature-settings:normal;font-variant-numeric:normal}.infinite-width-wrap.svelte-om7jij>*+*{margin-left:var(--space-between)}.roll.svelte-8g0vkn.svelte-8g0vkn:before{content:\x22\x22;position:absolute;z-index:1;top:0;left:0;border-radius:var(--border-radius-0-25);transition:box-shadow\x20.2s,background\x20.2s,transform\x20.2s;width:100%;height:100%;box-shadow:var(--shadows-md);background:var(--grey-500)}.multiplier.svelte-8g0vkn.svelte-8g0vkn{z-index:4;position:absolute;top:30%;left:50%;transform:translate(calc(-50%\x20+\x20.15ch),-50%)}.multiplier.svelte-8g0vkn>span{color:var(--variant-subtle-color);line-height:1.5;text-align:left;justify-content:flex-start;font-weight:400;font-feature-settings:\x22tnum\x22;font-variant-numeric:tabular-nums;font-size:var(--scale)!important}.payout.svelte-8g0vkn.svelte-8g0vkn{display:block;z-index:2;position:absolute;bottom:-1%;left:0;width:100%;height:auto;-webkit-user-select:none;-moz-user-select:none;user-select:none}.roll.is-winner.svelte-8g0vkn.svelte-8g0vkn:before{transition-delay:.3s;box-shadow:0\x200\x200\x203px\x20var(--roll-font-color)}.sprite-wrap.svelte-8g0vkn.svelte-8g0vkn{position:absolute;z-index:3;width:100%;height:100%}.hexagon.svelte-8g0vkn.svelte-8g0vkn{position:absolute;top:30%;left:50%;width:100%;transform:translate(-50%,-50%);pointer-events:none}.sprite-wrap.svelte-8g0vkn\x20canvas{width:100%}.sprite-sheet.svelte-13vrxb2{pointer-events:none}",
    "betslip-form",
    "v-show",
    "imgHex10",
    "#00E701",
    "fillStyle",
    "floor",
    "gamestate_label",
    "255,\x20137,\x2018",
    "255,\x2072,\x2039",
    "center-wrap\x20svelte-om7jij",
    "sliding",
    "plinko",
    "beginPath",
    "success",
    "isControl",
    "default",
    "sent",
    "SlideRepository",
    "transition",
    "#aa6300",
    "971350mWlmRs",
    "history-title",
    "#a94400",
    "isAutobet",
    "false",
    "eec6fecc",
    "570",
    "offsetx",
    "selectBetcount",
    "getSplitdisabled",
    "255,\x20154,\x2013",
    "hidden",
    "target_numbers",
    "toLocaleString",
    "risk",
    "ceil",
    "hit",
    "255,\x20115,\x2025",
    "currentTime",
    "setNumbers",
    "online",
    "hex100",
    "betContainer",
    "remove",
    "multiplier",
    "getfcolor",
    "radiusinfo",
    "angle",
    "#a93000",
    "#aa5b00",
    "lastChild",
    "last_page",
    "container",
    "betloading",
    "hexcanvas",
    "500ms",
    "payout5",
    "x.mp3",
    "title",
    "hex1000",
    "appendChild",
    "0.1s",
    "autoschedule",
    "Bet",
    "370px",
    "split",
    "830808myhICe",
    "255,\x2038,\x2050",
    "setBetdisabled",
    "webkitAudioContext",
    "drawfade",
    "Start\x20Autobet",
    "style",
    "connect",
    "$nextTick",
    "activeManual",
    "getMultiplier",
    "data",
    "decodeAudioData",
    "getCollistionPinByRow",
    "wrap\x20svelte-nc3u35",
    "createBufferSource",
    "#ab6b00",
    "255,\x2027,\x2054",
    "winsize",
    "plinko.balance",
    "down",
    "removeChild",
    "cash-updown",
    "Next\x20round\x20in:\x20",
    "__esModule",
    "#017BFF",
    "last-bet-wrap\x20svelte-1a90w5o",
    "catch",
    "wrap",
    "setPayoutHighligted",
    "history-wrap",
    "defineProperty",
    "animation_stop",
    "games",
    "radius",
    "content",
    "setResultboard",
    "getSetdisabled",
    "fa-regular\x20fa-eraser",
    "playBetSound",
    "370440JfUABx",
    "span",
    "locals",
    "$auth",
    "d0255fba",
    "setAutodisabled",
    "created_at",
    "#FF9D00",
    "VPlayCanvas",
    "schedule",
    "pin_points",
    "100",
    "selectrisk",
    "step",
    "width",
    "result",
    "orange",
    "setdisabled",
    "#aa4f00",
    "#FF9400",
    "255,\x20175,\x206",
    "getTimestamp",
    "payout0",
    "name",
    "insurance-btn",
    "user",
    "height",
    "onresize",
    "#3ed54a",
    "full",
    "255,\x2051,\x2046",
    "next",
    "255,\x20168,\x208",
    "#a80100",
    "autostop",
    "bet-select-btn",
    "$swal2",
    "255,\x20171,\x207",
    "pinSpacing",
    "margin-bottom-10",
    "activeAuto",
    "scale",
    "VDialogHistory",
    "setAttribute",
    "gamecontent",
    "barstat",
    "parentElement",
    "log",
    "hexagon",
    "setBet",
    "255,\x20128,\x2021",
    "d7949120",
    "content-or-loader\x20svelte-1uofbko",
    "plinko.history",
    "target_multiplier",
    "#aa6000",
    "src",
    "255,\x2077,\x2038",
    "imgHex0",
    "username",
    "betcount",
    "variant-game\x20lineHeight-base\x20size-medium\x20spacing-normal\x20weight-semibold\x20align-center\x20svelte-oho9kj",
    "arc",
    "255,\x2048,\x2047",
    "payout_sd",
    "thead",
    "getGamestate",
    "v-text",
    "1074da9e",
    "settingForm.amounts",
    ");\x20--bg-hover-color:",
    "changePayout",
    "getOwnPropertySymbols",
    "<button\x20data-v-0e0d2184\x20data-last-bet-index=\x221\x22\x20class=\x22svelte-1b5z8o7\x22\x20style=\x22--bg-color:rgb(",
    "length",
    "Cancel",
    "isAutobetFinsihing",
    "_self",
    "update",
    "payout2",
    "red",
    "insertBefore",
    "v-dialog-history",
    "play",
    "payout100",
    "table1000",
    "progressReady",
    "startAutoBet",
    "amount-input",
    "255,\x2096,\x2032",
    "plinko.rows",
    "prev",
    "auto",
    "toRadian",
    "getContext",
    "amount",
    "notAcceptInsurance",
    "loop",
    "canvas_values",
    "winmoney",
    "defineProperties",
    "profit",
    "255,\x2055,\x2045",
    "children",
    "pin",
    "600px",
    "destination",
    "selectRows",
    "MM/DD\x20HH:mm",
    "setPage",
    "playHexSound",
    "forEach",
    "show",
    "getUmultiplier",
    "elapsedTime",
    "clearPayoutHighlighted",
    "255,\x200,\x2063",
    "apply",
    "autobetcount",
    "addEventListener",
    "sqrt",
    "charCodeAt",
    "fillText",
    "isDisabled",
    "ball",
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "255,\x20144,\x2016",
    "order",
    "clear",
    "getLeaderboard",
    "readyProgress",
    "IsInsurance",
    "svelte-gjzs56",
    "wrap\x20svelte-1rv2cnq",
    "slidegame",
    "stopProfit",
    "255,\x20102,\x2029",
    "getNextbet",
    "getBet",
    "attachEvent",
    "plinko_ratios",
    "255,\x20109,\x2029",
    "imgPayouts",
    "start0",
    "pointer\x20svelte-1ovq9jb",
    "betlist",
    "255,\x20192,\x200",
    "스탠드",
    "bet_label",
    "stand",
    "#a70000",
    "row",
    "113872VErAqX",
    "add",
    "#a82200",
    "atan2",
    "restore",
    "setGamestate",
    "imgHex",
    "#a81300",
    "last-bet-content\x20svelte-1a90w5o",
    "pastBets",
    "bet",
    "selectrow",
    "drawFrames",
    "v-input",
    "canvasrectinfo",
    "offset_dist",
    "VBetslipCard",
    "collisionTime",
    "Cancel\x20(Next\x20Round)",
    "string",
    "checkBallFloor",
    "offset_ratio",
    "autocount",
    "scorebox",
    "svelte-nc3u35",
    "betend",
    "is-winner",
    "255,\x20165,\x209",
    "autoCount",
    "cash",
    "#ab6d00",
    "#icon-icon-casino_icon-stake-game-slide",
    "plinko.numberOfBets",
    "#ff7171",
    "isBetting",
    "autobet_label",
    "get_ratios",
    "shownum",
    "buffer",
    "plinko.betDate",
    ";\x22><span\x20data-v-0e0d2184\x20class=\x22content\x20svelte-198g0pr\x22>",
    "setLeaderboard",
    "$emit",
    "imgHexs",
    "#50E3C2",
    "slidetime",
    "fillRect",
    "payout1000",
    "num",
    "setSetdisabled",
    "255,\x2030,\x2053",
    "button",
    "getState",
    "plinko.betAmount",
    "requestAnimationFrame",
    "footer-content\x20svelte-f1h4ry",
    "footer\x20svelte-f1h4ry",
    "indicator\x20svelte-12bg4or",
    "255,\x2059,\x2044",
    "pending",
    "보유금액",
    "min-height",
    "rgba(255,\x20255,\x20255,\x20",
    "fontSize",
    "expect-amount",
    "startBet",
    "filter",
    "drawImage",
    "target",
    "인슈어런스",
    "setBetloading",
    "getOwnPropertyDescriptors",
    "setTimestamp",
    "history",
    "date",
    "255,\x20160,\x2011",
    "removeProperty",
    "money",
    "pin_collision_time",
    "leaderboard",
    "webpackJsonp",
    "fa-regular\x20fa-cards-blank",
    "black",
    "div",
    "table10",
    "drawball",
    "submit",
    "selectRisk",
    "setProperty",
    "getElementById",
    "hex0",
    "sizeMonitor",
    "getAttribute",
    "table0",
    "$refs",
    "85%",
    "progress-bar\x20svelte-nc3u35",
    "#aa5500",
    "#ab7900",
    "317313skshnm",
    "ballcolorinfo",
    "isCollision",
    "\x20);\x20--shadow-color:\x20",
    "-webkit-transition",
    "eplasedtime_label",
    "finish",
    "255,\x20117,\x205",
    "베팅하기",
    "fetch",
    "v-pagination",
    "255,\x20148,\x2015",
    "plinko.risk",
    "</span></div>",
    "activator",
    "255,\x2043,\x2049",
    "Bet\x20(Next\x20Round)",
    "255,\x2085,\x2035",
    "highlighted",
    "margin-right-5",
    "clearRect",
    "Autobet\x20started",
    "gamepad_width",
    "imgHex2",
    "fa-regular\x20fa-minus",
    "rows",
    "table",
    "img",
    "now",
    "font",
    "#aa4b00",
    "start",
    "255,\x20120,\x2024",
    "wrap\x20svelte-1ybg266",
    "7eYHtOU",
    "hex10",
    "dark-background\x20svelte-17becnl\x20plinko-game",
    "off",
    "cur_page",
    "#202940",
    "shadow",
    "#FF6F03",
    "#ab6900",
    "starting",
    "resetAutoBet",
    "ctx",
    "rgb(252,",
    "numbers",
    "66a2c4c0",
    "0.562604em",
    "#a60000",
    "middleX",
    "베팅금액을\x20입력하세요",
    "setGameid",
    "playbackRate",
    "setUmultiplier",
    "prevstate",
    "tabs",
    "canvas",
    "payoutContainer",
    "myCanvas",
    "#a82a00",
    "1125780rqdSAc",
    "plinko.riskEnum",
    "exports",
    "payout10",
    "$moment",
    "balance",
    "#ffe588",
    "playPayoutSound",
    "nextleaderboard",
    "#a82e00",
    "255,\x2032,\x2053",
    "ctx_scale",
    "per_page",
    "hexIndex",
    "slide",
    "svg",
    "count",
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "history-btn",
    "PlinkoRepository",
    "gamepane",
    "slide\x20resize",
    "clientWidth",
    "desc\x20svelte-ithfqn",
    "slideEnd",
    "others-wrap\x20svelte-1kij38k",
    "autodisabled",
    "table5",
    "wrap\x20svelte-1fpkf13",
    "cancel_label",
    "table2",
    "v-select",
    "v-column",
    "double",
    "Bets:",
    "colliedy",
    "$error",
    "offline",
    "$set",
    "resize",
    "<div\x20data-v-0e0d2184\x20class=\x22payout\x20svelte-198g0pr\x22\x20style=\x22background:\x20rgb(",
    "#a93a00",
    "255,\x20110,\x2027",
    "getBetdisabled",
    "4398de0f",
    "timestamp",
    "quickAmount",
    "slideStart",
    "collision",
    "playSlidingSound",
    "rownum",
    "drawpin",
    "0\x20!important",
    "wrap\x20svelte-1kij38k",
    "10px",
    "setNextbet",
    "$loading",
    "expect_amount",
    "getResultboard",
    "#a60004",
    "255,\x2089,\x2034",
    "SlidePlayPanel",
    "toggleForm",
    "Finishing\x20Bet",
    "progresstime",
    "keys",
    "fill",
    "settingForm",
    "gamepad",
    "255,\x2082,\x2036",
    "content\x20svelte-1a5knjc",
    "fa-solid\x20fa-table-columns",
    "v-row",
    "payout_bg",
    "loss",
    "blackjack-betslip",
    "fontColors",
    "push",
    "main",
    "1000",
    "255,\x2024,\x2055",
    "settingForm.rows",
    "#ab6500",
    "progress_stop",
    "255,\x2035,\x2052",
    "255,\x209,\x2063",
    "reorderBetlist",
    "SlideSettingPanel",
    "payout_widths",
    "addBetItem",
    "init",
    "plinko.win",
    "end",
    "#ff9d00",
    "282816HEFAGz",
    "resetBet",
    "imgHex100",
    "calcCanv",
    "v-dialog",
    "gamestate",
    "#fff",
    ".plinko-game{flex-grow:2}.plinko-game\x20.game-content.svelte-1wfq6vq{width:100%;display:flex;flex-direction:column;justify-content:center;flex-grow:1;-webkit-user-select:none;-moz-user-select:none;user-select:none;position:relative;overflow:hidden;margin:0\x20auto;border-top-right-radius:var(--game-frame-radius)}.plinko-game\x20.content.svelte-1a5knjc{width:100%;position:relative}.plinko-game\x20.content.svelte-1a5knjc:before{content:\x22\x22;display:block;padding-top:75%}.plinko-game\x20.wrap.svelte-1rv2cnq{flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center;width:100%;max-width:750px;margin:auto;padding:0\x201em\x201em}.plinko-game\x20.wrap.wide.svelte-1rv2cnq{max-width:100vh}.plinko-game\x20canvas.svelte-gjzs56{width:100%;height:100%}.plinko-game\x20.footer.svelte-f1h4ry{height:1.8em;width:100%;display:flex;justify-content:center}.plinko-game\x20.footer-content.svelte-f1h4ry{display:grid;grid-gap:1%;height:100%;position:relative}.plinko-game\x20.footer-content.svelte-f1h4ry>*{grid-row:1}.plinko-game\x20.payout.svelte-198g0pr{position:relative;cursor:help;border-radius:.3em;text-align:center;animation-duration:.3s!important;animation-timing-function:cubic-bezier(.18,.89,.32,1.28);box-shadow:0\x20.2em\x200\x200\x20var(--shadow-color)}.plinko-game\x20.payout.highlighted.svelte-198g0pr{animation-name:svelte-198g0pr-slideDown}.plinko-game\x20.content.svelte-198g0pr{position:absolute;top:0;left:0;bottom:0;right:0;display:flex;align-items:center;justify-content:center;font-weight:700;color:rgba(0,0,0,.8);font-size:.75em}@keyframes\x20svelte-198g0pr-slideDown{0%,to{transform:translate(0)}50%{transform:translateY(30%)}}.plinko-game\x20button.svelte-1b5z8o7{display:inline-flex;align-items:center;justify-content:center;width:3.2em;height:3.2em;transition-property:background-color;transition-duration:.2\x20s;background-color:var(--bg-color);flex-shrink:0;color:rgba(0,0,0,.8);font-weight:700}.plinko-game\x20button.svelte-1b5z8o7:hover{background-color:var(--bg-hover-color)}@keyframes\x20svelte-1a90w5o-slideDownFadeIn{0%{opacity:0;transform:translateY(-100%)}}@keyframes\x20svelte-1a90w5o-slideDownOdd{0%{transform:translateY(-100%)}}@keyframes\x20svelte-1a90w5o-slideDownEven{0%{transform:translateY(-100%)}}.plinko-game\x20.last-bet-wrap.svelte-1a90w5o{grid-area:LastBets;display:flex;flex-direction:column;align-items:center;justify-content:center;position:absolute;right:5%;top:50%;transform:translateY(-50%)}.plinko-game\x20.last-bet-content.svelte-1a90w5o{display:flex;flex-direction:column;align-items:center;width:3.2em;height:12.8em;overflow:hidden;border-radius:.7em}.plinko-game\x20.last-bet-content.svelte-1a90w5o>*{animation-fill-mode:forwards;animation-duration:var(--duration);animation-timing-function:ease-out}.plinko-game\x20.last-bet-content.svelte-1a90w5o>:nth-child(2n){animation-name:svelte-1a90w5o-slideDownEven}.plinko-game\x20.last-bet-content.svelte-1a90w5o>:nth-child(odd){animation-name:svelte-1a90w5o-slideDownOdd}.plinko-game\x20.last-bet-content.svelte-1a90w5o>:first-child{animation-name:svelte-1a90w5o-slideDownFadeIn}",
    "value",
    "canv",
    "gradient-overlay\x20svelte-1kij38k",
    "sin",
    "calcball",
    "mark",
    "$nuxt",
    "enumerable",
    "255,\x2064,\x2042",
    "100%",
    "ready",
    "checkCollision",
    "imgHex5",
    "$repositories",
    "tbody",
    "dwn",
    "v-button",
    "lastPage",
    "getOwnPropertyDescriptor",
    "gameservice_stop",
    "format",
    "changedAmount",
    "loggedIn",
    "v-icon",
    "Starting...",
    "classList",
    "</button>",
    "pi2",
    "#AB1344",
    "imgSelectedHex",
    ".plinko-betslip\x20.content[data-v-24e3e3fa]{width:100%}.plinko-betslip\x20.content\x20.history-btn[data-v-24e3e3fa]{margin-bottom:10px;justify-content:flex-end;padding:0\x2010px;transition:.2s\x20ease}.plinko-betslip\x20.content\x20.history-btn\x20button[data-v-24e3e3fa]{opacity:.6}@media(hover:hover){.plinko-betslip\x20.content\x20.history-btn\x20button[data-v-24e3e3fa]:hover{opacity:1}.plinko-betslip\x20.content\x20.history-btn\x20button:hover\x20span[data-v-24e3e3fa]{color:#ffe588}}.plinko-betslip\x20.content\x20.tabs[data-v-24e3e3fa]{width:100%;height:45px;background-color:#2b3654;padding:5px;border-radius:3rem;margin-bottom:10px;flex-shrink:0}.plinko-betslip\x20.content\x20.tabs>button[data-v-24e3e3fa]{width:50%;height:35px;background-color:unset;border-radius:100px}@media(hover:hover){.plinko-betslip\x20.content\x20.tabs>button[data-v-24e3e3fa]:hover{background-color:#313e60}}.plinko-betslip\x20.content\x20.tabs>button.active[data-v-24e3e3fa]{background-color:#313e60}.plinko-betslip\x20.content\x20.betslip-form\x20.amount>div[data-v-24e3e3fa]{margin-bottom:10px;flex-shrink:0}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20button[data-v-24e3e3fa]{flex-shrink:0;background-color:#313e60}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.cash-updown[data-v-24e3e3fa]{border-right:1px\x20solid\x20#252e48}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.input[data-v-24e3e3fa]{transition:.2s\x20ease;width:100%;background-color:#313e60;text-align:right;border-right:1px\x20solid\x20#252e48;border-left:1px\x20solid\x20#445174}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.amount-init[data-v-24e3e3fa]{border-left:1px\x20solid\x20#445174}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance[data-v-24e3e3fa]{height:40px}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance>div[data-v-24e3e3fa]{height:100%;align-items:center;justify-content:center}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.title[data-v-24e3e3fa]{width:40%;background-color:#313e60}.plinko-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.count[data-v-24e3e3fa]{width:60%;background-color:#2b3654}.plinko-betslip\x20.content\x20.betslip-form\x20.risk>div[data-v-24e3e3fa],.plinko-betslip\x20.content\x20.betslip-form\x20.rows>div[data-v-24e3e3fa]{margin-bottom:10px;flex-shrink:0}.plinko-betslip\x20.content\x20.betslip-form\x20.risk[data-v-24e3e3fa]\x20.v-select,.plinko-betslip\x20.content\x20.betslip-form\x20.rows[data-v-24e3e3fa]\x20.v-select{width:100%}.plinko-betslip\x20.content\x20.betslip-form\x20.risk[data-v-24e3e3fa]\x20.v-select.vs--disabled,.plinko-betslip\x20.content\x20.betslip-form\x20.rows[data-v-24e3e3fa]\x20.v-select.vs--disabled{opacity:.4}.plinko-betslip\x20.content\x20.betslip-form\x20.risk[data-v-24e3e3fa]\x20.v-select.vs--disabled\x20.vs__dropdown-toggle,.plinko-betslip\x20.content\x20.betslip-form\x20.rows[data-v-24e3e3fa]\x20.v-select.vs--disabled\x20.vs__dropdown-toggle{cursor:not-allowed!important}.plinko-betslip\x20.content\x20.betslip-form\x20.risk[data-v-24e3e3fa]\x20.v-select\x20.vs__open-indicator,.plinko-betslip\x20.content\x20.betslip-form\x20.rows[data-v-24e3e3fa]\x20.v-select\x20.vs__open-indicator{background-color:unset!important}.plinko-betslip\x20.content\x20.betslip-form\x20.risk[data-v-24e3e3fa]\x20.v-select\x20.vs__dropdown-toggle,.plinko-betslip\x20.content\x20.betslip-form\x20.rows[data-v-24e3e3fa]\x20.v-select\x20.vs__dropdown-toggle{width:100%;background-color:#313e60}.plinko-betslip\x20.content\x20.betslip-form\x20.betcount>div[data-v-24e3e3fa]{margin-bottom:10px;flex-shrink:0}.plinko-betslip\x20.content\x20.betslip-form\x20.betcount>div\x20.input[data-v-24e3e3fa]{width:100%;background-color:#313e60;text-align:right}.plinko-betslip\x20.content\x20.betslip-form\x20.submit[data-v-24e3e3fa]{flex-shrink:0}.plinko-betslip\x20.content\x20.betslip-form\x20.submit\x20button[data-v-24e3e3fa]{background-color:#ffe588;height:40px}.plinko-betslip\x20.content\x20.betslip-form\x20.submit\x20button>span[data-v-24e3e3fa]{color:#000}@media(hover:hover){.plinko-betslip\x20.content\x20.betslip-form\x20.submit\x20button[data-v-24e3e3fa]:hover{background-color:#ffdc60}}",
    "fa-regular\x20fa-plus",
  ];
  a5_0xb00d = function () {
    return _0x48940c;
  };
  return a5_0xb00d();
}
function a5_0x31ca(_0x25a532, _0x3e5c74) {
  var _0xb00da7 = a5_0xb00d();
  return (
    (a5_0x31ca = function (_0x31ca42, _0x1a7484) {
      _0x31ca42 = _0x31ca42 - 0x1b4;
      var _0x46bdb6 = _0xb00da7[_0x31ca42];
      return _0x46bdb6;
    }),
    a5_0x31ca(_0x25a532, _0x3e5c74)
  );
}
(function (_0x129b5e, _0x5260e0) {
  var _0x593644 = a5_0x31ca,
    _0x65424 = _0x129b5e();
  while (!![]) {
    try {
      var _0x544693 =
        -parseInt(_0x593644(0x3e5)) / 0x1 +
        parseInt(_0x593644(0x2a6)) / 0x2 +
        parseInt(_0x593644(0x20a)) / 0x3 +
        parseInt(_0x593644(0x34d)) / 0x4 +
        -parseInt(_0x593644(0x2f7)) / 0x5 +
        (parseInt(_0x593644(0x248)) / 0x6) *
          (parseInt(_0x593644(0x22c)) / 0x7) +
        -parseInt(_0x593644(0x325)) / 0x8;
      if (_0x544693 === _0x5260e0) break;
      else _0x65424["push"](_0x65424["shift"]());
    } catch (_0x18d830) {
      _0x65424["push"](_0x65424["shift"]());
    }
  }
})(a5_0xb00d, 0x1c2e2),
  (window[a5_0x17320c(0x1f7)] = window[a5_0x17320c(0x1f7)] || [])[
    a5_0x17320c(0x295)
  ]([
    [0x5],
    {
      0x400: function (_0x5cbc8c, _0x51e8e8, _0x58d66d) {
        "use strict";
        _0x58d66d(0x179);
      },
      0x401: function (_0x3f5df0, _0x45112a, _0x55e594) {
        var _0xd4ee10 = a5_0x17320c,
          _0x245601 = _0x55e594(0x4)(!0x1);
        _0x245601[_0xd4ee10(0x295)]([_0x3f5df0["i"], _0xd4ee10(0x2e2), ""]),
          (_0x3f5df0["exports"] = _0x245601);
      },
      0x167: function (_0x50e143, _0x3a8c49, _0x48e31a) {
        var _0x4871a0 = a5_0x17320c,
          _0x2611b9 = _0x48e31a(0x3c4);
        _0x2611b9[_0x4871a0(0x33d)] &&
          (_0x2611b9 = _0x2611b9[_0x4871a0(0x2f2)]),
          _0x4871a0(0x1ba) == typeof _0x2611b9 &&
            (_0x2611b9 = [[_0x50e143["i"], _0x2611b9, ""]]),
          _0x2611b9[_0x4871a0(0x34f)] &&
            (_0x50e143[_0x4871a0(0x24a)] = _0x2611b9["locals"]),
          (0x0, _0x48e31a(0x5)[_0x4871a0(0x2f2)])(
            _0x4871a0(0x2fc),
            _0x2611b9,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x168: function (_0x1fe6f4, _0x2f9929, _0x401810) {
        var _0x28bce8 = a5_0x17320c,
          _0x2135d6 = _0x401810(0x3c6);
        _0x2135d6["__esModule"] && (_0x2135d6 = _0x2135d6[_0x28bce8(0x2f2)]),
          _0x28bce8(0x1ba) == typeof _0x2135d6 &&
            (_0x2135d6 = [[_0x1fe6f4["i"], _0x2135d6, ""]]),
          _0x2135d6[_0x28bce8(0x34f)] &&
            (_0x1fe6f4[_0x28bce8(0x24a)] = _0x2135d6[_0x28bce8(0x34f)]),
          (0x0, _0x401810(0x5)["default"])(_0x28bce8(0x380), _0x2135d6, !0x0, {
            sourceMap: !0x1,
          });
      },
      0x172: function (_0x6207b7, _0x21615d, _0x19a19d) {
        var _0x2c2a87 = a5_0x17320c,
          _0x44e00d = _0x19a19d(0x3d2);
        _0x44e00d[_0x2c2a87(0x33d)] &&
          (_0x44e00d = _0x44e00d[_0x2c2a87(0x2f2)]),
          _0x2c2a87(0x1ba) == typeof _0x44e00d &&
            (_0x44e00d = [[_0x6207b7["i"], _0x44e00d, ""]]),
          _0x44e00d["locals"] &&
            (_0x6207b7[_0x2c2a87(0x24a)] = _0x44e00d[_0x2c2a87(0x34f)]),
          (0x0, _0x19a19d(0x5)[_0x2c2a87(0x2f2)])(
            _0x2c2a87(0x23a),
            _0x44e00d,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x178: function (_0x15d080, _0x35f167, _0x5c8d28) {
        var _0x4c23f7 = a5_0x17320c,
          _0x4284f6 = _0x5c8d28(0x3e3);
        _0x4284f6["__esModule"] && (_0x4284f6 = _0x4284f6[_0x4c23f7(0x2f2)]),
          _0x4c23f7(0x1ba) == typeof _0x4284f6 &&
            (_0x4284f6 = [[_0x15d080["i"], _0x4284f6, ""]]),
          _0x4284f6[_0x4c23f7(0x34f)] &&
            (_0x15d080["exports"] = _0x4284f6[_0x4c23f7(0x34f)]),
          (0x0, _0x5c8d28(0x5)[_0x4c23f7(0x2f2)])("5b4e3e24", _0x4284f6, !0x0, {
            sourceMap: !0x1,
          });
      },
      0x179: function (_0x43b825, _0x140e40, _0x200791) {
        var _0x43191d = a5_0x17320c,
          _0x3b327a = _0x200791(0x401);
        _0x3b327a[_0x43191d(0x33d)] &&
          (_0x3b327a = _0x3b327a[_0x43191d(0x2f2)]),
          _0x43191d(0x1ba) == typeof _0x3b327a &&
            (_0x3b327a = [[_0x43b825["i"], _0x3b327a, ""]]),
          _0x3b327a[_0x43191d(0x34f)] &&
            (_0x43b825[_0x43191d(0x24a)] = _0x3b327a[_0x43191d(0x34f)]),
          (0x0, _0x200791(0x5)[_0x43191d(0x2f2)])(
            _0x43191d(0x274),
            _0x3b327a,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x1d7: function (_0x3b9767, _0x2e7989, _0x5efe93) {
        "use strict";
        var _0x23a578 = a5_0x17320c;
        var _0x4cdf75 = _0x5efe93(0x3),
          _0x1a9c3e = _0x5efe93(0x2),
          _0x3de947 = _0x5efe93(0x0),
          _0x36991f =
            (_0x5efe93(0x7),
            {
              name: _0x23a578(0x377),
              components: { VPagination: _0x5efe93(0x27)["a"] },
              data: function () {
                return {
                  history: {
                    per_page: 0xf,
                    cur_page: 0x1,
                    last_page: 0x0,
                    data: [],
                  },
                };
              },
              computed: {
                risk: function () {
                  var _0xee0036 = _0x23a578;
                  return {
                    0x0: this["$t"](_0xee0036(0x249))[0x0],
                    0x1: this["$t"]("plinko.riskEnum")[0x1],
                    0x2: this["$t"](_0xee0036(0x249))[0x2],
                  };
                },
              },
              methods: {
                setPage: function (_0x3196e9) {
                  var _0x284def = _0x23a578;
                  (this[_0x284def(0x1f0)][_0x284def(0x230)] = _0x3196e9),
                    this[_0x284def(0x213)]();
                },
                fetch: function () {
                  var _0x1eb895 = _0x23a578,
                    _0x50af4e = this;
                  return Object(_0x3de947["a"])(
                    regeneratorRuntime[_0x1eb895(0x2b3)](function _0x5d7eb2() {
                      var _0x505a74 = _0x1eb895,
                        _0x4f8a70,
                        _0xd5a43f,
                        _0x41422c,
                        _0x56a5d6;
                      return regeneratorRuntime[_0x505a74(0x341)](
                        function (_0x5295cb) {
                          var _0x2e071a = _0x505a74;
                          for (;;)
                            switch (
                              (_0x5295cb["prev"] = _0x5295cb[_0x2e071a(0x36c)])
                            ) {
                              case 0x0:
                                return (
                                  (_0x5295cb["prev"] = 0x0),
                                  _0x50af4e[_0x2e071a(0x32d)](function () {
                                    var _0x27b437 = _0x2e071a;
                                    _0x50af4e["$nuxt"][_0x27b437(0x280)][
                                      "start"
                                    ]();
                                  }),
                                  (_0x5295cb[_0x2e071a(0x36c)] = 0x4),
                                  _0x50af4e[_0x2e071a(0x2bb)]["games"][
                                    _0x2e071a(0x25b)
                                  ]["index"]({
                                    per_page:
                                      _0x50af4e[_0x2e071a(0x1f0)][
                                        _0x2e071a(0x254)
                                      ],
                                    page: _0x50af4e[_0x2e071a(0x1f0)][
                                      _0x2e071a(0x230)
                                    ],
                                  })
                                );
                              case 0x4:
                                (_0x4f8a70 = _0x5295cb[_0x2e071a(0x2f3)]),
                                  (_0xd5a43f = _0x4f8a70["data"]),
                                  (_0x41422c = _0x4f8a70[_0x2e071a(0x316)]),
                                  (_0x56a5d6 = _0x4f8a70[_0x2e071a(0x230)]),
                                  (_0x50af4e[_0x2e071a(0x1f0)][
                                    _0x2e071a(0x316)
                                  ] = _0x41422c),
                                  (_0x50af4e["history"]["cur_page"] =
                                    _0x56a5d6),
                                  (_0x50af4e[_0x2e071a(0x1f0)][
                                    _0x2e071a(0x330)
                                  ] = _0xd5a43f),
                                  (_0x5295cb[_0x2e071a(0x36c)] = 0x10);
                                break;
                              case 0xd:
                                (_0x5295cb[_0x2e071a(0x3a8)] = 0xd),
                                  (_0x5295cb["t0"] =
                                    _0x5295cb[_0x2e071a(0x340)](0x0)),
                                  _0x50af4e[_0x2e071a(0x371)][_0x2e071a(0x26c)](
                                    _0x5295cb["t0"]
                                  );
                              case 0x10:
                                return (
                                  (_0x5295cb[_0x2e071a(0x3a8)] = 0x10),
                                  _0x50af4e["$nextTick"](function () {
                                    var _0x1302db = _0x2e071a;
                                    _0x50af4e[_0x1302db(0x2b4)][
                                      _0x1302db(0x280)
                                    ][_0x1302db(0x210)]();
                                  }),
                                  _0x5295cb[_0x2e071a(0x210)](0x10)
                                );
                              case 0x13:
                              case "end":
                                return _0x5295cb[_0x2e071a(0x2d0)]();
                            }
                        },
                        _0x5d7eb2,
                        null,
                        [[0x0, 0xd, 0x10, 0x13]]
                      );
                    })
                  )();
                },
              },
            }),
          _0x19f7d8 = (_0x5efe93(0x3c3), _0x5efe93(0x1)),
          _0x25a6db = {
            name: _0x23a578(0x1b7),
            components: {
              VDialogHistory: Object(_0x19f7d8["a"])(
                _0x36991f,
                function () {
                  var _0x3af6eb = _0x23a578,
                    _0x2d3f70,
                    _0x3d7138 = this,
                    _0x15a146 = _0x3d7138[_0x3af6eb(0x39a)]["_c"];
                  return _0x15a146(
                    _0x3af6eb(0x2aa),
                    {
                      ref: _0x3af6eb(0x2ee),
                      attrs: { "max-width": _0x3af6eb(0x3b6) },
                      on: { dialogActive: _0x3d7138["fetch"] },
                      scopedSlots: _0x3d7138["_u"](
                        [
                          {
                            key: _0x3af6eb(0x218),
                            fn: function (_0x10f93f) {
                              var _0xdf8b1a = _0x3af6eb,
                                _0x49eb58 = _0x10f93f["on"];
                              return [
                                _0x3d7138["_t"](_0xdf8b1a(0x218), null, {
                                  on: _0x49eb58,
                                }),
                              ];
                            },
                          },
                        ],
                        null,
                        !0x0
                      ),
                    },
                    [
                      _0x3d7138["_v"]("\x20"),
                      _0x15a146(
                        _0x3af6eb(0x268),
                        { staticClass: _0x3af6eb(0x317) },
                        [
                          _0x15a146(
                            "v-row",
                            { staticClass: _0x3af6eb(0x2f8) },
                            [
                              _0x15a146("v-text", [
                                _0x3d7138["_v"](
                                  _0x3d7138["_s"](
                                    _0x3d7138["$t"](_0x3af6eb(0x382))
                                  )
                                ),
                              ]),
                            ],
                            0x1
                          ),
                          _0x3d7138["_v"]("\x20"),
                          _0x15a146(
                            "v-column",
                            { staticClass: _0x3af6eb(0x343) },
                            [
                              _0x15a146(
                                "v-column",
                                {
                                  staticClass: "history-log\x20scrollable-auto",
                                },
                                [
                                  _0x15a146(_0x3af6eb(0x224), [
                                    _0x15a146(_0x3af6eb(0x38e), [
                                      _0x15a146("tr", [
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"](_0x3af6eb(0x1ce))
                                            )
                                          ),
                                        ]),
                                        _0x3d7138["_v"]("\x20"),
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"](_0x3af6eb(0x216))
                                            )
                                          ),
                                        ]),
                                        _0x3d7138["_v"]("\x20"),
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"]("plinko.rows")
                                            )
                                          ),
                                        ]),
                                        _0x3d7138["_v"]("\x20"),
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"](
                                                "plinko.betAmount"
                                              )
                                            )
                                          ),
                                        ]),
                                        _0x3d7138["_v"]("\x20"),
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"]("plinko.odds")
                                            )
                                          ),
                                        ]),
                                        _0x3d7138["_v"]("\x20"),
                                        _0x15a146("th", [
                                          _0x3d7138["_v"](
                                            _0x3d7138["_s"](
                                              _0x3d7138["$t"](_0x3af6eb(0x2a3))
                                            )
                                          ),
                                        ]),
                                      ]),
                                    ]),
                                    _0x3d7138["_v"]("\x20"),
                                    _0x15a146(
                                      _0x3af6eb(0x2bc),
                                      [
                                        _0x3d7138["_l"](
                                          _0x3d7138[_0x3af6eb(0x1f0)][
                                            _0x3af6eb(0x330)
                                          ],
                                          function (_0x2145e4) {
                                            var _0x459b56 = _0x3af6eb;
                                            return _0x15a146("tr", [
                                              _0x15a146(
                                                "td",
                                                {
                                                  staticClass: _0x459b56(0x1f1),
                                                },
                                                [
                                                  _0x15a146(_0x459b56(0x390), [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        _0x3d7138[
                                                          _0x459b56(0x24c)
                                                        ](
                                                          _0x2145e4[
                                                            _0x459b56(0x353)
                                                          ]
                                                        )[_0x459b56(0x2c2)](
                                                          _0x459b56(0x3b9)
                                                        )
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                              _0x3d7138["_v"]("\x20"),
                                              _0x15a146(
                                                "td",
                                                {
                                                  staticClass: _0x459b56(0x305),
                                                },
                                                [
                                                  _0x15a146(_0x459b56(0x390), [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        _0x3d7138[
                                                          _0x459b56(0x305)
                                                        ][
                                                          _0x2145e4[
                                                            _0x459b56(0x305)
                                                          ]
                                                        ]
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                              _0x3d7138["_v"]("\x20"),
                                              _0x15a146(
                                                "td",
                                                {
                                                  staticClass: _0x459b56(0x3e4),
                                                },
                                                [
                                                  _0x15a146(_0x459b56(0x390), [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        _0x2145e4[
                                                          _0x459b56(0x3e4)
                                                        ]
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                              _0x3d7138["_v"]("\x20"),
                                              _0x15a146(
                                                "td",
                                                {
                                                  staticClass: _0x459b56(0x3ac),
                                                },
                                                [
                                                  _0x15a146(_0x459b56(0x390), [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        parseInt(
                                                          _0x2145e4[
                                                            _0x459b56(0x3ac)
                                                          ]
                                                        )[_0x459b56(0x304)]()
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                              _0x3d7138["_v"]("\x20"),
                                              _0x15a146(
                                                "td",
                                                { staticClass: "odds" },
                                                [
                                                  _0x15a146("v-text", [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        _0x2145e4["odds"]
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                              _0x3d7138["_v"]("\x20"),
                                              _0x15a146(
                                                "td",
                                                {
                                                  staticClass: _0x459b56(0x1e7),
                                                },
                                                [
                                                  _0x15a146(_0x459b56(0x390), [
                                                    _0x3d7138["_v"](
                                                      _0x3d7138["_s"](
                                                        parseInt(
                                                          _0x2145e4[
                                                            _0x459b56(0x281)
                                                          ]
                                                        )["toLocaleString"]()
                                                      )
                                                    ),
                                                  ]),
                                                ],
                                                0x1
                                              ),
                                            ]);
                                          }
                                        ),
                                        _0x3d7138["_v"]("\x20"),
                                        0x0 ==
                                        _0x3d7138[_0x3af6eb(0x1f0)][
                                          _0x3af6eb(0x330)
                                        ][_0x3af6eb(0x397)]
                                          ? [
                                              _0x15a146(
                                                "td",
                                                {
                                                  style: {
                                                    "background-color":
                                                      _0x3af6eb(0x231),
                                                  },
                                                  attrs: { colspan: "6" },
                                                },
                                                [
                                                  _0x15a146(
                                                    "v-text",
                                                    {
                                                      style: {
                                                        "justify-content":
                                                          "center",
                                                      },
                                                    },
                                                    [
                                                      _0x3d7138["_v"](
                                                        _0x3af6eb(0x259) +
                                                          _0x3d7138["_s"](
                                                            _0x3d7138["$t"](
                                                              "global.noData"
                                                            )
                                                          ) +
                                                          _0x3af6eb(0x3ca)
                                                      ),
                                                    ]
                                                  ),
                                                ],
                                                0x1
                                              ),
                                            ]
                                          : _0x3d7138["_e"](),
                                      ],
                                      0x2
                                    ),
                                  ]),
                                ]
                              ),
                            ],
                            0x1
                          ),
                          _0x3d7138["_v"]("\x20"),
                          _0x15a146(
                            _0x3af6eb(0x268),
                            { staticClass: _0x3af6eb(0x374) },
                            [
                              _0x15a146(_0x3af6eb(0x214), {
                                attrs:
                                  ((_0x2d3f70 = {
                                    value:
                                      _0x3d7138[_0x3af6eb(0x1f0)][
                                        _0x3af6eb(0x230)
                                      ],
                                    perPage:
                                      _0x3d7138[_0x3af6eb(0x1f0)][
                                        _0x3af6eb(0x254)
                                      ],
                                  }),
                                  Object(_0x1a9c3e["a"])(
                                    _0x2d3f70,
                                    "perPage",
                                    _0x3d7138[_0x3af6eb(0x1f0)][
                                      _0x3af6eb(0x254)
                                    ]
                                  ),
                                  Object(_0x1a9c3e["a"])(
                                    _0x2d3f70,
                                    _0x3af6eb(0x2bf),
                                    _0x3d7138["history"][_0x3af6eb(0x316)]
                                  ),
                                  _0x2d3f70),
                                on: {
                                  "update:perPage": function (_0x329219) {
                                    var _0x8699b8 = _0x3af6eb;
                                    return _0x3d7138[_0x8699b8(0x26e)](
                                      _0x3d7138["history"],
                                      _0x8699b8(0x254),
                                      _0x329219
                                    );
                                  },
                                  "update:per-page": [
                                    function (_0x22fef6) {
                                      var _0x570ad3 = _0x3af6eb;
                                      return _0x3d7138[_0x570ad3(0x26e)](
                                        _0x3d7138["history"],
                                        _0x570ad3(0x254),
                                        _0x22fef6
                                      );
                                    },
                                    _0x3d7138[_0x3af6eb(0x213)],
                                  ],
                                  input: _0x3d7138[_0x3af6eb(0x3ba)],
                                },
                              }),
                            ],
                            0x1
                          ),
                        ],
                        0x1
                      ),
                    ],
                    0x1
                  );
                },
                [],
                !0x1,
                null,
                _0x23a578(0x391),
                null
              )[_0x23a578(0x24a)],
            },
            props: [_0x23a578(0x1c3)],
            data: function () {
              return {
                settingForm: {
                  risk: [],
                  rows: { label: "16", value: 0x10 },
                  amounts: null,
                  betcount: null,
                },
                quickAmount: 0x2710,
                activeManual: !0x0,
                activeAuto: !0x1,
              };
            },
            computed: Object(_0x4cdf75["c"])(_0x23a578(0x2ee), [
              _0x23a578(0x318),
              "setdisabled",
              "autodisabled",
            ]),
            watch: {
              "settingForm.risk": function () {
                var _0x66fbf1 = _0x23a578;
                this[_0x66fbf1(0x1fe)]();
              },
              "settingForm.rows": function () {
                var _0xc55571 = _0x23a578;
                this[_0xc55571(0x3b8)]();
              },
              autoCount: function (_0x2d0282) {
                var _0x3a95b9 = _0x23a578;
                this[_0x3a95b9(0x28b)][_0x3a95b9(0x389)] = _0x2d0282;
              },
            },
            mounted: function () {
              var _0xff80dc = _0x23a578;
              this["settingForm"][_0xff80dc(0x305)] = {
                label: this["$t"](_0xff80dc(0x249))[0x1],
                value: 0x1,
              };
            },
            methods: {
              toggleForm: function (_0x117bb3) {
                var _0x3fcb76 = _0x23a578;
                _0x117bb3
                  ? ((this["activeAuto"] = !0x1),
                    (this[_0x3fcb76(0x32e)] = !0x0))
                  : ((this[_0x3fcb76(0x375)] = !0x0),
                    (this[_0x3fcb76(0x32e)] = !0x1));
              },
              up: function () {
                var _0x10f212 = _0x23a578;
                (this[_0x10f212(0x28b)][_0x10f212(0x2d6)] +=
                  this[_0x10f212(0x276)]),
                  this["changedAmount"]();
              },
              down: function () {
                var _0x7e770a = _0x23a578;
                this[_0x7e770a(0x28b)]["amounts"] > this[_0x7e770a(0x276)]
                  ? (this[_0x7e770a(0x28b)][_0x7e770a(0x2d6)] -=
                      this["quickAmount"])
                  : (this["settingForm"]["amounts"] = null),
                  this["changedAmount"]();
              },
              clear: function () {
                var _0x32572a = _0x23a578;
                (this[_0x32572a(0x28b)][_0x32572a(0x2d6)] = null),
                  this[_0x32572a(0x2c3)]();
              },
              startBet: function () {
                var _0x4f65bb = _0x23a578;
                this[_0x4f65bb(0x1d1)](_0x4f65bb(0x1e8));
              },
              startAutoBet: function () {
                var _0x271163 = _0x23a578;
                this[_0x271163(0x1d1)](_0x271163(0x3a4));
              },
              stopAutoBet: function () {
                this["$emit"]("stopAutoBet");
              },
              selectRisk: function () {
                var _0x5b4e06 = _0x23a578;
                this[_0x5b4e06(0x1d1)](
                  _0x5b4e06(0x1fe),
                  this["settingForm"][_0x5b4e06(0x305)][_0x5b4e06(0x2ae)]
                );
              },
              selectRows: function () {
                var _0x4b405a = _0x23a578;
                this[_0x4b405a(0x1d1)](
                  _0x4b405a(0x3b8),
                  this["settingForm"][_0x4b405a(0x223)]["value"]
                );
              },
              selectBetcount: function () {
                var _0xced63e = _0x23a578;
                this[_0xced63e(0x1d1)](
                  _0xced63e(0x2ff),
                  this[_0xced63e(0x28b)][_0xced63e(0x389)]
                );
              },
              changedAmount: function () {
                var _0x462b79 = _0x23a578;
                this[_0x462b79(0x1d1)](
                  _0x462b79(0x2c3),
                  this["settingForm"][_0x462b79(0x2d6)]
                );
              },
            },
          },
          _0x217113 =
            (_0x5efe93(0x3c5),
            Object(_0x19f7d8["a"])(
              _0x25a6db,
              function () {
                var _0x2aa96a = _0x23a578,
                  _0x36990a = this,
                  _0x1afdd4 = _0x36990a[_0x2aa96a(0x39a)]["_c"];
                return _0x1afdd4(
                  "v-row",
                  { staticClass: "plinko-betslip" },
                  [
                    _0x1afdd4(
                      _0x2aa96a(0x268),
                      { staticClass: _0x2aa96a(0x348) },
                      [
                        _0x36990a[_0x2aa96a(0x350)]["loggedIn"]
                          ? _0x1afdd4(
                              "v-row",
                              { staticClass: _0x2aa96a(0x25a) },
                              [
                                _0x1afdd4(_0x2aa96a(0x39f), {
                                  scopedSlots: _0x36990a["_u"](
                                    [
                                      {
                                        key: "activator",
                                        fn: function (_0x2b6533) {
                                          var _0x72e6f9 = _0x2aa96a,
                                            _0x4fdee7 = _0x2b6533["on"];
                                          return [
                                            _0x1afdd4(
                                              "v-button",
                                              _0x36990a["_g"](
                                                { attrs: { text: "" } },
                                                _0x4fdee7
                                              ),
                                              [
                                                _0x1afdd4(_0x72e6f9(0x390), [
                                                  _0x36990a["_v"](
                                                    _0x36990a["_s"](
                                                      _0x36990a["$t"](
                                                        "plinko.history"
                                                      )
                                                    )
                                                  ),
                                                ]),
                                              ],
                                              0x1
                                            ),
                                          ];
                                        },
                                      },
                                    ],
                                    null,
                                    !0x1,
                                    0xd4fda56b
                                  ),
                                }),
                              ],
                              0x1
                            )
                          : _0x36990a["_e"](),
                        _0x36990a["_v"]("\x20"),
                        _0x1afdd4(
                          _0x2aa96a(0x290),
                          { staticClass: _0x2aa96a(0x243) },
                          [
                            _0x1afdd4(
                              _0x2aa96a(0x2be),
                              {
                                class: { active: _0x36990a[_0x2aa96a(0x32e)] },
                                on: {
                                  click: function (_0x439e12) {
                                    var _0x37040c = _0x2aa96a;
                                    return _0x36990a[_0x37040c(0x286)](!0x0);
                                  },
                                },
                              },
                              [
                                _0x1afdd4(_0x2aa96a(0x390), [
                                  _0x36990a["_v"](
                                    _0x36990a["_s"](
                                      _0x36990a["$t"]("plinko.manual")
                                    )
                                  ),
                                ]),
                              ],
                              0x1
                            ),
                            _0x36990a["_v"]("\x20"),
                            _0x1afdd4(
                              _0x2aa96a(0x2be),
                              {
                                class: { active: _0x36990a[_0x2aa96a(0x375)] },
                                on: {
                                  click: function (_0x433e27) {
                                    var _0x33dd0b = _0x2aa96a;
                                    return _0x36990a[_0x33dd0b(0x286)](!0x1);
                                  },
                                },
                              },
                              [
                                _0x1afdd4("v-text", [
                                  _0x36990a["_v"](
                                    _0x36990a["_s"](
                                      _0x36990a["$t"]("plinko.auto")
                                    )
                                  ),
                                ]),
                              ],
                              0x1
                            ),
                          ],
                          0x1
                        ),
                        _0x36990a["_v"]("\x20"),
                        _0x1afdd4(
                          _0x2aa96a(0x268),
                          { staticClass: _0x2aa96a(0x2e3) },
                          [
                            _0x1afdd4(
                              _0x2aa96a(0x268),
                              { staticClass: "amount" },
                              [
                                _0x36990a["$auth"][_0x2aa96a(0x2c4)]
                                  ? _0x1afdd4(
                                      _0x2aa96a(0x290),
                                      { staticClass: "balance" },
                                      [
                                        _0x1afdd4(
                                          _0x2aa96a(0x290),
                                          { staticClass: "title" },
                                          [
                                            _0x1afdd4("v-text", [
                                              _0x36990a["_v"](
                                                _0x36990a["_s"](
                                                  _0x36990a["$t"](
                                                    _0x2aa96a(0x338)
                                                  )
                                                )
                                              ),
                                            ]),
                                          ],
                                          0x1
                                        ),
                                        _0x36990a["_v"]("\x20"),
                                        _0x1afdd4(
                                          _0x2aa96a(0x290),
                                          { staticClass: _0x2aa96a(0x258) },
                                          [
                                            _0x1afdd4(_0x2aa96a(0x390), [
                                              _0x36990a["_v"](
                                                _0x36990a["_s"](
                                                  parseInt(
                                                    _0x36990a[_0x2aa96a(0x350)][
                                                      _0x2aa96a(0x366)
                                                    ][_0x2aa96a(0x1c4)]
                                                  )[_0x2aa96a(0x304)]()
                                                )
                                              ),
                                            ]),
                                          ],
                                          0x1
                                        ),
                                      ],
                                      0x1
                                    )
                                  : _0x36990a["_e"](),
                                _0x36990a["_v"]("\x20"),
                                _0x1afdd4(
                                  "v-row",
                                  [
                                    _0x1afdd4(_0x2aa96a(0x390), [
                                      _0x36990a["_v"](
                                        _0x36990a["_s"](
                                          _0x36990a["$t"](_0x2aa96a(0x1dc))
                                        )
                                      ),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x36990a["_v"]("\x20"),
                                _0x1afdd4(
                                  "v-row",
                                  { staticClass: _0x2aa96a(0x3a5) },
                                  [
                                    _0x1afdd4(
                                      _0x2aa96a(0x290),
                                      { staticClass: "cash-updown" },
                                      [
                                        _0x1afdd4(
                                          _0x2aa96a(0x2be),
                                          {
                                            staticClass: _0x2aa96a(0x339),
                                            attrs: {
                                              disabled:
                                                _0x36990a[_0x2aa96a(0x35e)] ||
                                                _0x36990a[_0x2aa96a(0x262)],
                                            },
                                            on: {
                                              click: function (_0x4b19cd) {
                                                var _0x5ac178 = _0x2aa96a;
                                                return _0x36990a[
                                                  _0x5ac178(0x339)
                                                ]();
                                              },
                                            },
                                          },
                                          [
                                            _0x1afdd4("v-icon", {
                                              staticClass: _0x2aa96a(0x2e1),
                                              attrs: { icon: _0x2aa96a(0x222) },
                                            }),
                                          ],
                                          0x1
                                        ),
                                        _0x36990a["_v"]("\x20"),
                                        _0x1afdd4(
                                          _0x2aa96a(0x2be),
                                          {
                                            staticClass: "up",
                                            attrs: {
                                              disabled:
                                                _0x36990a[_0x2aa96a(0x35e)] ||
                                                _0x36990a[_0x2aa96a(0x262)],
                                            },
                                            on: {
                                              click: function (_0x279d91) {
                                                return _0x36990a["up"]();
                                              },
                                            },
                                          },
                                          [
                                            _0x1afdd4(_0x2aa96a(0x2c5), {
                                              staticClass: "margin-right-0",
                                              attrs: { icon: _0x2aa96a(0x2cd) },
                                            }),
                                          ],
                                          0x1
                                        ),
                                      ],
                                      0x1
                                    ),
                                    _0x36990a["_v"]("\x20"),
                                    _0x1afdd4(_0x2aa96a(0x1b4), {
                                      attrs: {
                                        placeholder:
                                          _0x36990a["$t"]("plinko.betAmount"),
                                        disabled:
                                          _0x36990a[_0x2aa96a(0x35e)] ||
                                          _0x36990a[_0x2aa96a(0x262)],
                                        "number-format": !0x0,
                                      },
                                      on: { input: _0x36990a["changedAmount"] },
                                      model: {
                                        value:
                                          _0x36990a[_0x2aa96a(0x28b)][
                                            _0x2aa96a(0x2d6)
                                          ],
                                        callback: function (_0x3605ef) {
                                          var _0x2217d4 = _0x2aa96a;
                                          _0x36990a[_0x2217d4(0x26e)](
                                            _0x36990a[_0x2217d4(0x28b)],
                                            _0x2217d4(0x2d6),
                                            _0x3605ef
                                          );
                                        },
                                        expression: _0x2aa96a(0x392),
                                      },
                                    }),
                                    _0x36990a["_v"]("\x20"),
                                    _0x1afdd4(
                                      _0x2aa96a(0x2be),
                                      {
                                        staticClass: "amount-init",
                                        attrs: {
                                          disabled:
                                            _0x36990a[_0x2aa96a(0x35e)] ||
                                            _0x36990a[_0x2aa96a(0x262)],
                                        },
                                        on: {
                                          click: function (_0x34847a) {
                                            var _0x36565c = _0x2aa96a;
                                            return _0x36990a[
                                              _0x36565c(0x3cd)
                                            ]();
                                          },
                                        },
                                      },
                                      [
                                        _0x1afdd4(_0x2aa96a(0x2c5), {
                                          staticClass: _0x2aa96a(0x2e1),
                                          attrs: { icon: _0x2aa96a(0x34b) },
                                        }),
                                      ],
                                      0x1
                                    ),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                            _0x36990a["_v"]("\x20"),
                            _0x1afdd4(
                              _0x2aa96a(0x268),
                              { staticClass: "risk" },
                              [
                                _0x1afdd4(
                                  _0x2aa96a(0x290),
                                  [
                                    _0x1afdd4(_0x2aa96a(0x390), [
                                      _0x36990a["_v"](
                                        _0x36990a["_s"](
                                          _0x36990a["$t"](_0x2aa96a(0x216))
                                        )
                                      ),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x36990a["_v"]("\x20"),
                                _0x1afdd4(
                                  _0x2aa96a(0x290),
                                  [
                                    _0x1afdd4(_0x2aa96a(0x267), {
                                      attrs: {
                                        options: [
                                          {
                                            label: _0x36990a["$t"](
                                              _0x2aa96a(0x249)
                                            )[0x0],
                                            value: 0x0,
                                          },
                                          {
                                            label:
                                              _0x36990a["$t"](
                                                "plinko.riskEnum"
                                              )[0x1],
                                            value: 0x1,
                                          },
                                          {
                                            label:
                                              _0x36990a["$t"](
                                                "plinko.riskEnum"
                                              )[0x2],
                                            value: 0x2,
                                          },
                                        ],
                                        disabled:
                                          _0x36990a[_0x2aa96a(0x35e)] ||
                                          _0x36990a["autodisabled"],
                                      },
                                      model: {
                                        value:
                                          _0x36990a[_0x2aa96a(0x28b)]["risk"],
                                        callback: function (_0x19b9b2) {
                                          var _0x9f4b7c = _0x2aa96a;
                                          _0x36990a[_0x9f4b7c(0x26e)](
                                            _0x36990a[_0x9f4b7c(0x28b)],
                                            _0x9f4b7c(0x305),
                                            _0x19b9b2
                                          );
                                        },
                                        expression: "settingForm.risk",
                                      },
                                    }),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                            _0x36990a["_v"]("\x20"),
                            _0x1afdd4(
                              _0x2aa96a(0x268),
                              { staticClass: "rows" },
                              [
                                _0x1afdd4(
                                  "v-row",
                                  [
                                    _0x1afdd4("v-text", [
                                      _0x36990a["_v"](
                                        _0x36990a["_s"](
                                          _0x36990a["$t"](_0x2aa96a(0x3a7))
                                        )
                                      ),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x36990a["_v"]("\x20"),
                                _0x1afdd4(
                                  _0x2aa96a(0x290),
                                  [
                                    _0x1afdd4(_0x2aa96a(0x267), {
                                      attrs: {
                                        options: [
                                          { label: "8", value: 0x8 },
                                          { label: "9", value: 0x9 },
                                          { label: "10", value: 0xa },
                                          { label: "11", value: 0xb },
                                          { label: "12", value: 0xc },
                                          { label: "13", value: 0xd },
                                          { label: "14", value: 0xe },
                                          { label: "15", value: 0xf },
                                          { label: "16", value: 0x10 },
                                        ],
                                        disabled:
                                          _0x36990a[_0x2aa96a(0x35e)] ||
                                          _0x36990a["autodisabled"],
                                      },
                                      model: {
                                        value:
                                          _0x36990a[_0x2aa96a(0x28b)][
                                            _0x2aa96a(0x223)
                                          ],
                                        callback: function (_0x339abc) {
                                          var _0x275f5a = _0x2aa96a;
                                          _0x36990a[_0x275f5a(0x26e)](
                                            _0x36990a[_0x275f5a(0x28b)],
                                            "rows",
                                            _0x339abc
                                          );
                                        },
                                        expression: _0x2aa96a(0x299),
                                      },
                                    }),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                            _0x36990a["_v"]("\x20"),
                            _0x36990a[_0x2aa96a(0x375)]
                              ? _0x1afdd4(
                                  _0x2aa96a(0x268),
                                  { staticClass: "betcount" },
                                  [
                                    _0x1afdd4(
                                      "v-row",
                                      [
                                        _0x1afdd4("v-text", [
                                          _0x36990a["_v"](
                                            _0x36990a["_s"](
                                              _0x36990a["$t"](_0x2aa96a(0x1c7))
                                            )
                                          ),
                                        ]),
                                      ],
                                      0x1
                                    ),
                                    _0x36990a["_v"]("\x20"),
                                    _0x1afdd4(
                                      "v-row",
                                      [
                                        _0x1afdd4(_0x2aa96a(0x1b4), {
                                          attrs: {
                                            autocomplete: _0x2aa96a(0x22f),
                                            disabled:
                                              _0x36990a[_0x2aa96a(0x35e)] ||
                                              _0x36990a[_0x2aa96a(0x262)],
                                            placeholder: _0x36990a["$t"](
                                              _0x2aa96a(0x1c7)
                                            ),
                                          },
                                          on: {
                                            change: function (_0x3e8a9e) {
                                              var _0x589467 = _0x2aa96a;
                                              return _0x36990a[
                                                _0x589467(0x2ff)
                                              ]();
                                            },
                                          },
                                          model: {
                                            value:
                                              _0x36990a[_0x2aa96a(0x28b)][
                                                _0x2aa96a(0x389)
                                              ],
                                            callback: function (_0x3ee59c) {
                                              var _0x1de3a2 = _0x2aa96a;
                                              _0x36990a["$set"](
                                                _0x36990a[_0x1de3a2(0x28b)],
                                                _0x1de3a2(0x389),
                                                _0x3ee59c
                                              );
                                            },
                                            expression: "settingForm.betcount",
                                          },
                                        }),
                                      ],
                                      0x1
                                    ),
                                  ],
                                  0x1
                                )
                              : _0x36990a["_e"](),
                            _0x36990a["_v"]("\x20"),
                            _0x1afdd4(
                              _0x2aa96a(0x268),
                              { staticClass: _0x2aa96a(0x1fd) },
                              [
                                _0x1afdd4(
                                  _0x2aa96a(0x2be),
                                  [
                                    _0x1afdd4("v-text", [
                                      _0x36990a["_v"](_0x2aa96a(0x212)),
                                    ]),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                          ],
                          0x1
                        ),
                      ],
                      0x1
                    ),
                  ],
                  0x1
                );
              },
              [],
              !0x1,
              null,
              "24e3e3fa",
              null
            ));
        _0x2e7989["a"] = _0x217113[_0x23a578(0x24a)];
      },
      0x1f9: function (_0x4b4b72, _0x2d9663, _0x57770c) {
        "use strict";
        var _0x204af8 = a5_0x17320c;
        _0x57770c(0xc),
          _0x57770c(0xa),
          _0x57770c(0xb),
          _0x57770c(0x10),
          _0x57770c(0xd),
          _0x57770c(0x11);
        var _0x4b515b = _0x57770c(0x0),
          _0x3e1a6e = _0x57770c(0x18),
          _0x2df6d1 = _0x57770c(0x2),
          _0x36553c =
            (_0x57770c(0x7),
            _0x57770c(0x5e),
            _0x57770c(0x8f),
            _0x57770c(0x8),
            _0x57770c(0x43),
            _0x57770c(0x40),
            _0x57770c(0xac),
            _0x57770c(0xd8),
            _0x57770c(0xd9),
            _0x57770c(0xda),
            _0x57770c(0xdb),
            _0x57770c(0xdc),
            _0x57770c(0xdd),
            _0x57770c(0xde),
            _0x57770c(0xdf),
            _0x57770c(0xe0),
            _0x57770c(0xe1),
            _0x57770c(0xe2),
            _0x57770c(0xe3),
            _0x57770c(0xe4),
            _0x57770c(0xe5),
            _0x57770c(0xe6),
            _0x57770c(0xe7),
            _0x57770c(0xe8),
            _0x57770c(0xe9),
            _0x57770c(0xea),
            _0x57770c(0xeb),
            _0x57770c(0xec),
            _0x57770c(0xed),
            _0x57770c(0xee),
            _0x57770c(0xef),
            _0x57770c(0x3)),
          _0x501773 = _0x57770c(0x93);
        function _0x1d404e(_0x21d6d6, _0x5bb717) {
          var _0xcb7e7b = a5_0x31ca,
            _0x4c306f = Object["keys"](_0x21d6d6);
          if (Object[_0xcb7e7b(0x395)]) {
            var _0x454ca1 = Object[_0xcb7e7b(0x395)](_0x21d6d6);
            _0x5bb717 &&
              (_0x454ca1 = _0x454ca1[_0xcb7e7b(0x1e9)](function (_0x4b27cd) {
                return Object["getOwnPropertyDescriptor"](
                  _0x21d6d6,
                  _0x4b27cd
                )["enumerable"];
              })),
              _0x4c306f[_0xcb7e7b(0x295)][_0xcb7e7b(0x3c2)](
                _0x4c306f,
                _0x454ca1
              );
          }
          return _0x4c306f;
        }
        function _0x5dcbf6(_0x34cbb7) {
          var _0x384c60 = a5_0x31ca;
          for (
            var _0xa7bc59 = 0x1;
            _0xa7bc59 < arguments["length"];
            _0xa7bc59++
          ) {
            var _0x2abe3e =
              null != arguments[_0xa7bc59] ? arguments[_0xa7bc59] : {};
            _0xa7bc59 % 0x2
              ? _0x1d404e(Object(_0x2abe3e), !0x0)["forEach"](function (
                  _0x1cfd84
                ) {
                  Object(_0x2df6d1["a"])(
                    _0x34cbb7,
                    _0x1cfd84,
                    _0x2abe3e[_0x1cfd84]
                  );
                })
              : Object[_0x384c60(0x1ee)]
              ? Object[_0x384c60(0x3b1)](
                  _0x34cbb7,
                  Object["getOwnPropertyDescriptors"](_0x2abe3e)
                )
              : _0x1d404e(Object(_0x2abe3e))[_0x384c60(0x3bc)](function (
                  _0x3e18a5
                ) {
                  var _0xddb645 = _0x384c60;
                  Object[_0xddb645(0x344)](
                    _0x34cbb7,
                    _0x3e18a5,
                    Object["getOwnPropertyDescriptor"](_0x2abe3e, _0x3e18a5)
                  );
                });
          }
          return _0x34cbb7;
        }
        var _0x4321d2 = {
            name: _0x204af8(0x355),
            props: {
              IsStartedBet: { type: Boolean },
              IsStartedAutoBet: { type: Boolean },
              changedRisk: { type: Number, default: 0x0 },
              changedRows: { type: Number, default: 0x8 },
              changedAmount: { type: Number, default: 0x0 },
              changedBetcount: { type: Number, default: 0x0 },
            },
            data: function () {
              var _0x417ca8 = _0x204af8;
              return {
                canv: null,
                ctx: null,
                radiusinfo: null,
                canvasrectinfo: null,
                ballcolorinfo: null,
                rwin: null,
                pi2: 0x0,
                offset_ratio: 0.55,
                offset_dist: 0.4,
                pin_collision_time: 0x12c,
                rownum: 0x10,
                risk: 0x1,
                num: 0x0,
                ball: [],
                barstat: [],
                scorebox: [],
                shownum: 0x0,
                boxnum: 0x4,
                pin_points: [],
                canvas_values: [],
                amount: 0x0,
                autoschedule: !0x1,
                autocount: 0x0,
                betcount: 0x0,
                pre_rownum: 0x0,
                ctx_scale: 0x1,
                ballcolor_idxs: [_0x417ca8(0x2d7), "orange", _0x417ca8(0x39d)],
                animation_stop: !0x1,
                audioCtx: null,
                plinko_ratios: [
                  [
                    [5.6, 2.1, 1.1, 0x1, 0.5, 0x1, 1.1, 2.1, 5.6],
                    [5.6, 0x2, 1.6, 0x1, 0.7, 0.7, 0x1, 1.6, 0x2, 5.6],
                    [8.9, 0x3, 1.4, 1.1, 0x1, 0.5, 0x1, 1.1, 1.4, 0x3, 8.9],
                    [
                      8.4, 0x3, 1.9, 1.3, 0x1, 0.7, 0.7, 0x1, 1.3, 1.9, 0x3,
                      8.4,
                    ],
                    [
                      0xa, 0x3, 1.6, 1.4, 1.1, 0x1, 0.5, 0x1, 1.1, 1.4, 1.6,
                      0x3, 0xa,
                    ],
                    [
                      8.1, 0x4, 0x3, 1.9, 1.2, 0.9, 0.7, 0.7, 0.9, 1.2, 1.9,
                      0x3, 0x4, 8.1,
                    ],
                    [
                      7.1, 0x4, 1.9, 1.4, 1.3, 1.1, 0x1, 0.5, 0x1, 1.1, 1.3,
                      1.4, 1.9, 0x4, 7.1,
                    ],
                    [
                      0xf, 0x8, 0x3, 0x2, 1.5, 1.1, 0x1, 0.7, 0.7, 0x1, 1.1,
                      1.5, 0x2, 0x3, 0x8, 0xf,
                    ],
                    [
                      0x10, 0x9, 0x2, 1.4, 1.4, 1.2, 1.1, 0x1, 0.5, 0x1, 1.1,
                      1.2, 1.4, 1.4, 0x2, 0x9, 0x10,
                    ],
                  ],
                  [
                    [0xd, 0x3, 1.3, 0.7, 0.4, 0.7, 1.3, 0x3, 0xd],
                    [0x12, 0x4, 1.7, 0.9, 0.5, 0.5, 0.9, 1.7, 0x4, 0x12],
                    [0x16, 0x5, 0x2, 1.4, 0.6, 0.4, 0.6, 1.4, 0x2, 0x5, 0x16],
                    [
                      0x18, 0x6, 0x3, 1.8, 0.7, 0.5, 0.5, 0.7, 1.8, 0x3, 0x6,
                      0x18,
                    ],
                    [
                      0x21, 0xb, 0x4, 0x2, 1.1, 0.6, 0.3, 0.6, 1.1, 0x2, 0x4,
                      0xb, 0x21,
                    ],
                    [
                      0x2b, 0xd, 0x6, 0x3, 1.3, 0.7, 0.4, 0.4, 0.7, 1.3, 0x3,
                      0x6, 0xd, 0x2b,
                    ],
                    [
                      0x3a, 0xf, 0x7, 0x4, 1.9, 0x1, 0.5, 0.2, 0.5, 0x1, 1.9,
                      0x4, 0x7, 0xf, 0x3a,
                    ],
                    [
                      0x58, 0x12, 0xb, 0x5, 0x3, 1.3, 0.5, 0.3, 0.3, 0.5, 1.3,
                      0x3, 0x5, 0xb, 0x12, 0x58,
                    ],
                    [
                      0x6e, 0x29, 0xa, 0x5, 0x3, 1.5, 0x1, 0.5, 0.3, 0.5, 0x1,
                      1.5, 0x3, 0x5, 0xa, 0x29, 0x6e,
                    ],
                  ],
                  [
                    [0x1d, 0x4, 1.5, 0.3, 0.2, 0.3, 1.5, 0x4, 0x1d],
                    [0x2b, 0x7, 0x2, 0.6, 0.2, 0.2, 0.6, 0x2, 0x7, 0x2b],
                    [0x4c, 0xa, 0x3, 0.9, 0.3, 0.2, 0.3, 0.9, 0x3, 0xa, 0x4c],
                    [
                      0x78, 0xe, 5.2, 1.4, 0.4, 0.2, 0.2, 0.4, 1.4, 5.2, 0xe,
                      0x78,
                    ],
                    [
                      0xaa, 0x18, 8.1, 0x2, 0.7, 0.2, 0.2, 0.2, 0.7, 0x2, 8.1,
                      0x18, 0xaa,
                    ],
                    [
                      0x104, 0x25, 0xb, 0x4, 0x1, 0.2, 0.2, 0.2, 0.2, 0x1, 0x4,
                      0xb, 0x25, 0x104,
                    ],
                    [
                      0x1a4, 0x38, 0x12, 0x5, 1.9, 0.3, 0.2, 0.2, 0.2, 0.3, 1.9,
                      0x5, 0x12, 0x38, 0x1a4,
                    ],
                    [
                      0x26c, 0x53, 0x1b, 0x8, 0x3, 0.5, 0.2, 0.2, 0.2, 0.2, 0.5,
                      0x3, 0x8, 0x1b, 0x53, 0x26c,
                    ],
                    [
                      0x3e8, 0x82, 0x1a, 0x9, 0x4, 0x2, 0.2, 0.2, 0.2, 0.2, 0.2,
                      0x2, 0x4, 0x9, 0x1a, 0x82, 0x3e8,
                    ],
                  ],
                ],
                payout_bg: [
                  [
                    _0x417ca8(0x29d),
                    "255,\x2048,\x2047",
                    _0x417ca8(0x3a6),
                    _0x417ca8(0x3cb),
                    _0x417ca8(0x3df),
                    "255,\x20144,\x2016",
                    _0x417ca8(0x3a6),
                    _0x417ca8(0x38c),
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    _0x417ca8(0x219),
                    _0x417ca8(0x21b),
                    _0x417ca8(0x37f),
                    _0x417ca8(0x372),
                    _0x417ca8(0x372),
                    _0x417ca8(0x37f),
                    _0x417ca8(0x21b),
                    "255,\x2043,\x2049",
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    "255,\x2038,\x2050",
                    _0x417ca8(0x386),
                    _0x417ca8(0x308),
                    _0x417ca8(0x301),
                    _0x417ca8(0x3df),
                    _0x417ca8(0x301),
                    _0x417ca8(0x308),
                    _0x417ca8(0x386),
                    _0x417ca8(0x326),
                    "255,\x200,\x2063",
                  ],
                  [
                    _0x417ca8(0x3c1),
                    "255,\x2035,\x2052",
                    _0x417ca8(0x2d2),
                    _0x417ca8(0x3da),
                    "255,\x20140,\x2017",
                    "255,\x20175,\x206",
                    _0x417ca8(0x361),
                    "255,\x20140,\x2017",
                    "255,\x20109,\x2029",
                    _0x417ca8(0x2d2),
                    _0x417ca8(0x29c),
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    "255,\x2032,\x2053",
                    "255,\x2064,\x2042",
                    _0x417ca8(0x3a6),
                    "255,\x20128,\x2021",
                    _0x417ca8(0x1f2),
                    "255,\x20192,\x200",
                    _0x417ca8(0x1f2),
                    _0x417ca8(0x37f),
                    _0x417ca8(0x3a6),
                    _0x417ca8(0x2b6),
                    _0x417ca8(0x252),
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    _0x417ca8(0x1d9),
                    "255,\x2059,\x2044",
                    _0x417ca8(0x284),
                    "255,\x20118,\x2024",
                    _0x417ca8(0x215),
                    "255,\x20117,\x205",
                    _0x417ca8(0x211),
                    _0x417ca8(0x215),
                    "255,\x20118,\x2024",
                    "255,\x2089,\x2034",
                    _0x417ca8(0x1e1),
                    _0x417ca8(0x1d9),
                    _0x417ca8(0x3c1),
                  ],
                  [
                    "255,\x200,\x2063",
                    _0x417ca8(0x336),
                    _0x417ca8(0x3b3),
                    "255,\x2082,\x2036",
                    _0x417ca8(0x272),
                    _0x417ca8(0x2ea),
                    _0x417ca8(0x1c2),
                    _0x417ca8(0x3df),
                    "255,\x20165,\x209",
                    "255,\x20137,\x2018",
                    "255,\x20110,\x2027",
                    _0x417ca8(0x28d),
                    _0x417ca8(0x3b3),
                    _0x417ca8(0x336),
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    "255,\x2026,\x2055",
                    _0x417ca8(0x36b),
                    _0x417ca8(0x386),
                    _0x417ca8(0x3d5),
                    _0x417ca8(0x37f),
                    _0x417ca8(0x301),
                    "255,\x20179,\x204",
                    "255,\x20179,\x204",
                    _0x417ca8(0x301),
                    _0x417ca8(0x37f),
                    "255,\x20102,\x2029",
                    _0x417ca8(0x386),
                    "255,\x2051,\x2046",
                    "255,\x2026,\x2055",
                    _0x417ca8(0x3c1),
                  ],
                  [
                    _0x417ca8(0x3c1),
                    "255,\x2024,\x2055",
                    _0x417ca8(0x38c),
                    "255,\x2072,\x2039",
                    "255,\x2096,\x2032",
                    "255,\x20120,\x2024",
                    _0x417ca8(0x3cb),
                    _0x417ca8(0x36d),
                    _0x417ca8(0x3df),
                    "255,\x20168,\x208",
                    _0x417ca8(0x3cb),
                    _0x417ca8(0x22a),
                    _0x417ca8(0x3a6),
                    _0x417ca8(0x2eb),
                    _0x417ca8(0x38c),
                    _0x417ca8(0x298),
                    _0x417ca8(0x3c1),
                  ],
                ],
                payout_sd: [
                  [
                    _0x417ca8(0x283),
                    _0x417ca8(0x23c),
                    "#a80100",
                    _0x417ca8(0x228),
                    _0x417ca8(0x209),
                    "#aa4b00",
                    _0x417ca8(0x36e),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x283),
                  ],
                  [
                    _0x417ca8(0x283),
                    _0x417ca8(0x23c),
                    "#a70000",
                    _0x417ca8(0x271),
                    "#ab6500",
                    _0x417ca8(0x29a),
                    _0x417ca8(0x271),
                    _0x417ca8(0x3e3),
                    "#a60000",
                    _0x417ca8(0x283),
                  ],
                  [
                    _0x417ca8(0x283),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x3e3),
                    "#a82a00",
                    _0x417ca8(0x208),
                    _0x417ca8(0x209),
                    _0x417ca8(0x208),
                    _0x417ca8(0x247),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x283),
                  ],
                  [
                    _0x417ca8(0x283),
                    "#a60000",
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x2d8),
                    _0x417ca8(0x2dd),
                    _0x417ca8(0x234),
                    _0x417ca8(0x234),
                    "#a94700",
                    _0x417ca8(0x2d8),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x283),
                  ],
                  [
                    "#a60004",
                    _0x417ca8(0x23c),
                    _0x417ca8(0x23c),
                    "#a80100",
                    _0x417ca8(0x271),
                    "#aa5b00",
                    "#ab7900",
                    _0x417ca8(0x314),
                    _0x417ca8(0x271),
                    _0x417ca8(0x36e),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x283),
                  ],
                  [
                    "#a60004",
                    "#a60000",
                    "#a60000",
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x251),
                    _0x417ca8(0x35f),
                    "#ab6b00",
                    _0x417ca8(0x335),
                    _0x417ca8(0x35f),
                    "#a82e00",
                    _0x417ca8(0x3e3),
                    "#a60000",
                    "#a60000",
                    "#a60004",
                  ],
                  [
                    _0x417ca8(0x283),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x23c),
                    "#a70000",
                    _0x417ca8(0x3e7),
                    "#a94400",
                    "#aa6000",
                    "#ab7900",
                    _0x417ca8(0x384),
                    _0x417ca8(0x2f9),
                    _0x417ca8(0x3e7),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x23c),
                    "#a60004",
                  ],
                  [
                    _0x417ca8(0x283),
                    "#a60000",
                    _0x417ca8(0x23c),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x3ec),
                    _0x417ca8(0x271),
                    "#aa5500",
                    _0x417ca8(0x1c5),
                    _0x417ca8(0x1c5),
                    _0x417ca8(0x208),
                    _0x417ca8(0x271),
                    _0x417ca8(0x3ec),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x23c),
                    "#a60000",
                    _0x417ca8(0x283),
                  ],
                  [
                    _0x417ca8(0x283),
                    _0x417ca8(0x23c),
                    "#a60000",
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x36e),
                    _0x417ca8(0x313),
                    _0x417ca8(0x228),
                    _0x417ca8(0x2f6),
                    _0x417ca8(0x209),
                    _0x417ca8(0x2f6),
                    _0x417ca8(0x228),
                    "#a93000",
                    _0x417ca8(0x36e),
                    _0x417ca8(0x3e3),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x23c),
                    _0x417ca8(0x283),
                  ],
                ],
                payout_widths: [
                  0x55, 82.5, 81.2, 80.2, 79.2, 78.2, 77.5, 0x4d, 76.2,
                ],
              };
            },
            beforeMount: function () {
              var _0x56ca93 = _0x204af8;
              this[_0x56ca93(0x1cb)]();
            },
            beforeDestroy: function () {
              var _0x592db0 = _0x204af8;
              0x1 == this[_0x592db0(0x321)] && this[_0x592db0(0x36f)](),
                (this["animation_stop"] = !0x0);
            },
            mounted: function () {
              var _0x2b19d7 = _0x204af8;
              this[_0x2b19d7(0x394)](),
                (this[_0x2b19d7(0x311)] = { ball: 0x8, pin: 0x4 }),
                (this[_0x2b19d7(0x1b5)] = { width: 0x2f8, height: 0x23a }),
                (this["ballcolorinfo"] = {
                  red: { main: _0x2b19d7(0x2d5), shadow: _0x2b19d7(0x2ca) },
                  yellow: { main: "#FFBF03", shadow: _0x2b19d7(0x360) },
                  orange: { main: _0x2b19d7(0x233), shadow: "#CA4228" },
                }),
                (this["pi2"] = 0x2 * Math["PI"]),
                (this[_0x2b19d7(0x2af)] =
                  this[_0x2b19d7(0x205)][_0x2b19d7(0x244)]),
                (this["ctx"] = this[_0x2b19d7(0x2af)][_0x2b19d7(0x3ab)]("2d")),
                this[_0x2b19d7(0x2a2)](),
                window[_0x2b19d7(0x3c4)]
                  ? window["addEventListener"](
                      _0x2b19d7(0x26f),
                      this[_0x2b19d7(0x337)],
                      !0x1
                    )
                  : window[_0x2b19d7(0x3d8)] &&
                    window[_0x2b19d7(0x3d8)](
                      _0x2b19d7(0x368),
                      this[_0x2b19d7(0x337)]
                    ),
                this[_0x2b19d7(0x3f0)](this["rownum"]);
            },
            methods: _0x5dcbf6(
              _0x5dcbf6(
                {},
                Object(_0x36553c["b"])("plinko", [
                  _0x204af8(0x1ed),
                  _0x204af8(0x1d8),
                  _0x204af8(0x327),
                  "setAutodisabled",
                ])
              ),
              {},
              {
                selectrow: function (_0x26011e) {
                  var _0x20e61b = _0x204af8;
                  (this["rownum"] = _0x26011e),
                    this["ctx"][_0x20e61b(0x21e)](
                      0x0,
                      0x0,
                      this[_0x20e61b(0x1b5)][_0x20e61b(0x35b)],
                      this["canvasrectinfo"]["height"]
                    ),
                    0x0 == this[_0x20e61b(0x2d3)]
                      ? (this[_0x20e61b(0x253)] =
                          15.3 / (this[_0x20e61b(0x27a)] - 0.7))
                      : (this[_0x20e61b(0x253)] =
                          (this["pre_rownum"] - 0.7) /
                          (this[_0x20e61b(0x27a)] - 0.7)),
                    (this[_0x20e61b(0x2d3)] = this[_0x20e61b(0x27a)]),
                    this[_0x20e61b(0x237)]["translate"](
                      (this["canvasrectinfo"][_0x20e61b(0x35b)] *
                        (0x1 - this[_0x20e61b(0x253)])) /
                        0x2,
                      0x1e * (0x1 - this[_0x20e61b(0x253)])
                    ),
                    this[_0x20e61b(0x237)][_0x20e61b(0x376)](
                      this["ctx_scale"],
                      this[_0x20e61b(0x253)]
                    );
                },
                selectrisk: function (_0x5a1394) {
                  var _0x24f624 = _0x204af8;
                  this[_0x24f624(0x305)] = _0x5a1394;
                },
                drawpin: function (_0x312963) {
                  var _0x958683 = _0x204af8,
                    _0x1a6eef = _0x312963["x"],
                    _0x42168f = _0x312963["y"],
                    _0xd0633 = Date["now"]() - _0x312963["collisionTime"];
                  if (
                    0x0 !== _0x312963["collisionTime"] &&
                    _0xd0633 < this[_0x958683(0x1f5)]
                  ) {
                    var _0x549768 = _0xd0633 / this["pin_collision_time"],
                      _0x2c4a57 = 0x1 - _0x549768;
                    (this[_0x958683(0x237)][_0x958683(0x2e7)] =
                      "rgba(255,\x20255,\x20255,\x20" + 0.6 * _0x2c4a57 + ")"),
                      this[_0x958683(0x237)][_0x958683(0x2ef)](),
                      this[_0x958683(0x237)][_0x958683(0x38b)](
                        _0x1a6eef,
                        _0x42168f,
                        0xa * _0x549768 + _0x312963[_0x958683(0x347)],
                        0x0,
                        this[_0x958683(0x2c9)]
                      ),
                      this["ctx"][_0x958683(0x28a)]();
                  }
                  (this[_0x958683(0x237)][_0x958683(0x2e7)] = "#fff"),
                    this[_0x958683(0x237)]["beginPath"](),
                    this[_0x958683(0x237)]["arc"](
                      _0x1a6eef,
                      _0x42168f,
                      _0x312963["radius"],
                      0x0,
                      this["pi2"]
                    ),
                    this["ctx"][_0x958683(0x28a)](),
                    this[_0x958683(0x237)][_0x958683(0x3e9)]();
                },
                drawbar: function () {
                  for (
                    var _0x480fe8 = 0x0;
                    _0x480fe8 <= this["rownum"];
                    _0x480fe8++
                  )
                    this["fillRoundRect"](_0x480fe8);
                },
                getfcolor: function (_0x5a393a) {
                  var _0xdb1d4c = _0x204af8;
                  return _0x5a393a <= this[_0xdb1d4c(0x27a)] / 0x2
                    ? _0xdb1d4c(0x238) +
                        (0x180 / this["rownum"]) * _0x5a393a +
                        "," +
                        0x42 * (0x1 - (0x2 / this["rownum"]) * _0x5a393a) +
                        ")"
                    : _0xdb1d4c(0x238) +
                        0x180 * (0x1 - _0x5a393a / this[_0xdb1d4c(0x27a)]) +
                        "," +
                        0x42 *
                          (0x1 -
                            0x2 * (0x1 - _0x5a393a / this[_0xdb1d4c(0x27a)])) +
                        ")";
                },
                fillRoundRect: function (_0x4cb1e4) {
                  var _0x2d59e8 = _0x204af8,
                    _0x46028e,
                    _0x278608,
                    _0x44e884,
                    _0x529f10,
                    _0x3ec711 = 0x0,
                    _0x3ed9e4 = this[_0x2d59e8(0x310)](_0x4cb1e4);
                  (_0x46028e = this[_0x2d59e8(0x37a)][_0x4cb1e4]["x"]),
                    (_0x278608 = this[_0x2d59e8(0x37a)][_0x4cb1e4]["y"]),
                    (_0x44e884 = this[_0x2d59e8(0x37a)][_0x4cb1e4]["w"]),
                    (_0x529f10 = this[_0x2d59e8(0x37a)][_0x4cb1e4]["h"]);
                  var _0x2cf782 =
                    this[_0x2d59e8(0x3d9)][this[_0x2d59e8(0x305)]][
                      this["rownum"] - 0x8
                    ][_0x4cb1e4];
                  this[_0x2d59e8(0x37a)][_0x4cb1e4][_0x2d59e8(0x2bd)] > 0x0 &&
                    ((_0x3ec711 = 0.7 * this["barstat"][_0x4cb1e4]["h"]),
                    Date[_0x2d59e8(0x226)]() -
                      this["barstat"][_0x4cb1e4][_0x2d59e8(0x2bd)] >
                      0x64 && (this["barstat"][_0x4cb1e4]["dwn"] = 0x0)),
                    (this[_0x2d59e8(0x237)][_0x2d59e8(0x2e7)] = _0x3ed9e4),
                    this[_0x2d59e8(0x237)]["clearRect"](
                      _0x46028e - 0x1,
                      _0x278608 - 0x1,
                      _0x44e884 + 0x2,
                      _0x529f10 + 0x6 + 0x2
                    ),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x2ef)](),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x38b)](
                      _0x46028e + 0x3,
                      _0x278608 + 0x3 + _0x3ec711,
                      0x3,
                      0x0,
                      this[_0x2d59e8(0x2c9)]
                    ),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x38b)](
                      _0x46028e + 0x3,
                      _0x278608 + _0x529f10 - 0x3 + _0x3ec711,
                      0x3,
                      0x0,
                      this[_0x2d59e8(0x2c9)]
                    ),
                    this["ctx"][_0x2d59e8(0x38b)](
                      _0x46028e + _0x44e884 - 0x3,
                      _0x278608 + 0x3 + _0x3ec711,
                      0x3,
                      0x0,
                      this[_0x2d59e8(0x2c9)]
                    ),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x38b)](
                      _0x46028e + _0x44e884 - 0x3,
                      _0x278608 + _0x529f10 - 0x3 + _0x3ec711,
                      0x3,
                      0x0,
                      this[_0x2d59e8(0x2c9)]
                    ),
                    this["ctx"][_0x2d59e8(0x28a)](),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x1d5)](
                      _0x46028e,
                      _0x278608 + 0x3 + _0x3ec711,
                      _0x44e884,
                      _0x529f10 - 0x6
                    ),
                    this["ctx"][_0x2d59e8(0x1d5)](
                      _0x46028e + 0x3,
                      _0x278608 + _0x3ec711,
                      _0x44e884 - 0x6,
                      _0x529f10
                    ),
                    (this["ctx"][_0x2d59e8(0x227)] = "14px\x20Tahoma"),
                    (this["ctx"][_0x2d59e8(0x2e7)] = _0x2d59e8(0x1f9));
                  var _0x28b452 = _0x2cf782;
                  _0x2cf782 < 0x64 && (_0x28b452 += "x"),
                    this[_0x2d59e8(0x237)][_0x2d59e8(0x3c7)](
                      _0x28b452,
                      _0x46028e +
                        _0x44e884 / 0x2 -
                        (0x7 * _0x28b452["toString"]()[_0x2d59e8(0x397)]) / 0x2,
                      _0x278608 + 0xf + _0x3ec711
                    );
                },
                showscore: function () {
                  var _0x4c773f = _0x204af8;
                  for (
                    var _0x29b641 = this[_0x4c773f(0x1b5)]["width"] - 0x46,
                      _0x17c8f5 = 0xb4,
                      _0xa55d53 = 0x28,
                      _0x4361cf = 0x1;
                    _0x4361cf <= this[_0x4c773f(0x1cc)];
                    _0x4361cf++
                  ) {
                    this[_0x4c773f(0x237)][_0x4c773f(0x2ef)](),
                      (this[_0x4c773f(0x237)][_0x4c773f(0x2e7)] =
                        this[_0x4c773f(0x1be)][_0x4361cf]["col"]),
                      this[_0x4c773f(0x237)][_0x4c773f(0x21e)](
                        _0x29b641,
                        _0x17c8f5 + _0x4361cf * _0xa55d53,
                        _0xa55d53,
                        0x27
                      ),
                      this["ctx"]["fill"](),
                      this[_0x4c773f(0x237)]["beginPath"](),
                      0x1 == _0x4361cf
                        ? (this["ctx"][_0x4c773f(0x38b)](
                            _0x29b641 + 0x3,
                            _0x17c8f5 + _0x4361cf * _0xa55d53 + 0x3,
                            0x2,
                            0x0,
                            this[_0x4c773f(0x2c9)]
                          ),
                          this[_0x4c773f(0x237)]["arc"](
                            _0x29b641 + _0xa55d53 - 0x3,
                            _0x17c8f5 + _0x4361cf * _0xa55d53 + 0x3,
                            0x2,
                            0x0,
                            this[_0x4c773f(0x2c9)]
                          ),
                          this[_0x4c773f(0x237)][_0x4c773f(0x28a)](),
                          this["ctx"][_0x4c773f(0x1d5)](
                            _0x29b641,
                            _0x17c8f5 + _0x4361cf * _0xa55d53 + 0x3,
                            _0xa55d53,
                            0x24
                          ),
                          this[_0x4c773f(0x237)][_0x4c773f(0x1d5)](
                            _0x29b641 + 0x3,
                            _0x17c8f5 + _0x4361cf * _0xa55d53,
                            0x22,
                            0x27
                          ))
                        : 0x4 == _0x4361cf
                        ? (this["ctx"][_0x4c773f(0x38b)](
                            _0x29b641 + 0x3,
                            _0x17c8f5 +
                              (_0x4361cf + 0x1) * _0xa55d53 -
                              0x3 -
                              0x1,
                            0x2,
                            0x0,
                            this["pi2"]
                          ),
                          this[_0x4c773f(0x237)][_0x4c773f(0x38b)](
                            _0x29b641 + _0xa55d53 - 0x3,
                            _0x17c8f5 +
                              (_0x4361cf + 0x1) * _0xa55d53 -
                              0x3 -
                              0x1,
                            0x2,
                            0x0,
                            this["pi2"]
                          ),
                          this[_0x4c773f(0x237)]["fill"](),
                          this[_0x4c773f(0x237)][_0x4c773f(0x1d5)](
                            _0x29b641,
                            _0x17c8f5 + _0x4361cf * _0xa55d53,
                            _0xa55d53,
                            0x24
                          ),
                          this[_0x4c773f(0x237)][_0x4c773f(0x1d5)](
                            _0x29b641 + 0x3,
                            _0x17c8f5 + _0x4361cf * _0xa55d53,
                            0x22,
                            0x27
                          ))
                        : this[_0x4c773f(0x237)][_0x4c773f(0x1d5)](
                            _0x29b641,
                            _0x17c8f5 + _0x4361cf * _0xa55d53,
                            _0xa55d53,
                            0x27
                          );
                    var _0x216c88 =
                      this[_0x4c773f(0x1be)][_0x4361cf][_0x4c773f(0x1d7)];
                    _0x216c88 < 0x64 && (_0x216c88 += "x"),
                      (this[_0x4c773f(0x237)]["font"] = "14px\x20Tahoma"),
                      (this[_0x4c773f(0x237)][_0x4c773f(0x2e7)] =
                        _0x4c773f(0x1f9)),
                      this[_0x4c773f(0x237)][_0x4c773f(0x3c7)](
                        _0x216c88,
                        _0x29b641 +
                          0x14 -
                          (0x7 *
                            _0x216c88[_0x4c773f(0x2ce)]()[_0x4c773f(0x397)]) /
                            0x2,
                        _0x17c8f5 + _0x4361cf * _0xa55d53 + 0x18
                      );
                  }
                },
                calcAngle: function (_0x54161d, _0x41f1d5) {
                  var _0x29059b = _0x204af8,
                    _0xd6c105 = _0x41f1d5["y"] - _0x54161d["y"],
                    _0x37bb39 = _0x41f1d5["x"] - _0x54161d["x"],
                    _0x37c79b = Math[_0x29059b(0x3e8)](_0xd6c105, _0x37bb39);
                  return (
                    (_0x37c79b *= 0xb4 / Math["PI"]) < 0x0 &&
                      (_0x37c79b = 0x168 + _0x37c79b),
                    0x168 - _0x37c79b
                  );
                },
                checkCollision: function (_0x6a2bb8, _0x3a679c) {
                  var _0xc4de90 = _0x204af8,
                    _0x56f353 =
                      this[_0xc4de90(0x3c9)][_0x3a679c]["x"] - _0x6a2bb8["x"],
                    _0x5232df =
                      this[_0xc4de90(0x3c9)][_0x3a679c]["y"] - _0x6a2bb8["y"];
                  if (
                    Math[_0xc4de90(0x3c5)](
                      _0x56f353 * _0x56f353 + _0x5232df * _0x5232df
                    ) <
                    this[_0xc4de90(0x311)][_0xc4de90(0x3c9)] +
                      _0x6a2bb8[_0xc4de90(0x347)]
                  ) {
                    var _0x47fa9b = this["calcAngle"](_0x6a2bb8, {
                      x: this[_0xc4de90(0x3c9)][_0x3a679c]["x"],
                      y: this[_0xc4de90(0x3c9)][_0x3a679c]["y"],
                    });
                    return (
                      (this[_0xc4de90(0x3c9)][_0x3a679c][_0xc4de90(0x278)] =
                        this[_0xc4de90(0x3c9)][_0x3a679c][_0xc4de90(0x278)] +
                        0x1),
                      { isCollision: !0x0, angle: _0x47fa9b, target: _0x6a2bb8 }
                    );
                  }
                  return { isCollision: !0x1 };
                },
                getCollistionPinByRow: function (
                  _0x5e0a13,
                  _0x2a218f,
                  _0x4eba74,
                  _0x569712
                ) {
                  var _0x430f75 = _0x204af8,
                    _0x3b94c0 = this["pin_points"][_0x2a218f][_0x5e0a13];
                  if (
                    this["checkCollision"](_0x3b94c0, _0x4eba74)[
                      _0x430f75(0x20c)
                    ]
                  )
                    return (
                      (this[_0x430f75(0x3c9)][_0x4eba74]["colliedx"] =
                        _0x2a218f),
                      (this[_0x430f75(0x3c9)][_0x4eba74][_0x430f75(0x26b)] =
                        _0x5e0a13),
                      (this["pin_points"][_0x2a218f][_0x5e0a13][
                        _0x430f75(0x1b8)
                      ] = _0x569712),
                      { v: this[_0x430f75(0x2b9)](_0x3b94c0, _0x4eba74) }
                    );
                },
                getCollisonPin: function (_0x79d4b4, _0x12c9f1, _0x4063ca) {
                  var _0xfd34e1 = _0x204af8,
                    _0x426685 = _0x79d4b4[_0xfd34e1(0x373)],
                    _0x1624f4 = _0x79d4b4[_0xfd34e1(0x2cf)],
                    _0x5a6bac = Math[_0xfd34e1(0x2e8)](
                      Math["abs"](
                        (this[_0xfd34e1(0x3c9)][_0x4063ca]["y"] -
                          _0x1624f4 +
                          this[_0xfd34e1(0x357)][0x0][0x0][_0xfd34e1(0x347)]) /
                          _0x426685[_0xfd34e1(0x367)]
                      )
                    );
                  if (this[_0xfd34e1(0x357)][_0x5a6bac])
                    for (
                      var _0x34b965 = 0x0;
                      _0x34b965 <
                      this["pin_points"][_0x5a6bac][_0xfd34e1(0x397)];
                      _0x34b965 += 0x1
                    ) {
                      var _0x390dcb = this[_0xfd34e1(0x332)](
                        _0x34b965,
                        _0x5a6bac,
                        _0x4063ca,
                        _0x12c9f1
                      );
                      if ("object" == Object(_0x3e1a6e["a"])(_0x390dcb))
                        return _0x390dcb["v"];
                    }
                  return { isCollision: !0x1 };
                },
                toRadian: function (_0x4f7fac) {
                  return (_0x4f7fac * Math["PI"]) / 0xb4;
                },
                calcball: function (_0x460b9f, _0x487d0c, _0x5c10a9) {
                  var _0x2f36f1 = _0x204af8,
                    _0x594495,
                    _0x1bc7a4,
                    _0x5a7b10 = this["getCollisonPin"](
                      _0x460b9f,
                      _0x487d0c,
                      _0x5c10a9
                    );
                  if (_0x5a7b10[_0x2f36f1(0x20c)]) {
                    var _0x21bfab = _0x5a7b10[_0x2f36f1(0x312)],
                      _0x267cbe = _0x5a7b10[_0x2f36f1(0x1eb)],
                      _0x599846 = this[_0x2f36f1(0x3aa)](_0x21bfab),
                      _0x21f226 = Math[_0x2f36f1(0x2b1)](_0x599846),
                      _0x298ce6 = Math["cos"](_0x599846);
                    (_0x594495 =
                      _0x267cbe["x"] +
                      _0x298ce6 *
                        (this[_0x2f36f1(0x311)]["ball"] +
                          this[_0x2f36f1(0x311)][_0x2f36f1(0x3b5)] +
                          0.00001)),
                      (_0x1bc7a4 =
                        _0x267cbe["y"] -
                        _0x21f226 *
                          (this[_0x2f36f1(0x311)][_0x2f36f1(0x3c9)] +
                            this["radiusinfo"][_0x2f36f1(0x3b5)] +
                            0.00001));
                    var _0x139fae =
                        -_0x21f226 *
                        this[_0x2f36f1(0x3c9)][_0x5c10a9]["vy"] *
                        this[_0x2f36f1(0x1bc)],
                      _0x225e18 =
                        _0x298ce6 *
                        this[_0x2f36f1(0x3c9)][_0x5c10a9]["vy"] *
                        this["offset_ratio"];
                    (this["ball"][_0x5c10a9]["vx"] = _0x225e18),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["vy"] = _0x139fae),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["x"] += _0x225e18),
                      (this["ball"][_0x5c10a9]["y"] += _0x139fae),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["x"] = _0x594495),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["y"] = _0x1bc7a4);
                  } else {
                    var _0x4dc9bf =
                        this[_0x2f36f1(0x3c9)][_0x5c10a9]["vy"] +
                        this[_0x2f36f1(0x1b6)],
                      _0x211c6e =
                        this[_0x2f36f1(0x3c9)][_0x5c10a9]["vx"] -
                        (0x1 * this[_0x2f36f1(0x3c9)][_0x5c10a9]["vx"]) / 0x6e;
                    (this[_0x2f36f1(0x3c9)][_0x5c10a9]["x"] += _0x211c6e),
                      (this["ball"][_0x5c10a9]["y"] += _0x4dc9bf),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["vx"] = _0x211c6e),
                      (this[_0x2f36f1(0x3c9)][_0x5c10a9]["vy"] = _0x4dc9bf);
                  }
                },
                checkBallFloor: function (_0x518c14) {
                  var _0x2b5b0a = _0x204af8,
                    _0x5b67d5 = -0x1;
                  if (
                    this["ball"][_0x518c14]["y"] >=
                    this[_0x2b5b0a(0x357)][this[_0x2b5b0a(0x27a)] - 0x1][0x0][
                      "y"
                    ] +
                      this["radiusinfo"][_0x2b5b0a(0x3c9)]
                  ) {
                    for (
                      _0x5b67d5 = -0x1;
                      _0x5b67d5 <= this[_0x2b5b0a(0x27a)] &&
                      this[_0x2b5b0a(0x357)][this[_0x2b5b0a(0x27a)] - 0x1][
                        _0x5b67d5 + 0x1
                      ]["x"] < this[_0x2b5b0a(0x3c9)][_0x518c14]["x"];
                      _0x5b67d5++
                    );
                    _0x5b67d5 > this[_0x2b5b0a(0x27a)] &&
                      (_0x5b67d5 = this[_0x2b5b0a(0x27a)]),
                      -0x1 == _0x5b67d5 && (_0x5b67d5 = 0x0),
                      setTimeout(this[_0x2b5b0a(0x24f)], 0x1, _0x5b67d5),
                      this[_0x2b5b0a(0x342)](_0x5b67d5),
                      this["addBetList"](_0x5b67d5);
                    for (
                      var _0x13b060 = this["ball"][_0x518c14]["betid"],
                        _0x11954f = _0x518c14;
                      _0x11954f < this[_0x2b5b0a(0x1d7)];
                      _0x11954f++
                    )
                      this[_0x2b5b0a(0x3c9)][_0x11954f] =
                        this[_0x2b5b0a(0x3c9)][_0x11954f + 0x1];
                    return (
                      this[_0x2b5b0a(0x1d7)]--,
                      0x0 == this[_0x2b5b0a(0x1d7)] &&
                        this["setSetdisabled"](!0x1),
                      this[_0x2b5b0a(0x1c0)](_0x13b060),
                      0x1
                    );
                  }
                  return 0x0;
                },
                drawball: function (_0x415bea, _0x57673e) {
                  var _0x329704 = _0x204af8;
                  for (
                    var _0x10e408 =
                        this[_0x329704(0x20b)][
                          this["ballcolor_idxs"][this["risk"]]
                        ],
                      _0x137f78 = _0x10e408["main"],
                      _0x4b80b5 = _0x10e408["shadow"],
                      _0x306e17 = this[_0x329704(0x311)]["ball"],
                      _0x10c4c1 = 0x1;
                    _0x10c4c1 <= this[_0x329704(0x1d7)];
                    _0x10c4c1++
                  ) {
                    var _0x3cdb24 = this["ball"][_0x10c4c1]["x"],
                      _0x453dc5 = this[_0x329704(0x3c9)][_0x10c4c1]["y"] - 0x1;
                    if (this[_0x329704(0x1bb)](_0x10c4c1)) _0x10c4c1--;
                    else {
                      this[_0x329704(0x2b2)](_0x415bea, _0x57673e, _0x10c4c1),
                        this[_0x329704(0x237)][_0x329704(0x2ef)](),
                        (this[_0x329704(0x237)][_0x329704(0x2e7)] = _0x4b80b5),
                        this["ctx"][_0x329704(0x38b)](
                          _0x3cdb24,
                          _0x453dc5,
                          this[_0x329704(0x311)][_0x329704(0x3c9)],
                          0x0,
                          this["pi2"]
                        ),
                        this[_0x329704(0x237)][_0x329704(0x28a)]();
                      var _0x46f634 = _0x453dc5 - 0x1;
                      this[_0x329704(0x237)][_0x329704(0x2ef)](),
                        (this[_0x329704(0x237)][_0x329704(0x2e7)] = _0x137f78),
                        this[_0x329704(0x237)][_0x329704(0x38b)](
                          _0x3cdb24,
                          _0x46f634,
                          _0x306e17,
                          0x0,
                          this[_0x329704(0x2c9)]
                        ),
                        this[_0x329704(0x237)]["fill"](),
                        this[_0x329704(0x237)][_0x329704(0x2ef)](),
                        (this[_0x329704(0x237)][_0x329704(0x2e7)] = _0x4b80b5),
                        this["ctx"][_0x329704(0x38b)](
                          _0x3cdb24,
                          _0x46f634,
                          _0x306e17 / 1.5,
                          0x0,
                          this[_0x329704(0x2c9)]
                        ),
                        this[_0x329704(0x237)][_0x329704(0x28a)](),
                        this[_0x329704(0x237)]["beginPath"](),
                        (this[_0x329704(0x237)][_0x329704(0x2e7)] = _0x137f78),
                        this[_0x329704(0x237)][_0x329704(0x38b)](
                          _0x3cdb24,
                          _0x46f634,
                          _0x306e17 / 0x2,
                          0x0,
                          this[_0x329704(0x2c9)]
                        ),
                        this["ctx"][_0x329704(0x28a)](),
                        this[_0x329704(0x237)][_0x329704(0x3e9)]();
                    }
                  }
                },
                drawballForCalc: function (_0xa593e0, _0x343ad3) {
                  var _0x1968ad = _0x204af8;
                  for (
                    var _0x1ee63b = this[_0x1968ad(0x20b)][_0x1968ad(0x35d)],
                      _0x55dd1c =
                        (_0x1ee63b[_0x1968ad(0x296)],
                        _0x1ee63b[_0x1968ad(0x232)],
                        this[_0x1968ad(0x311)][_0x1968ad(0x3c9)],
                        0x1);
                    _0x55dd1c <= this[_0x1968ad(0x1d7)];
                    _0x55dd1c++
                  ) {
                    return (
                      this[_0x1968ad(0x3c9)][_0x55dd1c]["x"],
                      this[_0x1968ad(0x3c9)][_0x55dd1c]["y"],
                      this["checkBallFloor"](_0x55dd1c)
                        ? (_0x55dd1c--, !0x0)
                        : (this[_0x1968ad(0x2b2)](
                            _0xa593e0,
                            _0x343ad3,
                            _0x55dd1c
                          ),
                          !0x1)
                    );
                  }
                },
                start: function () {
                  var _0x2beff4 = _0x204af8;
                  this[_0x2beff4(0x3ef)]();
                },
                auto: function () {
                  var _0x31e7e2 = _0x204af8;
                  if (0x0 != this[_0x31e7e2(0x321)]) {
                    if (!document[_0x31e7e2(0x302)]) {
                      if (
                        ((this[_0x31e7e2(0x1bd)] =
                          this[_0x31e7e2(0x1bd)] + 0x1),
                        this[_0x31e7e2(0x389)] > 0x0 &&
                          this[_0x31e7e2(0x1bd)] > this[_0x31e7e2(0x389)])
                      )
                        return (
                          (this["betcount"] = 0x0),
                          this["$emit"](_0x31e7e2(0x2d9), null),
                          void this[_0x31e7e2(0x1d1)](_0x31e7e2(0x2dc))
                        );
                      this[_0x31e7e2(0x389)] > 0x0 &&
                        this[_0x31e7e2(0x389)] - this[_0x31e7e2(0x1bd)] >=
                          0x0 &&
                        this[_0x31e7e2(0x1d1)](
                          _0x31e7e2(0x2d9),
                          this[_0x31e7e2(0x389)] - this["autocount"]
                        ),
                        this["bet"]();
                    }
                    setTimeout(this[_0x31e7e2(0x3a9)], 0x4b0);
                  }
                },
                autostart: function () {
                  var _0x7c913f = _0x204af8;
                  (this[_0x7c913f(0x1bd)] = 0x0),
                    this["setAutodisabled"](!0x0),
                    (this[_0x7c913f(0x321)] = !0x0),
                    this["auto"]();
                },
                autostop: function () {
                  var _0x5e524e = _0x204af8;
                  (this[_0x5e524e(0x321)] = !0x1),
                    this[_0x5e524e(0x352)](!0x1),
                    setTimeout(this[_0x5e524e(0x34c)], 0x1);
                },
                start0: function (_0x165a3d, _0x21c197) {
                  var _0x55aeb3 = _0x204af8;
                  this["num"]++,
                    (this[_0x55aeb3(0x3c9)][this[_0x55aeb3(0x1d7)]] = {
                      x: _0x21c197,
                      y: 0x0,
                      vx: 0x0,
                      vy: 0x0,
                      colliedx: -0x1,
                      colliedy: -0x1,
                      betid: _0x165a3d,
                      collision: 0x0,
                      startx: _0x21c197,
                    });
                },
                pinCalc: function (
                  _0x14df92,
                  _0x52d712,
                  _0x121385,
                  _0x1de964,
                  _0x4099db
                ) {
                  var _0x161557 = _0x204af8;
                  for (
                    var _0x5a3ab6 = [], _0x6d85a5 = 0x0;
                    _0x6d85a5 < _0x52d712;
                    _0x6d85a5 += 0x1
                  ) {
                    _0x5a3ab6[_0x6d85a5] = [];
                    for (
                      var _0x26b879 = 0x3 + _0x6d85a5,
                        _0x3f493d =
                          _0x14df92 -
                          ((0x1 * _0x26b879) / 0x2) *
                            _0x121385[_0x161557(0x35b)],
                        _0x4aef7e = 0x0;
                      _0x4aef7e < _0x26b879;
                      _0x4aef7e += 0x1
                    )
                      _0x5a3ab6[_0x6d85a5][_0x161557(0x295)]({
                        x: _0x3f493d + (_0x4aef7e + 0.5) * _0x121385["width"],
                        y:
                          _0x6d85a5 * _0x121385[_0x161557(0x367)] +
                          _0x1de964 +
                          _0x4099db,
                        radius: _0x1de964,
                        collisionTime: 0x0,
                      });
                  }
                  return _0x5a3ab6;
                },
                toCeil: function (_0x5ef44f) {
                  var _0x2b3034 = _0x204af8;
                  return (
                    (0.1 * Math[_0x2b3034(0x306)](0x2540be400 * _0x5ef44f)) /
                    0x2540be400
                  );
                },
                calcCanv: function () {
                  var _0x1a5fae = _0x204af8;
                  (this[_0x1a5fae(0x3af)] = {
                    canvasHeight: this[_0x1a5fae(0x1b5)][_0x1a5fae(0x367)],
                    canvasWidth: this["canvasrectinfo"][_0x1a5fae(0x35b)],
                    margin: 0x46,
                    marginTop: 0x1e,
                    marginBottom: 0x14,
                    rows: 0x10,
                    middleX: (0x1 * this[_0x1a5fae(0x1b5)]["width"]) / 0x2,
                    pinSpacing: {
                      height:
                        (0x1 *
                          (this["canvasrectinfo"]["height"] -
                            0x2 * this[_0x1a5fae(0x311)][_0x1a5fae(0x3b5)] -
                            0x1e -
                            0x14)) /
                        0xf,
                      width:
                        (0x1 *
                          (this[_0x1a5fae(0x1b5)][_0x1a5fae(0x35b)] - 0x8c)) /
                        0x12,
                    },
                    totalPins: 0x13,
                    columnOnTop: 0x3,
                    pinAreaHeight:
                      this[_0x1a5fae(0x1b5)][_0x1a5fae(0x367)] - 0x1e - 0x14,
                    pinRadius: this[_0x1a5fae(0x311)][_0x1a5fae(0x3b5)],
                  }),
                    (this[_0x1a5fae(0x357)] = this["pinCalc"](
                      this["canvas_values"][_0x1a5fae(0x23d)],
                      0x10,
                      this[_0x1a5fae(0x3af)][_0x1a5fae(0x373)],
                      this[_0x1a5fae(0x311)][_0x1a5fae(0x3b5)],
                      0x1e
                    ));
                  for (var _0x51dd68 = 0x0; _0x51dd68 <= 0x10; _0x51dd68++) {
                    var _0x21c76d =
                        this["pin_points"][0xf][0x1]["x"] -
                        this[_0x1a5fae(0x357)][0xf][0x0]["x"] -
                        0x2,
                      _0x144877 =
                        this[_0x1a5fae(0x357)][0xf][_0x51dd68]["x"] + 0x1;
                    this[_0x1a5fae(0x37a)][_0x51dd68] = {
                      x: _0x144877,
                      y: this[_0x1a5fae(0x1b5)]["height"],
                      w: _0x21c76d,
                      h: 0x16,
                      dwn: 0x0,
                    };
                  }
                },
                drwCanv: function () {
                  var _0x961fb3 = _0x204af8;
                  this[_0x961fb3(0x237)][_0x961fb3(0x21e)](
                    0x0,
                    0x0,
                    this["canv"][_0x961fb3(0x35b)],
                    this["canv"][_0x961fb3(0x367)]
                  );
                  for (var _0x11c025 = 0x0; _0x11c025 < 0x10; _0x11c025++)
                    for (
                      var _0x3edbb9 = 0x0;
                      _0x3edbb9 <= _0x11c025 + 0x2;
                      _0x3edbb9++
                    )
                      this[_0x961fb3(0x27b)](
                        this[_0x961fb3(0x357)][_0x11c025][_0x3edbb9]
                      ),
                        this["pin_points"][_0x11c025][_0x3edbb9][
                          _0x961fb3(0x1b8)
                        ] > 0x0 && this[_0x961fb3(0x329)](_0x11c025, _0x3edbb9);
                  this[_0x961fb3(0x1fc)](
                    this["canvas_values"],
                    Date[_0x961fb3(0x226)]()
                  );
                },
                drawfade: function (_0x541181, _0x42d97f) {
                  var _0x376642 = _0x204af8,
                    _0x33dac9 = this[_0x376642(0x357)][_0x541181][_0x42d97f],
                    _0x589153 = _0x33dac9["x"],
                    _0x24589e = _0x33dac9["y"],
                    _0x31fc36 = _0x33dac9["collisionTime"],
                    _0x184cb7 = this[_0x376642(0x311)][_0x376642(0x3b5)],
                    _0x39cfa4 = 0x0,
                    _0x5b987f = Date[_0x376642(0x226)]() - _0x31fc36;
                  if (0x0 !== _0x31fc36 && _0x5b987f < this[_0x376642(0x1f5)]) {
                    var _0x2299e2 =
                      0x1 -
                      (_0x39cfa4 = _0x5b987f / this["pin_collision_time"]);
                    (this["ctx"][_0x376642(0x2e7)] =
                      _0x376642(0x1e5) + 0.6 * _0x2299e2 + ")"),
                      this[_0x376642(0x237)][_0x376642(0x2ef)](),
                      this[_0x376642(0x237)][_0x376642(0x38b)](
                        _0x589153,
                        _0x24589e,
                        0xa * _0x39cfa4 + _0x184cb7,
                        0x0,
                        this[_0x376642(0x2c9)]
                      ),
                      this[_0x376642(0x237)]["fill"]();
                  } else
                    this["pin_points"][_0x541181][_0x42d97f][
                      _0x376642(0x1b8)
                    ] = 0x0;
                  (this["ctx"]["fillStyle"] = _0x376642(0x2ac)),
                    this[_0x376642(0x237)][_0x376642(0x2ef)](),
                    this[_0x376642(0x237)][_0x376642(0x38b)](
                      _0x589153,
                      _0x24589e,
                      _0x184cb7,
                      0x0,
                      this[_0x376642(0x2c9)]
                    ),
                    this[_0x376642(0x237)][_0x376642(0x28a)](),
                    this[_0x376642(0x237)][_0x376642(0x3e9)]();
                },
                winsize: function () {
                  var _0x111500 = _0x204af8;
                  if (void 0x0 !== this[_0x111500(0x205)][_0x111500(0x25c)]) {
                    var _0x401a8f =
                      (0x1 *
                        this["$refs"][_0x111500(0x25c)][_0x111500(0x25e)]) /
                      0x2ee;
                    this[_0x111500(0x205)]["gamepane"][_0x111500(0x32b)][
                      _0x111500(0x1e6)
                    ] = _0x401a8f + "em";
                    var _0x2bde36 = 0x276 * _0x401a8f;
                    this[_0x111500(0x205)]["gamepane"][_0x111500(0x37b)][
                      _0x111500(0x32b)
                    ]["minHeight"] = _0x2bde36 + "px";
                  }
                },
                step: function (_0x1d2c38) {
                  var _0x46f683 = _0x204af8;
                  0x0 == this[_0x46f683(0x345)] &&
                    (this["drwCanv"](),
                    window[_0x46f683(0x1dd)](this[_0x46f683(0x35a)]));
                },
                init: function () {
                  var _0x28873a = _0x204af8;
                  (this["audioCtx"] = new (window["AudioContext"] ||
                    window[_0x28873a(0x328)])()),
                    this[_0x28873a(0x337)](),
                    this[_0x28873a(0x2a9)](),
                    window[_0x28873a(0x1dd)](this[_0x28873a(0x35a)]);
                },
                get_ratios: function () {
                  var _0x40991b = _0x204af8,
                    _0x2e36bf = this;
                  this[_0x40991b(0x2bb)][_0x40991b(0x346)]["PlinkoRepository"]
                    ["show"]()
                    [_0x40991b(0x2da)](function (_0x165658) {
                      var _0x7980a3 = _0x40991b,
                        _0x291eb8 = _0x165658["data"];
                      _0x2e36bf[_0x7980a3(0x3d9)] = _0x291eb8;
                    })
                    [_0x40991b(0x340)](function (_0x52eac1) {
                      var _0x3f791e = _0x40991b;
                      _0x2e36bf[_0x3f791e(0x371)][_0x3f791e(0x26c)](_0x52eac1);
                    });
                },
                listen: function (_0x17a98a) {
                  var _0x35d7a2 = _0x204af8;
                  if (_0x17a98a["success"]) {
                    var _0x51f618 = _0x17a98a["id"],
                      _0x585a2d = _0x17a98a["bx"];
                    this[_0x35d7a2(0x3dc)](_0x51f618, _0x585a2d),
                      this[_0x35d7a2(0x1ed)](!0x1);
                  } else
                    this[_0x35d7a2(0x1d1)](_0x35d7a2(0x2a7)),
                      this[_0x35d7a2(0x1d1)](_0x35d7a2(0x236)),
                      this[_0x35d7a2(0x1ed)](!0x1),
                      this[_0x35d7a2(0x1d8)](!0x1),
                      0x1 == this[_0x35d7a2(0x321)] && this[_0x35d7a2(0x36f)](),
                      this["$swal2"][_0x35d7a2(0x26c)](_0x17a98a["message"]);
                },
                bet: function () {
                  var _0x667401 = _0x204af8,
                    _0x5aa1fb = this;
                  ((0x1 == this[_0x667401(0x321)] &&
                    0x1 == this[_0x667401(0x1bd)]) ||
                    0x0 == this[_0x667401(0x321)]) &&
                    setTimeout(this[_0x667401(0x34c)], 0x1),
                    this[_0x667401(0x1ed)](!0x0),
                    this[_0x667401(0x1d8)](!0x0),
                    this["$repositories"][_0x667401(0x346)]["PlinkoRepository"]
                      ["create"]({
                        rownum: this[_0x667401(0x27a)],
                        risk: this[_0x667401(0x305)],
                        amount: this[_0x667401(0x3ac)],
                      })
                      [_0x667401(0x2da)](function (_0x3d096b) {
                        var _0x1e579e = _0x667401,
                          _0x18288a = _0x3d096b[_0x1e579e(0x330)],
                          _0x57dc60 = _0x18288a["id"],
                          _0x475143 = _0x18288a["bx"];
                        _0x5aa1fb[_0x1e579e(0x3dc)](_0x57dc60, _0x475143),
                          _0x5aa1fb[_0x1e579e(0x1ed)](!0x1);
                      })
                      ["catch"](function (_0x5d94b7) {
                        var _0x44af51 = _0x667401;
                        _0x5aa1fb[_0x44af51(0x1d1)](_0x44af51(0x2a7)),
                          _0x5aa1fb["$emit"](_0x44af51(0x236)),
                          _0x5aa1fb[_0x44af51(0x1ed)](!0x1),
                          _0x5aa1fb[_0x44af51(0x1d8)](!0x1),
                          0x1 == _0x5aa1fb[_0x44af51(0x321)] &&
                            _0x5aa1fb[_0x44af51(0x36f)](),
                          _0x5aa1fb["$swal2"][_0x44af51(0x26c)](_0x5d94b7);
                      }),
                    this[_0x667401(0x1d1)](_0x667401(0x2a7));
                },
                betend: function (_0x3c7203) {
                  var _0x16957b = _0x204af8,
                    _0x665f9c = this;
                  return Object(_0x4b515b["a"])(
                    regeneratorRuntime[_0x16957b(0x2b3)](function _0x33b203() {
                      var _0x231632 = _0x16957b;
                      return regeneratorRuntime[_0x231632(0x341)](function (
                        _0x118552
                      ) {
                        var _0x586b16 = _0x231632;
                        for (;;)
                          switch (
                            (_0x118552[_0x586b16(0x3a8)] =
                              _0x118552[_0x586b16(0x36c)])
                          ) {
                            case 0x0:
                              _0x3c7203 &&
                                _0x665f9c[_0x586b16(0x2bb)][_0x586b16(0x346)][
                                  _0x586b16(0x25b)
                                ][_0x586b16(0x39b)](_0x3c7203);
                            case 0x1:
                            case _0x586b16(0x2a4):
                              return _0x118552["stop"]();
                          }
                      },
                      _0x33b203);
                    })
                  )();
                },
                changePayout: function () {
                  var _0x4d22cc = _0x204af8;
                  for (
                    var _0x3d6a78 = "", _0x47c6e4 = 0x0;
                    _0x47c6e4 <
                    this[_0x4d22cc(0x291)][this["rownum"] - 0x8][
                      _0x4d22cc(0x397)
                    ];
                    _0x47c6e4++
                  ) {
                    var _0xc54e3c =
                      this[_0x4d22cc(0x3d9)][this[_0x4d22cc(0x305)]][
                        this[_0x4d22cc(0x27a)] - 0x8
                      ][_0x47c6e4];
                    _0xc54e3c < 0x64 && (_0xc54e3c += "×"),
                      (_0x3d6a78 +=
                        _0x4d22cc(0x270) +
                        this["payout_bg"][this[_0x4d22cc(0x27a)] - 0x8][
                          _0x47c6e4
                        ] +
                        _0x4d22cc(0x20d) +
                        this[_0x4d22cc(0x38d)][this["rownum"] - 0x8][
                          _0x47c6e4
                        ] +
                        _0x4d22cc(0x1cf) +
                        _0xc54e3c +
                        _0x4d22cc(0x217));
                  }
                  (this[_0x4d22cc(0x205)][_0x4d22cc(0x245)]["innerHTML"] =
                    _0x3d6a78),
                    (this[_0x4d22cc(0x205)]["payoutContainer"][
                      _0x4d22cc(0x32b)
                    ][_0x4d22cc(0x35b)] =
                      this[_0x4d22cc(0x2a0)][this[_0x4d22cc(0x27a)] - 0x8] +
                      "%");
                },
                setPayoutHighligted: function (_0x2b1a4f) {
                  var _0x47b712 = _0x204af8;
                  this[_0x47b712(0x205)]["payoutContainer"]["children"][
                    _0x2b1a4f
                  ]["classList"][_0x47b712(0x3e6)](_0x47b712(0x21c)),
                    setTimeout(this[_0x47b712(0x3c0)], 0x136, _0x2b1a4f);
                },
                clearPayoutHighlighted: function (_0x545ff4) {
                  var _0xe7d155 = _0x204af8;
                  this[_0xe7d155(0x205)][_0xe7d155(0x245)][_0xe7d155(0x3b4)][
                    _0x545ff4
                  ][_0xe7d155(0x2c7)][_0xe7d155(0x30e)]("highlighted");
                },
                addBetList: function (_0x53106e) {
                  var _0x395c14 = _0x204af8;
                  this[_0x395c14(0x205)]["betContainer"][_0x395c14(0x3b4)][
                    _0x395c14(0x397)
                  ] >= 0x6 &&
                    this["$refs"][_0x395c14(0x30d)]["removeChild"](
                      this[_0x395c14(0x205)][_0x395c14(0x30d)][_0x395c14(0x315)]
                    );
                  var _0xf00cb1 =
                    this[_0x395c14(0x3d9)][this[_0x395c14(0x305)]][
                      this["rownum"] - 0x8
                    ][_0x53106e];
                  _0xf00cb1 < 0x64 && (_0xf00cb1 += "×");
                  var _0x2ffd8d =
                    _0x395c14(0x396) +
                    this[_0x395c14(0x291)][this[_0x395c14(0x27a)] - 0x8][
                      _0x53106e
                    ] +
                    _0x395c14(0x393) +
                    this[_0x395c14(0x38d)][this["rownum"] - 0x8][_0x53106e] +
                    "\x22>" +
                    _0xf00cb1 +
                    _0x395c14(0x2c8);
                  this[_0x395c14(0x205)][_0x395c14(0x30d)][_0x395c14(0x2df)] =
                    _0x2ffd8d +
                    this[_0x395c14(0x205)]["betContainer"][_0x395c14(0x2df)];
                },
                playBetSound: function () {
                  var _0x5d2a35 = _0x204af8,
                    _0x135a87,
                    _0x28f387,
                    _0x2b268a = null,
                    _0x3214a4 = this[_0x5d2a35(0x2de)],
                    _0x25eefa = Object(_0x501773["a"])(),
                    _0x2a4246 = _0x3214a4[_0x5d2a35(0x334)]();
                  for (
                    _0x135a87 = atob(_0x25eefa[_0x5d2a35(0x324)](",")[0x1]),
                      _0x28f387 = new Uint8Array(_0x135a87[_0x5d2a35(0x397)]),
                      _0x2b268a = 0x0;
                    _0x2b268a < _0x135a87[_0x5d2a35(0x397)];
                    ++_0x2b268a
                  )
                    _0x28f387[_0x2b268a] =
                      _0x135a87[_0x5d2a35(0x3c6)](_0x2b268a);
                  _0x3214a4[_0x5d2a35(0x331)](_0x28f387[_0x5d2a35(0x1cd)])[
                    _0x5d2a35(0x2da)
                  ](function (_0x44128e) {
                    var _0x2684c6 = _0x5d2a35;
                    (_0x2a4246["buffer"] = _0x44128e),
                      _0x2a4246[_0x2684c6(0x32c)](_0x3214a4[_0x2684c6(0x3b7)]),
                      (_0x2a4246[_0x2684c6(0x3ae)] = !0x1),
                      _0x2a4246["start"](0x0);
                  });
                },
                playPayoutSound: function (_0x4350b8) {
                  var _0x3e1b1e = _0x204af8,
                    _0x10ef1c,
                    _0x49d723,
                    _0x41ff85 = null,
                    _0x184318 = this[_0x3e1b1e(0x2de)],
                    _0x3ef90c = Object(_0x501773["b"])(),
                    _0x460379 = _0x184318[_0x3e1b1e(0x334)](),
                    _0x225d64 =
                      0x1 +
                      Math["abs"](
                        _0x4350b8 - (this[_0x3e1b1e(0x27a)] + 0x1) / 0x2
                      ) /
                        (this[_0x3e1b1e(0x27a)] + 0x1);
                  for (
                    _0x10ef1c = atob(_0x3ef90c[_0x3e1b1e(0x324)](",")[0x1]),
                      _0x49d723 = new Uint8Array(_0x10ef1c[_0x3e1b1e(0x397)]),
                      _0x41ff85 = 0x0;
                    _0x41ff85 < _0x10ef1c["length"];
                    ++_0x41ff85
                  )
                    _0x49d723[_0x41ff85] = _0x10ef1c["charCodeAt"](_0x41ff85);
                  _0x184318[_0x3e1b1e(0x331)](_0x49d723[_0x3e1b1e(0x1cd)])[
                    _0x3e1b1e(0x2da)
                  ](function (_0x2006c3) {
                    var _0x3f9545 = _0x3e1b1e;
                    (_0x460379[_0x3f9545(0x1cd)] = _0x2006c3),
                      (_0x460379[_0x3f9545(0x240)][_0x3f9545(0x2ae)] =
                        _0x225d64),
                      _0x460379[_0x3f9545(0x32c)](_0x184318[_0x3f9545(0x3b7)]),
                      (_0x460379[_0x3f9545(0x3ae)] = !0x1),
                      _0x460379[_0x3f9545(0x229)](0x0);
                  });
                },
              }
            ),
            watch: {
              IsStartedBet: function (_0x212f7b) {
                _0x212f7b && this["start"]();
              },
              IsStartedAutoBet: function (_0x17d6e4) {
                _0x17d6e4 ? this["autostart"]() : this["autostop"]();
              },
              changedRisk: function (_0x268b2c) {
                var _0x57946a = _0x204af8;
                this[_0x57946a(0x359)](_0x268b2c), this[_0x57946a(0x394)]();
              },
              changedAmount: function (_0x37d14e) {
                this["amount"] = _0x37d14e;
              },
              changedRows: function (_0x2458c5) {
                var _0x421725 = _0x204af8;
                _0x2458c5 &&
                  (this[_0x421725(0x3f0)](_0x2458c5), this["changePayout"]());
              },
              changedBetcount: function (_0x5022a3) {
                var _0x2e7795 = _0x204af8;
                this[_0x2e7795(0x389)] = _0x5022a3;
              },
            },
          },
          _0x277471 = (_0x57770c(0x3d1), _0x57770c(0x1)),
          _0x3255da = Object(_0x277471["a"])(
            _0x4321d2,
            function () {
              var _0x554e8b = _0x204af8,
                _0x2a8bce = this,
                _0xee63d4 = _0x2a8bce[_0x554e8b(0x39a)]["_c"];
              return _0xee63d4(
                "v-column",
                {
                  staticClass: _0x554e8b(0x22e),
                  staticStyle: { margin: _0x554e8b(0x27c) },
                },
                [
                  _0xee63d4(
                    _0x554e8b(0x1fa),
                    { staticClass: "game-content\x20svelte-1wfq6vq" },
                    [
                      _0xee63d4(
                        _0x554e8b(0x1fa),
                        {
                          ref: "gamepane",
                          staticClass: _0x554e8b(0x3d2),
                          staticStyle: { "font-size": _0x554e8b(0x23b) },
                        },
                        [
                          _0xee63d4(
                            _0x554e8b(0x1fa),
                            { staticClass: _0x554e8b(0x28e) },
                            [
                              _0xee63d4(_0x554e8b(0x244), {
                                ref: _0x554e8b(0x244),
                                staticClass: _0x554e8b(0x3d1),
                                attrs: {
                                  id: _0x554e8b(0x246),
                                  height: _0x554e8b(0x2fd),
                                  width: "760",
                                },
                              }),
                            ]
                          ),
                          _0x2a8bce["_v"]("\x20"),
                          _0xee63d4(
                            _0x554e8b(0x1fa),
                            { staticClass: _0x554e8b(0x33f) },
                            [
                              _0xee63d4(_0x554e8b(0x1fa), {
                                ref: _0x554e8b(0x30d),
                                staticClass: _0x554e8b(0x3ed),
                                staticStyle: { "--duration": _0x554e8b(0x31a) },
                              }),
                            ]
                          ),
                          _0x2a8bce["_v"]("\x20"),
                          _0xee63d4(
                            _0x554e8b(0x1fa),
                            { staticClass: _0x554e8b(0x1df) },
                            [
                              _0xee63d4(_0x554e8b(0x1fa), {
                                ref: _0x554e8b(0x245),
                                staticClass: _0x554e8b(0x1de),
                                staticStyle: { width: _0x554e8b(0x206) },
                              }),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              );
            },
            [],
            !0x1,
            null,
            null,
            null
          );
        _0x2d9663["a"] = _0x3255da[_0x204af8(0x24a)];
      },
      0x1fb: function (_0x3ed415, _0x22a32b, _0x55874f) {
        "use strict";
        var _0x150c9b = a5_0x17320c;
        _0x55874f(0x13),
          _0x55874f(0xf0),
          _0x55874f(0xc),
          _0x55874f(0xa),
          _0x55874f(0xb),
          _0x55874f(0x8),
          _0x55874f(0x10),
          _0x55874f(0xd),
          _0x55874f(0x11);
        var _0x2b8cd3 = _0x55874f(0x2),
          _0xde7c9c = (_0x55874f(0xe), _0x55874f(0x3));
        function _0x3b29be(_0x2b9d7e, _0x28e6ee) {
          var _0x5d661b = a5_0x31ca,
            _0x4e4490 = Object[_0x5d661b(0x289)](_0x2b9d7e);
          if (Object[_0x5d661b(0x395)]) {
            var _0x3aa7f8 = Object["getOwnPropertySymbols"](_0x2b9d7e);
            _0x28e6ee &&
              (_0x3aa7f8 = _0x3aa7f8[_0x5d661b(0x1e9)](function (_0x24a5c1) {
                var _0x12e884 = _0x5d661b;
                return Object[_0x12e884(0x2c0)](
                  _0x2b9d7e,
                  _0x24a5c1
                )[_0x12e884(0x2b5)];
              })),
              _0x4e4490["push"]["apply"](_0x4e4490, _0x3aa7f8);
          }
          return _0x4e4490;
        }
        function _0x875f93(_0x552126) {
          var _0x51b059 = a5_0x31ca;
          for (
            var _0x30907f = 0x1;
            _0x30907f < arguments[_0x51b059(0x397)];
            _0x30907f++
          ) {
            var _0x28f54f =
              null != arguments[_0x30907f] ? arguments[_0x30907f] : {};
            _0x30907f % 0x2
              ? _0x3b29be(Object(_0x28f54f), !0x0)[_0x51b059(0x3bc)](function (
                  _0x2cb7b4
                ) {
                  Object(_0x2b8cd3["a"])(
                    _0x552126,
                    _0x2cb7b4,
                    _0x28f54f[_0x2cb7b4]
                  );
                })
              : Object[_0x51b059(0x1ee)]
              ? Object[_0x51b059(0x3b1)](
                  _0x552126,
                  Object[_0x51b059(0x1ee)](_0x28f54f)
                )
              : _0x3b29be(Object(_0x28f54f))["forEach"](function (_0x3b6841) {
                  var _0x58793d = _0x51b059;
                  Object[_0x58793d(0x344)](
                    _0x552126,
                    _0x3b6841,
                    Object[_0x58793d(0x2c0)](_0x28f54f, _0x3b6841)
                  );
                });
          }
          return _0x552126;
        }
        var _0x3a6110 = {
            name: _0x150c9b(0x29f),
            data: function () {
              var _0x2b502f = _0x150c9b;
              return {
                isManual: !0x0,
                isControl: !0x0,
                isDisabled: !0x1,
                isBetting: !0x1,
                isAutobet: !0x1,
                isAutobetFinsihing: !0x1,
                bet_label: _0x2b502f(0x322),
                cancel_label: _0x2b502f(0x398),
                autobet_label: _0x2b502f(0x32a),
                profit: 0x0,
                loss: 0x0,
                autobetcount: 0x0,
                multiplier: 0x2,
              };
            },
            computed: _0x875f93(
              {},
              Object(_0xde7c9c["c"])(_0x150c9b(0x256), [
                _0x150c9b(0x38f),
                _0x150c9b(0x3d7),
                _0x150c9b(0x3d6),
                _0x150c9b(0x282),
              ])
            ),
            watch: {
              multiplier: function (_0x466b5b) {
                var _0x5234d3 = _0x150c9b;
                this[_0x5234d3(0x241)](_0x466b5b);
              },
              getGamestate: function (_0x17c434) {
                var _0x4e65a0 = _0x150c9b;
                "ready" == _0x17c434
                  ? ((this[_0x4e65a0(0x3c8)] = !0x1),
                    (this[_0x4e65a0(0x3e1)] = "Bet"),
                    (this[_0x4e65a0(0x265)] = _0x4e65a0(0x398)),
                    0x1 == this[_0x4e65a0(0x2fa)]
                      ? 0x0 == this[_0x4e65a0(0x3d7)] &&
                        0x0 == this[_0x4e65a0(0x3d6)] &&
                        this["bet"]()
                      : 0x0 == this[_0x4e65a0(0x3d7)] &&
                        0x0 == this[_0x4e65a0(0x3d6)] &&
                        ((this[_0x4e65a0(0x1ca)] = "Start\x20Autobet"),
                        (this[_0x4e65a0(0x399)] = !0x1),
                        (this[_0x4e65a0(0x3c8)] = !0x1)))
                  : "pending" == _0x17c434
                  ? ((this[_0x4e65a0(0x3c8)] = !0x0),
                    (this[_0x4e65a0(0x3e1)] = _0x4e65a0(0x2c6)))
                  : (_0x4e65a0(0x235) == _0x17c434 || "result" == _0x17c434) &&
                    (0x0 == this["isAutobetFinsihing"] &&
                      (this[_0x4e65a0(0x3c8)] = !0x1),
                    (this[_0x4e65a0(0x3e1)] = _0x4e65a0(0x21a)),
                    (this["cancel_label"] = _0x4e65a0(0x1b9))),
                  0x1 == this["isAutobet"] && (this[_0x4e65a0(0x3c8)] = !0x0);
              },
              getResultboard: function (_0x4cebf6) {
                var _0xdc3c99 = _0x150c9b;
                if (0x1 == this["isAutobet"]) {
                  for (
                    var _0x1551c3 = !0x1, _0x3ac130 = 0x0;
                    _0x3ac130 < _0x4cebf6[_0xdc3c99(0x397)];
                    _0x3ac130++
                  )
                    if (
                      this[_0xdc3c99(0x364)] ==
                      _0x4cebf6[_0x3ac130][_0xdc3c99(0x388)]
                    ) {
                      var _0xd90544 = _0x4cebf6[_0x3ac130]["amount"],
                        _0x46142b = _0x4cebf6[_0x3ac130][_0xdc3c99(0x3b0)];
                      _0x46142b - _0xd90544 > 0x0
                        ? (this[_0xdc3c99(0x3b2)] =
                            this[_0xdc3c99(0x3b2)] + (_0x46142b - _0xd90544))
                        : (this["loss"] =
                            this[_0xdc3c99(0x292)] + (_0xd90544 - _0x46142b)),
                        (_0x1551c3 = !0x0);
                    }
                  0x1 == _0x1551c3 &&
                    (this[_0xdc3c99(0x3c3)] = this[_0xdc3c99(0x3c3)] + 0x1),
                    this[_0xdc3c99(0x205)][_0xdc3c99(0x1bd)][_0xdc3c99(0x205)][
                      "v"
                    ][_0xdc3c99(0x2ae)] > 0x0 &&
                      this["autobetcount"] >=
                        this[_0xdc3c99(0x205)]["autocount"][_0xdc3c99(0x205)][
                          "v"
                        ][_0xdc3c99(0x2ae)] &&
                      (this["isAutobet"] = !0x1),
                    this[_0xdc3c99(0x205)]["stopProfit"]["$refs"]["v"][
                      "value"
                    ] > 0x0 &&
                      this[_0xdc3c99(0x3b2)] - this[_0xdc3c99(0x292)] >=
                        this["$refs"][_0xdc3c99(0x3d4)][_0xdc3c99(0x205)]["v"][
                          _0xdc3c99(0x2ae)
                        ] &&
                      (this[_0xdc3c99(0x2fa)] = !0x1),
                    this[_0xdc3c99(0x205)][_0xdc3c99(0x2e0)][_0xdc3c99(0x205)][
                      "v"
                    ][_0xdc3c99(0x2ae)] > 0x0 &&
                      this["loss"] - this[_0xdc3c99(0x3b2)] >=
                        this["$refs"]["stopLoss"][_0xdc3c99(0x205)]["v"][
                          _0xdc3c99(0x2ae)
                        ] &&
                      (this[_0xdc3c99(0x2fa)] = !0x1),
                    0x0 == this[_0xdc3c99(0x2fa)] &&
                      ((this[_0xdc3c99(0x1ca)] = _0xdc3c99(0x287)),
                      (this["isAutobetFinsihing"] = !0x0),
                      (this[_0xdc3c99(0x3c8)] = !0x0));
                }
              },
            },
            methods: _0x875f93(
              _0x875f93(
                {},
                Object(_0xde7c9c["b"])(_0x150c9b(0x256), [
                  _0x150c9b(0x3ea),
                  _0x150c9b(0x23f),
                  _0x150c9b(0x1ef),
                  "setMultiplier",
                  _0x150c9b(0x30a),
                  _0x150c9b(0x1d0),
                  "setBet",
                  _0x150c9b(0x27f),
                  "setResultboard",
                  _0x150c9b(0x241),
                ])
              ),
              {},
              {
                toggleMaunal: function (_0x3ed8c0) {
                  var _0x17961a = _0x150c9b;
                  (this["isManual"] = _0x3ed8c0), this[_0x17961a(0x29e)]();
                },
                toggleControl: function (_0x32b68e) {
                  var _0xd6a96d = _0x150c9b;
                  (this[_0xd6a96d(0x2f1)] = _0x32b68e),
                    this[_0xd6a96d(0x29e)]();
                },
                reorderBetlist: function () {
                  var _0x5d0c86 = _0x150c9b;
                  this[_0x5d0c86(0x205)]["betlist"][_0x5d0c86(0x32b)][
                    _0x5d0c86(0x1f3)
                  ](_0x5d0c86(0x3cc)),
                    0x1 == this["isManual"] || 0x1 == this[_0x5d0c86(0x2f1)]
                      ? this["$refs"][_0x5d0c86(0x3de)][_0x5d0c86(0x32b)][
                          _0x5d0c86(0x1ff)
                        ]("order", "14")
                      : this[_0x5d0c86(0x205)][_0x5d0c86(0x3de)][
                          _0x5d0c86(0x32b)
                        ][_0x5d0c86(0x1ff)](_0x5d0c86(0x3cc), "11");
                },
                startAutobet: function () {
                  var _0x5033d4 = _0x150c9b;
                  (this[_0x5033d4(0x2fa)] = !0x0),
                    (this[_0x5033d4(0x3b2)] = 0x0),
                    (this[_0x5033d4(0x292)] = 0x0),
                    (this[_0x5033d4(0x3c3)] = 0x0),
                    Message({
                      message: _0x5033d4(0x21f),
                      type: _0x5033d4(0x2f0),
                      showClose: !0x0,
                      duration: 0x1388,
                    }),
                    0x0 == this["getBet"] &&
                      0x0 == this[_0x5033d4(0x3d6)] &&
                      this["bet"]();
                },
                stopAutobet: function () {
                  var _0x1837cb = _0x150c9b;
                  (this["isAutobet"] = !0x1),
                    (this[_0x1837cb(0x3d7)] > 0x0 ||
                      this[_0x1837cb(0x3d6)] > 0x0) &&
                      ((this[_0x1837cb(0x1ca)] = _0x1837cb(0x287)),
                      (this["isAutobetFinsihing"] = !0x0),
                      (this[_0x1837cb(0x3c8)] = !0x0));
                },
                halfAmount: function () {
                  var _0x1d824e = _0x150c9b;
                  this["$refs"][_0x1d824e(0x3ac)][_0x1d824e(0x205)]["v"][
                    _0x1d824e(0x2ae)
                  ] =
                    this["$refs"][_0x1d824e(0x3ac)][_0x1d824e(0x205)]["v"][
                      _0x1d824e(0x2ae)
                    ] / 0x2;
                },
                multipleAmount: function () {
                  var _0x2ff21d = _0x150c9b;
                  this[_0x2ff21d(0x205)]["amount"][_0x2ff21d(0x205)]["v"][
                    _0x2ff21d(0x2ae)
                  ] =
                    0x2 *
                    this["$refs"]["amount"]["$refs"]["v"][_0x2ff21d(0x2ae)];
                },
                bet: function () {
                  var _0x2c8ca6 = _0x150c9b;
                  (this[_0x2c8ca6(0x1c9)] = !0x0), this[_0x2c8ca6(0x38f)];
                },
                cancel: function () {
                  var _0x260b17 = _0x150c9b;
                  (this[_0x260b17(0x1c9)] = !0x0),
                    (this[_0x260b17(0x38f)],
                    _0x260b17(0x2b8) == this[_0x260b17(0x38f)]
                      ? this["getBet"]
                      : this[_0x260b17(0x3d6)]);
                },
              }
            ),
          },
          _0x1e2438 = (_0x55874f(0x3e2), _0x55874f(0x1)),
          _0x2cc132 = Object(_0x1e2438["a"])(
            _0x3a6110,
            function () {
              var _0x47e3b1 = _0x150c9b,
                _0x9392e1 = this,
                _0x4ef1d6 = _0x9392e1[_0x47e3b1(0x39a)]["_c"];
              return _0x4ef1d6(
                _0x47e3b1(0x290),
                { staticClass: _0x47e3b1(0x293) },
                [
                  _0x4ef1d6(
                    _0x47e3b1(0x268),
                    { staticClass: _0x47e3b1(0x348) },
                    [
                      _0x9392e1[_0x47e3b1(0x350)][_0x47e3b1(0x2c4)]
                        ? _0x4ef1d6(
                            _0x47e3b1(0x290),
                            { staticClass: _0x47e3b1(0x25a) },
                            [
                              _0x4ef1d6(_0x47e3b1(0x39f), {
                                scopedSlots: _0x9392e1["_u"](
                                  [
                                    {
                                      key: _0x47e3b1(0x218),
                                      fn: function (_0x11219d) {
                                        var _0xbdb712 = _0x47e3b1,
                                          _0xd63581 = _0x11219d["on"];
                                        return [
                                          _0x4ef1d6(
                                            _0xbdb712(0x2be),
                                            _0x9392e1["_g"](
                                              { attrs: { text: "" } },
                                              _0xd63581
                                            ),
                                            [
                                              _0x4ef1d6(_0xbdb712(0x390), [
                                                _0x9392e1["_v"]("베팅내역"),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                        ];
                                      },
                                    },
                                  ],
                                  null,
                                  !0x1,
                                  0xc181b458
                                ),
                              }),
                            ],
                            0x1
                          )
                        : _0x9392e1["_e"](),
                      _0x9392e1["_v"]("\x20"),
                      _0x4ef1d6(
                        _0x47e3b1(0x268),
                        { staticClass: _0x47e3b1(0x2e3) },
                        [
                          _0x4ef1d6(
                            _0x47e3b1(0x268),
                            { staticClass: _0x47e3b1(0x3ac) },
                            [
                              _0x9392e1[_0x47e3b1(0x350)][_0x47e3b1(0x2c4)]
                                ? _0x4ef1d6(
                                    "v-row",
                                    { staticClass: _0x47e3b1(0x24d) },
                                    [
                                      _0x4ef1d6(
                                        _0x47e3b1(0x290),
                                        { staticClass: _0x47e3b1(0x31d) },
                                        [
                                          _0x4ef1d6(_0x47e3b1(0x390), [
                                            _0x9392e1["_v"](_0x47e3b1(0x1e3)),
                                          ]),
                                        ],
                                        0x1
                                      ),
                                      _0x9392e1["_v"]("\x20"),
                                      _0x4ef1d6(
                                        "v-row",
                                        { staticClass: _0x47e3b1(0x258) },
                                        [
                                          _0x4ef1d6(_0x47e3b1(0x390), [
                                            _0x9392e1["_v"](
                                              _0x9392e1["_s"](
                                                parseInt(
                                                  _0x9392e1["$auth"][
                                                    _0x47e3b1(0x366)
                                                  ][_0x47e3b1(0x1c4)]
                                                )[_0x47e3b1(0x304)]()
                                              )
                                            ),
                                          ]),
                                        ],
                                        0x1
                                      ),
                                    ],
                                    0x1
                                  )
                                : _0x9392e1["_e"](),
                              _0x9392e1["_v"]("\x20"),
                              _0x4ef1d6(
                                "v-row",
                                [
                                  _0x4ef1d6("v-text", [
                                    _0x9392e1["_v"]("베팅금액"),
                                  ]),
                                ],
                                0x1
                              ),
                              _0x9392e1["_v"]("\x20"),
                              _0x4ef1d6(
                                _0x47e3b1(0x290),
                                { staticClass: _0x47e3b1(0x3a5) },
                                [
                                  _0x4ef1d6(
                                    _0x47e3b1(0x290),
                                    { staticClass: _0x47e3b1(0x33b) },
                                    [
                                      _0x4ef1d6(
                                        "v-button",
                                        {
                                          staticClass: _0x47e3b1(0x339),
                                          attrs: {
                                            disabled:
                                              _0x9392e1[_0x47e3b1(0x273)],
                                          },
                                          on: {
                                            click: function (_0x14cdae) {
                                              var _0x1ee6c8 = _0x47e3b1;
                                              return _0x9392e1[
                                                _0x1ee6c8(0x339)
                                              ]();
                                            },
                                          },
                                        },
                                        [
                                          _0x4ef1d6(_0x47e3b1(0x2c5), {
                                            staticClass: "margin-right-0",
                                            attrs: { icon: _0x47e3b1(0x222) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x9392e1["_v"]("\x20"),
                                      _0x4ef1d6(
                                        _0x47e3b1(0x2be),
                                        {
                                          staticClass: "up",
                                          attrs: {
                                            disabled:
                                              _0x9392e1[_0x47e3b1(0x273)],
                                          },
                                          on: {
                                            click: function (_0x2a2758) {
                                              return _0x9392e1["up"]();
                                            },
                                          },
                                        },
                                        [
                                          _0x4ef1d6(_0x47e3b1(0x2c5), {
                                            staticClass: _0x47e3b1(0x2e1),
                                            attrs: { icon: _0x47e3b1(0x2cd) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                    ],
                                    0x1
                                  ),
                                  _0x9392e1["_v"]("\x20"),
                                  _0x4ef1d6(_0x47e3b1(0x1b4), {
                                    attrs: {
                                      placeholder: _0x47e3b1(0x23e),
                                      disabled: _0x9392e1[_0x47e3b1(0x273)],
                                      "number-format": !0x0,
                                    },
                                    on: { input: _0x9392e1["changedAmount"] },
                                  }),
                                  _0x9392e1["_v"]("\x20"),
                                  _0x4ef1d6(
                                    _0x47e3b1(0x2be),
                                    {
                                      staticClass: "amount-init",
                                      attrs: {
                                        disabled: _0x9392e1[_0x47e3b1(0x273)],
                                      },
                                      on: {
                                        click: function (_0x334545) {
                                          var _0x20a4c3 = _0x47e3b1;
                                          return _0x9392e1[_0x20a4c3(0x3cd)]();
                                        },
                                      },
                                    },
                                    [
                                      _0x4ef1d6(_0x47e3b1(0x2c5), {
                                        staticClass: "margin-right-0",
                                        attrs: { icon: _0x47e3b1(0x34b) },
                                      }),
                                    ],
                                    0x1
                                  ),
                                ],
                                0x1
                              ),
                            ],
                            0x1
                          ),
                        ],
                        0x1
                      ),
                      _0x9392e1["_v"]("\x20"),
                      _0x9392e1[_0x47e3b1(0x3d0)]
                        ? [
                            _0x4ef1d6(
                              _0x47e3b1(0x1fa),
                              {
                                staticClass: _0x47e3b1(0x25f),
                                style: {
                                  "margin-bottom": _0x47e3b1(0x27e),
                                  "flex-shrink": "0",
                                },
                              },
                              [_0x9392e1["_v"](_0x47e3b1(0x1ec))]
                            ),
                            _0x9392e1["_v"]("\x20"),
                            _0x4ef1d6(
                              _0x47e3b1(0x290),
                              { staticClass: _0x47e3b1(0x365) },
                              [
                                _0x4ef1d6(
                                  "v-button",
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x34a)],
                                    },
                                    on: { click: _0x9392e1["acceptInsurance"] },
                                  },
                                  [
                                    _0x4ef1d6("v-text", [
                                      _0x9392e1["_v"]("수락"),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x9392e1["_v"]("\x20"),
                                _0x4ef1d6(
                                  _0x47e3b1(0x2be),
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x34a)],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x3ad)] },
                                  },
                                  [
                                    _0x4ef1d6("v-text", [
                                      _0x9392e1["_v"]("거절"),
                                    ]),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                          ]
                        : [
                            _0x4ef1d6(
                              "v-column",
                              { staticClass: _0x47e3b1(0x370) },
                              [
                                _0x4ef1d6(
                                  "v-button",
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x34a)],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x307)] },
                                  },
                                  [
                                    _0x4ef1d6(
                                      _0x47e3b1(0x390),
                                      {
                                        staticClass: "margin-right-5",
                                        attrs: { color: _0x47e3b1(0x2a5) },
                                      },
                                      [
                                        _0x4ef1d6(_0x47e3b1(0x2c5), {
                                          attrs: { icon: _0x47e3b1(0x1f8) },
                                        }),
                                      ],
                                      0x1
                                    ),
                                    _0x9392e1["_v"]("\x20"),
                                    _0x4ef1d6(_0x47e3b1(0x390), [
                                      _0x9392e1["_v"]("히트"),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x9392e1["_v"]("\x20"),
                                _0x4ef1d6(
                                  "v-button",
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x34a)],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x3e2)] },
                                  },
                                  [
                                    _0x4ef1d6(
                                      _0x47e3b1(0x390),
                                      {
                                        staticClass: _0x47e3b1(0x21d),
                                        attrs: { color: _0x47e3b1(0x1c8) },
                                      },
                                      [
                                        _0x4ef1d6(_0x47e3b1(0x2c5), {
                                          attrs: {
                                            icon: "fa-solid\x20fa-hand",
                                          },
                                        }),
                                      ],
                                      0x1
                                    ),
                                    _0x9392e1["_v"]("\x20"),
                                    _0x4ef1d6(_0x47e3b1(0x390), [
                                      _0x9392e1["_v"](_0x47e3b1(0x3e0)),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x9392e1["_v"]("\x20"),
                                _0x4ef1d6(
                                  _0x47e3b1(0x2be),
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x300)],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x324)] },
                                  },
                                  [
                                    _0x4ef1d6(
                                      _0x47e3b1(0x390),
                                      {
                                        staticClass: _0x47e3b1(0x21d),
                                        attrs: { color: _0x47e3b1(0x369) },
                                      },
                                      [
                                        _0x4ef1d6("v-icon", {
                                          attrs: { icon: _0x47e3b1(0x28f) },
                                        }),
                                      ],
                                      0x1
                                    ),
                                    _0x9392e1["_v"]("\x20"),
                                    _0x4ef1d6(_0x47e3b1(0x390), [
                                      _0x9392e1["_v"]("스플릿"),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x9392e1["_v"]("\x20"),
                                _0x4ef1d6(
                                  _0x47e3b1(0x2be),
                                  {
                                    attrs: {
                                      disabled: _0x9392e1["getSetdisabled"],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x269)] },
                                  },
                                  [
                                    _0x4ef1d6(
                                      _0x47e3b1(0x390),
                                      {
                                        staticClass: "margin-right-5",
                                        attrs: { color: _0x47e3b1(0x24e) },
                                      },
                                      [
                                        _0x4ef1d6(_0x47e3b1(0x2c5), {
                                          attrs: {
                                            icon: "fa-solid\x20fa-splotch",
                                          },
                                        }),
                                      ],
                                      0x1
                                    ),
                                    _0x9392e1["_v"]("\x20"),
                                    _0x4ef1d6(_0x47e3b1(0x390), [
                                      _0x9392e1["_v"]("더블"),
                                    ]),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                            _0x9392e1["_v"]("\x20"),
                            _0x4ef1d6(
                              _0x47e3b1(0x268),
                              { staticClass: "submit" },
                              [
                                _0x4ef1d6(
                                  _0x47e3b1(0x2be),
                                  {
                                    attrs: {
                                      disabled: _0x9392e1[_0x47e3b1(0x273)],
                                    },
                                    on: { click: _0x9392e1[_0x47e3b1(0x1e8)] },
                                  },
                                  [
                                    _0x4ef1d6(_0x47e3b1(0x390), [
                                      _0x9392e1["_v"](_0x47e3b1(0x212)),
                                    ]),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                          ],
                    ],
                    0x2
                  ),
                ],
                0x1
              );
            },
            [],
            !0x1,
            null,
            _0x150c9b(0x351),
            null
          );
        _0x22a32b["a"] = _0x2cc132[_0x150c9b(0x24a)];
      },
      0x1fc: function (_0x58df42, _0x3c7c92, _0x4436b3) {
        "use strict";
        var _0x90e214 = a5_0x17320c;
        _0x4436b3(0xc),
          _0x4436b3(0xa),
          _0x4436b3(0xb),
          _0x4436b3(0x8),
          _0x4436b3(0x10),
          _0x4436b3(0xd),
          _0x4436b3(0x11);
        var _0x328124 = _0x4436b3(0x2),
          _0x452433 = (_0x4436b3(0x40), _0x4436b3(0xe), _0x4436b3(0x3)),
          _0x46dcd6 = _0x4436b3(0x62);
        function _0x53fca0(_0x47bbf1, _0x1ee1ff) {
          var _0xd13b9f = a5_0x31ca,
            _0x2478ab = Object["keys"](_0x47bbf1);
          if (Object[_0xd13b9f(0x395)]) {
            var _0x2dff00 = Object["getOwnPropertySymbols"](_0x47bbf1);
            _0x1ee1ff &&
              (_0x2dff00 = _0x2dff00[_0xd13b9f(0x1e9)](function (_0x44e233) {
                var _0x38eedd = _0xd13b9f;
                return Object[_0x38eedd(0x2c0)](
                  _0x47bbf1,
                  _0x44e233
                )[_0x38eedd(0x2b5)];
              })),
              _0x2478ab[_0xd13b9f(0x295)]["apply"](_0x2478ab, _0x2dff00);
          }
          return _0x2478ab;
        }
        function _0x446a75(_0x30b909) {
          var _0x1c31f9 = a5_0x31ca;
          for (
            var _0x1c29fc = 0x1;
            _0x1c29fc < arguments["length"];
            _0x1c29fc++
          ) {
            var _0x166a85 =
              null != arguments[_0x1c29fc] ? arguments[_0x1c29fc] : {};
            _0x1c29fc % 0x2
              ? _0x53fca0(Object(_0x166a85), !0x0)[_0x1c31f9(0x3bc)](function (
                  _0x2cfb63
                ) {
                  Object(_0x328124["a"])(
                    _0x30b909,
                    _0x2cfb63,
                    _0x166a85[_0x2cfb63]
                  );
                })
              : Object["getOwnPropertyDescriptors"]
              ? Object[_0x1c31f9(0x3b1)](
                  _0x30b909,
                  Object["getOwnPropertyDescriptors"](_0x166a85)
                )
              : _0x53fca0(Object(_0x166a85))[_0x1c31f9(0x3bc)](function (
                  _0x2aa4dd
                ) {
                  var _0x5e653a = _0x1c31f9;
                  Object["defineProperty"](
                    _0x30b909,
                    _0x2aa4dd,
                    Object[_0x5e653a(0x2c0)](_0x166a85, _0x2aa4dd)
                  );
                });
          }
          return _0x30b909;
        }
        var _0x20cfb1 = 0x4e20,
          _0x391a3b = 0x2710,
          _0x54d1ec = {
            name: _0x90e214(0x285),
            components: {},
            data: function () {
              return {
                imgPayouts: [],
                fontColors: [],
                sounds: [],
                imgHexs: [],
                imgSelectedHex: "",
                hexIndex: 0x0,
                gamepad_width: 0x0,
                gameservice_stop: !0x1,
                elapsedTime: _0x20cfb1,
                gamestate_label: "",
                eplasedtime_label: "",
                prevstate: "",
                target_multiplier: 0x1,
                target_numbers: [],
                betmoney: 0x0,
                progresstime: _0x20cfb1,
                slidetime: _0x391a3b,
                progress_stop: !0x1,
              };
            },
            mounted: function () {
              var _0x32bac4 = _0x90e214;
              (this[_0x32bac4(0x3db)][_0x32bac4(0x363)] =
                this[_0x32bac4(0x205)]["payout0"][_0x32bac4(0x385)]),
                (this[_0x32bac4(0x3db)][_0x32bac4(0x39c)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x39c)][_0x32bac4(0x385)]),
                (this[_0x32bac4(0x3db)][_0x32bac4(0x31b)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x31b)][_0x32bac4(0x385)]),
                (this[_0x32bac4(0x3db)][_0x32bac4(0x24b)] =
                  this[_0x32bac4(0x205)]["payout10"]["src"]),
                (this["imgPayouts"][_0x32bac4(0x3a1)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x3a1)]["src"]),
                (this[_0x32bac4(0x3db)][_0x32bac4(0x1d6)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x1d6)]["src"]),
                (this[_0x32bac4(0x294)][_0x32bac4(0x363)] = "#2D4454"),
                (this[_0x32bac4(0x294)][_0x32bac4(0x39c)] = "#DCDFE4"),
                (this["fontColors"][_0x32bac4(0x31b)] = _0x32bac4(0x33e)),
                (this["fontColors"]["payout10"] = _0x32bac4(0x354)),
                (this[_0x32bac4(0x294)][_0x32bac4(0x3a1)] = _0x32bac4(0x2e6)),
                (this[_0x32bac4(0x294)][_0x32bac4(0x1d6)] = _0x32bac4(0x1d3)),
                (this[_0x32bac4(0x1d2)][_0x32bac4(0x363)] =
                  this["$refs"][_0x32bac4(0x201)]["src"]),
                (this[_0x32bac4(0x1d2)][_0x32bac4(0x39c)] =
                  this[_0x32bac4(0x205)]["hex2"][_0x32bac4(0x385)]),
                (this["imgHexs"][_0x32bac4(0x31b)] =
                  this[_0x32bac4(0x205)]["hex5"]["src"]),
                (this[_0x32bac4(0x1d2)][_0x32bac4(0x24b)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x22d)][_0x32bac4(0x385)]),
                (this[_0x32bac4(0x1d2)][_0x32bac4(0x3a1)] =
                  this["$refs"][_0x32bac4(0x30c)][_0x32bac4(0x385)]),
                (this[_0x32bac4(0x1d2)][_0x32bac4(0x1d6)] =
                  this[_0x32bac4(0x205)][_0x32bac4(0x31e)]["src"]),
                setTimeout(this[_0x32bac4(0x202)], 0x64),
                setTimeout(this[_0x32bac4(0x1db)], 0x1);
            },
            beforeDestroy: function () {
              var _0x202928 = _0x90e214;
              this[_0x202928(0x2c1)] = !0x0;
            },
            computed: _0x446a75(
              _0x446a75(
                {},
                Object(_0x452433["c"])(_0x90e214(0x256), [
                  _0x90e214(0x38f),
                  "getGameid",
                  _0x90e214(0x362),
                  _0x90e214(0x32f),
                  "getNumbers",
                  _0x90e214(0x3ce),
                  _0x90e214(0x3d7),
                  _0x90e214(0x3be),
                ])
              ),
              {},
              {
                gamestate: function () {
                  var _0x3c6b56 = _0x90e214;
                  return this[_0x3c6b56(0x38f)];
                },
              }
            ),
            watch: { gamestate: function (_0x5c6af9) {} },
            methods: _0x446a75(
              _0x446a75(
                {},
                Object(_0x452433["b"])(_0x90e214(0x256), [
                  _0x90e214(0x3ea),
                  "setGameid",
                  _0x90e214(0x1ef),
                  "setMultiplier",
                  _0x90e214(0x30a),
                  _0x90e214(0x1d0),
                  _0x90e214(0x37e),
                  "setNextbet",
                  "setResultboard",
                  _0x90e214(0x241),
                ])
              ),
              {},
              {
                addBetItem: function (_0x5d7f79) {
                  var _0x210c96 = _0x90e214,
                    _0x297cfe = Object(_0x46dcd6["a"])(_0x5d7f79, 0x2);
                  0x0 ==
                  this["$refs"][_0x210c96(0x3ee)][_0x210c96(0x3b4)][
                    _0x210c96(0x397)
                  ]
                    ? this[_0x210c96(0x205)]["pastBets"][_0x210c96(0x31f)](
                        _0x297cfe
                      )
                    : this[_0x210c96(0x205)][_0x210c96(0x3ee)][
                        _0x210c96(0x39e)
                      ](
                        _0x297cfe,
                        this["$refs"][_0x210c96(0x3ee)][_0x210c96(0x3b4)][0x0]
                      ),
                    this["$refs"][_0x210c96(0x3ee)][_0x210c96(0x3b4)][
                      "length"
                    ] > 0x5 &&
                      this[_0x210c96(0x205)]["pastBets"]["classList"][
                        _0x210c96(0x3e6)
                      ](_0x210c96(0x36a)),
                    this[_0x210c96(0x205)][_0x210c96(0x3ee)][_0x210c96(0x3b4)][
                      "length"
                    ] > 0x6 &&
                      this["$refs"][_0x210c96(0x3ee)][_0x210c96(0x33a)](
                        this[_0x210c96(0x205)][_0x210c96(0x3ee)][
                          _0x210c96(0x3b4)
                        ][0x6]
                      );
                },
                sliding: function () {
                  var _0x2e480b = _0x90e214;
                  this["$refs"][_0x2e480b(0x28c)][_0x2e480b(0x3b4)]["length"] >
                    0x0 &&
                    this[_0x2e480b(0x205)][_0x2e480b(0x28c)][_0x2e480b(0x33a)](
                      this[_0x2e480b(0x205)]["gamepad"][_0x2e480b(0x3b4)][0x0]
                    );
                  var _0x1fe9ae = this[_0x2e480b(0x303)];
                  0x0 == _0x1fe9ae[_0x2e480b(0x397)] &&
                    (_0x1fe9ae = Object(_0x46dcd6["b"])());
                  var _0x55abdc = Object(_0x46dcd6["c"])(
                    _0x1fe9ae,
                    this[_0x2e480b(0x383)],
                    this["$refs"]["gamepad"][_0x2e480b(0x25e)],
                    this[_0x2e480b(0x205)][_0x2e480b(0x37d)][_0x2e480b(0x385)],
                    this["imgPayouts"],
                    this[_0x2e480b(0x294)],
                    this["slidetime"]
                  );
                  this[_0x2e480b(0x205)]["gamepad"][_0x2e480b(0x31f)](
                    _0x55abdc
                  ),
                    setTimeout(this[_0x2e480b(0x277)], 0x2),
                    setTimeout(
                      this[_0x2e480b(0x260)],
                      this[_0x2e480b(0x1d4)] + 0x2
                    ),
                    this[_0x2e480b(0x1d4)] > 0xbb8 &&
                      setTimeout(this[_0x2e480b(0x279)], 0x1, 0x0);
                },
                slideStart: function () {
                  var _0x239ed1 = _0x90e214;
                  if (document["getElementById"](_0x239ed1(0x256))) {
                    var _0x317003 = document[_0x239ed1(0x200)](
                      _0x239ed1(0x256)
                    )[_0x239ed1(0x203)](_0x239ed1(0x2fe));
                    document[_0x239ed1(0x200)]("slide")[_0x239ed1(0x378)](
                      _0x239ed1(0x32b),
                      document[_0x239ed1(0x200)](_0x239ed1(0x256))[
                        _0x239ed1(0x203)
                      ]("style") +
                        "transform:\x20translate(" +
                        _0x317003 +
                        "px,\x200px);"
                    );
                  }
                },
                slideEnd: function () {
                  var _0x11cfb5 = _0x90e214;
                  document[_0x11cfb5(0x200)]("slide") &&
                    (document[_0x11cfb5(0x200)]("slideTarget")[
                      _0x11cfb5(0x2c7)
                    ][_0x11cfb5(0x3e6)](_0x11cfb5(0x1c1)),
                    this["drawCanvas"](this[_0x11cfb5(0x383)]),
                    this[_0x11cfb5(0x3bb)](this[_0x11cfb5(0x383)]),
                    this["setResultboard"](this[_0x11cfb5(0x3ce)]),
                    this[_0x11cfb5(0x2a1)](this[_0x11cfb5(0x383)]));
                },
                sizeMonitor: function () {
                  var _0x5f2706 = _0x90e214;
                  0x0 == this[_0x5f2706(0x220)]
                    ? ((this["gamepad_width"] = document["getElementById"](
                        _0x5f2706(0x3d3)
                      )["clientWidth"]),
                      this["$refs"]["gamecontent"][_0x5f2706(0x32b)][
                        "removeProperty"
                      ](_0x5f2706(0x1e4)),
                      this[_0x5f2706(0x205)][_0x5f2706(0x379)][
                        _0x5f2706(0x32b)
                      ]["setProperty"](
                        "min-height",
                        0.73 * this[_0x5f2706(0x220)] + "px"
                      ))
                    : this[_0x5f2706(0x220)] !=
                        document[_0x5f2706(0x200)](_0x5f2706(0x3d3))[
                          "clientWidth"
                        ] &&
                      Math["abs"](
                        this[_0x5f2706(0x220)] -
                          document[_0x5f2706(0x200)](_0x5f2706(0x3d3))[
                            "clientWidth"
                          ]
                      ) > 0xa &&
                      (document[_0x5f2706(0x200)]("slide") &&
                        (console[_0x5f2706(0x37c)](_0x5f2706(0x25d)),
                        Object(_0x46dcd6["d"])(
                          document["getElementById"]("slidegame")[
                            _0x5f2706(0x25e)
                          ]
                        )),
                      (this[_0x5f2706(0x220)] = document[_0x5f2706(0x200)](
                        _0x5f2706(0x3d3)
                      )["clientWidth"]),
                      this["$refs"][_0x5f2706(0x379)][_0x5f2706(0x32b)][
                        _0x5f2706(0x1f3)
                      ](_0x5f2706(0x1e4)),
                      this["$refs"][_0x5f2706(0x379)][_0x5f2706(0x32b)][
                        _0x5f2706(0x1ff)
                      ](_0x5f2706(0x1e4), 0.73 * this["gamepad_width"] + "px")),
                    0x0 == this["gameservice_stop"] &&
                      setTimeout(this[_0x5f2706(0x202)], 0x64);
                },
                drawCanvas: function (_0x41b619) {
                  var _0x46ebd9 = _0x90e214,
                    _0x4b5b66 = "";
                  (_0x4b5b66 =
                    _0x41b619 >= 0x3e8
                      ? _0x46ebd9(0x297)
                      : _0x41b619 >= 0x64
                      ? _0x46ebd9(0x358)
                      : _0x41b619 >= 0xa
                      ? "10"
                      : _0x41b619 >= 0x5
                      ? "5"
                      : _0x41b619 >= 0x2
                      ? "2"
                      : "0"),
                    (this[_0x46ebd9(0x2cb)] = _0x46ebd9(0x3eb) + _0x4b5b66),
                    (this["hexIndex"] = 0x0),
                    this[_0x46ebd9(0x3f1)]();
                },
                drawFrames: function () {
                  var _0x1b393f = _0x90e214;
                  if (document[_0x1b393f(0x200)](_0x1b393f(0x319))) {
                    var _0xaa54ee = document[_0x1b393f(0x200)](
                        _0x1b393f(0x319)
                      )["getContext"]("2d"),
                      _0x3897b1 = document[_0x1b393f(0x200)](
                        this["imgSelectedHex"]
                      ),
                      _0xd7f272 = this[_0x1b393f(0x255)] % 0xa,
                      _0x3b4c5c = Math[_0x1b393f(0x2e8)](
                        this[_0x1b393f(0x255)] / 0xa
                      );
                    _0xaa54ee["clearRect"](0x0, 0x0, 0x80, 0x80),
                      _0xaa54ee[_0x1b393f(0x1ea)](
                        _0x3897b1,
                        0x80 * _0xd7f272,
                        0x80 * _0x3b4c5c,
                        0x80,
                        0x80,
                        0x0,
                        0x0,
                        0x80,
                        0x80
                      ),
                      (this[_0x1b393f(0x255)] = this[_0x1b393f(0x255)] + 0x1),
                      this[_0x1b393f(0x255)] < 0x28 &&
                        0x0 == this[_0x1b393f(0x2c1)] &&
                        window[_0x1b393f(0x1dd)](this["drawFrames"]);
                  }
                },
                schedule: function () {
                  var _0x1a6b36 = _0x90e214;
                  if (
                    ((this["elapsedTime"] = this[_0x1a6b36(0x3bf)] - 0x64),
                    _0x1a6b36(0x2b8) == this[_0x1a6b36(0x2ab)])
                  ) {
                    var _0x4d3b07 =
                      ((0x1 * this[_0x1a6b36(0x3bf)]) / _0x20cfb1) * 0x64;
                    (this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)][_0x1a6b36(0x32b)][
                      "width"
                    ] = _0x4d3b07 + "%"),
                      this[_0x1a6b36(0x3bf)] <= 0x0
                        ? (this[_0x1a6b36(0x3ea)](_0x1a6b36(0x1e2)),
                          (this[_0x1a6b36(0x3bf)] = 0x7d0),
                          this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)]["style"][
                            _0x1a6b36(0x1f3)
                          ](_0x1a6b36(0x2f5)),
                          this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)][
                            _0x1a6b36(0x32b)
                          ]["removeProperty"](_0x1a6b36(0x20e)),
                          this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)][
                            _0x1a6b36(0x32b)
                          ]["setProperty"](_0x1a6b36(0x2f5), "0s"),
                          this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)]["style"][
                            "setProperty"
                          ](_0x1a6b36(0x20e), "0s"),
                          (this[_0x1a6b36(0x2e9)] = _0x1a6b36(0x2c6)),
                          (this[_0x1a6b36(0x20f)] = ""))
                        : (this[_0x1a6b36(0x3bf)] > 0x6a4 &&
                            (this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)][
                              _0x1a6b36(0x32b)
                            ][_0x1a6b36(0x1f3)](_0x1a6b36(0x2f5)),
                            this["$refs"][_0x1a6b36(0x3cf)]["style"][
                              _0x1a6b36(0x1f3)
                            ](_0x1a6b36(0x20e)),
                            this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)][
                              _0x1a6b36(0x32b)
                            ]["setProperty"](
                              _0x1a6b36(0x2f5),
                              _0x1a6b36(0x320)
                            ),
                            this[_0x1a6b36(0x205)][_0x1a6b36(0x3cf)]["style"][
                              "setProperty"
                            ](_0x1a6b36(0x20e), "0.1s")),
                          (this[_0x1a6b36(0x2e9)] = _0x1a6b36(0x33c)),
                          (this[_0x1a6b36(0x20f)] =
                            this[_0x1a6b36(0x3bf)] / 0x3e8 + "s"));
                  } else
                    _0x1a6b36(0x1e2) == this[_0x1a6b36(0x2ab)]
                      ? this[_0x1a6b36(0x3bf)] <= 0x0 &&
                        (this["setGamestate"](_0x1a6b36(0x235)),
                        (this["elapsedTime"] = _0x391a3b),
                        (this[_0x1a6b36(0x2e9)] = ""),
                        this[_0x1a6b36(0x2ed)]())
                      : _0x1a6b36(0x235) == this[_0x1a6b36(0x2ab)]
                      ? this["elapsedTime"] <= 0x0 &&
                        (this["setGamestate"](_0x1a6b36(0x35c)),
                        (this[_0x1a6b36(0x3bf)] = 0x1770))
                      : _0x1a6b36(0x35c) == this[_0x1a6b36(0x2ab)] &&
                        this[_0x1a6b36(0x3bf)] <= 0x0 &&
                        (this[_0x1a6b36(0x3ea)](_0x1a6b36(0x2b8)),
                        (this["elapsedTime"] = _0x20cfb1),
                        (this["$refs"][_0x1a6b36(0x3cf)][_0x1a6b36(0x32b)][
                          _0x1a6b36(0x35b)
                        ] = _0x1a6b36(0x2b7)));
                  0x0 == this["gameservice_stop"] &&
                    setTimeout(this[_0x1a6b36(0x356)], 0x64);
                },
                playSlidingSound: function (_0x31cf4b) {
                  var _0x452f2c = _0x90e214,
                    _0x53ff8a = _0x4436b3(0x3f8)[_0x452f2c(0x2f2)],
                    _0x7fd2ed = new Audio(_0x53ff8a);
                  (_0x7fd2ed[_0x452f2c(0x309)] = _0x31cf4b),
                    _0x7fd2ed[_0x452f2c(0x3a0)]();
                },
                playHexSound: function (_0x35a9ea) {
                  var _0x4163d0 = _0x90e214,
                    _0x1e52c8 = "",
                    _0x14420d =
                      ((_0x1e52c8 =
                        _0x35a9ea >= 0x3e8
                          ? _0x4163d0(0x297)
                          : _0x35a9ea >= 0x64
                          ? _0x4163d0(0x358)
                          : _0x35a9ea >= 0xa
                          ? "10"
                          : _0x35a9ea >= 0x5
                          ? "5"
                          : _0x35a9ea >= 0x2
                          ? "2"
                          : "0"),
                      _0x4436b3(0x3f9)("./" + _0x1e52c8 + _0x4163d0(0x31c))[
                        _0x4163d0(0x2f2)
                      ]);
                  new Audio(_0x14420d)[_0x4163d0(0x3a0)]();
                },
                getState: function () {
                  var _0x2032e4 = _0x90e214,
                    _0x3cd34f = this;
                  new Date()[_0x2032e4(0x2d1)](),
                    this["$repositories"][_0x2032e4(0x346)][_0x2032e4(0x2f4)]
                      [_0x2032e4(0x3bd)]({ prevstate: this[_0x2032e4(0x242)] })
                      [_0x2032e4(0x2da)](function (_0x1c582a) {
                        var _0xf562e7 = _0x2032e4;
                        for (
                          var _0x23c5f1 = _0x1c582a["state"],
                            _0x146d9e = _0x1c582a[_0xf562e7(0x275)],
                            _0x2ca80e = _0x1c582a["multiplier"],
                            _0x38751f = _0x1c582a[_0xf562e7(0x239)],
                            _0x2c3b41 = _0x1c582a[_0xf562e7(0x1f6)],
                            _0x50119a = _0x1c582a[_0xf562e7(0x250)],
                            _0x40ec96 =
                              (_0x1c582a[_0xf562e7(0x1f4)],
                              _0x1c582a["gamehist"]),
                            _0x560f67 = 0x0,
                            _0x1aea95 = 0x0;
                          _0x1aea95 < _0x2c3b41["length"];
                          _0x1aea95++
                        )
                          if (
                            _0x3cd34f["name"] ==
                            _0x2c3b41[_0x1aea95]["username"]
                          ) {
                            _0x560f67 = _0x2c3b41[_0x1aea95]["id"];
                            break;
                          }
                        _0x3cd34f[_0xf562e7(0x37e)](_0x560f67);
                        for (
                          var _0x35feaf = 0x0, _0x5449d7 = 0x0;
                          _0x5449d7 < _0x50119a[_0xf562e7(0x397)];
                          _0x5449d7++
                        )
                          if (
                            _0x3cd34f[_0xf562e7(0x364)] ==
                            _0x50119a[_0x5449d7][_0xf562e7(0x388)]
                          ) {
                            _0x35feaf = _0x50119a[_0x5449d7]["id"];
                            break;
                          }
                        _0x3cd34f[_0xf562e7(0x27f)](_0x35feaf),
                          _0x3cd34f[_0xf562e7(0x1d0)](_0x2c3b41);
                        var _0x518429 = 0x1f4;
                        if (_0x23c5f1 != _0x3cd34f["prevstate"]) {
                          if (
                            _0xf562e7(0x2b8) != _0x23c5f1 ||
                            (_0xf562e7(0x35c) != _0x3cd34f[_0xf562e7(0x242)] &&
                              "" != _0x3cd34f[_0xf562e7(0x242)])
                          ) {
                            if (
                              _0xf562e7(0x235) != _0x23c5f1 ||
                              ("ready" != _0x3cd34f[_0xf562e7(0x242)] &&
                                "pending" != _0x3cd34f[_0xf562e7(0x242)] &&
                                "" != _0x3cd34f[_0xf562e7(0x242)])
                            ) {
                              if (
                                _0xf562e7(0x35c) == _0x23c5f1 &&
                                ("starting" == _0x3cd34f[_0xf562e7(0x242)] ||
                                  "" == _0x3cd34f[_0xf562e7(0x242)])
                              ) {
                                if (
                                  ((_0x518429 = 0x1770 - _0x146d9e),
                                  (_0x3cd34f["progress_stop"] = !0x0),
                                  "" == _0x3cd34f["prevstate"])
                                ) {
                                  if (_0x40ec96["length"] > 0x0) {
                                    for (
                                      var _0x19ce48 =
                                        _0x40ec96[_0xf562e7(0x397)] - 0x1;
                                      _0x19ce48 >= 0x0;
                                      _0x19ce48--
                                    )
                                      _0x3cd34f[_0xf562e7(0x2a1)](
                                        _0x40ec96[_0x19ce48][_0xf562e7(0x30f)]
                                      );
                                  }
                                  (_0x3cd34f["target_multiplier"] = _0x2ca80e),
                                    (_0x3cd34f["target_numbers"] = _0x38751f),
                                    (_0x3cd34f["slidetime"] = 0x0),
                                    _0x3cd34f["sliding"]();
                                }
                                _0x3cd34f[_0xf562e7(0x3ea)](_0xf562e7(0x35c));
                              }
                            } else {
                              if (
                                "" == _0x3cd34f["prevstate"] &&
                                _0x40ec96[_0xf562e7(0x397)] > 0x0
                              ) {
                                _0x3cd34f[_0xf562e7(0x349)](
                                  _0x40ec96[0x0][_0xf562e7(0x1f6)]
                                );
                                for (
                                  var _0x15deae = _0x40ec96["length"] - 0x1;
                                  _0x15deae >= 0x0;
                                  _0x15deae--
                                )
                                  _0x3cd34f[_0xf562e7(0x2a1)](
                                    _0x40ec96[_0x15deae][_0xf562e7(0x30f)]
                                  );
                              }
                              (_0x518429 = _0x391a3b - _0x146d9e),
                                (_0x3cd34f["target_multiplier"] = _0x2ca80e),
                                (_0x3cd34f[_0xf562e7(0x303)] = _0x38751f),
                                (_0x3cd34f[_0xf562e7(0x2e9)] = ""),
                                (_0x3cd34f["eplasedtime_label"] = ""),
                                (_0x3cd34f["progress_stop"] = !0x0),
                                (_0x3cd34f[_0xf562e7(0x1d4)] = _0x518429),
                                _0x3cd34f[_0xf562e7(0x2ed)](),
                                _0x3cd34f["setGamestate"](_0xf562e7(0x235));
                            }
                          } else {
                            if (
                              "" == _0x3cd34f[_0xf562e7(0x242)] &&
                              _0x40ec96[_0xf562e7(0x397)] > 0x0
                            ) {
                              _0x3cd34f[_0xf562e7(0x1d0)](
                                _0x40ec96[0x0][_0xf562e7(0x1f6)]
                              );
                              for (
                                var _0x3e6bf8 =
                                  _0x40ec96[_0xf562e7(0x397)] - 0x1;
                                _0x3e6bf8 > 0x0;
                                _0x3e6bf8--
                              )
                                _0x3cd34f[_0xf562e7(0x2a1)](
                                  _0x40ec96[_0x3e6bf8][_0xf562e7(0x30f)]
                                );
                              (_0x3cd34f[_0xf562e7(0x383)] =
                                _0x40ec96[0x0][_0xf562e7(0x30f)]),
                                (_0x3cd34f[_0xf562e7(0x303)] =
                                  _0x40ec96[0x0][_0xf562e7(0x239)]),
                                (_0x3cd34f[_0xf562e7(0x1d4)] = 0x0),
                                _0x3cd34f[_0xf562e7(0x2ed)]();
                            }
                            (_0x518429 = _0x20cfb1 - _0x146d9e),
                              (_0x3cd34f[_0xf562e7(0x288)] = _0x518429),
                              (_0x3cd34f[_0xf562e7(0x29b)] = !0x1),
                              setTimeout(_0x3cd34f[_0xf562e7(0x3a3)], 0x1),
                              _0x3cd34f["setGamestate"](_0xf562e7(0x2b8)),
                              _0x518429 > 0x7d0 && (_0x518429 = 0x7d0);
                          }
                        } else _0xf562e7(0x2b8) == _0x23c5f1 && (_0x518429 = _0x20cfb1 - _0x146d9e) > 0x7d0 && (_0x518429 = 0x7d0);
                        (_0x3cd34f["prevstate"] = _0x23c5f1),
                          _0x518429 < 0x1f4 && (_0x518429 = 0x1f4),
                          0x0 == _0x3cd34f[_0xf562e7(0x2c1)] &&
                            setTimeout(_0x3cd34f[_0xf562e7(0x1db)], _0x518429);
                      })
                      [_0x2032e4(0x340)](function (_0x54c5db) {
                        var _0x3cfe1a = _0x2032e4;
                        console[_0x3cfe1a(0x37c)](_0x54c5db),
                          0x0 == _0x3cd34f[_0x3cfe1a(0x2c1)] &&
                            setTimeout(_0x3cd34f[_0x3cfe1a(0x1db)], 0x3e8);
                      });
                },
                progressReady: function () {
                  var _0x27c0a1 = _0x90e214,
                    _0x43aa2c =
                      ((0x1 * this[_0x27c0a1(0x288)]) / _0x20cfb1) * 0x64;
                  _0x43aa2c < 0x0 && (_0x43aa2c = 0x0),
                    0x1 == this[_0x27c0a1(0x29b)] && (_0x43aa2c = 0x0),
                    this[_0x27c0a1(0x205)][_0x27c0a1(0x3cf)] &&
                      (this["$refs"][_0x27c0a1(0x3cf)][_0x27c0a1(0x32b)][
                        _0x27c0a1(0x1f3)
                      ](_0x27c0a1(0x35b)),
                      this["$refs"][_0x27c0a1(0x3cf)][_0x27c0a1(0x32b)][
                        _0x27c0a1(0x1ff)
                      ](_0x27c0a1(0x35b), _0x43aa2c + "%")),
                    0x1 == this[_0x27c0a1(0x29b)]
                      ? ((this[_0x27c0a1(0x2e9)] = ""),
                        (this[_0x27c0a1(0x20f)] = ""))
                      : this[_0x27c0a1(0x288)] <= 0x0
                      ? ((this[_0x27c0a1(0x2e9)] = _0x27c0a1(0x2c6)),
                        (this[_0x27c0a1(0x20f)] = ""),
                        this[_0x27c0a1(0x3ea)](_0x27c0a1(0x1e2)))
                      : ((this[_0x27c0a1(0x2e9)] = _0x27c0a1(0x33c)),
                        (this[_0x27c0a1(0x20f)] =
                          Math[_0x27c0a1(0x2e8)](
                            this[_0x27c0a1(0x288)] / 0x64
                          ) /
                            0xa +
                          "s"),
                        0x0 == this[_0x27c0a1(0x2c1)] &&
                          ((this[_0x27c0a1(0x288)] =
                            this["progresstime"] - 0x64),
                          setTimeout(this[_0x27c0a1(0x3a3)], 0x64)));
                },
              }
            ),
          },
          _0x33365b = (_0x4436b3(0x400), _0x4436b3(0x1)),
          _0x1b6154 = Object(_0x33365b["a"])(
            _0x54d1ec,
            function () {
              var _0x15a450 = _0x90e214,
                _0xb94b65 = this,
                _0x2a2af3 = _0xb94b65[_0x15a450(0x39a)]["_c"];
              return _0x2a2af3(
                "div",
                {
                  ref: _0x15a450(0x379),
                  staticClass: "game-content\x20svelte",
                  staticStyle: { "min-height": _0x15a450(0x323) },
                },
                [
                  _0x2a2af3(_0x15a450(0x1fa), {
                    staticClass: _0x15a450(0x2b0),
                  }),
                  _0xb94b65["_v"]("\x20"),
                  _0x2a2af3(
                    _0x15a450(0x1fa),
                    { staticClass: _0x15a450(0x261) },
                    [
                      _0x2a2af3(
                        _0x15a450(0x1fa),
                        { staticClass: _0x15a450(0x264) },
                        [
                          _0x2a2af3(_0x15a450(0x1fa), {
                            ref: "pastBets",
                            staticClass: "past-bets\x20svelte-1fpkf13",
                          }),
                          _0xb94b65["_v"]("\x20"),
                          _0x2a2af3(
                            _0x15a450(0x1da),
                            { staticClass: _0x15a450(0x38a) },
                            [
                              _0x2a2af3(
                                _0x15a450(0x34e),
                                { staticClass: _0x15a450(0x381) },
                                [
                                  _0x2a2af3(
                                    _0x15a450(0x257),
                                    {
                                      staticClass: "svg-icon\x20svelte-10mcogx",
                                    },
                                    [
                                      _0x2a2af3("use", {
                                        attrs: {
                                          "xlink:href": _0x15a450(0x1c6),
                                        },
                                      }),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                  _0xb94b65["_v"]("\x20"),
                  _0x2a2af3(
                    _0x15a450(0x1fa),
                    { staticClass: _0x15a450(0x27d) },
                    [
                      _0x2a2af3(_0x15a450(0x1fa), {
                        ref: _0x15a450(0x28c),
                        staticClass: _0x15a450(0x2ec),
                        attrs: { id: _0x15a450(0x3d3) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        staticClass: _0x15a450(0x3dd),
                        staticStyle: {
                          transform:
                            "translate(-50%,\x20calc(100%\x20+\x2016.1px))",
                        },
                        attrs: { src: _0x4436b3(0x3e4) },
                      }),
                    ]
                  ),
                  _0xb94b65["_v"]("\x20"),
                  _0x2a2af3(
                    _0x15a450(0x1fa),
                    { staticClass: "others-wrap\x20svelte-1kij38k" },
                    [
                      _0x2a2af3(
                        _0x15a450(0x34e),
                        { staticClass: _0x15a450(0x22b) },
                        [
                          _0x2a2af3(_0x15a450(0x1fa), {
                            staticClass: _0x15a450(0x1e0),
                            class:
                              _0xb94b65[_0x15a450(0x3ce)][_0x15a450(0x397)] >
                              0x0
                                ? _0x15a450(0x30b)
                                : _0x15a450(0x26d),
                          }),
                          _0xb94b65["_v"]("\x20"),
                          _0x2a2af3(
                            _0x15a450(0x34e),
                            {
                              staticClass:
                                "weight-semibold\x20lineHeight-base\x20inline\x20align-left\x20size-medium\x20variant-highlighted\x20with-icon-space\x20svelte-1bjlgfi",
                            },
                            [
                              _0xb94b65["_v"](
                                _0x15a450(0x26a) +
                                  _0xb94b65["_s"](
                                    _0xb94b65[_0x15a450(0x3ce)][
                                      _0x15a450(0x397)
                                    ]
                                  )
                              ),
                            ]
                          ),
                        ]
                      ),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(
                        _0x15a450(0x1fa),
                        { staticClass: _0x15a450(0x333) },
                        [
                          _0x2a2af3(
                            _0x15a450(0x34e),
                            { staticClass: _0x15a450(0x1bf) },
                            [
                              _0x2a2af3(_0x15a450(0x34e), [
                                _0xb94b65["_v"](
                                  _0xb94b65["_s"](_0xb94b65[_0x15a450(0x2e9)]) +
                                    "\x20"
                                ),
                              ]),
                              _0xb94b65["_v"]("\x20"),
                              _0x2a2af3(_0x15a450(0x34e), [
                                _0xb94b65["_v"](
                                  _0xb94b65["_s"](_0xb94b65[_0x15a450(0x20f)])
                                ),
                              ]),
                            ]
                          ),
                          _0xb94b65["_v"]("\x20"),
                          _0x2a2af3("div", {
                            ref: "readyProgress",
                            staticClass: _0x15a450(0x207),
                            staticStyle: { width: "0%" },
                          }),
                        ]
                      ),
                    ]
                  ),
                  _0xb94b65["_v"]("\x20"),
                  _0x2a2af3(
                    _0x15a450(0x1fa),
                    {
                      directives: [
                        {
                          name: _0x15a450(0x3bd),
                          rawName: _0x15a450(0x2e4),
                          value: !0x1,
                          expression: _0x15a450(0x2fb),
                        },
                      ],
                    },
                    [
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x37d),
                        attrs: { src: _0x4436b3(0x3e5) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x363),
                        attrs: { src: _0x4436b3(0x3e6) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: "payout2",
                        attrs: { src: _0x4436b3(0x3e7) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x31b),
                        attrs: { src: _0x4436b3(0x3e8) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x24b),
                        attrs: { src: _0x4436b3(0x3e9) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x3a1),
                        attrs: { src: _0x4436b3(0x3ea) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: "payout1000",
                        attrs: { src: _0x4436b3(0x3eb) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x204),
                        attrs: { src: _0x4436b3(0x3ec) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x266),
                        attrs: { src: _0x4436b3(0x3ed) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x263),
                        attrs: { src: _0x4436b3(0x3ee) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x1fb),
                        attrs: { src: _0x4436b3(0x3ef) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x2db),
                        attrs: { src: _0x4436b3(0x3f0) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: _0x15a450(0x3a2),
                        attrs: { src: _0x4436b3(0x3f1) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x201),
                        attrs: { src: _0x4436b3(0x3f2), id: _0x15a450(0x387) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: "hex2",
                        attrs: { src: _0x4436b3(0x3f3), id: _0x15a450(0x221) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x2d4),
                        attrs: { src: _0x4436b3(0x3f4), id: _0x15a450(0x2ba) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x22d),
                        attrs: { src: _0x4436b3(0x3f5), id: _0x15a450(0x2e5) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3("img", {
                        ref: "hex100",
                        attrs: { src: _0x4436b3(0x3f6), id: _0x15a450(0x2a8) },
                      }),
                      _0xb94b65["_v"]("\x20"),
                      _0x2a2af3(_0x15a450(0x225), {
                        ref: _0x15a450(0x31e),
                        attrs: { src: _0x4436b3(0x3f7), id: "imgHex1000" },
                      }),
                    ]
                  ),
                ]
              );
            },
            [],
            !0x1,
            null,
            null,
            null
          );
        _0x3c7c92["a"] = _0x1b6154[_0x90e214(0x24a)];
      },
      0x3c3: function (_0x13a4be, _0x23f7dd, _0x42d6f2) {
        "use strict";
        _0x42d6f2(0x167);
      },
      0x3c4: function (_0x3d772f, _0x3306e2, _0x2f084f) {
        var _0x1a3c9f = a5_0x17320c,
          _0x222392 = _0x2f084f(0x4)(!0x1);
        _0x222392[_0x1a3c9f(0x295)]([
          _0x3d772f["i"],
          ".container[data-v-1074da9e]{padding:10px;min-width:600px}.container[data-v-1074da9e]\x20.pagination\x20.vs__dropdown-toggle{background-color:#2b3654}.container[data-v-1074da9e]\x20.pagination\x20button{background-color:#2b3654!important}.history-title[data-v-1074da9e]{margin-bottom:10px;height:40px;justify-content:center;align-items:center;color:#ffe588;box-shadow:inset\x200\x20-1px\x200\x200\x20#ffe588}.history-log[data-v-1074da9e]{height:300px;margin-bottom:10px}.history-log\x20table[data-v-1074da9e]{width:100%;text-align:center;border-collapse:collapse;border-spacing:0}.history-log\x20table\x20tr[data-v-1074da9e]{background-color:#494e5c}.history-log\x20table\x20thead\x20th[data-v-1074da9e]{background-color:#2b3654;font-weight:400;height:40px}.history-log\x20table\x20tbody\x20td[data-v-1074da9e]{background-color:#202940;height:40px;border-bottom:1px\x20solid\x20hsla(0,0%,100%,.03);justify-content:center;align-items:center}",
          "",
        ]),
          (_0x3d772f[_0x1a3c9f(0x24a)] = _0x222392);
      },
      0x3c5: function (_0x1638dc, _0x255e84, _0x240fd9) {
        "use strict";
        _0x240fd9(0x168);
      },
      0x3c6: function (_0x28592f, _0x173528, _0x3bfe63) {
        var _0x45a7ef = a5_0x17320c,
          _0x2f63f8 = _0x3bfe63(0x4)(!0x1);
        _0x2f63f8["push"]([_0x28592f["i"], _0x45a7ef(0x2cc), ""]),
          (_0x28592f[_0x45a7ef(0x24a)] = _0x2f63f8);
      },
      0x3d1: function (_0x2b4de4, _0x587e1e, _0x211c1f) {
        "use strict";
        _0x211c1f(0x172);
      },
      0x3d2: function (_0x5022c8, _0x54d4ce, _0x377912) {
        var _0x2d28e6 = a5_0x17320c,
          _0x6c2fe0 = _0x377912(0x4)(!0x1);
        _0x6c2fe0[_0x2d28e6(0x295)]([_0x5022c8["i"], _0x2d28e6(0x2ad), ""]),
          (_0x5022c8[_0x2d28e6(0x24a)] = _0x6c2fe0);
      },
      0x3e2: function (_0xb7bdef, _0x2f3c59, _0x7f405c) {
        "use strict";
        _0x7f405c(0x178);
      },
      0x3e3: function (_0x4a0da0, _0x1cf5f0, _0x3a32fa) {
        var _0xad07b9 = a5_0x17320c,
          _0x1048d1 = _0x3a32fa(0x4)(!0x1);
        _0x1048d1["push"]([
          _0x4a0da0["i"],
          ".blackjack-betslip\x20.content[data-v-d0255fba]{width:100%}.blackjack-betslip\x20.content\x20.insurance-btn[data-v-d0255fba]{margin-bottom:10px}.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-d0255fba]{width:100%;height:40px;background-color:#313e60;margin-right:10px}.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-d0255fba]:last-child{margin-right:0}@media(hover:hover){.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-d0255fba]:hover{background-color:#37456a}}.blackjack-betslip\x20.content\x20.history-btn[data-v-d0255fba]{margin-bottom:10px;justify-content:flex-end;padding:0\x2010px;transition:.2s\x20ease}.blackjack-betslip\x20.content\x20.history-btn\x20button[data-v-d0255fba]{opacity:.6}@media(hover:hover){.blackjack-betslip\x20.content\x20.history-btn\x20button[data-v-d0255fba]:hover{opacity:1}.blackjack-betslip\x20.content\x20.history-btn\x20button:hover\x20span[data-v-d0255fba]{color:#ffe588}}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount>div[data-v-d0255fba]{margin-bottom:10px;flex-shrink:0}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20button[data-v-d0255fba]{flex-shrink:0;background-color:#313e60}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.cash-updown[data-v-d0255fba]{border-right:1px\x20solid\x20#252e48}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.input[data-v-d0255fba]{transition:.2s\x20ease;width:100%;background-color:#313e60;text-align:right;border-right:1px\x20solid\x20#252e48;border-left:1px\x20solid\x20#445174}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.amount-init[data-v-d0255fba]{border-left:1px\x20solid\x20#445174}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance[data-v-d0255fba]{height:40px}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance>div[data-v-d0255fba]{height:100%;align-items:center;justify-content:center}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.title[data-v-d0255fba]{width:40%;background-color:#313e60}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.count[data-v-d0255fba]{width:60%;background-color:#2b3654}.blackjack-betslip\x20.content\x20.bet-select-btn[data-v-d0255fba]{display:grid;grid-gap:10px;gap:10px;grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:10px}.blackjack-betslip\x20.content\x20.bet-select-btn>button[data-v-d0255fba]{height:40px;background-color:#313e60}@media(hover:hover){.blackjack-betslip\x20.content\x20.bet-select-btn>button[data-v-d0255fba]:hover{background-color:#37456a}}.blackjack-betslip\x20.content\x20.submit[data-v-d0255fba]{flex-shrink:0}.blackjack-betslip\x20.content\x20.submit\x20button[data-v-d0255fba]{background-color:#ffe588;height:40px}.blackjack-betslip\x20.content\x20.submit\x20button>span[data-v-d0255fba]{color:#000}@media(hover:hover){.blackjack-betslip\x20.content\x20.submit\x20button[data-v-d0255fba]:hover{background-color:#ffdc60}}",
          "",
        ]),
          (_0x4a0da0[_0xad07b9(0x24a)] = _0x1048d1);
      },
    },
  ]);
