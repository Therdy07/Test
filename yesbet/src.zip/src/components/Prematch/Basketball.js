import React from "react";

function Basketball() {
  return (
    <>
      <div
        data-v-47fb79fe=""
        className="match-title row"
        style={{ flexDirection: "row" }}
      >
        <div
          data-v-47fb79fe=""
          className="league row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-78fee962=""
            data-v-47fb79fe=""
            className="tournament-icon row"
            style={{ flexDirection: "row" }}
          >
            <img
              data-v-78fee962=""
              src="https://mt-sportradar.com/assets/images/regions/780.png"
              alt=""
            />
          </div>
          <div
            data-v-47fb79fe=""
            className="league-name text-ellipsis row"
            style={{ flexDirection: "row", display: "block" }}
          >
            IBL
          </div>
        </div>
        <div
          data-v-47fb79fe=""
          className="desc-title row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-47fb79fe=""
            className="title-1x2 row"
            style={{ flexDirection: "row" }}
          >
            <span data-v-47fb79fe="" className="text-level-11 text">
              Home Team
            </span>
            <span data-v-47fb79fe="" className="text-level-11 text">
              Draw
            </span>
            <span data-v-47fb79fe="" className="text-level-11 text">
              Away Team
            </span>
          </div>
        </div>
      </div>
      <div
        data-v-47fb79fe=""
        className="match row"
        style={{ flexDirection: "row" }}
      >
        <div
          data-v-47fb79fe=""
          className="match-info row"
          style={{ flexDirection: "row" }}
        >
          <div data-v-47fb79fe="" className="date column">
            <div
              data-v-47fb79fe=""
              className="day row"
              style={{ flexDirection: "row" }}
            >
              05/29
            </div>
            <div
              data-v-47fb79fe=""
              className="time row"
              style={{ flexDirection: "row" }}
            >
              13:30
            </div>
          </div>
          <div data-v-47fb79fe="" className="team column">
            <div
              data-v-47fb79fe=""
              className="row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-cc68f3fe=""
                data-v-47fb79fe=""
                className="team-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  data-v-cc68f3fe=""
                  src="https://img.mt-sportradar.com/ls/crest/big/96601.png"
                  className=""
                  alt=""
                  style={{ height: 14 }}
                />
              </div>{" "}
              <span data-v-47fb79fe="" className="text">
                NSH Mountain Gold Timika
              </span>
            </div>
            <div
              data-v-47fb79fe=""
              className="row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-cc68f3fe=""
                data-v-47fb79fe=""
                className="team-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  data-v-cc68f3fe=""
                  src="https://img.mt-sportradar.com/ls/crest/big/868661.png"
                  className="blank-away"
                  alt=""
                  style={{ height: 14 }}
                />
              </div>
              <span data-v-47fb79fe="" className="text">
                Tangerang Hawks
              </span>
            </div>
          </div>
        </div>
        <div
          data-v-47fb79fe=""
          className="odds row"
          style={{ flexDirection: "row" }}
        >
          <div
            data-v-47fb79fe=""
            className="odds-1x2 row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-6bf0219c=""
              data-v-47fb79fe=""
              className="outcome row"
              style={{ flexDirection: "row" }}
            >
              <button data-v-6bf0219c="" className="button">
                <span data-v-6bf0219c="" className="odd text">
                  2.25
                </span>
              </button>
            </div>
            <div
              data-v-6bf0219c=""
              data-v-47fb79fe=""
              className="outcome row"
              style={{ flexDirection: "row" }}
            >
              <button data-v-6bf0219c="" className="button">
                <span data-v-6bf0219c="" className="odd text">
                  1.58
                </span>
              </button>
            </div>
          </div>{" "}
          <div
            data-v-47fb79fe=""
            className="detail-wrap row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-47fb79fe=""
              className="detail row"
              style={{ flexDirection: "row" }}
            >
              <button
                data-v-47fb79fe=""
                className="button text active"
                style={{ background: "transparent" }}
              >
                <span data-v-47fb79fe="" className="text">
                  +46
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Basketball;
