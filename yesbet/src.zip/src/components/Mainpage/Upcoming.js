import React from "react";

function Upcoming() {
  return (
    <div
      data-v-4dc2aaba=""
      data-v-756132ea=""
      className="upcoming row"
      style={{ flexDirection: "row" }}
    >
      <div data-v-4dc2aaba="" className="column">
        <div
          data-v-4dc2aaba=""
          className="title row"
          style={{ flexDirection: "row" }}
        >
          <span
            data-v-4dc2aaba=""
            className="text"
            style={{
              color: "rgb(255, 229, 136)",
              fontWeight: "bold",
            }}
          >
            Upcoming
          </span>
        </div>
        <div data-v-4dc2aaba="" className="match-list scrollable-auto column">
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 07:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/4.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Int. Friendly Games W
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Paraguay
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Ecuador
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 08:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/13.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Copa do Brasil
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                SC Internacional RS
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                CS Alagoano AL
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 08:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/13.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Roraimense
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Gremio Atletico Sampaio RR
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Sao Raimundo EC RR
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/392.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                U17 CONMEBOL Championship
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Ecuador
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Paraguay
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/13.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Copa do Brasil
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Sao Paulo FC SP
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Ituano FC SP
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/48.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Liga Profesional
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Instituto AC Cordoba
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Velez Sarsfield
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/48.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Liga Profesional
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                CA Banfield
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Defensa y Justicia
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/48.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Liga Profesional
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                CA Central Cordoba SE
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Atletico Lanus
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 09:30
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/13.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Copa do Brasil
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Fortaleza EC CE
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Aguia de Maraba PA
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 10:20
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/274.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Primera A, Apertura
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                America de Cali
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Aguilas Doradas Rionegro
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 11:15
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/393.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                CONCACAF Champions League
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Los Angeles FC
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Vancouver Whitecaps FC
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 12:05
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/12.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Liga de Expansion MX, Clausura
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                CSD Dorados Sinaloa
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Venados FC
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 15:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/291.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                FA Cup
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Gyeongnam FC
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Siheung Citizen FC
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 17:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/18.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                U19 1st Division
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                FC Hradec Kralove
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Slavia Prague
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/52.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                J.League 2
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Omiya Ardija
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Thespakusatsu
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/52.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                J.League 2
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Tokyo Verdy
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Blaublitz Akita
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/52.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                J.League 2
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Tochigi SC
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Montedio Yamagata
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/52.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                J.League 2
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Shimizu S-Pulse
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Vegalta Sendai
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/52.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                J.League 2
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Zweigen Kanazawa
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Iwaki FC
              </span>
            </div>
          </div>
          <div
            data-v-4dc2aaba=""
            className="match row"
            style={{ flexDirection: "row" }}
          >
            <div
              data-v-4dc2aaba=""
              className="date row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                04/12 19:00
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="event row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-4dc2aaba=""
                className="row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-4dc2aaba=""
                  src="https://assets.support-yes.bet/img/1.e26e720.svg"
                  className="sports-icon"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                Soccer
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="league row"
              style={{ flexDirection: "row" }}
            >
              <div
                data-v-78fee962=""
                data-v-4dc2aaba=""
                className="tournament-icon row"
                style={{ flexDirection: "row" }}
              >
                <img
                  alt=""
                  data-v-78fee962=""
                  src="https://mt-sportradar.com/assets/images/regions/291.png"
                />
              </div>
              <span data-v-4dc2aaba="" className="text">
                FA Cup
              </span>
            </div>
            <div
              data-v-4dc2aaba=""
              className="team row"
              style={{ flexDirection: "row" }}
            >
              <span data-v-4dc2aaba="" className="text">
                Daegu FC
              </span>
              <span
                data-v-4dc2aaba=""
                className="margin-horizontal-5 vs text"
                style={{ color: "rgb(255, 229, 136)" }}
              >
                vs
              </span>
              <span data-v-4dc2aaba="" className="text">
                Cheonan City FC
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Upcoming;
