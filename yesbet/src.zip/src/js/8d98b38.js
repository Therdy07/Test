function a16_0x47bb() {
  var _0x1d331e = [
    "2em",
    "cashout",
    "\x0a\x09\x09\x09\x09\x09\x09\x09\x09\x09\x09",
    "win",
    "\x0a\x09\x09",
    "translate",
    "removeChild",
    "skip\x20stake-1xp6zc8",
    "canvas",
    "5em",
    "bet-select-btn",
    "getCrashGameState",
    "cur_page",
    "\x0a\x09\x09\x09\x09\x09\x09\x09\x09",
    "now",
    "스탠드",
    "#icon-icon-casino_icon-equal",
    "fa-solid\x20fa-diamond",
    "currentCard",
    "catch",
    "$swal2",
    "lineWidth",
    "fa-solid\x20fa-angle-right",
    "weight-semibold\x20lineHeight-base\x20inline\x20align-left\x20size-medium\x20variant-highlighted\x20with-icon-space\x20player-count-number",
    "Same",
    "getRealValueForShow",
    "bust",
    "setCrashBet",
    "#1a2c38",
    "down",
    "mucked",
    "IsInsurance",
    "fillText",
    "width:\x205em;\x20height:\x207.9em;\x20--transition-time:300ms;",
    "value",
    "setCrashLeaderboard",
    "bottomGuess",
    "defineProperties",
    "globalAlpha",
    "setCrashGameId",
    "formatNumber",
    "175850IHUoTt",
    "fa-solid\x20",
    "payout",
    "left",
    "mark",
    "rangeY",
    "amount",
    "input\x20spacing-expanded\x20input-icon-after\x20stake-17q8hbc",
    "cardHistory",
    "risk",
    "profitOnWin",
    "wrap\x20svelte-player-count",
    "!isManual\x20&&\x20!isAutobet",
    "active",
    "indexOf",
    "wrap\x20svelte-n07u8e",
    "number-multiplier\x20stake-1ogwhrk",
    "middle",
    "webkitAudioContext",
    "progress-bar\x20svelte-progressbar",
    "isManual\x20&&\x20(getCrashGameState\x20==\x20\x27join\x27\x20||\x20getCrashGameState\x20==\x20\x27waiting\x27\x20||\x20getCrashGameState\x20==\x20\x27end\x27)",
    "amount-init",
    "Skip\x20Card",
    "result",
    "maxY",
    "setBetdisabled",
    "blackjack",
    "#B7BFD6",
    "margin-bottom-10",
    "inherit",
    "fire",
    "$auth",
    "setDoubledisabled",
    "content\x20svelte-1wtyksp\x20face-down",
    "players",
    "graphHeight",
    "isStartedBet",
    "startCard",
    "dealerWrapper",
    "playerValueResult",
    "CrashPlayPanel",
    "18648YvFIZU",
    "getCrashUMultiplier",
    "dCard-",
    "settingForm",
    "play",
    "labels\x20stake-5v1hdl",
    "getSplitdisabled",
    "detachEvent",
    "isControl",
    "#icon-icon-casino_icon-currency-btc",
    "includes",
    "Hidden",
    "prevFaceDown",
    "autobetcount",
    "indicator\x20svelte-crash",
    "row",
    "cashOut",
    "On\x20Loss",
    "split",
    "user_name",
    "label-content\x20full-width\x20svelte-ri5vof",
    "0\x2010px",
    "getElapsed",
    "#fe2247",
    "resetCashout",
    "getOwnPropertyDescriptors",
    "profitAmount",
    "formatBetNumber",
    "currentValue",
    "save",
    "reset",
    "insurance",
    "\x0a\x09\x09\x09\x09\x09\x09\x09\x09\x09",
    "checkFinishedAfterDeal",
    "textBaseline",
    "dealt",
    "data",
    "updateState",
    "offsetY",
    "BlackjackRepository",
    "wrap\x20stake-1wtyksp",
    "data:audio/mpeg;base64,//uAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAHAAALbQAkJCQkJCQkJCQkJCQkJElJSUlJSUlJSUlJSUlJbW1tbW1tbW1tbW1tbW2SkpKSkpKSkpKSkpKSkpK2tra2tra2tra2tra2ttvb29vb29vb29vb29vb//////////////////8AAAA3TEFNRTMuOTlyAZwAAAAAAAAAABRwJAJNTgAAcAAAC21lPFFrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/+4BkAAACxiDBhSUgAClAB0WgiAAQ7Yk8uPaACKCAIsMCMABiyMLhsn2CBGjRz3/zQQuc/CxWAADBJZGCYJitvJoyMVo29gjb3+aOdI0aNuc/UEbZ8QAgAwffBA//+nsLg/BAE4gBDrlwffKA+oEAQ9QPg/gmD58QBiD4fMYQGt68vLh/EjgfPxOD5/wf/KAh+XeU//4jD/+IAQ9QYxACDgQOeD4f/+37Y2v6D4slr9CIzxCr7gSRHFZwmFQVIOcaEoeII9hMSgLMWrzBAchfHYalRwmkRBbpusoF44MAisxHYDa/PTNTuJyPErPkxf/oUmN3Nz5cSQ/9kFIGgwZgaGB5kDAjgDSHRKg3+80PGy01qdNZu5gydBNlX+391OmYWXSdStnMS4PUqL6tFOjGFbh2QdrWpKdwjZ+bOsaO3dm5/1tNLHvIF/9A7S41/0tbprL64kX696iAZGWd+/rdrnb+EcdwxSZgq5imaP/7gmQLgAPDYdQGYaACLQAJHcCAAA7Jc2AY9YAArAAkcwAAAIHSmioCji47JoUTVATAnj3frO2qZMvl80UyH0dcyL5kPAFmGx7+1rhcCkMINhKFxD6Q+opL7onDp4Sgml80WmmxRdnX/TTdls1nU6Zw+aHkEzcZZIe3/tf+rywwQUXGVHrIBhoGoNpNRhJAAApIgv1VMse+qAoogkqfSWSsr9c49rGf//+z81nfVm/e3/1gG6yQpbUEa0v3vc0G+90+ZmzxUHo1gul5aQZkaKJP3Oj1qfNzF3P8c5UCeAsOr5a1H9yuOkuH4faVHejMuUD0ep7Z3MLR9L2/HMGze59zK/m3O9zD8m5ibAkL8bnLto1UXa1sdzVRZ3mbbdU4+n/+1znerCvqQQGywKQkijVNAhEyrOPa/WvGqXempNxq5os9vYqQbq/1f/oT/2+3q/ae7lISsFZkLolM6+WNh1Wt1G2MXuBOIs1TpjCLGv/7gmQNAAOtZFcGPUACJ6AY1cAAABFBWVgY94AAqIAlNwAAAJE6tLnnnkQgAuQL6aEicPiwoBsC8qprKk92MJwbyYLwGsfsvNb+eZcRA0Wm/b37mi24ixbJy1/9zdfZeDYF4LAAMAuF+PRFk5jf3a1f//mOPBYArhfi2BULHkCggAlAECGr6bNFGMeRRpON2tIlms0avqZvzP+9npvSm//Xlqb7DHD6EUJVHkNVD9Xqu81qIYUjI04jipOVSFyjNoYZeXaJao2rbJ5wxhMpoNG6Jn4ZWM/S/TWs+9tVtnsMFUna7TuM/P1j/H6E3YrMSet8/NYsX//17fHo/21wmJ9nVc/GMZ+f///GN4v1T9OWBOuWZ98T2jYxv//6////OZSnS9VqGoa3K6M2PkO1KYKEdZGLXAGHRGw0AAAowgmua91J1Sdupa2cfru9Wj///6tJJta98//+j/+5VQDJECAAAtmEbo4oYnyiFLVh1P/7gmQJACOKYNBnPQAAKcAIueAAAA65jTmsPO3AjIAi4BCIAHasKmI3J85dZ6DsQQFTAdHKAYRjmJDkPyiw6Fh6Oc3BrlHyPFqll4q5kVu24rkSWvqnH/Ew/Mw8CS6kdGq1bxe1r3/dfH/NfLcHfs3/98knS0r////8///81+x0fI7jAGqYgAAHpucOXahqZZVaziUbY2Lrc7/R+i5ns1blPjuz9DFabKtVuj3pCV2jRAQAAdkBDJFeylWGUOPOOw9V12pTUcE9kOcpZjRh3ZZp5mR644gC2jwbndXK0BrcvquK+AzNdI/+satv/Uve1QscWGpIlSpRGXZWrZHNJI6FvmVar68dzjvVscPY46jtvtG1AVOiw0179ft//+RN60yioKHGVI1j0NTMVMXXntqEyTf7e/7qf+h2xe30K7Oz0+3q494qAW1sIAAAAsVQxpZpEmTy5rssaVD0OO8aSmi3Rs26YVXrZyPlW6kmS//7gGQUAgPWS8vrD1rwIuAI3AQAABHRMyOH4WvAh4Ai4BAAABOBL6ZqXvMuYn9bPtwGKG4wKXObm7N7nDJ+dIFIb31BsbQlG7zXpsMi6sk8Qxsf3bOGzW78ib2Kru7lSGBkZPa/hykVy6pZ2FJYeCbrWubZ/75YtsJQpVSIKCDkvG2la0Ire/o6Pvmuqy/9/ef/b/6fV/7n/0gFuIgAJCZgGoZo4SbTH64GAwE2bZt+X2pYflMtp5LD0Sl0fgZeLTtyh/WNhQge2JxirVgSRTLm81jav8W1Lp18nF1HTqBrW97lDEBAoIIjCgeLi0tgoNA1VOTMQOnXtNdU1bRAGZqTpNauZMHpxDzXmVpcCGt0r9x8NHshb/qHneuq6vFo4YXPkf3UI3/LKAMgJB9kc17DZtNtm3R66U6FMkNl3R/TvZbT6yf/+r99KQGeQAAGDvAVE8+f5jR05l7Go5bGX2nqS/TdlkN5SVsz6M0j//uCZBGCBDVTSEn4WvAlwAjLBAAADnEzJaY9a8CKgGNwAAAAb8TLOQsUW9TyGmvTsZvQLrf//yucllmB6kEy9/fdGygKkiRoI5cQpG3kglEcjsbFwZNUORFlXBdUdHXfokCandx19s/H1f5+P/Hm2X37X/9RuxaEZJzep/iIuFgiF21HvtQ8u0EXEiX3epjXPOpuMKRGb1jFet+miN69v26r/9H/7Z592/+/r7VhxNOMACM1KzZFAmxasDl8iuK9XvXq2yvYdoh9FAOmzE+UAR0eECuZGGHAr//jGG1kvJ1zc1/DogREpOHXtnVckTImG8HaqbbKvaO2+n156V0OO+/x6i1D7OO4cwgC5t1HM1w6+/kgQ41QKBSmkDkDvnb71JNQkoqmQFJXE0Rr9jqUpK2lbmb1hPaQYj///+///6ftt/66FVhAAAggfQx8D7rM1tu61Grje86Yp6tz9PTvXSeRwawjaMjWbmbcka3z//uCZBUCAx5MR8mPUvAj4BipAAAACuTxAgS9C4CIACBwAIgA/i7C4R2XD0fUeuqADSSWHw+ONNnD4+y549STMht6PnGPqPTCrOhz74gS3NbQ7Hz/paqfISX//7cjrbYAlJAAAxJJKeU/qkWJcqvVZCthaq2h9n1f9n6f86/6v/3fSIh4UqNsy2/V63n7z8Wzmrc7LamUapk+LiLMRRCWCIzQYtt6+bpnFYtpZab4ugdDgAMGQqdNMvzBypbSsbKl7OsNKtF+qlHCr03+xLmx87b9QFM7v/KtrRsbjkczMMtySTFkbqE9mw77ej/O7fV/zzX2//X/v/5Jn6pMQU1FMy45OS41qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq",
    "setCrashUmultiplier",
    "crash",
    "dCard-1",
    "setCashoutdisabled",
    "doGuess",
    "state",
    "lastPage",
    "rangeX",
    "prepareBet",
    "5180ad71",
    "Stop\x20on\x20Profit",
    "main\x20stake-k2ijz0",
    "transform",
    "strokeStyle",
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "10px",
    "variant-game\x20line-height-150pct\x20text-size-default\x20spacing-primary\x20weight-semibold\x20align-left\x20square\x20stake-4s0iv9",
    "fa-solid\x20fa-chevrons-right\x20fa-sm",
    "getCurrentMultiplier",
    "equal",
    "switchHand",
    ".container[data-v-0f3cd04b]{padding:10px;min-width:600px}.container[data-v-0f3cd04b]\x20.pagination\x20.vs__dropdown-toggle{background-color:#2b3654}.container[data-v-0f3cd04b]\x20.pagination\x20button{background-color:#2b3654!important}.history-title[data-v-0f3cd04b]{margin-bottom:10px;height:40px;justify-content:center;align-items:center;color:#ffe588;box-shadow:inset\x200\x20-1px\x200\x200\x20#ffe588}.history-log[data-v-0f3cd04b]{height:300px;margin-bottom:10px}.history-log\x20table[data-v-0f3cd04b]{width:100%;text-align:center;border-collapse:collapse;border-spacing:0}.history-log\x20table\x20tr[data-v-0f3cd04b]{background-color:#494e5c}.history-log\x20table\x20thead\x20th[data-v-0f3cd04b]{background-color:#2b3654;font-weight:400;height:40px}.history-log\x20table\x20tbody\x20td[data-v-0f3cd04b]{background-color:#202940;height:40px;border-bottom:1px\x20solid\x20hsla(0,0%,100%,.03);justify-content:center;align-items:center}",
    "suits",
    "600\x20",
    "Bet\x20Amount",
    "playerOtherValueResult",
    "Profit\x20on\x20Win",
    "Lower\x20or\x20Same",
    "width",
    "log",
    "setCrashAutoBet",
    "minY",
    "$repositories",
    "games",
    "rounds",
    "total",
    "dealer\x20svelte-15ph9dz",
    "appendChild",
    "face-content\x20svelte-soy9i6",
    "cards",
    "pCard-",
    "reorderBetlist",
    "@font-face{font-family:\x22brandon-grotesque\x22;src:url(",
    "10254meGRww",
    "dealerValueResult",
    "playerOtherCards",
    "plinko.betDate",
    "lower",
    "input\x20spacing-expanded\x20input-icon-after\x20input-icon-before\x20stake-17q8hbc",
    "v-button",
    "weight-semibold\x20lineHeight-base\x20align-right\x20size-medium\x20variant-highlighted\x20numeric\x20with-icon-space\x20truncate\x20svelte-1bjlgfi",
    "upperY",
    "auto-bet-button",
    "hiloBet",
    "plinko",
    "MM/DD\x20HH:mm",
    "token",
    "quickAmount",
    "getCashoutdisabled",
    "!isManual\x20&&\x20isAutobet\x20&&\x20(getCrashGameState\x20!==\x20\x27in_progress\x27)",
    "sent",
    "wrap\x20svelte-13td3s2",
    "firstCoordinate",
    "svelte-1xzc9au\x20crypto",
    "9KoJpmR",
    "setCurrentMultiplier",
    "elapse",
    "history-title",
    "resultShow",
    "0.00",
    "translate(0px,\x200px)",
    "pCard-1",
    "wrap\x20stake-1xp6zc8",
    "join",
    "perPage",
    "100%",
    "back\x20stake-1wtyksp\x20face-down",
    "data:audio/mpeg;base64,//uAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAKAAAPtgAZGRkZGRkZGRkZMzMzMzMzMzMzM0xMTExMTExMTExmZmZmZmZmZmZmgICAgICAgICAmZmZmZmZmZmZmZmzs7Ozs7Ozs7PMzMzMzMzMzMzMzObm5ubm5ubm5v////////////8AAAA3TEFNRTMuOTlyAZwAAAAAAAAAABRwJAY6TgAAcAAAD7YRHzDqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/+4BkAAACykq9BQhgAikgCH2hjAEOSZFEGNUACQCmKAMicAADPIQhPQmd9c//cQm4GLc0d30RCqIiIiFogAIQt3AEKu//u/ESgAgq7u5l7u7u6Iidd3930RKAJXFv9RC3d3gGLf+nHNAAQjDwDw8f8cPP/45/4GRw94/8w8NByx6WVxtVn1AhLvi9t0u+Q9mJ3z/Lv4f4Jg/EDv7//OLD///7fg/y7wl3ArDk3sXvJA0zGEIP+xlxFj32PPcWxAKv/sMmC7C//PFgxiSLYAsGsfhYGP9pAxGlzB8aaVCf/zFc8xTzzAGxDuYIEQ4hyISfV/zyRipA+5GRBeDULkRQtisVOLCj//l6o6MQNbxsbJyAkFckLliUkTjBtCIMi/Uv/3M+jDhD95gkGN/43G540If/wGCQwB5f//PZTyDf/+uNBwgTQwaGjf/77fweA8EgS3uSf//+xKEjtmVg95y1s8SLuzhM4O8QAB0Wsf/7gmQKAAMLYVcGMKAAPMm6wMgIAA3RVVoY+AAA/qCrQx5wAED7iBSuni87mkWqUAhKBwYYx9GmeKOQgfD/ZlEqVTD4pOHA4KJXS7PeVawOdzEYPh8XtMr3VXSxdalFAAFCIRjnPP///l/6hwOCgu/D4sEc9Qfcrv6d95lzv+xGL/fJ1/Oep1sjv+9XAAC639PEC3qc66f/4ggxCMcio6///ynFhAAY5///76gQD4wDmAlYQ1p5jmZz/gtpIVAjXuuPR9zBSw5Qiozw5xVPoJMNAUEQEulKcRdWTSzJLRUyTGlGQ0yMp0mbst6KPlRlrUtWtdBk631LnFstSaK0aHXSay0UNI4TRiTpdSdal9f9mu/9JJ1LReXVD//uUPRUenkOjXtjG+1R4Vs4ICa+D8gNWNKNlxaPOXSq///ppb/89FNQ5P/9TTVjw1GoQ1XT/8bDYbDp1bv2fLP1iVUEtVVDAAAAARoF+IQowzTSaf/7gmQIgANOJ1V3PMACM+LaueWIAA7hOVXMMMvIroJqfPeMCGZdOzgMM87K1UvVdqYINTFOWc8wxspYtBavT0591Pbt96LmSkYfdmZuZ/bPGagH4CyPGeIgO1YgsLN/cr1f5ukR7tP7UTpBHV9zlZHcWvxn1aZKte1sAq5t//3a5AQXEE65qb2S2tdzmIQGLBKKRuc1mv/BHD+UhYBkHcuIQI0B9bFiqAsaFk//fbpZQTvLoiiIigAC02gsEZdTulKwE5aL8RaCgnWMGXHN0qlp5xr4bR9f6bnsM7t3cnH+nOhrOTvPem2L7Z2Ty8J3fEdAzZd5doySd1j+z5nXu3hvv11xGEI7Rn+GfNzNTvv/+1OgnkR37FpyW7K2PrLOBZ0EbrfjLFhKWyKhqAiEUA04cY8Qpg0swSDMMrCDCJKM9Okr6Uv/O/9+hKJnT//VU///+tVr14RnQkhQACektTRYoJTnFg+lxlYPkvsUQf/7gmQNAWPNXlXx6BtyKcLp6zxCOI9heVvHmM3Ii4chzDCsmBCCURkFSVsiSC4gyoFj24+4iFWPiLLRSkG1CyPl6/DeYCOeZUiBCNhJvIuCAz6ozHh3LUkJLTEVBDYqgK5KTPiHgPGM6GCoFajHpSoiRhGUo4gulLC2jkrF+bIHtnnG4YkUgAAIJ6WEYp42zmpr3RdLwrf0Nq1erIBFyo1jOS/k8rPaFCVZ3SVDXZVWzuSHSJzjrIIQSIQQnDMiCeMZlnodD0HoBoUojRYd8W4tJmvtacTylNcXDQUnZ05/jPsxj7Hnu4dRqSBeb/+8duZ81sDSZnxvfmzXyzyjcZ//lmNf7L7+V5m6TXSzLzv9x3L2aC6Qayirnut99+6SrxuP8booPiI04OAjZhjQgmpl90TV5iBCCKds7SEiP4qAiJn/ywTDLv4sa/oVl2ZjRDIuUAAHVHAoHLF41KIuoqnSwMvvBL8piR58woFAif/7gGQRAfPtXlhzKRt0KwImSD2POE+paV/HpM3IAAA0gAAABBCAfBJm0KF5ManjVQL15wl6PTbvK6+3a7a9tLyd8Nzh/LTCrQwgIXt6+LUMyb5+aWe3Sn5ZrIkGyiS7cKaERujkw4AAaQoVBh6gZTGCCSuedROVzQXFlZUHtDVIALAAAHEMkghNySmkuXA+z5/rrTrjkchWHg6gvROhawDECREkHWapxK2E3VvUsjoRSgwGcQBUq4yTGP5WHMmzqRp8MQaNChArMd3U4weuvWQVSRlNvPFPJq96tVu5U/vtvbqp1jNsNFoM1Rb93+VePVVngryjHzfTpY5V3CGl4dnaZ2zrat15ju3L52c5JWpowqFkryi0M/BZ2lOqkv7iJJK4xZApPVD4hpdVVTMqlUE/AJcttzsIOc5J4x2qlYXI5TfmAFWhUnplzazOGySbT4G2f87/Hvy6uKzl9yXrz9XHco5HcizGGnqujpqp//uCZCKA81lXWXHpK3YAAA0gAAABDMSdXewwaUgAADSAAAAEcwrQhGsuNW6lcspbr/W2+if6OV2Vq3U1qt19lIDe5SqU9NEmfoR+3ru7upOIEAAPg6CPCdfW9VvCqGGTwJgcfDkWWLSlXzR71o1duv2UgTMqNAQqOrFBA4YB0Lzbs5fKDa+LgHBhzlX/2w5B3zNZbd+r//0++0m3EBsR1C1UC3wMuE3Z6GpXS//7WXbqAtrttcZRRAP/+W4gouRwsIkCOFB/ZeaDufpmcEhO0TV6HFMBY4ojaynoruVMrjaa4t6UnHlpRuvPdnnwuSWeLJaSMOBU91oW5r9P1sKmMVdU3rpWeSCzSdiLQ0pU5KGjMgCisrTgig8QwsCLxqLI7D8HogGw5I2/U+ts9jV/rOGok7b7N0ERjNSVp52kGb//Q1gaDecxMKHfjxa2PjeOYr3xpbxWT/t/9+xvLmubFf/VBvMWTa0OuDav9EmG//uCZF6A8uUm1+nsMlAAAA0gAAABDBB9T8YwaUgAADSAAAAE1Xh3VGZBCBEkkueabHkWnYBQRBJGDE/OhCH9aSWev9eZ6azXmYdHZv2Ff7NxiYKTYUKMxyHhRKB0Gnh0qRLHioKokukGVB1jhW5Qcp6g67DSxgTJJRDVajsOhpSSK3CJQVGCDcyAH8qq0HQKQCgOBkFpQ0PVayRUVNUVrKOZm+WvZpFUFqbi+GvoCMyrspVVUocO/1QoZv1L9V9VIMW3/wlgoKJUtmMKJ2Y//Y1Vm41LhMcAgICiE6BTJ1Mr8s7EtwdVTEFNRTMuOTkuNVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//uAZKSA8wsiz/mMGlAAAA0gAAABC/0tHwQga8AAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQgAB/mwluSuG+V0uKYEQaLE0YItjH1//VxWpqKzxSZIiZkibZIj7Kz1gSPikzKMk55REaEIZWTTg+NbklU4PZldXX2NXCeSxpCsqkupNVKeb7r///40quZRKpLwmkk2ytNyzxSVQGkK03NWlUxBTUUzLjk5LjVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+4JkkI/zXlE3KClK8gAADSAAAAEAAAAAAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjk5LjVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVX/+4JkWo/wAABpAAAACAAADSAAAAEAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=",
    "hit",
    "isManual\x20&&\x20getCrashGameState\x20==\x20\x27in_progress\x27\x20&&\x20(isCurrentBet\x20==\x20false\x20&&\x20isNextbet\x20==\x20false\x20||\x20isCurrentBet\x20==\x20true\x20&&\x20this.multiplier\x20<=\x20this.getCurrentMultiplier)",
    "actions",
    "upperX",
    "audio/mpeg",
    "font",
    "#icon-icon-casino_icon-ghost-mode",
    "Lower",
    "poCard-0",
    "resetStand",
    "min",
    "Profit\x20Lower\x0a\x09\x09\x09\x09\x09\x09\x09\x09(",
    "audio",
    "slider\x20variant-dark\x20svelte-17cnp9o",
    "fontSize",
    "negative",
    "getCrashBetId",
    "waiting",
    "setSetdisabled",
    "f5cfe0bc",
    "resetHit",
    "px)",
    "Next\x20round\x20In:\x20",
    "getBetloading",
    "\x0a\x09\x09Cashout\x0a\x09",
    "startAutobet",
    "clear",
    "isAutobet",
    "keys",
    "betEnd",
    "historyFaceDown",
    "default",
    "plinko.risk",
    "face\x20none\x20stake-1wtyksp",
    "map",
    "absolute",
    "per_page",
    "initY",
    "-2.5",
    "footer",
    "fa-solid\x20fa-club",
    "deck\x20stake-1xp6zc8",
    "fa-regular\x20fa-eraser",
    "#icon-icon-casino_icon-arrow-up",
    "content\x20svelte-z4ax21",
    "horizontal\x20stake-1wtyksp",
    "readyProgress",
    "translate(0,\x202%)",
    "143436kjEiNM",
    "blackjackBet",
    "Network\x20Status",
    "\x0a\x09\x09Starting...\x0a\x09",
    "lowerEqual",
    "wrap\x20stake-k2ijz0",
    "full",
    "topCard",
    "dealerCards",
    "div",
    "setCrashTimestamp",
    "stop",
    "_self",
    "add",
    "center",
    "percent",
    "Manual",
    "Cashout\x20At",
    "Stop\x20on\x20Loss",
    "input-content\x20stake-17q8hbc",
    "getOwnPropertyDescriptor",
    "moveTo",
    "getContext",
    "crashboard",
    "$refs",
    "label-content\x20stacked\x20svelte-ri5vof",
    "18fea2d4",
    "1477XSaBgr",
    "10ch",
    "offsetX",
    "getGuessHighInfo",
    "isManual",
    "history-wrap",
    "values",
    "plinko.riskEnum",
    "deal",
    "$emit",
    "lineCap",
    "#202940",
    "input-wrap\x20stake-17q8hbc",
    "12px",
    "translate(0,\x20",
    "setAutoBet",
    "9593336CojjyF",
    "weight-semibold\x20lineHeight-base\x20align-left\x20size-medium\x20variant-subtle\x20numeric\x20with-icon-space\x20truncate\x20svelte-1bjlgfi",
    "weight-bold\x20line-height-default\x20align-center\x20size-default\x20text-size-default\x20variant-success\x20numeric\x20with-icon-space\x20truncate\x20stake-129khay",
    "setChanceAndPayout",
    "onresize",
    "v-icon",
    "moveCardToInitPosition",
    "betId",
    "prevCard",
    "variant-game\x20lineHeight-base\x20size-small\x20spacing-primary\x20weight-semibold\x20align-center\x20svelte-oho9kj",
    "halfAmount",
    "profit\x20stake-5v1hdl",
    "index",
    "bottom",
    "108ffd82",
    "balance",
    "cancel",
    "getElementById",
    "getCrashMultiplier",
    "prevValue",
    "beginPath",
    "#icon-icon-casino_icon-stake-game-crash",
    "hide",
    "moveCard",
    "remove",
    "wrap\x20svelte-gro036",
    "hilo-betslip",
    "fa-solid\x20fa-angles-right",
    "setProperty",
    "5334990ZqMgil",
    "horizontal",
    "wrap\x20stake-18pg48l",
    "input",
    "ranks",
    "rank",
    "getCrashTimestamp",
    "doHitOrDouble",
    "300ms",
    "px,\x200)",
    "svg",
    "loss",
    "12ch",
    "player",
    "getCrashGameId",
    "preventDefault",
    "game-result-content\x20stake-1ogwhrk",
    "webpackJsonp",
    "draw",
    "\x0a\x09\x09Cancel\x0a\x09",
    "user",
    "stroke",
    "weight-normal\x20line-height-default\x20align-left\x20size-default\x20text-size-default\x20variant-subtle\x20truncate\x20stake-129khay",
    "setSplitdisabled",
    "PlinkoRepository",
    "skipCard",
    "fa-regular\x20fa-cards-blank",
    "round",
    "\x0a\x09\x09Start\x20AutoBet\x0a\x09",
    "schedule",
    ")\x20format(\x22woff2\x22)}.game-content.svelte-1wfq6vq[data-v-108ffd82]{width:100%;display:flex;flex-direction:column;justify-content:center;flex-grow:1;-webkit-user-select:none;-moz-user-select:none;user-select:none;position:relative;overflow:hidden;margin:0\x20auto}.wrap.svelte-gro036[data-v-108ffd82]{flex-grow:1;width:100%;padding:3em\x201em;grid-gap:1em;display:flex;grid-template-rows:minmax(max-content,100%)\x20max-content}.dealer.svelte-gro036[data-v-108ffd82]{position:absolute;top:0;right:0;transform:translate(-50%,-75%);font-size:1.2em}.hands.svelte-gro036[data-v-108ffd82]{position:relative;width:100%;min-height:250px;display:grid;flex-grow:1;grid-template-rows:repeat(2,max-content);align-content:space-between;background-size:40%;background-position:50%;background-repeat:no-repeat;background-image:url(",
    "getElementsByClassName",
    "decodeAudioData",
    "setCrashNextBet",
    "settingForm.amounts",
    "minX",
    "back\x20svelte-1wtyksp",
    "neutral",
    "resetBet",
    "setCrashNumbers",
    "transition",
    "activator",
    "plinko.odds",
    "stand",
    "getValueStep",
    "dom",
    "$error",
    "input-wrap\x20svelte-1vu9of",
    "charCodeAt",
    "currency\x20svelte-z4ax21",
    "game-content\x20stake-1wfq6vq",
    "global.noData",
    "hand-wrap\x20svelte-eq0hy3",
    "audio-win",
    "content\x20stake-1wtyksp",
    "betMoney",
    "type",
    "Number\x20of\x20Bets",
    "bet",
    "audio-bet",
    "02c55b58",
    "fillStyle",
    "보유금액",
    "CrashSettingPanel",
    "right",
    "!isManual\x20&&\x20isControl",
    "isNextbet",
    "getCrashBet",
    "stopProfit",
    "#00E449",
    "defineProperty",
    "quadraticCurveTo",
    "content-or-loader\x20svelte-1uofbko",
    ".00",
    "red",
    "#253742",
    "doSkipAnimation",
    "4294967000",
    "136bJZwpt",
    "fetch",
    "text",
    "setCrashResultboard",
    "resetInsurance",
    "face\x20none\x20svelte-1wtyksp",
    "wrap\x20svelte-1ulh9na",
    "0ms",
    "fa-solid\x20fa-splotch",
    "0px",
    "label-wrapper\x20svelte-z4q0w4\x20stacked",
    "e5d87aea",
    "acceptInsurance",
    "hilo",
    "span",
    "floor",
    "getDoubledisabled",
    "face",
    "1\x201\x200%",
    "label",
    "Split",
    "getIconName",
    "end",
    "classList",
    "getCrashNumbers",
    "6ec4dce2",
    "stopLoss",
    "skip",
    "chance",
    "game-result-wrap\x20win\x20stake-1ogwhrk",
    "stacked\x20svelte-ypka6t",
    "400ms",
    "current-card\x20stake-1xp6zc8",
    "wrap\x20svelte-2ah6g4",
    "lineTo",
    "!(isControl\x20&&\x20!isManual)",
    "margin-right-5",
    "$nextTick",
    "exports",
    "currentCardFaceClass",
    "prepareDeal",
    ");background-color:#fff;background-position:50%;background-repeat:no-repeat;background-size:100%;-webkit-backface-visibility:hidden;backface-visibility:hidden}.current-card.stake-1xp6zc8[data-v-18fea2d4]{position:absolute;top:0;left:0}.current-card.disable-flip.stake-1xp6zc8\x20*[data-v-18fea2d4]{transition-duration:0ms}.prev-card.right.stake-1xp6zc8[data-v-18fea2d4]{animation-name:stake-1xp6zc8-flyRight-18fea2d4}.prev-card.left.stake-1xp6zc8[data-v-18fea2d4]{animation-name:stake-1xp6zc8-flyLeft-18fea2d4}.prev-card.stake-1xp6zc8[data-v-18fea2d4]{animation-fill-mode:forwards;animation-timing-function:ease-in;animation-duration:var(--duration);position:absolute;top:0;left:0}.skip.stake-1xp6zc8[data-v-18fea2d4]:not(.stacked){left:100%;transform:translate(-50%,-50%)}.skip.stake-1xp6zc8[data-v-18fea2d4]{position:absolute;top:0}button.variant-game[disabled].stake-4s0iv9[data-v-18fea2d4]{cursor:not-allowed;opacity:.5}button.stake-4s0iv9[data-v-18fea2d4]{-webkit-appearance:none;-moz-appearance:none;appearance:none;margin:0;padding:0;background:0\x200;border:none;font-size:inherit;line-height:inherit;cursor:pointer;touch-action:manipulation;position:relative;display:inline-flex;justify-content:flex-start;align-items:center;border-radius:100px;-webkit-tap-highlight-color:rgba(0,0,0,0);transition:background-color\x20.2s,color\x20.2s;flex-shrink:0}button.variant-game.stake-4s0iv9[data-v-18fea2d4]:hover:not([disabled]){color:#fff;background:#37466c}button.variant-game.stake-4s0iv9[data-v-18fea2d4]{color:#d5dceb;background:#313e60}button.variant-game.stake-4s0iv9[data-v-18fea2d4]:not(.no-shadow){box-shadow:0\x201px\x203px\x200\x20rgba(0,0,0,.2),inset\x200\x201px\x20hsla(0,0%,100%,.04)}button.square.stake-4s0iv9[data-v-18fea2d4]{border-radius:.25rem}button.spacing-primary.stake-4s0iv9[data-v-18fea2d4]{padding:.75em\x201em}button.align-left.stake-4s0iv9[data-v-18fea2d4]{justify-content:flex-start}button.text-size-default.stake-4s0iv9[data-v-18fea2d4]{font-size:var(--text-size-default)}button.weight-semibold.stake-4s0iv9[data-v-18fea2d4]{font-weight:600}button.line-height-150pct.stake-4s0iv9[data-v-18fea2d4]{line-height:150%}.content-or-loader.stake-1uofbko[data-v-18fea2d4]{display:inline-flex;position:relative;align-items:center}button.variant-game.stake-4s0iv9:not(.iconOnly)\x20.svg-icon[data-v-18fea2d4]{transition:color\x20.2s;color:var(--variant-game-icon-color)}.wrap.stake-18pg48l[data-v-18fea2d4]{width:calc(100%\x20-\x202em);background:#252e48;border-radius:.25rem;box-shadow:0\x204px\x206px\x20-1px\x20rgba(27,23,23,.2),0\x202px\x204px\x20-1px\x20rgba(0,0,0,.12);display:grid;grid-template-columns:repeat(auto-fit,minmax(50px,1fr));grid-gap:1rem;margin-bottom:.5rem;padding:1rem}.profit.stake-5v1hdl>label[data-v-18fea2d4]{width:100%}label.stacked.stake-ypka6t[data-v-18fea2d4]{flex-direction:column-reverse;align-items:flex-start}label.stake-ypka6t[data-v-18fea2d4]{display:inline-flex;flex-direction:row-reverse;align-items:center;position:relative}.input-wrap.stake-17q8hbc[data-v-18fea2d4]{width:100%;display:flex;flex-shrink:0;box-shadow:0\x201px\x203px\x200\x20rgba(0,0,0,.2),0\x201px\x202px\x200\x20rgba(0,0,0,.12);border-radius:.25rem}.input-content.stake-17q8hbc[data-v-18fea2d4]{position:relative;flex-grow:1;width:100%;display:flex}.input[readonly].stake-17q8hbc[data-v-18fea2d4]{background:#313e60}.input.spacing-expanded.stake-17q8hbc[data-v-18fea2d4]{padding:.5em}.input.input-icon-after.stake-17q8hbc[data-v-18fea2d4]{padding-right:2em}.input.input-icon-before.stake-17q8hbc[data-v-18fea2d4]{padding-left:2.5em}.input.stake-17q8hbc[data-v-18fea2d4]{width:100%;color:#fff;background:#0f212e;box-shadow:0\x201px\x203px\x200\x20rgba(0,0,0,.2),0\x201px\x202px\x200\x20rgba(0,0,0,.12);border:2px\x20solid\x20#313e60;border-radius:.25rem;letter-spacing:0;font-weight:600;transition:all\x20.25s;outline:0;margin:0;cursor:text;-webkit-appearance:none;-moz-appearance:none;appearance:none;box-shadow:none}.before-icon.stake-17q8hbc[data-v-18fea2d4]{cursor:text;left:.75em}.after-icon.stake-17q8hbc[data-v-18fea2d4],.before-icon.stake-17q8hbc[data-v-18fea2d4]{position:absolute;display:flex;top:50%;transform:translateY(-50%);pointer-events:none;color:hsla(0,0%,100%,.6);z-index:2}.after-icon.stake-17q8hbc[data-v-18fea2d4]{cursor:text;right:.75em}.label-content.full-width.stake-5ecfln[data-v-18fea2d4],.labels.stake-5v1hdl[data-v-18fea2d4]{width:100%}.label-content.stake-5ecfln[data-v-18fea2d4]{display:inline-flex;align-items:center;font-weight:600;font-size:var(--text-size-default);color:hsla(0,0%,100%,.6);transition:.2s;letter-spacing:0;padding:0\x200\x20.25rem;justify-content:space-between}.footer.stake-q9yg42[data-v-18fea2d4]{overflow-x:scroll;width:calc(100%\x20-\x202em);padding:.5em\x20.5em\x201.5em;background:rgba(0,0,0,.25);border-radius:.3em;margin-bottom:1em}.scrollX[data-v-18fea2d4],.scrollY[data-v-18fea2d4]{scrollbar-color:#313e60\x20transparent}.scrollX[data-v-18fea2d4]{overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;transform:translate(0);-moz-transform:none!important;scrollbar-width:thin}.slide-down.stake-q9yg42[data-v-18fea2d4]{transition-property:transform;display:flex;align-items:center}.slide-in.stake-1nq5h7m[data-v-18fea2d4]{position:relative}.payout-multiplier.positive.stake-1nq5h7m[data-v-18fea2d4]{color:#00e701;justify-content:center}.payout-start.positive.stake-1nq5h7m[data-v-18fea2d4]{color:#fff!important;justify-content:center}.payout-multiplier.negative.stake-1nq5h7m[data-v-18fea2d4]{color:#fe2247;justify-content:center}.payout-multiplier.stake-1nq5h7m[data-v-18fea2d4]{position:absolute;top:100%;left:0;width:100%;border-radius:30px;font-weight:600;text-align:center;font-size:.75rem;white-space:nowrap;animation-name:stake-1nq5h7m-payoutShow-18fea2d4;transform:scale(0)\x20translate(0);opacity:0;animation-delay:.3s;animation-duration:.3s;animation-fill-mode:forwards;animation-timing-function:cubic-bezier(.87,-.41,.19,1.44)}.slide-in.slide.stake-1nq5h7m[data-v-18fea2d4]{animation-name:stake-1nq5h7m-slideIn-18fea2d4;animation-duration:.4s;animation-timing-function:ease-out}.slide-in.animation-off.stake-1nq5h7m[data-v-18fea2d4]{animation-duration:0ms}.slide-down.down.stake-q9yg42[data-v-18fea2d4]{animation:stake-q9yg42-slideDown-18fea2d4\x20ease-out\x20forwards;animation-delay:.3s;animation-duration:.3s}.slide-down.stake-q9yg42>*+*[data-v-18fea2d4]{margin-left:.5em}.guess.positive.stake-gp35en[data-v-18fea2d4]{color:#00e701}.guess.negative.stake-gp35en[data-v-18fea2d4]{color:#fe2247}.guess.neutral.stake-gp35en[data-v-18fea2d4]{color:#ff9d00}.guess.stake-gp35en[data-v-18fea2d4]{box-shadow:0\x200\x200\x202px\x20rgba(42,47,60,.2);display:flex;align-items:center;justify-content:center;padding:.5em;border-radius:.3em;position:absolute;top:50%;left:-.25em;background:#fff;animation-name:stake-gp35en-guessShow-18fea2d4;transform:scale(0)\x20translate(-50%,-50%);opacity:0;animation-delay:.3s;animation-duration:.3s;animation-fill-mode:forwards;animation-timing-function:cubic-bezier(.87,-.41,.19,1.44)}.game-result-wrap.win.stake-1ogwhrk[data-v-18fea2d4]{border-color:#00e701}.game-result-wrap.stake-1ogwhrk[data-v-18fea2d4]{background:#252e48;border-radius:.5rem;text-align:center;position:absolute;font-weight:800;top:50%;left:50%;transform:translate(-50%,-50%)\x20scale(1);max-width:100%;min-width:150px;animation-duration:.18s;animation-name:stake-rsub90-resultShow-18fea2d4;border:3px\x20solid;box-shadow:var(--shadows-lg)}.game-result-content.stake-1ogwhrk[data-v-18fea2d4]{display:flex;text-align:center;width:100%;padding:.75em\x201em;flex-direction:column;align-items:center}.divider.stake-1ogwhrk[data-v-18fea2d4]{background:#313e60;height:3px;width:30%;margin:.25rem\x200\x20.5rem}.currency.stake-z4ax21[data-v-18fea2d4]{display:inline-flex;align-items:center}.content.stake-z4ax21[data-v-18fea2d4]{display:inline-block;overflow:hidden;white-space:nowrap;font-feature-settings:\x22tnum\x22;font-variant-numeric:tabular-nums}span.stake-129khay[data-v-18fea2d4]{display:inline-flex;align-items:center}span.variant-success.stake-129khay[data-v-18fea2d4]{color:var(--variant-success-background)}span.line-height-default.stake-129khay[data-v-18fea2d4]{line-height:1.5}span.align-left.stake-129khay[data-v-18fea2d4]{text-align:left;justify-content:flex-start}span.text-size-default.stake-129khay[data-v-18fea2d4]{font-size:var(--text-size-default)}span.weight-bold.stake-129khay[data-v-18fea2d4]{font-weight:700}span.weight-normal.stake-129khay[data-v-18fea2d4]{font-weight:400}span.numeric.stake-129khay[data-v-18fea2d4]{font-feature-settings:\x22tnum\x22;font-variant-numeric:tabular-nums}span.variant-subtle.stake-129khay[data-v-18fea2d4]{color:var(--variant-subtle-color)}.number-multiplier.stake-1ogwhrk>*[data-v-18fea2d4]{font-size:2em!important}.truncate.stake-129khay[data-v-18fea2d4]{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:inherit}.currency.stake-z4ax21>*+*[data-v-18fea2d4]{margin-left:.25rem}@keyframes\x20stake-1xp6zc8-flyRight-18fea2d4{to{transform:rotate(-40deg)\x20translate(50vw,-50vh)}}@keyframes\x20stake-1xp6zc8-flyLeft-18fea2d4{to{transform:rotate(40deg)\x20translate(-50vw,-50vh)}}@keyframes\x20stake-1nq5h7m-slideIn-18fea2d4{0%{transform:translate(100vw)}}@keyframes\x20stake-1nq5h7m-payoutShow-18fea2d4{to{transform:scale(1)\x20translate(0);opacity:1}}@keyframes\x20stake-gp35en-guessShow-18fea2d4{to{transform:scale(1)\x20translate(-50%,-50%);opacity:1}}@keyframes\x20stake-q9yg42-slideDown-18fea2d4{0%{transform:translate(0)}to{transform:translateY(150%)}}@keyframes\x20stake-rsub90-resultShow-18fea2d4{0%{transform:translate(-50%,-50%)\x20scale(.5)}80%{transform:translate(-50%,-50%)\x20scale(1.1)}90%{transform:translate(-50%,-50%)\x20scale(1.05)}}",
    "\x0a\x09\x09\x09\x09\x09\x09\x09",
    "apply",
    "clearRect",
    "getChancePercent",
    "betlist",
    "sendInsurance",
    "suit",
    "svelte-n07u8e",
    "Auto",
    "timestamp",
    "weight-semibold\x20lineHeight-normal\x20inline\x20align-left\x20size-medium\x20variant-subtle\x20with-icon-space\x20truncate\x20svelte-1bjlgfi",
    "count",
    "hidden",
    "before-icon\x20stake-17q8hbc",
    "playerOtherWrapper",
    "after-icon\x20stake-17q8hbc",
    "getRandomCard",
    "gamestate_label",
    "order",
    "class",
    "audio-flip",
    "1IIzIKE",
    "900",
    "input-button-wrap\x20svelte-1vu9of",
    "progressElapse",
    "guessHistory",
    "isAutobetFinsihing",
    "slideDown",
    "getFaceColor",
    "cash",
    "forEach",
    "isManual\x20&&\x20getCrashGameState\x20==\x20\x27fire\x27",
    "VPlayCanvas",
    "prevCardFly",
    "off",
    "face-content\x20stake-soy9i6",
    "setCrashCashOut",
    "variant-subtle-link\x20lineHeight-normal\x20size-medium\x20spacing-none\x20weight-semibold\x20align-left\x20svelte-oho9kj",
    "thead",
    "grey",
    "!isManual",
    "content\x20stake-1wtyksp\x20face-down",
    "higherEqual",
    "player\x20svelte-eq0hy3",
    "attachEvent",
    "winsize",
    "revealDealerCards",
    "),url(",
    "Top",
    "Bet",
    "concat",
    "measureText",
    "children",
    "#icon-icon-casino_icon-arrow-down",
    "topCardRect",
    "Cashout",
    "\x0a\x09\x09\x09Players:\x20",
    "history-btn",
    "submit",
    "toggleControl",
    "__esModule",
    "getButtonFlag",
    "audio-deal",
    "connect",
    "4479280kMTbdQ",
    "graphLineWidth",
    "model",
    "horizontal\x20svelte-1wtyksp",
    "info",
    "variant-success\x20lineHeight-base\x20size-medium\x20spacing-mega\x20weight-semibold\x20align-center\x20min-width\x20fullWidth\x20square\x20svelte-1e6i4pv",
    "multiplierFontSize",
    "footer\x20scrollX\x20stake-q9yg42",
    "history",
    "minHeight",
    "v-model",
    "expect_amount",
    "getCrashResultBoard",
    "interval",
    "then",
    "amounts",
    "clientHeight",
    "fill",
    "playerWrapper",
    "isCurrentBet",
    "top",
    "setSkipdisabled",
    "payoutMultiplier",
    "toString",
    "v-dialog",
    "money",
    "hands\x20svelte-gro036",
    "buffer",
    "margin-left-5",
    "table",
    "restore",
    "isControl\x20||\x20isManual",
    "getCrashCashOut",
    "desc\x20svelte-ithfqn",
    "lose",
    "odds",
    "#2f4553",
    "Higher",
    "topGuess",
    "positive",
    "gameId",
    "600\x2016px\x20proxima-nova",
    "format",
    "localStorage",
    "input-content\x20svelte-1vu9of",
    "game",
    "past-bets\x20svelte-crash",
    "doSplit",
    "Profit\x20Higher(",
    "flipCardWithoutTransition",
    "630px",
    "getButtonInfo",
    "noInsurance",
    "initialize",
    "v-row",
    "1em",
    "베팅금액을\x20입력하세요",
    "multiplier",
    "fa-solid\x20fa-table-columns",
    "On\x20Win",
    "label-content",
    "fa-solid\x20fa-angle-left",
    "none",
    "600px",
    "VBetslipCard",
    "drawStats",
    "fa-solid\x20fa-up",
    "setAttribute",
    "getBoundingClientRect",
    "v-input",
    "wrapper\x20svelte-1uk84nr",
    "fa-solid\x20fa-hand",
    "fa-solid\x20fa-heart",
    "datalist",
    "startBet",
    "checkOrFinish",
    "crashElapse",
    "px\x20proxima-nova",
    "isManual\x20&&\x20getCrashGameState\x20==\x20\x27in_progress\x27\x20&&\x20isCurrentBet\x20==\x20true\x20&&\x20this.multiplier\x20>\x20this.getCurrentMultiplier",
    "ctx",
    "setButtonInfo",
    "start",
    "graphWidth",
    "$set",
    "transform\x20400ms\x20ease\x200s",
    "stake-1wtyksp",
    "8cd8b22e",
    "source",
    "v-dialog-history",
    "filter",
    "betNextRound",
    "string",
    "#FFD900",
    "#4ca4ff",
    "create",
    "resize",
    "v-column",
    "audio-correct",
    "firstPack",
    "height",
    "logs",
    "slide",
    "currentFaceDown",
    "random",
    "audio-click",
    "setCrashBetId",
    "getCardValue",
    "$loading",
    "warn",
    "use",
    "setPage",
    "profit",
    "HiloRepository",
    "label-left-wrapper\x20svelte-1vu9of",
    "베팅금액",
    "color",
    "fa-regular\x20fa-minus",
    "changedAmount",
    "Cancel",
    "toggleMaunal",
    "startCardSlide",
    "setCrashGameState",
    "toLocaleString",
    "toFixed",
    "max",
    "\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20",
    "Bottom",
    "elapsed",
    "removeEventListener",
    "wrap",
    "dealer",
    "table\x20svelte-1ulh9na",
    "clientWidth",
    "activeHand",
    "#ff9d00",
    "\x0a\x09\x09\x09\x09\x09\x09",
    "insertBefore",
    "textAlign",
    "fa-up-from-line",
    "createBufferSource",
    "plinko.history",
    "data:audio/mpeg;base64,//uQRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAKAAAJdwBCQkJCQkJCQkJxcXFxcXFxcXFxkpKSkpKSkpKSkqampqampqampqa6urq6urq6urq6ysrKysrKysrKytjY2NjY2NjY2Njl5eXl5eXl5eXl8vLy8vLy8vLy8v////////////8AAAAyTEFNRTMuOTggBKUAAAAAAAAAABQgJATaTQABwgAACXe5w/f0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//ugZAAAAAAAf4UAAAgMYAuToAABHKGVb/mngEpaq6w/NLAAAAA4A////////5TDGa00ymTKrQiGcAYETiVi+pnhBh0IAnm02mJAmICmnQnOVg4YYUQClJiBYQjWIXOclYqeCjBTznSnCyNsto1mI9S6liSqOSYsovh0VenTphjWYVaP9+VIjdvWzDBi2iMQhYA/QxVoS1J199bhQmuJZhcUExGuSMYp1I2NaeC+i5mfUbYLIyl1ALyxAezEEzJ+SBFsUWCwuMtYuo7163MUv2+MOxL2c4CxpREms2oKDKy1pGw+g/EX3eW+Z/HwaB0B7FhDRO87CYImZnZYaLMjvoymhRrYheuYMtWNMvsxN482tyYMb5mOZUgGxMiSQKAwChCFXKoucECjVSAofyTkpJHFbocbbnSY3rVi7jw61VTlvmJeQ5YyGft1GOaybYnw7id20+Qj9RqaTrhzZ/0DzTACYhInhJFY2VYcJyjjw/ExMyirum8T/zO7rryFPHGG5MHcPjDYtPUlUtlzu5c7j+ujcb0Dw1mBCFpnjvIg9oj4LiUSytq1t2OYHxaZdDQxUCTJRTfVCpsc8GPqpUFUNXta1OOnPT0jjMV11ghiJG9MCOZzJwZGAqU/2Y/bM3LgZavl5ns2+GNgpXnK5Thn9UlEnY1XtIqvhmjQM2QYKPJlEr/1iyTBYoK7//uAZC8AA4FA1v9gYAJXyasv7AgBTbVbT6wgbck3iSp0wI0U/y750Q7UmgE2VyUmSOyhcIitbMvDq2S+ntRF5G5NqBJVaXdGoy8Mupf1j+W9AApwFzFfq04ZbdW7zOUqKXW1Ss1L9aG7q3Mbeib/1K3p/////95kdAwryL9pefiKTm96nfkcE65zVfoeNWZxBVlEEkp12lanlE5Ibpyo5wSzdj74RmBp/oLUpDg7gfEz6m+zOyStt8f7NffSZFrpIhWtmzlScj/yi2bltLPI8+ewmivZslNZeX4q1Jb39Mj8TTPpSIGUI1SkWzd++PbVP8BOLPuTk8+E5r1s+qRPnEgSCqJEW2bAZBc00jT0XLVFT/4zkFVIM2atnJbJWhYsKtDpUBAMqs/LLcXm05OxirB43okTbTc9zhVbyww8XEokMJUVNCwuy4TKZ7BESFMm4SkrskEIVxEKiDhpuNRd5lymLqUcpf2xK4ZnQw7/+2BkEYHTGkzS+yMT4E9Ceg08w0QG0Hk3rWFi6B0AJswAAAQC02b2DHYzksZlLzjAxLLGYvZj43G/NNVtDTKVHmCmNb9H7qU3/66lUsz//M6GUrVKFBp6gaAywV3lniV13kfnjN2Ta6WgiG4pXHEFQxEWBlXpqp8oKvFL6q9a8bjZhSPCIOwqEnnpUFXSKg6TDSoScHQVDR4NXh3BU71cNZ47K/wa/LVSRUFZ5ANFnlfLPrAglklSv+rJtKGi4QTbEj2jCfY6Dgvw3Cp3ekCjkWXcQoA9q/7lpbcW/by2j7ouOnQld67K5foAff////36KiaIbbgruAABpMcYOOo1kCyzSNz/+zBkCYERmBxN6yxBygpgGYMAAAEGIFM1rKRpYDsAJmgAAATSmgVL36nW5NZCYYIyV8BF89VAvdobcXTslvVeamrf+wOAAAPX//+sNIJgMQ2zO/cX1cppB8Y0FGDPU09MMg6eHogeDee7B0I7bo+J0IRLq56jMAyiDoNgGpPEwGQBjfjj7P9P08ZeQMuM1QUEXLXd+AABpPYqrFb/+zBkBoERZA/M6wxBmhDgya0AYiEE2EUzrLDmoEKH5nRwCVzRGUmac7rooVtdAz94qavEQuCMIU9iib3z98dhq0n/oAOQACXjgAABWZgH/lNiLf0BQSS0ffgYs/Lqn4Gmw7wBGnmCYFpp3IQJePN50QA7ePOJRKA1C3QAI2ABh+B+EWh78L4xZ0r3JREImoMOOAABIMpHHWbGqUv/+yBkCAUw+A9M6TkQKBPh+Z0IAlcDLBExROMAICiAZlAAAARjeFKGFtv9v0Cfin0OueoAJwADb/gAAfhaQz8FqilnvnlaFnTD/igGTLO5qesbRUZMl6OW5ZNK06kNxcVAAAAAur/7f/9FSgU0IAMOAAAAZmCR02Q6t7ev+38eACGA//sQZAuDMJ8EzOgvwBgNwBmNAAABAcgRV8AZ4GAhgCr4AAAEBQOAAANdH/Z/p0BV5mYAB5oTzgdcZrbf0gAWAAAB/Z/66gVAAAAB+AABK4MXA7//+7RmwPwAAP///v/tSAYBUgVOf///+xBkEQfQigPM6CJ4iAlgGZMAAAEBOA8wgAWAYCcAJkwAAATi/SP+P//43XvmltRVBEAAAAH4AABPDT///3vs18mPwAAB//+Z61gQDgDK//9sskxBTUUzLjk4qqqqqqqqqqqqqqqqqv/7EGQbhfCJA8zoAUgYCIAZkwAAAQEAAzNAAAAgAAA/wAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//sQRCyP8AAAf4AAAAgAAA/wAAABAAABpAAAACAAADSAAAAEqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo=",
    "plinko.betAmount",
    "wrap\x20svelte-1wtyksp",
    "crash-game\x20svelte-crash",
    "getSkipdisabled",
    "scrollLeft",
    "getGuessLowInfo",
    "object",
    "title",
    "stacked\x20stake-ypka6t",
    "dataInit",
    "length",
    "setBetloading",
    "svelte-1xzc9au",
    "content-wrapper\x20svelte-17cnp9o",
    "payout-multiplier\x20payout-start\x20positive\x20stake-1nq5h7m",
    "back\x20stake-1wtyksp",
    "next",
    "getOwnPropertySymbols",
    "cash-updown",
    "fa-regular\x20fa-plus",
    "style",
    "firstpack",
    "audio-mucked",
    "multipleAmount",
    "icon",
    "getCrashLeaderboard",
    "push",
    "content\x20stake-z4ax21",
    "button",
    "face-down",
    "#icon-icon-casino_icon-times",
    "drawLine",
    "addEventListener",
    "label-content\x20full-width\x20stake-5ecfln",
    "isCashout",
    "isManual\x20&&\x20getCrashGameState\x20==\x20\x27in_progress\x27\x20&&\x20isCurrentBet\x20==\x20false\x20&&\x20isNextbet\x20==\x20true",
    "margin-right-0",
    "last_page",
    "473ogpUpk",
    "getItem",
    "setItem",
    "gameboard",
    "currentCardDuration",
    "specialValues",
    "resetSkip",
    "variant-tabmenu\x20lineHeight-base\x20size-medium\x20spacing-normal\x20weight-semibold\x20align-center\x20svelte-oho9kj",
    "content\x20svelte-n07u8e",
    "content-or-loader\x20svelte-1uofbko\x20truncate",
    "higher",
    "#3ed54a",
    "pop",
    "scale",
    "#252e48",
    "stake-gp35en",
    "playerCards",
    "Start\x20Card",
    "amount-input",
    "target",
    "0.0",
    "7ch",
    ");background-color:#fff;background-position:50%;background-repeat:no-repeat;background-size:100%;-webkit-backface-visibility:hidden;backface-visibility:hidden}.face-content.svelte-soy9i6[data-v-108ffd82]{display:flex;flex-direction:column;align-items:center;font-size:2.2em;width:-moz-max-content;width:max-content;margin-left:10%}.content.svelte-1wtyksp[data-v-108ffd82]:not(.face-down){transform:rotateY(180deg)}.content.svelte-n07u8e[data-v-108ffd82]:not(.dealt){opacity:0}.content.mucked.svelte-n07u8e[data-v-108ffd82]{animation-name:svelte-n07u8e-muckCard-108ffd82;animation-duration:var(--muck-transition);animation-fill-mode:forwards}.svg-icon.svelte-10mcogx[data-v-108ffd82]{pointer-events:none;stroke-width:0;stroke:currentColor;fill:currentColor;flex-shrink:0;display:inline-block;width:1em;height:1em}.deck.svelte-s5ivtb[data-v-108ffd82]>:not(:first-child){position:absolute;top:0;left:0}.dealer.svelte-15ph9dz[data-v-108ffd82]{display:flex;width:100%;justify-content:center}.wrap.svelte-n07u8e[data-v-108ffd82]{display:flex;position:relative;align-items:flex-start;margin-top:1em;font-size:1.2em;min-width:5em;min-height:7.9em;transition-duration:.4s}.player.svelte-eq0hy3[data-v-108ffd82]{display:flex;width:100%;justify-content:space-around;flex-direction:row-reverse}.hand-wrap.svelte-eq0hy3[data-v-108ffd82]{display:flex;align-items:center;justify-content:center;flex-direction:column;position:relative}.value.svelte-n07u8e[data-v-108ffd82]{font-size:.75rem;position:absolute;top:0;left:100%;border-radius:999px;padding:.25rem\x20.5rem;font-weight:800;color:#fff;width:7ch;text-align:center;justify-content:center;transform:translate(-100%,-100%);transition-duration:.3s;transition-property:background,color,transform,opacity;transition-timing-function:ease-out;box-shadow:0\x201px\x203px\x200\x20rgba(0,0,0,.2),0\x201px\x202px\x200\x20rgba(0,0,0,.12)}.value.none.svelte-n07u8e[data-v-108ffd82]{background:#252e48}.value.lose.svelte-n07u8e[data-v-108ffd82]{background:#ff1f44;color:#4d000d}.value.win.svelte-n07u8e[data-v-108ffd82]{background:#1fff20;color:#004d00}.value.active.svelte-n07u8e[data-v-108ffd82]{background:#4391e7;color:#082f5a}.value.draw.svelte-n07u8e[data-v-108ffd82]{background:#ff9d00;color:#633d00}.value.hide.svelte-n07u8e[data-v-108ffd82]{opacity:0}.content.dealt.svelte-n07u8e[data-v-108ffd82]{opacity:1}.face.lose.svelte-1wtyksp[data-v-108ffd82]{box-shadow:0\x200\x200\x20.3em\x20#ff1f44}.face.win.svelte-1wtyksp[data-v-108ffd82]{box-shadow:0\x200\x200\x20.3em\x20#00e701}.face.draw.svelte-1wtyksp[data-v-108ffd82]{box-shadow:0\x200\x200\x20.3em\x20#ff9d00}.face.active.svelte-1wtyksp[data-v-108ffd82]{box-shadow:0\x200\x200\x20.3em\x20#1475e1}@keyframes\x20svelte-n07u8e-muckCard-108ffd82{to{opacity:0;transform:translate(-10%,10%)}}",
    "722c3b60",
    "render",
    "flipCard",
    "svelte-1k0lzek\x20truncate",
    "145fa689",
    "\x0a\x09\x09\x09\x09$0.00\x0a\x09\x09\x09",
    "v-show",
    "600",
    "totalPayoutMultiplier",
    "prev",
    "fa-solid\x20fa-spade",
    "maxX",
    "double",
    "blackjack-betslip",
    "enumerable",
    "poCard-1",
    "content",
    "drawAxis",
    "베팅내역",
    "#ffe588",
    "베팅하기",
    "label-content\x20svelte-ri5vof",
    "in_progress",
    "translate(",
    "setCrashMultiplier",
    "loggedIn",
    "userMoney",
    "gamestate",
    "closePath",
    "number",
    "Total\x20Profit\x0a\x09\x09\x09\x09\x09\x09\x09\x09(",
    "opacity",
    "addBetItem",
    "finish",
    "fa-solid\x20fa-down",
    "poCard-",
    "isDisabled",
    "crash_elasped",
    "show",
    "removeItem",
    "v-text",
    "fa-down",
    "pastBets",
    "card",
    "#ff7171",
    "autocount",
    "divider\x20stake-1ogwhrk",
    "PlayPan",
    "wrapper\x20svelte-crash",
    "init",
    "dealer\x20svelte-gro036",
    "getBetdisabled",
    "getPayout",
    "svg-icon\x20svelte-10mcogx",
    "Stand",
    "history-log\x20scrollable-auto",
    "getSetdisabled",
    "#1475e1",
    ".game-content.stake-1wfq6vq[data-v-18fea2d4]{width:100%;display:flex;flex-direction:column;justify-content:center;flex-grow:1;-webkit-user-select:none;-moz-user-select:none;user-select:none;position:relative;overflow:hidden;margin:0\x20auto;border-top-right-radius:.5rem}.svg-icon.stake-10mcogx[data-v-18fea2d4]{pointer-events:none;stroke-width:0;stroke:currentColor;fill:currentColor;flex-shrink:0;display:inline-block;width:1em;height:1em}.wrap.stake-k2ijz0[data-v-18fea2d4]{justify-content:space-between;flex-direction:column}.main.stake-k2ijz0[data-v-18fea2d4],.wrap.stake-k2ijz0[data-v-18fea2d4]{display:flex;align-items:center;flex-grow:1;width:100%}.main.stake-k2ijz0[data-v-18fea2d4]{justify-content:center}.main.stake-k2ijz0[data-v-18fea2d4]:not(.stacked){background-image:url(",
    "eplasedtime_label",
    "fa-equals",
    "인슈어런스",
    "7.9em",
    "player1",
    "Controls",
    "locals",
    "toggleProgressBar",
  ];
  a16_0x47bb = function () {
    return _0x1d331e;
  };
  return a16_0x47bb();
}
function a16_0x269f(_0x301bf9, _0x50510e) {
  var _0x47bbe3 = a16_0x47bb();
  return (
    (a16_0x269f = function (_0x269f71, _0x2058e2) {
      _0x269f71 = _0x269f71 - 0x118;
      var _0x468dbf = _0x47bbe3[_0x269f71];
      return _0x468dbf;
    }),
    a16_0x269f(_0x301bf9, _0x50510e)
  );
}
var a16_0x295903 = a16_0x269f;
(function (_0x22287f, _0x1416df) {
  var _0x26b43a = a16_0x269f,
    _0x253069 = _0x22287f();
  while (!![]) {
    try {
      var _0x3035c9 =
        (-parseInt(_0x26b43a(0x157)) / 0x1) *
          (parseInt(_0x26b43a(0x2b9)) / 0x2) +
        (parseInt(_0x26b43a(0x2e2)) / 0x3) *
          (parseInt(_0x26b43a(0x118)) / 0x4) +
        parseInt(_0x26b43a(0x182)) / 0x5 +
        (parseInt(_0x26b43a(0x337)) / 0x6) *
          (-parseInt(_0x26b43a(0x3a5)) / 0x7) +
        (parseInt(_0x26b43a(0x3b5)) / 0x8) *
          (parseInt(_0x26b43a(0x34c)) / 0x9) +
        -parseInt(_0x26b43a(0x3d2)) / 0xa +
        (-parseInt(_0x26b43a(0x236)) / 0xb) *
          (parseInt(_0x26b43a(0x38a)) / 0xc);
      if (_0x3035c9 === _0x1416df) break;
      else _0x253069["push"](_0x253069["shift"]());
    } catch (_0x3e4ff9) {
      _0x253069["push"](_0x253069["shift"]());
    }
  }
})(a16_0x47bb, 0xc5d7d),
  (window[a16_0x295903(0x3e3)] = window[a16_0x295903(0x3e3)] || [])[
    a16_0x295903(0x22a)
  ]([
    [0x10],
    {
      0x404: function (_0x390338, _0x1c03fd, _0x26a957) {
        "use strict";
        _0x26a957(0x17b);
      },
      0x405: function (_0x311317, _0x1d5f26, _0x4c6c9e) {
        var _0x24ce8b = a16_0x295903,
          _0x4bd34e = _0x4c6c9e(0x4)(!0x1);
        _0x4bd34e[_0x24ce8b(0x22a)]([
          _0x311317["i"],
          ".hilo-betslip\x20.content[data-v-145fa689]{width:100%}.hilo-betslip\x20.content\x20.insurance-btn[data-v-145fa689]{margin-bottom:10px}.hilo-betslip\x20.content\x20.insurance-btn>button[data-v-145fa689]{width:100%;height:40px;background-color:#313e60;margin-right:10px}.hilo-betslip\x20.content\x20.insurance-btn>button[data-v-145fa689]:last-child{margin-right:0}@media(hover:hover){.hilo-betslip\x20.content\x20.insurance-btn>button[data-v-145fa689]:hover{background-color:#37456a}}.hilo-betslip\x20.content\x20.history-btn[data-v-145fa689]{margin-bottom:10px;justify-content:flex-end;padding:0\x2010px;transition:.2s\x20ease}.hilo-betslip\x20.content\x20.history-btn\x20button[data-v-145fa689]{opacity:.6}@media(hover:hover){.hilo-betslip\x20.content\x20.history-btn\x20button[data-v-145fa689]:hover{opacity:1}.hilo-betslip\x20.content\x20.history-btn\x20button:hover\x20span[data-v-145fa689]{color:#ffe588}}.hilo-betslip\x20.content\x20.betslip-form\x20.amount>div[data-v-145fa689]{margin-bottom:10px;flex-shrink:0}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20button[data-v-145fa689]{flex-shrink:0;background-color:#313e60}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.cash-updown[data-v-145fa689]{border-right:1px\x20solid\x20#252e48}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.input[data-v-145fa689]{transition:.2s\x20ease;width:100%;background-color:#313e60;text-align:right;border-right:1px\x20solid\x20#252e48;border-left:1px\x20solid\x20#445174}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.amount-init[data-v-145fa689]{border-left:1px\x20solid\x20#445174}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance[data-v-145fa689]{height:40px}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance>div[data-v-145fa689]{height:100%;align-items:center;justify-content:center}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.title[data-v-145fa689]{width:40%;background-color:#313e60}.hilo-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.count[data-v-145fa689]{width:60%;background-color:#2b3654}.hilo-betslip\x20.content\x20.bet-select-btn[data-v-145fa689]{margin-bottom:10px}.hilo-betslip\x20.content\x20.bet-select-btn>button[data-v-145fa689]{height:40px;background-color:#313e60;margin-bottom:10px}.hilo-betslip\x20.content\x20.bet-select-btn>button[data-v-145fa689]:last-child{margin-bottom:0}@media(hover:hover){.hilo-betslip\x20.content\x20.bet-select-btn>button[data-v-145fa689]:hover{background-color:#37456a}}.hilo-betslip\x20.content\x20.submit[data-v-145fa689]{flex-shrink:0}.hilo-betslip\x20.content\x20.submit\x20button[data-v-145fa689]{background-color:#ffe588;height:40px}.hilo-betslip\x20.content\x20.submit\x20button>span[data-v-145fa689]{color:#000}@media(hover:hover){.hilo-betslip\x20.content\x20.submit\x20button[data-v-145fa689]:hover{background-color:#ffdc60}}",
          "",
        ]),
          (_0x311317[_0x24ce8b(0x13e)] = _0x4bd34e);
      },
      0x409: function (_0x26e6f0, _0x197a03, _0x598968) {
        "use strict";
        _0x598968(0x17c);
      },
      0x40a: function (_0x5d8b6d, _0x33ab32, _0x3498a8) {
        var _0x4dfaac = a16_0x295903,
          _0x1cc028 = _0x3498a8(0x4),
          _0x5eb9f1 = _0x3498a8(0x5d),
          _0x215317 = _0x3498a8(0x40b),
          _0x3b1bc7 = _0x3498a8(0x40c),
          _0x22388d = _0x3498a8(0x40d),
          _0x3cefce = _0x1cc028(!0x1),
          _0x49523f = _0x5eb9f1(_0x215317),
          _0x2b275d = _0x5eb9f1(_0x3b1bc7),
          _0x177b77 = _0x5eb9f1(_0x22388d);
        _0x3cefce[_0x4dfaac(0x22a)]([
          _0x5d8b6d["i"],
          _0x4dfaac(0x287) +
            _0x49523f +
            _0x4dfaac(0x171) +
            _0x2b275d +
            ");background-position:10%,90%;background-repeat:no-repeat;background-size:10%;padding:3em}.main.stake-k2ijz0>*[data-v-18fea2d4]{margin:0\x20.5em}.wrap.stake-1xp6zc8[data-v-18fea2d4]{display:flex;align-items:center;justify-content:center}.deck.stake-1xp6zc8[data-v-18fea2d4]{position:relative;font-size:1.5em}.deck.stake-s5ivtb[data-v-18fea2d4]{position:relative}.deck.stake-s5ivtb[data-v-18fea2d4]>:not(:first-child){position:absolute;top:0;left:0}.wrap.stake-1wtyksp[data-v-18fea2d4]:disabled{pointer-events:none}.horizontal.stake-1wtyksp[data-v-18fea2d4]{transition:var(--transition-time);transition-timing-function:ease-out;transition-property:transform}.content.stake-1wtyksp[data-v-18fea2d4]{position:relative;font-family:brandon-grotesque,sans-serif;-webkit-user-select:none;-moz-user-select:none;user-select:none;perspective:700px;transition:var(--transition-time);transform-style:preserve-3d;transition-timing-function:ease-out;transition-property:transform,box-shadow;box-shadow:0\x200\x20.25em\x20rgba(7,16,23,.3019607843);border-radius:.25em}.content.stake-1wtyksp[data-v-18fea2d4]:not(.face-down){transform:rotateY(180deg)}.face.stake-1wtyksp[data-v-18fea2d4]{position:absolute;width:100%;height:100%;border-radius:.25em;background:#fff;transform:scaleX(-1)}.face.lose.stake-1wtyksp[data-v-18fea2d4]{box-shadow:0\x200\x200\x20.3em\x20var(--red-400)}.face-content.stake-soy9i6[data-v-18fea2d4]{display:flex;flex-direction:column;align-items:center;font-size:2.2em;width:-moz-max-content;width:max-content;margin-left:10%}.back.stake-1wtyksp[data-v-18fea2d4]{position:absolute;width:100%;height:100%;border-radius:.25em;background:#fff;background-image:url(" +
            _0x177b77 +
            _0x4dfaac(0x141),
          "",
        ]),
          (_0x5d8b6d[_0x4dfaac(0x13e)] = _0x3cefce);
      },
      0x410: function (_0x390200, _0x1b5474, _0x2241ee) {
        "use strict";
        _0x2241ee(0x17e);
      },
      0x411: function (_0x4eb34c, _0xe73eb4, _0x27ab8e) {
        var _0x1c1e22 = a16_0x295903,
          _0x1ce49d = _0x27ab8e(0x4)(!0x1);
        _0x1ce49d[_0x1c1e22(0x22a)]([
          _0x4eb34c["i"],
          ".game-content.svelte-crash{width:100%;display:flex;flex-direction:column;justify-content:center;flex-grow:1;-webkit-user-select:none;-moz-user-select:none;user-select:none;position:relative;overflow:hidden;margin:0\x20auto;border-top-right-radius:var(--game-frame-radius)}.wrap.svelte-crash{position:relative;top:1em;right:1em;display:flex}.crash-game.svelte-crash{display:flex;justify-content:space-between;align-items:center;flex-direction:column;flex-grow:1;width:100%}.wrapper.svelte-crash{display:flex;justify-content:center;align-items:center;height:100%}.wrap.svelte-player-count{position:absolute;bottom:calc(10px\x20+\x201rem);left:1rem;display:flex;align-items:center}.indicator.svelte-crash{background:#00e449;width:.5em;height:.5em;border-radius:.25rem}.player-count-number{margin-left:var(--spacing-0-5)}.wrap.svelte-progressbar.svelte-progressbar:not(.mobile-view){text-align:center}.wrap.svelte-progressbar.svelte-progressbar{width:100%;position:relative;font-weight:600;display:grid;grid-gap:var(--spacingEm-1);font-size:var(--font-size-base)}.wrap.svelte-progressbar.svelte-progressbar:before{content:\x22\x22;position:absolute;height:10px;left:0;bottom:0;right:0;background:var(--grey-400)}.wrap.svelte-progressbar\x20span.svelte-progressbar{margin-right:var(--spacing-1)}.progress-bar.svelte-progressbar.svelte-progressbar{height:10px;transition:.1s;background:var(--blue-400);transition-timing-function:linear;z-index:100;width:0}@keyframes\x20svelte-crash-slideOdd{0%{transform:translate(100%)}}@keyframes\x20svelte-crash-slideEven{0%{transform:translate(100%)}}@keyframes\x20svelte-crash-slideOut{0%{transform:translate(100%)}to{transform:translate(0);opacity:0;pointer-events:none}}.past-bets.svelte-crash{width:100%;display:flex;flex-direction:row-reverse}.past-bets.svelte-crash>:nth-child(odd){animation-name:svelte-crash-slideOdd}.past-bets.svelte-crash>:nth-child(2n){animation-name:svelte-crash-slideEven}.past-bets.full.svelte-crash>:last-child{animation-name:svelte-crash-slideOut}.past-bets.svelte-crash>*{min-width:8ch;font-feature-settings:\x22tnum\x22;font-variant-numeric:tabular-nums;will-change:transform;animation-fill-mode:forwards;animation-duration:.5s;animation-timing-function:ease-out}.past-bets.svelte-crash>*+*{margin-right:var(--spacing-0-25)}button.variant-success.svelte-oho9kj{color:var(--variant-success-color);background:var(--variant-success-background)}button.svelte-oho9kj{margin-left:var(--spacing-0-25)}",
          "",
        ]),
          (_0x4eb34c[_0x1c1e22(0x13e)] = _0x1ce49d);
      },
      0x174: function (_0x3fb70c, _0xb8f3a0, _0x10d96f) {
        var _0x443c33 = a16_0x295903,
          _0x46a0a0 = _0x10d96f(0x3d6);
        _0x46a0a0["__esModule"] && (_0x46a0a0 = _0x46a0a0[_0x443c33(0x379)]),
          "string" == typeof _0x46a0a0 &&
            (_0x46a0a0 = [[_0x3fb70c["i"], _0x46a0a0, ""]]),
          _0x46a0a0[_0x443c33(0x28e)] &&
            (_0x3fb70c[_0x443c33(0x13e)] = _0x46a0a0[_0x443c33(0x28e)]),
          (0x0, _0x10d96f(0x5)["default"])(_0x443c33(0x40e), _0x46a0a0, !0x0, {
            sourceMap: !0x1,
          });
      },
      0x175: function (_0x558b52, _0x59ac5b, _0x2cd99e) {
        var _0xec6f36 = a16_0x295903,
          _0x2a1da9 = _0x2cd99e(0x3d8);
        _0x2a1da9["__esModule"] && (_0x2a1da9 = _0x2a1da9[_0xec6f36(0x379)]),
          _0xec6f36(0x1dd) == typeof _0x2a1da9 &&
            (_0x2a1da9 = [[_0x558b52["i"], _0x2a1da9, ""]]),
          _0x2a1da9[_0xec6f36(0x28e)] &&
            (_0x558b52["exports"] = _0x2a1da9[_0xec6f36(0x28e)]),
          (0x0, _0x2cd99e(0x5)[_0xec6f36(0x379)])(
            _0xec6f36(0x36d),
            _0x2a1da9,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x176: function (_0x33505d, _0x3deca8, _0x923977) {
        var _0x5eb3fc = a16_0x295903,
          _0xdf1d97 = _0x923977(0x3dc);
        _0xdf1d97[_0x5eb3fc(0x17e)] &&
          (_0xdf1d97 = _0xdf1d97[_0x5eb3fc(0x379)]),
          _0x5eb3fc(0x1dd) == typeof _0xdf1d97 &&
            (_0xdf1d97 = [[_0x33505d["i"], _0xdf1d97, ""]]),
          _0xdf1d97[_0x5eb3fc(0x28e)] &&
            (_0x33505d[_0x5eb3fc(0x13e)] = _0xdf1d97["locals"]),
          (0x0, _0x923977(0x5)[_0x5eb3fc(0x379)])(
            _0x5eb3fc(0x315),
            _0xdf1d97,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x17b: function (_0x50d80f, _0x41dbea, _0x309b1d) {
        var _0x5131e5 = a16_0x295903,
          _0x249a78 = _0x309b1d(0x405);
        _0x249a78["__esModule"] && (_0x249a78 = _0x249a78[_0x5131e5(0x379)]),
          _0x5131e5(0x1dd) == typeof _0x249a78 &&
            (_0x249a78 = [[_0x50d80f["i"], _0x249a78, ""]]),
          _0x249a78[_0x5131e5(0x28e)] &&
            (_0x50d80f["exports"] = _0x249a78[_0x5131e5(0x28e)]),
          (0x0, _0x309b1d(0x5)[_0x5131e5(0x379)])(
            _0x5131e5(0x24d),
            _0x249a78,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x17c: function (_0x50db5f, _0x1f95b8, _0x2becfe) {
        var _0x547a11 = a16_0x295903,
          _0x2e1123 = _0x2becfe(0x40a);
        _0x2e1123["__esModule"] && (_0x2e1123 = _0x2e1123[_0x547a11(0x379)]),
          _0x547a11(0x1dd) == typeof _0x2e1123 &&
            (_0x2e1123 = [[_0x50db5f["i"], _0x2e1123, ""]]),
          _0x2e1123["locals"] &&
            (_0x50db5f["exports"] = _0x2e1123[_0x547a11(0x28e)]),
          (0x0, _0x2becfe(0x5)["default"])(_0x547a11(0x1d8), _0x2e1123, !0x0, {
            sourceMap: !0x1,
          });
      },
      0x17e: function (_0xfb2c0a, _0x4969b5, _0x2abd5a) {
        var _0x207c5d = a16_0x295903,
          _0x374988 = _0x2abd5a(0x411);
        _0x374988[_0x207c5d(0x17e)] &&
          (_0x374988 = _0x374988[_0x207c5d(0x379)]),
          "string" == typeof _0x374988 &&
            (_0x374988 = [[_0xfb2c0a["i"], _0x374988, ""]]),
          _0x374988[_0x207c5d(0x28e)] &&
            (_0xfb2c0a[_0x207c5d(0x13e)] = _0x374988[_0x207c5d(0x28e)]),
          (0x0, _0x2abd5a(0x5)[_0x207c5d(0x379)])(
            _0x207c5d(0x131),
            _0x374988,
            !0x0,
            { sourceMap: !0x1 }
          );
      },
      0x1d8: function (_0x60dae8, _0x6968a4, _0x4a3f83) {
        "use strict";
        var _0x5038d4 = a16_0x295903;
        _0x4a3f83(0x13),
          _0x4a3f83(0xf0),
          _0x4a3f83(0xc),
          _0x4a3f83(0xa),
          _0x4a3f83(0xb),
          _0x4a3f83(0x8),
          _0x4a3f83(0x10),
          _0x4a3f83(0xd),
          _0x4a3f83(0x11);
        var _0x48f6af = _0x4a3f83(0x2),
          _0xd2125 = _0x4a3f83(0x3),
          _0x395fbe = _0x4a3f83(0x0),
          _0x579caa =
            (_0x4a3f83(0x7),
            {
              name: "VDialogHistory",
              components: { VPagination: _0x4a3f83(0x27)["a"] },
              data: function () {
                return {
                  history: {
                    per_page: 0xf,
                    cur_page: 0x1,
                    last_page: 0x0,
                    data: [],
                  },
                };
              },
              computed: {
                risk: function () {
                  var _0x1deba6 = a16_0x269f;
                  return {
                    0x0: this["$t"](_0x1deba6(0x3ac))[0x0],
                    0x1: this["$t"](_0x1deba6(0x3ac))[0x1],
                    0x2: this["$t"](_0x1deba6(0x3ac))[0x2],
                  };
                },
              },
              methods: {
                setPage: function (_0xe5f5f5) {
                  var _0x57053a = a16_0x269f;
                  (this[_0x57053a(0x18a)][_0x57053a(0x29c)] = _0xe5f5f5),
                    this["fetch"]();
                },
                fetch: function () {
                  var _0x59d23a = a16_0x269f,
                    _0xbd9183 = this;
                  return Object(_0x395fbe["a"])(
                    regeneratorRuntime[_0x59d23a(0x2bd)](function _0x385ca8() {
                      var _0x4596d4 = _0x59d23a,
                        _0x251ef4,
                        _0x437854,
                        _0x56f48f,
                        _0x5b6c78;
                      return regeneratorRuntime[_0x4596d4(0x203)](
                        function (_0x1c9858) {
                          var _0x17d68a = _0x4596d4;
                          for (;;)
                            switch (
                              (_0x1c9858[_0x17d68a(0x256)] =
                                _0x1c9858[_0x17d68a(0x220)])
                            ) {
                              case 0x0:
                                return (
                                  (_0x1c9858[_0x17d68a(0x256)] = 0x0),
                                  _0xbd9183[_0x17d68a(0x13d)](function () {
                                    var _0x53aad8 = _0x17d68a;
                                    _0xbd9183["$nuxt"][_0x53aad8(0x1ed)][
                                      _0x53aad8(0x1d3)
                                    ]();
                                  }),
                                  (_0x1c9858["next"] = 0x4),
                                  _0xbd9183["$repositories"][_0x17d68a(0x32d)][
                                    _0x17d68a(0x3ea)
                                  ][_0x17d68a(0x3c1)]({
                                    per_page:
                                      _0xbd9183["history"][_0x17d68a(0x37e)],
                                    page: _0xbd9183[_0x17d68a(0x18a)][
                                      "cur_page"
                                    ],
                                  })
                                );
                              case 0x4:
                                (_0x251ef4 = _0x1c9858[_0x17d68a(0x348)]),
                                  (_0x437854 = _0x251ef4[_0x17d68a(0x306)]),
                                  (_0x56f48f = _0x251ef4[_0x17d68a(0x235)]),
                                  (_0x5b6c78 = _0x251ef4["cur_page"]),
                                  (_0xbd9183["history"][_0x17d68a(0x235)] =
                                    _0x56f48f),
                                  (_0xbd9183[_0x17d68a(0x18a)]["cur_page"] =
                                    _0x5b6c78),
                                  (_0xbd9183["history"][_0x17d68a(0x306)] =
                                    _0x437854),
                                  (_0x1c9858[_0x17d68a(0x220)] = 0x10);
                                break;
                              case 0xd:
                                (_0x1c9858[_0x17d68a(0x256)] = 0xd),
                                  (_0x1c9858["t0"] =
                                    _0x1c9858[_0x17d68a(0x2a3)](0x0)),
                                  _0xbd9183[_0x17d68a(0x2a4)][_0x17d68a(0x400)](
                                    _0x1c9858["t0"]
                                  );
                              case 0x10:
                                return (
                                  (_0x1c9858[_0x17d68a(0x256)] = 0x10),
                                  _0xbd9183[_0x17d68a(0x13d)](function () {
                                    var _0x1e8c45 = _0x17d68a;
                                    _0xbd9183["$nuxt"][_0x1e8c45(0x1ed)][
                                      _0x1e8c45(0x26e)
                                    ]();
                                  }),
                                  _0x1c9858["finish"](0x10)
                                );
                              case 0x13:
                              case _0x17d68a(0x12e):
                                return _0x1c9858[_0x17d68a(0x395)]();
                            }
                        },
                        _0x385ca8,
                        null,
                        [[0x0, 0xd, 0x10, 0x13]]
                      );
                    })
                  )();
                },
              },
            }),
          _0x30eeb8 = (_0x4a3f83(0x3d5), _0x4a3f83(0x1)),
          _0x12e49c = Object(_0x30eeb8["a"])(
            _0x579caa,
            function () {
              var _0x214dca = a16_0x269f,
                _0x58338b,
                _0x308e25 = this,
                _0x409e00 = _0x308e25[_0x214dca(0x396)]["_c"];
              return _0x409e00(
                _0x214dca(0x19a),
                {
                  ref: _0x214dca(0x342),
                  attrs: { "max-width": _0x214dca(0x1c1) },
                  on: { dialogActive: _0x308e25["fetch"] },
                  scopedSlots: _0x308e25["_u"](
                    [
                      {
                        key: _0x214dca(0x3fb),
                        fn: function (_0x3dfde0) {
                          var _0x1fe339 = _0x214dca,
                            _0x26100a = _0x3dfde0["on"];
                          return [
                            _0x308e25["_t"](_0x1fe339(0x3fb), null, {
                              on: _0x26100a,
                            }),
                          ];
                        },
                      },
                    ],
                    null,
                    !0x0
                  ),
                },
                [
                  _0x308e25["_v"]("\x20"),
                  _0x409e00(
                    _0x214dca(0x1e2),
                    { staticClass: "container" },
                    [
                      _0x409e00(
                        _0x214dca(0x1b8),
                        { staticClass: _0x214dca(0x34f) },
                        [
                          _0x409e00(_0x214dca(0x275), [
                            _0x308e25["_v"](
                              _0x308e25["_s"](_0x308e25["$t"](_0x214dca(0x20e)))
                            ),
                          ]),
                        ],
                        0x1
                      ),
                      _0x308e25["_v"]("\x20"),
                      _0x409e00(
                        _0x214dca(0x1e2),
                        { staticClass: _0x214dca(0x3aa) },
                        [
                          _0x409e00(
                            _0x214dca(0x1e2),
                            { staticClass: _0x214dca(0x284) },
                            [
                              _0x409e00(_0x214dca(0x19f), [
                                _0x409e00(_0x214dca(0x168), [
                                  _0x409e00("tr", [
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"](_0x214dca(0x33a))
                                        )
                                      ),
                                    ]),
                                    _0x308e25["_v"]("\x20"),
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"](_0x214dca(0x37a))
                                        )
                                      ),
                                    ]),
                                    _0x308e25["_v"]("\x20"),
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"]("plinko.rows")
                                        )
                                      ),
                                    ]),
                                    _0x308e25["_v"]("\x20"),
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"](_0x214dca(0x210))
                                        )
                                      ),
                                    ]),
                                    _0x308e25["_v"]("\x20"),
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"](_0x214dca(0x3fc))
                                        )
                                      ),
                                    ]),
                                    _0x308e25["_v"]("\x20"),
                                    _0x409e00("th", [
                                      _0x308e25["_v"](
                                        _0x308e25["_s"](
                                          _0x308e25["$t"]("plinko.win")
                                        )
                                      ),
                                    ]),
                                  ]),
                                ]),
                                _0x308e25["_v"]("\x20"),
                                _0x409e00(
                                  "tbody",
                                  [
                                    _0x308e25["_l"](
                                      _0x308e25[_0x214dca(0x18a)][
                                        _0x214dca(0x306)
                                      ],
                                      function (_0x44862c) {
                                        var _0xbb1935 = _0x214dca;
                                        return _0x409e00("tr", [
                                          _0x409e00(
                                            "td",
                                            { staticClass: "date" },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    _0x308e25["$moment"](
                                                      _0x44862c["created_at"]
                                                    )[_0xbb1935(0x1ac)](
                                                      _0xbb1935(0x343)
                                                    )
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x308e25["_v"]("\x20"),
                                          _0x409e00(
                                            "td",
                                            { staticClass: _0xbb1935(0x2c2) },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    _0x308e25[_0xbb1935(0x2c2)][
                                                      _0x44862c[
                                                        _0xbb1935(0x2c2)
                                                      ]
                                                    ]
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x308e25["_v"]("\x20"),
                                          _0x409e00(
                                            "td",
                                            { staticClass: "row" },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    _0x44862c[_0xbb1935(0x2f1)]
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x308e25["_v"]("\x20"),
                                          _0x409e00(
                                            "td",
                                            { staticClass: _0xbb1935(0x2bf) },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    parseInt(
                                                      _0x44862c[
                                                        _0xbb1935(0x2bf)
                                                      ]
                                                    )[_0xbb1935(0x1fc)]()
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x308e25["_v"]("\x20"),
                                          _0x409e00(
                                            "td",
                                            { staticClass: _0xbb1935(0x1a5) },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    _0x44862c["odds"]
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x308e25["_v"]("\x20"),
                                          _0x409e00(
                                            "td",
                                            { staticClass: "expect-amount" },
                                            [
                                              _0x409e00(_0xbb1935(0x275), [
                                                _0x308e25["_v"](
                                                  _0x308e25["_s"](
                                                    parseInt(
                                                      _0x44862c[
                                                        _0xbb1935(0x18d)
                                                      ]
                                                    )[_0xbb1935(0x1fc)]()
                                                  )
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                        ]);
                                      }
                                    ),
                                    _0x308e25["_v"]("\x20"),
                                    0x0 ==
                                    _0x308e25["history"][_0x214dca(0x306)][
                                      "length"
                                    ]
                                      ? [
                                          _0x409e00(
                                            "td",
                                            {
                                              style: {
                                                "background-color":
                                                  _0x214dca(0x3b0),
                                              },
                                              attrs: { colspan: "6" },
                                            },
                                            [
                                              _0x409e00(
                                                "v-text",
                                                {
                                                  style: {
                                                    "justify-content":
                                                      _0x214dca(0x398),
                                                  },
                                                },
                                                [
                                                  _0x308e25["_v"](
                                                    _0x214dca(0x31a) +
                                                      _0x308e25["_s"](
                                                        _0x308e25["$t"](
                                                          _0x214dca(0x405)
                                                        )
                                                      ) +
                                                      _0x214dca(0x1ff)
                                                  ),
                                                ]
                                              ),
                                            ],
                                            0x1
                                          ),
                                        ]
                                      : _0x308e25["_e"](),
                                  ],
                                  0x2
                                ),
                              ]),
                            ]
                          ),
                        ],
                        0x1
                      ),
                      _0x308e25["_v"]("\x20"),
                      _0x409e00(
                        _0x214dca(0x1e2),
                        { staticClass: _0x214dca(0x2d5) },
                        [
                          _0x409e00("v-pagination", {
                            attrs:
                              ((_0x58338b = {
                                value: _0x308e25["history"][_0x214dca(0x29c)],
                                perPage: _0x308e25["history"]["per_page"],
                              }),
                              Object(_0x48f6af["a"])(
                                _0x58338b,
                                _0x214dca(0x356),
                                _0x308e25["history"][_0x214dca(0x37e)]
                              ),
                              Object(_0x48f6af["a"])(
                                _0x58338b,
                                _0x214dca(0x312),
                                _0x308e25[_0x214dca(0x18a)]["last_page"]
                              ),
                              _0x58338b),
                            on: {
                              "update:perPage": function (_0x36b1d3) {
                                var _0x105aee = _0x214dca;
                                return _0x308e25[_0x105aee(0x1d5)](
                                  _0x308e25["history"],
                                  _0x105aee(0x37e),
                                  _0x36b1d3
                                );
                              },
                              "update:per-page": [
                                function (_0x614ac5) {
                                  var _0x46760f = _0x214dca;
                                  return _0x308e25["$set"](
                                    _0x308e25[_0x46760f(0x18a)],
                                    _0x46760f(0x37e),
                                    _0x614ac5
                                  );
                                },
                                _0x308e25[_0x214dca(0x119)],
                              ],
                              input: _0x308e25[_0x214dca(0x1f0)],
                            },
                          }),
                        ],
                        0x1
                      ),
                    ],
                    0x1
                  ),
                ],
                0x1
              );
            },
            [],
            !0x1,
            null,
            "0f3cd04b",
            null
          )[_0x5038d4(0x13e)];
        function _0x486ed8(_0x62ff68, _0x5d566c) {
          var _0x50e344 = _0x5038d4,
            _0x4083b5 = Object[_0x50e344(0x376)](_0x62ff68);
          if (Object[_0x50e344(0x221)]) {
            var _0x5c48f5 = Object["getOwnPropertySymbols"](_0x62ff68);
            _0x5d566c &&
              (_0x5c48f5 = _0x5c48f5[_0x50e344(0x1db)](function (_0x2e8345) {
                var _0x3e7bb5 = _0x50e344;
                return Object[_0x3e7bb5(0x39e)](
                  _0x62ff68,
                  _0x2e8345
                )[_0x3e7bb5(0x25b)];
              })),
              _0x4083b5[_0x50e344(0x22a)]["apply"](_0x4083b5, _0x5c48f5);
          }
          return _0x4083b5;
        }
        var _0xd62c61 = {
            name: _0x5038d4(0x1c2),
            props: { IsInsurance: { type: Boolean } },
            components: { VDialogHistory: _0x12e49c },
            computed: (function (_0x4938e0) {
              var _0x24cea1 = _0x5038d4;
              for (
                var _0x15ac07 = 0x1;
                _0x15ac07 < arguments[_0x24cea1(0x21a)];
                _0x15ac07++
              ) {
                var _0x104dcc =
                  null != arguments[_0x15ac07] ? arguments[_0x15ac07] : {};
                _0x15ac07 % 0x2
                  ? _0x486ed8(Object(_0x104dcc), !0x0)["forEach"](function (
                      _0x26ac30
                    ) {
                      Object(_0x48f6af["a"])(
                        _0x4938e0,
                        _0x26ac30,
                        _0x104dcc[_0x26ac30]
                      );
                    })
                  : Object[_0x24cea1(0x2fb)]
                  ? Object[_0x24cea1(0x2b5)](
                      _0x4938e0,
                      Object[_0x24cea1(0x2fb)](_0x104dcc)
                    )
                  : _0x486ed8(Object(_0x104dcc))["forEach"](function (
                      _0x243654
                    ) {
                      Object["defineProperty"](
                        _0x4938e0,
                        _0x243654,
                        Object["getOwnPropertyDescriptor"](_0x104dcc, _0x243654)
                      );
                    });
              }
              return _0x4938e0;
            })(
              {},
              Object(_0xd2125["c"])(_0x5038d4(0x2d3), [
                _0x5038d4(0x371),
                "getSetdisabled",
                _0x5038d4(0x280),
                _0x5038d4(0x2e8),
                _0x5038d4(0x128),
              ])
            ),
            data: function () {
              return { settingForm: { amounts: null }, quickAmount: 0x2710 };
            },
            methods: {
              up: function () {
                var _0x18408d = _0x5038d4;
                (this[_0x18408d(0x2e5)][_0x18408d(0x191)] +=
                  this["quickAmount"]),
                  this[_0x18408d(0x1f7)]();
              },
              down: function () {
                var _0x1ea303 = _0x5038d4;
                this[_0x1ea303(0x2e5)][_0x1ea303(0x191)] >
                this[_0x1ea303(0x345)]
                  ? (this[_0x1ea303(0x2e5)][_0x1ea303(0x191)] -=
                      this[_0x1ea303(0x345)])
                  : (this[_0x1ea303(0x2e5)][_0x1ea303(0x191)] = null),
                  this["changedAmount"]();
              },
              startBet: function (_0x248f8f) {
                _0x248f8f["preventDefault"](), this["$emit"]("startBet");
              },
              hit: function (_0x42f1ef) {
                var _0x37dc12 = _0x5038d4;
                _0x42f1ef[_0x37dc12(0x3e1)](), this[_0x37dc12(0x3ae)]("hit");
              },
              stand: function (_0x3c50b8) {
                var _0x248955 = _0x5038d4;
                _0x3c50b8[_0x248955(0x3e1)](),
                  this[_0x248955(0x3ae)](_0x248955(0x3fd));
              },
              split: function (_0x102b5c) {
                var _0x58a619 = _0x5038d4;
                _0x102b5c[_0x58a619(0x3e1)](), this["$emit"]("split");
              },
              double: function (_0x4fbe79) {
                var _0x58993e = _0x5038d4;
                _0x4fbe79[_0x58993e(0x3e1)](),
                  this[_0x58993e(0x3ae)](_0x58993e(0x259));
              },
              acceptInsurance: function (_0x2d8715) {
                var _0x5dd87a = _0x5038d4;
                _0x2d8715[_0x5dd87a(0x3e1)](), this["$emit"]("acceptInsurance");
              },
              notAcceptInsurance: function (_0x49f20d) {
                var _0x355828 = _0x5038d4;
                _0x49f20d[_0x355828(0x3e1)](),
                  this[_0x355828(0x3ae)](_0x355828(0x1b6));
              },
              changedAmount: function () {
                var _0x4e29ab = _0x5038d4;
                this["$emit"](
                  _0x4e29ab(0x1f7),
                  this[_0x4e29ab(0x2e5)][_0x4e29ab(0x191)]
                );
              },
            },
          },
          _0x1f1886 = _0xd62c61,
          _0x1e6608 =
            (_0x4a3f83(0x3d7),
            Object(_0x30eeb8["a"])(
              _0x1f1886,
              function () {
                var _0x30fd6f = _0x5038d4,
                  _0x10e55f = this,
                  _0x7526d8 = _0x10e55f[_0x30fd6f(0x396)]["_c"];
                return _0x7526d8(
                  _0x30fd6f(0x1b8),
                  { staticClass: _0x30fd6f(0x25a) },
                  [
                    _0x7526d8(
                      _0x30fd6f(0x1e2),
                      { staticClass: _0x30fd6f(0x25d) },
                      [
                        _0x10e55f[_0x30fd6f(0x2d8)]["loggedIn"]
                          ? _0x7526d8(
                              _0x30fd6f(0x1b8),
                              { staticClass: "history-btn" },
                              [
                                _0x7526d8("v-dialog-history", {
                                  scopedSlots: _0x10e55f["_u"](
                                    [
                                      {
                                        key: _0x30fd6f(0x3fb),
                                        fn: function (_0x1e60f4) {
                                          var _0x95c129 = _0x30fd6f,
                                            _0x329381 = _0x1e60f4["on"];
                                          return [
                                            _0x7526d8(
                                              _0x95c129(0x33d),
                                              _0x10e55f["_g"](
                                                { attrs: { text: "" } },
                                                _0x329381
                                              ),
                                              [
                                                _0x7526d8(_0x95c129(0x275), [
                                                  _0x10e55f["_v"](
                                                    _0x95c129(0x25f)
                                                  ),
                                                ]),
                                              ],
                                              0x1
                                            ),
                                          ];
                                        },
                                      },
                                    ],
                                    null,
                                    !0x1,
                                    0xc181b458
                                  ),
                                }),
                              ],
                              0x1
                            )
                          : _0x10e55f["_e"](),
                        _0x10e55f["_v"]("\x20"),
                        _0x7526d8(
                          _0x30fd6f(0x1e2),
                          { staticClass: "betslip-form" },
                          [
                            _0x7526d8(
                              "v-column",
                              { staticClass: _0x30fd6f(0x2bf) },
                              [
                                _0x10e55f[_0x30fd6f(0x2d8)][_0x30fd6f(0x266)]
                                  ? _0x7526d8(
                                      "v-row",
                                      { staticClass: _0x30fd6f(0x3c4) },
                                      [
                                        _0x7526d8(
                                          _0x30fd6f(0x1b8),
                                          { staticClass: "title" },
                                          [
                                            _0x7526d8("v-text", [
                                              _0x10e55f["_v"](_0x30fd6f(0x410)),
                                            ]),
                                          ],
                                          0x1
                                        ),
                                        _0x10e55f["_v"]("\x20"),
                                        _0x7526d8(
                                          _0x30fd6f(0x1b8),
                                          { staticClass: _0x30fd6f(0x14d) },
                                          [
                                            _0x7526d8("v-text", [
                                              _0x10e55f["_v"](
                                                _0x10e55f["_s"](
                                                  parseInt(
                                                    _0x10e55f[_0x30fd6f(0x2d8)][
                                                      _0x30fd6f(0x3e6)
                                                    ][_0x30fd6f(0x15f)]
                                                  )[_0x30fd6f(0x1fc)]()
                                                )
                                              ),
                                            ]),
                                          ],
                                          0x1
                                        ),
                                      ],
                                      0x1
                                    )
                                  : _0x10e55f["_e"](),
                                _0x10e55f["_v"]("\x20"),
                                _0x7526d8(
                                  _0x30fd6f(0x1b8),
                                  [
                                    _0x7526d8(_0x30fd6f(0x275), [
                                      _0x10e55f["_v"](_0x30fd6f(0x1f4)),
                                    ]),
                                  ],
                                  0x1
                                ),
                                _0x10e55f["_v"]("\x20"),
                                _0x7526d8(
                                  "v-row",
                                  { staticClass: "amount-input" },
                                  [
                                    _0x7526d8(
                                      _0x30fd6f(0x1b8),
                                      { staticClass: _0x30fd6f(0x222) },
                                      [
                                        _0x7526d8(
                                          _0x30fd6f(0x33d),
                                          {
                                            staticClass: _0x30fd6f(0x2ad),
                                            attrs: {
                                              disabled:
                                                _0x10e55f["getBetdisabled"],
                                            },
                                            on: {
                                              click: function (_0x274373) {
                                                var _0x1d39d9 = _0x30fd6f;
                                                return _0x10e55f[
                                                  _0x1d39d9(0x2ad)
                                                ]();
                                              },
                                            },
                                          },
                                          [
                                            _0x7526d8(_0x30fd6f(0x3ba), {
                                              staticClass: _0x30fd6f(0x234),
                                              attrs: { icon: _0x30fd6f(0x1f6) },
                                            }),
                                          ],
                                          0x1
                                        ),
                                        _0x10e55f["_v"]("\x20"),
                                        _0x7526d8(
                                          "v-button",
                                          {
                                            staticClass: "up",
                                            attrs: {
                                              disabled:
                                                _0x10e55f[_0x30fd6f(0x280)],
                                            },
                                            on: {
                                              click: function (_0xc607e9) {
                                                return _0x10e55f["up"]();
                                              },
                                            },
                                          },
                                          [
                                            _0x7526d8(_0x30fd6f(0x3ba), {
                                              staticClass: _0x30fd6f(0x234),
                                              attrs: { icon: _0x30fd6f(0x223) },
                                            }),
                                          ],
                                          0x1
                                        ),
                                      ],
                                      0x1
                                    ),
                                    _0x10e55f["_v"]("\x20"),
                                    _0x7526d8("v-input", {
                                      attrs: {
                                        placeholder: _0x30fd6f(0x1ba),
                                        disabled: _0x10e55f[_0x30fd6f(0x280)],
                                        "number-format": !0x0,
                                      },
                                      on: { input: _0x10e55f["changedAmount"] },
                                      model: {
                                        value:
                                          _0x10e55f[_0x30fd6f(0x2e5)][
                                            "amounts"
                                          ],
                                        callback: function (_0x43a39b) {
                                          var _0x17a026 = _0x30fd6f;
                                          _0x10e55f[_0x17a026(0x1d5)](
                                            _0x10e55f[_0x17a026(0x2e5)],
                                            _0x17a026(0x191),
                                            _0x43a39b
                                          );
                                        },
                                        expression: _0x30fd6f(0x3f4),
                                      },
                                    }),
                                    _0x10e55f["_v"]("\x20"),
                                    _0x7526d8(
                                      _0x30fd6f(0x33d),
                                      {
                                        staticClass: _0x30fd6f(0x2ce),
                                        attrs: {
                                          disabled: _0x10e55f[_0x30fd6f(0x280)],
                                        },
                                        on: {
                                          click: function (_0x5d6f3e) {
                                            return _0x10e55f["clear"]();
                                          },
                                        },
                                      },
                                      [
                                        _0x7526d8(_0x30fd6f(0x3ba), {
                                          staticClass: _0x30fd6f(0x234),
                                          attrs: {
                                            icon: "fa-regular\x20fa-eraser",
                                          },
                                        }),
                                      ],
                                      0x1
                                    ),
                                  ],
                                  0x1
                                ),
                              ],
                              0x1
                            ),
                          ],
                          0x1
                        ),
                        _0x10e55f["_v"]("\x20"),
                        _0x10e55f["IsInsurance"]
                          ? [
                              _0x7526d8(
                                _0x30fd6f(0x393),
                                {
                                  staticClass: _0x30fd6f(0x1a3),
                                  style: {
                                    "margin-bottom": _0x30fd6f(0x31b),
                                    "flex-shrink": "0",
                                  },
                                },
                                [_0x10e55f["_v"](_0x30fd6f(0x28a))]
                              ),
                              _0x10e55f["_v"]("\x20"),
                              _0x7526d8(
                                _0x30fd6f(0x1b8),
                                { staticClass: "insurance-btn" },
                                [
                                  _0x7526d8(
                                    _0x30fd6f(0x33d),
                                    {
                                      attrs: {
                                        disabled: _0x10e55f["getSetdisabled"],
                                      },
                                      on: {
                                        click: _0x10e55f[_0x30fd6f(0x124)],
                                      },
                                    },
                                    [
                                      _0x7526d8("v-text", [
                                        _0x10e55f["_v"]("수락"),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                  _0x10e55f["_v"]("\x20"),
                                  _0x7526d8(
                                    _0x30fd6f(0x33d),
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x285)],
                                      },
                                      on: {
                                        click: _0x10e55f["notAcceptInsurance"],
                                      },
                                    },
                                    [
                                      _0x7526d8(_0x30fd6f(0x275), [
                                        _0x10e55f["_v"]("거절"),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                ],
                                0x1
                              ),
                            ]
                          : [
                              _0x7526d8(
                                _0x30fd6f(0x1e2),
                                { staticClass: _0x30fd6f(0x29a) },
                                [
                                  _0x7526d8(
                                    "v-button",
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x285)],
                                      },
                                      on: { click: _0x10e55f["hit"] },
                                    },
                                    [
                                      _0x7526d8(
                                        _0x30fd6f(0x275),
                                        {
                                          staticClass: _0x30fd6f(0x13c),
                                          attrs: { color: _0x30fd6f(0x208) },
                                        },
                                        [
                                          _0x7526d8(_0x30fd6f(0x3ba), {
                                            attrs: { icon: _0x30fd6f(0x3ec) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x10e55f["_v"]("\x20"),
                                      _0x7526d8(_0x30fd6f(0x275), [
                                        _0x10e55f["_v"]("히트"),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                  _0x10e55f["_v"]("\x20"),
                                  _0x7526d8(
                                    _0x30fd6f(0x33d),
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x285)],
                                      },
                                      on: {
                                        click: _0x10e55f[_0x30fd6f(0x3fd)],
                                      },
                                    },
                                    [
                                      _0x7526d8(
                                        _0x30fd6f(0x275),
                                        {
                                          staticClass: _0x30fd6f(0x13c),
                                          attrs: { color: _0x30fd6f(0x279) },
                                        },
                                        [
                                          _0x7526d8("v-icon", {
                                            attrs: { icon: _0x30fd6f(0x1c9) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x10e55f["_v"]("\x20"),
                                      _0x7526d8("v-text", [
                                        _0x10e55f["_v"](_0x30fd6f(0x29f)),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                  _0x10e55f["_v"]("\x20"),
                                  _0x7526d8(
                                    "v-button",
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x2e8)],
                                      },
                                      on: { click: _0x10e55f["split"] },
                                    },
                                    [
                                      _0x7526d8(
                                        "v-text",
                                        {
                                          staticClass: _0x30fd6f(0x13c),
                                          attrs: { color: _0x30fd6f(0x241) },
                                        },
                                        [
                                          _0x7526d8(_0x30fd6f(0x3ba), {
                                            attrs: { icon: _0x30fd6f(0x1bc) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x10e55f["_v"]("\x20"),
                                      _0x7526d8("v-text", [
                                        _0x10e55f["_v"]("스플릿"),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                  _0x10e55f["_v"]("\x20"),
                                  _0x7526d8(
                                    "v-button",
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x285)],
                                      },
                                      on: {
                                        click: _0x10e55f[_0x30fd6f(0x259)],
                                      },
                                    },
                                    [
                                      _0x7526d8(
                                        _0x30fd6f(0x275),
                                        {
                                          staticClass: "margin-right-5",
                                          attrs: { color: _0x30fd6f(0x260) },
                                        },
                                        [
                                          _0x7526d8("v-icon", {
                                            attrs: { icon: _0x30fd6f(0x120) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x10e55f["_v"]("\x20"),
                                      _0x7526d8(_0x30fd6f(0x275), [
                                        _0x10e55f["_v"]("더블"),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                ],
                                0x1
                              ),
                              _0x10e55f["_v"]("\x20"),
                              _0x7526d8(
                                _0x30fd6f(0x1e2),
                                { staticClass: "submit" },
                                [
                                  _0x7526d8(
                                    _0x30fd6f(0x33d),
                                    {
                                      attrs: {
                                        disabled: _0x10e55f[_0x30fd6f(0x280)],
                                      },
                                      on: {
                                        click: _0x10e55f[_0x30fd6f(0x1cc)],
                                      },
                                    },
                                    [
                                      _0x7526d8(_0x30fd6f(0x275), [
                                        _0x10e55f["_v"](_0x30fd6f(0x261)),
                                      ]),
                                    ],
                                    0x1
                                  ),
                                ],
                                0x1
                              ),
                            ],
                      ],
                      0x2
                    ),
                  ],
                  0x1
                );
              },
              [],
              !0x1,
              null,
              _0x5038d4(0x123),
              null
            ));
        _0x6968a4["a"] = _0x1e6608[_0x5038d4(0x13e)];
      },
      0x1fa: function (_0x5d2e4a, _0x8033f4, _0x354788) {
        "use strict";
        var _0x137e9c = a16_0x295903;
        var _0x523c2e = _0x354788(0x2),
          _0x4055a5 = [
            function () {
              var _0x3f5a37 = a16_0x269f,
                _0x417947 = this["_self"]["_c"];
              return _0x417947(
                _0x3f5a37(0x366),
                { attrs: { id: _0x3f5a37(0x40d) } },
                [
                  _0x417947(_0x3f5a37(0x1d9), {
                    attrs: { src: _0x3f5a37(0x30b), type: "audio/mpeg" },
                  }),
                ]
              );
            },
            function () {
              var _0x369396 = a16_0x269f,
                _0x206920 = this[_0x369396(0x396)]["_c"];
              return _0x206920(
                _0x369396(0x366),
                { attrs: { id: _0x369396(0x180) } },
                [
                  _0x206920(_0x369396(0x1d9), {
                    attrs: { src: _0x369396(0x359), type: _0x369396(0x35e) },
                  }),
                ]
              );
            },
            function () {
              var _0x4b1b71 = a16_0x269f,
                _0x312778 = this[_0x4b1b71(0x396)]["_c"];
              return _0x312778(
                _0x4b1b71(0x366),
                { attrs: { id: "audio-flip" } },
                [
                  _0x312778(_0x4b1b71(0x1d9), {
                    attrs: { src: _0x354788(0x3d9), type: _0x4b1b71(0x35e) },
                  }),
                ]
              );
            },
            function () {
              var _0x3afb83 = a16_0x269f,
                _0x429bdc = this[_0x3afb83(0x396)]["_c"];
              return _0x429bdc(
                _0x3afb83(0x366),
                { attrs: { id: _0x3afb83(0x226) } },
                [
                  _0x429bdc("source", {
                    attrs: { src: _0x354788(0x3da), type: "audio/mpeg" },
                  }),
                ]
              );
            },
            function () {
              var _0x3d5255 = a16_0x269f,
                _0x3aaa14 = this[_0x3d5255(0x396)]["_c"];
              return _0x3aaa14(
                _0x3d5255(0x393),
                { staticClass: _0x3d5255(0x185) },
                [
                  _0x3aaa14(
                    _0x3d5255(0x393),
                    {
                      staticClass: _0x3d5255(0x2da),
                      staticStyle: { width: "5em", height: "7.9em" },
                    },
                    [
                      _0x3aaa14(_0x3d5255(0x393), {
                        staticClass: _0x3d5255(0x3f6),
                      }),
                    ]
                  ),
                ]
              );
            },
            function () {
              var _0x2dbdd4 = a16_0x269f,
                _0x3ffb08 = this[_0x2dbdd4(0x396)]["_c"];
              return _0x3ffb08(
                _0x2dbdd4(0x393),
                { staticClass: _0x2dbdd4(0x185) },
                [
                  _0x3ffb08(
                    "div",
                    {
                      staticClass: _0x2dbdd4(0x2da),
                      staticStyle: {
                        width: _0x2dbdd4(0x299),
                        height: _0x2dbdd4(0x28b),
                      },
                    },
                    [_0x3ffb08("div", { staticClass: _0x2dbdd4(0x3f6) })]
                  ),
                ]
              );
            },
          ],
          _0x4f5679 =
            (_0x354788(0xa),
            _0x354788(0xb),
            _0x354788(0x10),
            _0x354788(0xd),
            _0x354788(0x11),
            _0x354788(0x18)),
          _0x117dee = _0x354788(0x1f),
          _0x4d6843 =
            (_0x354788(0x5e),
            _0x354788(0x26),
            _0x354788(0x29),
            _0x354788(0x8),
            _0x354788(0x2a),
            _0x354788(0x75),
            _0x354788(0xc),
            _0x354788(0x40),
            _0x354788(0x39),
            _0x354788(0x13),
            _0x354788(0x57),
            _0x354788(0x43),
            _0x354788(0x28),
            _0x354788(0x2d),
            _0x354788(0x3));
        function _0x4c1361(_0x4c3297, _0xeeb684) {
          var _0x169b06 = a16_0x269f,
            _0x37d630 = Object[_0x169b06(0x376)](_0x4c3297);
          if (Object["getOwnPropertySymbols"]) {
            var _0x2147c8 = Object[_0x169b06(0x221)](_0x4c3297);
            _0xeeb684 &&
              (_0x2147c8 = _0x2147c8[_0x169b06(0x1db)](function (_0x155d7b) {
                var _0x3392b1 = _0x169b06;
                return Object[_0x3392b1(0x39e)](
                  _0x4c3297,
                  _0x155d7b
                )["enumerable"];
              })),
              _0x37d630[_0x169b06(0x22a)][_0x169b06(0x143)](
                _0x37d630,
                _0x2147c8
              );
          }
          return _0x37d630;
        }
        function _0x5e377f(_0x4b291b) {
          var _0x59b3f7 = a16_0x269f;
          for (
            var _0x470e7e = 0x1;
            _0x470e7e < arguments[_0x59b3f7(0x21a)];
            _0x470e7e++
          ) {
            var _0x1ea7e7 =
              null != arguments[_0x470e7e] ? arguments[_0x470e7e] : {};
            _0x470e7e % 0x2
              ? _0x4c1361(Object(_0x1ea7e7), !0x0)[_0x59b3f7(0x160)](function (
                  _0x240197
                ) {
                  Object(_0x523c2e["a"])(
                    _0x4b291b,
                    _0x240197,
                    _0x1ea7e7[_0x240197]
                  );
                })
              : Object[_0x59b3f7(0x2fb)]
              ? Object[_0x59b3f7(0x2b5)](
                  _0x4b291b,
                  Object["getOwnPropertyDescriptors"](_0x1ea7e7)
                )
              : _0x4c1361(Object(_0x1ea7e7))[_0x59b3f7(0x160)](function (
                  _0x33c350
                ) {
                  var _0x5eb989 = _0x59b3f7;
                  Object[_0x5eb989(0x418)](
                    _0x4b291b,
                    _0x33c350,
                    Object[_0x5eb989(0x39e)](_0x1ea7e7, _0x33c350)
                  );
                });
          }
          return _0x4b291b;
        }
        var _0x4e106a = {
            name: _0x137e9c(0x162),
            props: {
              IsStartedBet: { type: Boolean },
              IsHit: { type: Boolean },
              IsStand: { type: Boolean },
              IsSplit: { type: Boolean },
              IsDouble: { type: Boolean },
              IsInsurance: { type: Boolean },
              acceptInsurance: { type: String },
              changedAmount: { type: Number, default: 0x0 },
            },
            data: function () {
              var _0x3b7d5c = _0x137e9c;
              return {
                amount: 0x0,
                betId: "",
                active: !0x1,
                dealerCards: [],
                playerCards: [],
                playerOtherCards: [],
                prevValue: { dealer: 0x0, player: 0x0, player1: 0x0 },
                currentValue: { dealer: "", player: "", player1: "" },
                values: { dealer: 0x0, player: 0x0, player1: 0x0 },
                actions: { dealer: [], player: [], player1: [] },
                result: { player: "", player1: "" },
                playerValueResult: _0x3b7d5c(0x3cb),
                dealerValueResult: _0x3b7d5c(0x3cb),
                playerOtherValueResult: _0x3b7d5c(0x3cb),
                topCardRect: null,
                activeHand: 0x0,
                firstPack: 0x0,
                userMoney: 0x0,
              };
            },
            mounted: function () {
              var _0x16ad58 = _0x137e9c,
                _0x2393fc = this;
              (this["topCardRect"] =
                this[_0x16ad58(0x3a2)]["topCard"][_0x16ad58(0x1c6)]()),
                window[_0x16ad58(0x230)]
                  ? window[_0x16ad58(0x230)](
                      _0x16ad58(0x1e1),
                      this[_0x16ad58(0x16f)],
                      !0x1
                    )
                  : window[_0x16ad58(0x16e)] &&
                    window[_0x16ad58(0x16e)](
                      "onresize",
                      this[_0x16ad58(0x16f)]
                    ),
                this[_0x16ad58(0x32c)][_0x16ad58(0x32d)][_0x16ad58(0x309)]
                  [_0x16ad58(0x3c1)]()
                  ["then"](function (_0x26f47c) {
                    var _0x473d5d = _0x16ad58,
                      _0x1fd08e = _0x26f47c[_0x473d5d(0x306)][_0x473d5d(0x38b)],
                      _0x4bde61 = _0x1fd08e["state"],
                      _0x62eb42 = _0x1fd08e[_0x473d5d(0x2c6)],
                      _0x336cba = _0x1fd08e["id"],
                      _0x527391 = _0x1fd08e[_0x473d5d(0x3e6)];
                    _0x2393fc[_0x473d5d(0x219)](),
                      (_0x2393fc[_0x473d5d(0x2c6)] = _0x62eb42),
                      (_0x2393fc["betId"] = _0x336cba),
                      (_0x2393fc[_0x473d5d(0x267)] = _0x527391["money"]),
                      (_0x2393fc[_0x473d5d(0x246)] = _0x4bde61["player"][0x0][
                        _0x473d5d(0x333)
                      ]["map"](function (_0x495849, _0x416d80) {
                        var _0x52c429 = _0x473d5d;
                        return {
                          rank: _0x495849[_0x52c429(0x3d7)] || "",
                          suit: _0x2393fc["getIconName"](_0x495849["suit"]),
                          value: _0x495849[_0x52c429(0x2b2)],
                          color: _0x2393fc[_0x52c429(0x15e)](
                            _0x495849[_0x52c429(0x148)]
                          ),
                        };
                      }));
                    var _0x49e4b5 = _0x4bde61[_0x473d5d(0x204)][0x0][
                      _0x473d5d(0x333)
                    ][_0x473d5d(0x37c)](function (_0x445c27, _0x5ba2a7) {
                      var _0x32d13f = _0x473d5d;
                      return {
                        rank: _0x445c27[_0x32d13f(0x3d7)] || "",
                        suit: _0x2393fc[_0x32d13f(0x12d)](
                          _0x445c27[_0x32d13f(0x148)]
                        ),
                        value: _0x445c27["value"],
                        color: _0x2393fc["getFaceColor"](
                          _0x445c27[_0x32d13f(0x148)]
                        ),
                      };
                    });
                    _0x4bde61["dealer"][0x0][_0x473d5d(0x333)]["length"] > 0x1
                      ? (_0x2393fc[_0x473d5d(0x392)] = _0x49e4b5)
                      : (_0x2393fc["dealerCards"] = []["concat"](
                          Object(_0x117dee["a"])(_0x49e4b5),
                          [{ rank: "", suit: "", value: 0x0 }]
                        )),
                      "A" ===
                        _0x4bde61[_0x473d5d(0x204)][0x0]["cards"][0x0][
                          "rank"
                        ] && _0x2393fc[_0x473d5d(0x3ae)]("insurance"),
                      (_0x2393fc[_0x473d5d(0x3ab)][_0x473d5d(0x3df)] =
                        _0x2393fc[_0x473d5d(0x2a9)](
                          _0x4bde61[_0x473d5d(0x3df)][0x0]["value"]
                        )),
                      (_0x2393fc["values"][_0x473d5d(0x204)] = _0x2393fc[
                        "getRealValueForShow"
                      ](_0x4bde61[_0x473d5d(0x204)][0x0]["value"])),
                      (_0x2393fc[_0x473d5d(0x35c)][_0x473d5d(0x3df)] =
                        _0x4bde61[_0x473d5d(0x3df)][0x0][_0x473d5d(0x35c)]),
                      (_0x2393fc["actions"]["dealer"] =
                        _0x4bde61[_0x473d5d(0x204)][0x0][_0x473d5d(0x35c)]),
                      (_0x2393fc[_0x473d5d(0x2d0)]["player"] =
                        _0x4bde61[_0x473d5d(0x3df)][0x0][_0x473d5d(0x2d0)]),
                      _0x2393fc["prepareDeal"]();
                  })
                  ["catch"](function (_0x3b2e47) {
                    var _0x271679 = _0x16ad58;
                    console[_0x271679(0x329)](_0x3b2e47),
                      _0x2393fc["setBetdisabled"](!0x1),
                      _0x2393fc["setBetloading"](!0x1),
                      _0x2393fc["$emit"](_0x271679(0x3f8));
                  });
            },
            destroyed: function () {
              var _0x2be8ca = _0x137e9c;
              window["addEventListener"]
                ? window["removeEventListener"](
                    _0x2be8ca(0x1e1),
                    this[_0x2be8ca(0x16f)],
                    !0x1
                  )
                : window[_0x2be8ca(0x2e9)] &&
                  window["detachEvent"](
                    _0x2be8ca(0x3b9),
                    this[_0x2be8ca(0x16f)]
                  );
            },
            methods: _0x5e377f(
              _0x5e377f(
                {},
                Object(_0x4d6843["b"])("blackjack", [
                  _0x137e9c(0x21b),
                  "setSetdisabled",
                  _0x137e9c(0x2d2),
                  _0x137e9c(0x3e9),
                  _0x137e9c(0x2d9),
                ])
              ),
              {},
              {
                getIconName: function (_0x554c3c) {
                  var _0x17f756 = _0x137e9c;
                  switch (_0x554c3c) {
                    case "S":
                      return _0x17f756(0x257);
                    case "H":
                      return _0x17f756(0x1ca);
                    case "C":
                      return _0x17f756(0x382);
                    case "D":
                      return _0x17f756(0x2a1);
                    default:
                      return "";
                  }
                },
                getFaceColor: function (_0x9cd29d) {
                  var _0x1cb88f = _0x137e9c;
                  return "S" == _0x9cd29d || "C" == _0x9cd29d
                    ? "grey"
                    : "H" == _0x9cd29d || "D" == _0x9cd29d
                    ? _0x1cb88f(0x41c)
                    : "grey";
                },
                getRealValueForShow: function (_0x542cd6) {
                  var _0x35cd4a = _0x137e9c;
                  return _0x35cd4a(0x26a) == typeof _0x542cd6
                    ? _0x542cd6
                    : _0x542cd6["join"](",");
                },
                winsize: function () {
                  var _0x2f43d8 = _0x137e9c;
                  this[_0x2f43d8(0x178)] =
                    this[_0x2f43d8(0x3a2)][_0x2f43d8(0x391)][
                      _0x2f43d8(0x1c6)
                    ]();
                },
                dataInit: function () {
                  var _0x1ce7e3 = _0x137e9c;
                  (this[_0x1ce7e3(0x3c8)] = {
                    dealer: 0x0,
                    player: 0x0,
                    player1: 0x0,
                  }),
                    (this["currentValue"] = {
                      dealer: "",
                      player: "",
                      player1: "",
                    }),
                    (this[_0x1ce7e3(0x2d0)] = { player: "", player1: "" }),
                    (this[_0x1ce7e3(0x339)] = []),
                    (this[_0x1ce7e3(0x2e0)] = _0x1ce7e3(0x3cb)),
                    (this[_0x1ce7e3(0x338)] = _0x1ce7e3(0x3cb)),
                    (this[_0x1ce7e3(0x325)] = "hide"),
                    (this[_0x1ce7e3(0x207)] = 0x0),
                    (this[_0x1ce7e3(0x1e4)] = 0x0);
                },
                bet: function () {
                  var _0x22b6e0 = _0x137e9c;
                  if (
                    (document["getElementById"](_0x22b6e0(0x40d))[
                      _0x22b6e0(0x2e6)
                    ](),
                    this["setBetloading"](!0x0),
                    this[_0x22b6e0(0x2d2)](!0x0),
                    Object["keys"](this[_0x22b6e0(0x3a2)])[_0x22b6e0(0x21a)] >
                      0x3)
                  ) {
                    for (var _0x108f50 in this[_0x22b6e0(0x3a2)])
                      if (
                        _0x22b6e0(0x391) != _0x108f50 &&
                        "dealerWrapper" != _0x108f50 &&
                        "playerWrapper" != _0x108f50 &&
                        _0x22b6e0(0x150) != _0x108f50
                      ) {
                        var _0x296b85 = this[_0x22b6e0(0x3a2)][_0x108f50][0x0];
                        _0x296b85
                          ? _0x296b85["classList"][_0x22b6e0(0x397)](
                              _0x22b6e0(0x2ae)
                            )
                          : delete this["$refs"][_0x108f50];
                      }
                    document["getElementById"]("audio-mucked")["play"]();
                    var _0x2afa7a =
                      0x12c +
                      0x32 *
                        (Math[_0x22b6e0(0x1fe)](
                          this[_0x22b6e0(0x392)][_0x22b6e0(0x21a)],
                          this[_0x22b6e0(0x246)][_0x22b6e0(0x21a)]
                        ) -
                          0x1);
                    return (
                      (this[_0x22b6e0(0x2e0)] = _0x22b6e0(0x3cb)),
                      (this["playerOtherValueResult"] = _0x22b6e0(0x3cb)),
                      (this[_0x22b6e0(0x338)] = _0x22b6e0(0x3cb)),
                      void setTimeout(this[_0x22b6e0(0x1d3)], _0x2afa7a)
                    );
                  }
                  this["start"]();
                },
                start: function () {
                  var _0x2b608c = _0x137e9c,
                    _0x143b61 = this,
                    _0x58a6f9 = parseFloat(
                      this[_0x2b608c(0x19b)] - this["amount"]
                    )[_0x2b608c(0x1fd)](0x8),
                    _0x4c79b0 = _0x58a6f9[_0x2b608c(0x199)]()["replace"](
                      /(\.0+$|0+$)/g,
                      ""
                    );
                  (_0x58a6f9 = parseFloat(_0x4c79b0) < 0x0 ? 0x0 : _0x4c79b0),
                    this[_0x2b608c(0x32c)][_0x2b608c(0x32d)][
                      "BlackjackRepository"
                    ]
                      ["create"]({
                        type: "bet",
                        amount: this[_0x2b608c(0x2bf)],
                      })
                      [_0x2b608c(0x190)](function (_0x519dcf) {
                        var _0x3ef1d9 = _0x2b608c,
                          _0x3b7e36 =
                            _0x519dcf[_0x3ef1d9(0x306)][_0x3ef1d9(0x38b)],
                          _0x115789 = _0x3b7e36[_0x3ef1d9(0x311)],
                          _0x1c4abf = _0x3b7e36[_0x3ef1d9(0x2c6)],
                          _0x413ca3 = _0x3b7e36["id"],
                          _0x23796d = _0x3b7e36[_0x3ef1d9(0x3e6)];
                        _0x143b61[_0x3ef1d9(0x219)](),
                          (_0x143b61[_0x3ef1d9(0x2c6)] = _0x1c4abf),
                          (_0x143b61[_0x3ef1d9(0x3bc)] = _0x413ca3),
                          (_0x143b61[_0x3ef1d9(0x267)] = _0x23796d["money"]),
                          (_0x143b61["playerCards"] = _0x115789[
                            _0x3ef1d9(0x3df)
                          ][0x0][_0x3ef1d9(0x333)][_0x3ef1d9(0x37c)](function (
                            _0x316d91,
                            _0x15cc29
                          ) {
                            var _0x1f6605 = _0x3ef1d9;
                            return {
                              rank: _0x316d91[_0x1f6605(0x3d7)] || "",
                              suit: _0x143b61[_0x1f6605(0x12d)](
                                _0x316d91[_0x1f6605(0x148)]
                              ),
                              value: _0x316d91[_0x1f6605(0x2b2)],
                              color: _0x143b61[_0x1f6605(0x15e)](
                                _0x316d91[_0x1f6605(0x148)]
                              ),
                            };
                          }));
                        var _0x158310 = _0x115789[_0x3ef1d9(0x204)][0x0][
                          _0x3ef1d9(0x333)
                        ]["map"](function (_0xefa136, _0xa1d70d) {
                          var _0x3f0817 = _0x3ef1d9;
                          return {
                            rank: _0xefa136[_0x3f0817(0x3d7)] || "",
                            suit: _0x143b61[_0x3f0817(0x12d)](
                              _0xefa136["suit"]
                            ),
                            value: _0xefa136[_0x3f0817(0x2b2)],
                            color: _0x143b61[_0x3f0817(0x15e)](
                              _0xefa136[_0x3f0817(0x148)]
                            ),
                          };
                        });
                        _0x115789["dealer"][0x0][_0x3ef1d9(0x333)][
                          _0x3ef1d9(0x21a)
                        ] > 0x1
                          ? (_0x143b61[_0x3ef1d9(0x392)] = _0x158310)
                          : (_0x143b61["dealerCards"] = [][_0x3ef1d9(0x174)](
                              Object(_0x117dee["a"])(_0x158310),
                              [{ rank: "", suit: "", value: 0x0 }]
                            )),
                          "A" ===
                            _0x115789[_0x3ef1d9(0x204)][0x0]["cards"][0x0][
                              _0x3ef1d9(0x3d7)
                            ] && _0x143b61[_0x3ef1d9(0x3ae)](_0x3ef1d9(0x301)),
                          (_0x143b61[_0x3ef1d9(0x3ab)][_0x3ef1d9(0x3df)] =
                            _0x143b61[_0x3ef1d9(0x2a9)](
                              _0x115789[_0x3ef1d9(0x3df)][0x0]["value"]
                            )),
                          (_0x143b61["values"][_0x3ef1d9(0x204)] = _0x143b61[
                            _0x3ef1d9(0x2a9)
                          ](
                            _0x115789[_0x3ef1d9(0x204)][0x0][_0x3ef1d9(0x2b2)]
                          )),
                          (_0x143b61[_0x3ef1d9(0x35c)][_0x3ef1d9(0x3df)] =
                            _0x115789[_0x3ef1d9(0x3df)][0x0][_0x3ef1d9(0x35c)]),
                          (_0x143b61["actions"]["dealer"] =
                            _0x115789[_0x3ef1d9(0x204)][0x0][_0x3ef1d9(0x35c)]),
                          (_0x143b61[_0x3ef1d9(0x2d0)][_0x3ef1d9(0x3df)] =
                            _0x115789[_0x3ef1d9(0x3df)][0x0][_0x3ef1d9(0x2d0)]),
                          _0x143b61[_0x3ef1d9(0x140)]();
                      })
                      [_0x2b608c(0x2a3)](function (_0x5eacef) {
                        var _0x32863a = _0x2b608c;
                        _0x143b61["$swal2"][_0x32863a(0x400)](_0x5eacef),
                          _0x143b61["setBetdisabled"](!0x1),
                          _0x143b61["setBetloading"](!0x1),
                          _0x143b61[_0x32863a(0x3ae)](_0x32863a(0x3f8));
                      });
                },
                prepareDeal: function () {
                  var _0x2d1b60 = this;
                  setTimeout(function () {
                    var _0x503fff = a16_0x269f;
                    if (
                      Object[_0x503fff(0x376)](_0x2d1b60[_0x503fff(0x3a2)])[
                        _0x503fff(0x21a)
                      ] > 0x3
                    ) {
                      for (var _0x376730 in _0x2d1b60[_0x503fff(0x3a2)])
                        if (
                          "topCard" != _0x376730 &&
                          _0x503fff(0x2df) != _0x376730 &&
                          _0x503fff(0x194) != _0x376730 &&
                          _0x503fff(0x150) != _0x376730
                        ) {
                          var _0x3d4d1d =
                            _0x2d1b60[_0x503fff(0x3a2)][_0x376730][0x0];
                          _0x3d4d1d &&
                            (_0x3d4d1d[_0x503fff(0x12f)][_0x503fff(0x3cd)](
                              _0x503fff(0x305),
                              "mucked"
                            ),
                            _0x3d4d1d[_0x503fff(0x3f1)](_0x503fff(0x129))[0x0][
                              _0x503fff(0x12f)
                            ][_0x503fff(0x3cd)](
                              _0x503fff(0x293),
                              _0x503fff(0x1a4),
                              "draw",
                              _0x503fff(0x2c6)
                            ),
                            _0x3d4d1d[_0x503fff(0x3f1)](_0x503fff(0x3d3))[0x0][
                              "firstChild"
                            ][_0x503fff(0x12f)][_0x503fff(0x397)]("face-down"),
                            _0x2d1b60[_0x503fff(0x3bb)](_0x3d4d1d));
                        }
                      _0x2d1b60[_0x503fff(0x3ad)]();
                    }
                  });
                },
                deal: function () {
                  var _0x5580d5 = _0x137e9c;
                  for (
                    var _0x15ae70 = this, _0x1e17e7 = [], _0xe8b952 = 0x0;
                    _0xe8b952 < 0x2;
                    _0xe8b952++
                  )
                    _0x1e17e7[_0x5580d5(0x22a)]({
                      type: _0x5580d5(0x3df),
                      dom: this[_0x5580d5(0x3a2)][
                        _0x5580d5(0x334) + _0xe8b952
                      ][0x0],
                      rank: this[_0x5580d5(0x246)][_0xe8b952][_0x5580d5(0x3d7)],
                      value:
                        this[_0x5580d5(0x246)][_0xe8b952][_0x5580d5(0x2b2)],
                    }),
                      _0x1e17e7["push"]({
                        type: "dealer",
                        dom: this[_0x5580d5(0x3a2)][
                          _0x5580d5(0x2e4) + _0xe8b952
                        ][0x0],
                        rank: this[_0x5580d5(0x392)][_0xe8b952][
                          _0x5580d5(0x3d7)
                        ],
                        value:
                          this[_0x5580d5(0x392)][_0xe8b952][_0x5580d5(0x2b2)],
                      });
                  _0x1e17e7[_0x5580d5(0x37c)](function (_0x2d3b2c, _0x25d1fe) {
                    setTimeout(function () {
                      var _0x229e7a = a16_0x269f;
                      _0x229e7a(0x3df) === _0x2d3b2c[_0x229e7a(0x40a)]
                        ? ((_0x15ae70[_0x229e7a(0x3a2)][_0x229e7a(0x194)][
                            _0x229e7a(0x224)
                          ][_0x229e7a(0x328)] =
                            0x5 + (2.5 * _0x25d1fe) / 0x2 + "em"),
                          (_0x15ae70["$refs"]["playerWrapper"][
                            _0x229e7a(0x224)
                          ][_0x229e7a(0x1e5)] =
                            7.9 + (0x1 * _0x25d1fe) / 0x2 + "em"))
                        : ((_0x15ae70[_0x229e7a(0x3a2)][_0x229e7a(0x2df)][
                            _0x229e7a(0x224)
                          ][_0x229e7a(0x328)] =
                            0x5 + (2.5 * (_0x25d1fe - 0x1)) / 0x2 + "em"),
                          (_0x15ae70["$refs"][_0x229e7a(0x2df)][
                            _0x229e7a(0x224)
                          ][_0x229e7a(0x1e5)] =
                            7.9 + (0x1 * (_0x25d1fe - 0x1)) / 0x2 + "em")),
                        _0x15ae70["moveCard"](_0x2d3b2c["dom"]),
                        setTimeout(function () {
                          var _0x45819c = _0x229e7a;
                          "dealer" != _0x2d3b2c[_0x45819c(0x40a)] ||
                          0x0 !== _0x2d3b2c[_0x45819c(0x2b2)]
                            ? _0x15ae70[_0x45819c(0x2af)] &&
                              _0x25d1fe == _0x1e17e7[_0x45819c(0x21a)] - 0x1
                              ? _0x15ae70["setSetdisabled"](!0x1)
                              : (_0x45819c(0x204) ==
                                  _0x2d3b2c[_0x45819c(0x40a)] &&
                                _0x45819c(0x1c0) != _0x15ae70[_0x45819c(0x338)]
                                  ? (_0x15ae70[_0x45819c(0x338)] =
                                      _0x45819c(0x1c0))
                                  : "player" == _0x2d3b2c[_0x45819c(0x40a)] &&
                                    _0x45819c(0x1c0) !=
                                      _0x15ae70["dealerValueResult"] &&
                                    (_0x15ae70[_0x45819c(0x2e0)] =
                                      _0x45819c(0x1c0)),
                                (_0x15ae70[_0x45819c(0x2fe)][
                                  _0x2d3b2c[_0x45819c(0x40a)]
                                ] = _0x15ae70[_0x45819c(0x3fe)](
                                  _0x2d3b2c["type"],
                                  _0x2d3b2c["value"]
                                )),
                                _0x15ae70["flipCard"](
                                  _0x2d3b2c[_0x45819c(0x3ff)]
                                ),
                                _0x25d1fe ==
                                  _0x1e17e7[_0x45819c(0x21a)] - 0x1 &&
                                  ((_0x15ae70[_0x45819c(0x2fe)][
                                    _0x2d3b2c[_0x45819c(0x40a)]
                                  ] = _0x15ae70[_0x45819c(0x2a9)](
                                    _0x15ae70[_0x45819c(0x3ab)][
                                      _0x2d3b2c[_0x45819c(0x40a)]
                                    ]
                                  )),
                                  setTimeout(
                                    _0x15ae70[_0x45819c(0x303)],
                                    0x190
                                  )))
                            : _0x15ae70[_0x45819c(0x303)]();
                        }, 0x190);
                    }, 0x190 * (_0x25d1fe + 0x1));
                  });
                },
                betEnd: function (_0xfc83cb) {
                  var _0x3daa83 = _0x137e9c;
                  if ("" != this["result"][_0x3daa83(0x3df)]) {
                    for (var _0x33e844 in this[_0x3daa83(0x3a2)])
                      if (_0x33e844["indexOf"](_0x3daa83(0x334)) > -0x1) {
                        var _0x397997 = this[_0x3daa83(0x3a2)][_0x33e844][0x0];
                        _0x397997 &&
                          (_0x397997[_0x3daa83(0x3f1)]("face")[0x0][
                            "classList"
                          ][_0x3daa83(0x3cd)](_0x3daa83(0x2c6)),
                          _0x397997[_0x3daa83(0x3f1)]("face")[0x0][
                            _0x3daa83(0x12f)
                          ][_0x3daa83(0x397)](
                            this[_0x3daa83(0x2d0)][_0x3daa83(0x3df)]
                          ));
                      }
                    this[_0x3daa83(0x2e0)] = this["result"][_0x3daa83(0x3df)];
                  }
                  if ("" != this["result"][_0x3daa83(0x28c)]) {
                    for (var _0x4d42dc in this["$refs"])
                      if (
                        _0x4d42dc[_0x3daa83(0x2c7)](_0x3daa83(0x270)) > -0x1
                      ) {
                        var _0x18900c = this[_0x3daa83(0x3a2)][_0x4d42dc][0x0];
                        _0x18900c &&
                          (_0x18900c[_0x3daa83(0x3f1)]("face")[0x0][
                            _0x3daa83(0x12f)
                          ][_0x3daa83(0x3cd)](_0x3daa83(0x2c6)),
                          _0x18900c[_0x3daa83(0x3f1)](_0x3daa83(0x129))[0x0][
                            _0x3daa83(0x12f)
                          ][_0x3daa83(0x397)](
                            this["result"][_0x3daa83(0x28c)]
                          ));
                      }
                    this[_0x3daa83(0x325)] =
                      this[_0x3daa83(0x2d0)][_0x3daa83(0x28c)];
                  }
                  this[_0x3daa83(0x2c6)] ||
                    ((this[_0x3daa83(0x207)] = 0x0),
                    this[_0x3daa83(0x2d2)](!0x1),
                    this[_0x3daa83(0x36c)](!0x0),
                    _0xfc83cb && this["$emit"](_0x3daa83(0x300) + _0xfc83cb),
                    this[_0x3daa83(0x3ae)]("resetBet"),
                    this[_0x3daa83(0x3ae)]("resetSplit"));
                },
                getResult: function (
                  _0x18d9aa,
                  _0xbfa7a4,
                  _0x18a96c,
                  _0x774cf6
                ) {
                  var _0x59256d = _0x137e9c;
                  return _0x59256d(0x2d3) === _0x18d9aa
                    ? _0x59256d(0x2d3) === _0xbfa7a4
                      ? _0x59256d(0x3e4)
                      : "win"
                    : _0x59256d(0x2aa) === _0x18d9aa
                    ? _0x59256d(0x1a4)
                    : _0x59256d(0x2aa) === _0xbfa7a4
                    ? _0x59256d(0x293)
                    : _0x59256d(0x3fd) === _0x18d9aa ||
                      _0x59256d(0x259) === _0x18d9aa
                    ? _0x18a96c > _0x774cf6
                      ? _0x59256d(0x293)
                      : _0x18a96c == _0x774cf6
                      ? _0x59256d(0x3e4)
                      : _0x59256d(0x1a4)
                    : "";
                },
                checkFinishedAfterDeal: function () {
                  var _0x3f7fb6 = _0x137e9c;
                  this[_0x3f7fb6(0x21b)](!0x1),
                    this[_0x3f7fb6(0x2af)]
                      ? this["setSetdisabled"](!0x1)
                      : this[_0x3f7fb6(0x2c6)]
                      ? (this[_0x3f7fb6(0x36c)](!0x1),
                        this["setDoubledisabled"](!0x1),
                        this[_0x3f7fb6(0x246)][0x0][_0x3f7fb6(0x3d7)] ===
                          this[_0x3f7fb6(0x246)][0x1][_0x3f7fb6(0x3d7)] &&
                          this[_0x3f7fb6(0x3e9)](!0x1))
                      : this[_0x3f7fb6(0x377)](null);
                },
                checkFinishedAfterHit: function (_0x11405a) {
                  var _0x4017a6 = _0x137e9c,
                    _0x94c3dd =
                      this[_0x4017a6(0x207)] > 0x1
                        ? this[_0x4017a6(0x2d0)][_0x4017a6(0x28c)]
                        : this[_0x4017a6(0x2d0)][_0x4017a6(0x3df)];
                  if (
                    (this["active"] &&
                      0x1 === this["activeHand"] &&
                      0x1 === this[_0x4017a6(0x1e4)] &&
                      this[_0x4017a6(0x320)](),
                    this["active"])
                  )
                    "" != _0x94c3dd && this[_0x4017a6(0x377)](_0x11405a),
                      this[_0x4017a6(0x36c)](!0x1),
                      this[_0x4017a6(0x3ae)]("reset" + _0x11405a);
                  else {
                    var _0x364347 = Object(_0x117dee["a"])(
                        this["actions"][_0x4017a6(0x3df)]
                      )[_0x4017a6(0x242)](),
                      _0x352fdb = Object(_0x117dee["a"])(
                        this[_0x4017a6(0x35c)][_0x4017a6(0x28c)]
                      )["pop"]();
                    (_0x4017a6(0x2aa) === _0x364347 &&
                      _0x4017a6(0x2aa) === _0x352fdb) ||
                    (0x0 == this[_0x4017a6(0x207)] &&
                      _0x4017a6(0x2aa) === _0x364347)
                      ? this[_0x4017a6(0x377)](_0x11405a)
                      : this[_0x4017a6(0x170)](_0x11405a);
                  }
                },
                checkFinishAfterSplit: function () {
                  var _0xcc7627 = _0x137e9c;
                  this[_0xcc7627(0x2c6)]
                    ? (0x1 === this[_0xcc7627(0x1e4)] && this["switchHand"](),
                      this[_0xcc7627(0x36c)](!0x1),
                      this[_0xcc7627(0x2d9)](!0x1))
                    : (this[_0xcc7627(0x320)](),
                      this["revealDealerCards"](_0xcc7627(0x12c)));
                },
                switchHand: function () {
                  var _0x33d346 = _0x137e9c;
                  for (var _0xd56876 in ((this[_0x33d346(0x207)] = 0x2),
                  (this[_0x33d346(0x2e0)] = _0x33d346(0x1c0)),
                  this[_0x33d346(0x3a2)])) {
                    if (_0xd56876[_0x33d346(0x2c7)](_0x33d346(0x334)) > -0x1) {
                      var _0x257290 = this["$refs"][_0xd56876][0x0];
                      _0x257290 &&
                        _0x257290[_0x33d346(0x3f1)]("face")[0x0][
                          _0x33d346(0x12f)
                        ]["remove"](_0x33d346(0x2c6));
                    }
                    if (_0xd56876["indexOf"](_0x33d346(0x270)) > -0x1) {
                      var _0x1bd129 = this[_0x33d346(0x3a2)][_0xd56876][0x0];
                      _0x1bd129 &&
                        _0x1bd129["getElementsByClassName"](
                          _0x33d346(0x129)
                        )[0x0][_0x33d346(0x12f)][_0x33d346(0x397)](
                          _0x33d346(0x2c6)
                        );
                    }
                  }
                  (this[_0x33d346(0x325)] = _0x33d346(0x2c6)),
                    this[_0x33d346(0x2d9)](!0x1);
                },
                getValueStep: function (_0x23d27a, _0x59c5f8) {
                  var _0x58460a = _0x137e9c,
                    _0x4218ef = this,
                    _0x5024a6 = 0xb === _0x59c5f8 ? [0x1, 0xb] : _0x59c5f8,
                    _0x3e18d9 = 0x0;
                  if (_0x58460a(0x26a) == typeof this["prevValue"][_0x23d27a])
                    "number" == typeof _0x5024a6
                      ? (_0x3e18d9 =
                          this[_0x58460a(0x3c8)][_0x23d27a] + _0x5024a6)
                      : _0x58460a(0x216) ===
                          Object(_0x4f5679["a"])(_0x5024a6) &&
                        (_0x3e18d9 = _0x5024a6[_0x58460a(0x37c)](function (
                          _0x2557cc
                        ) {
                          var _0x662bad = _0x58460a;
                          return (
                            _0x2557cc + _0x4218ef[_0x662bad(0x3c8)][_0x23d27a]
                          );
                        }));
                  else {
                    if (
                      _0x58460a(0x216) ===
                      Object(_0x4f5679["a"])(this[_0x58460a(0x3c8)][_0x23d27a])
                    ) {
                      if (_0x58460a(0x26a) == typeof _0x5024a6)
                        _0x3e18d9 = this[_0x58460a(0x3c8)][_0x23d27a][
                          _0x58460a(0x37c)
                        ](function (_0x41760b) {
                          return _0x41760b + _0x5024a6;
                        });
                      else {
                        if (
                          _0x58460a(0x216) === Object(_0x4f5679["a"])(_0x5024a6)
                        ) {
                          _0x3e18d9 = [];
                          for (
                            var _0x538cdb = 0x0;
                            _0x538cdb < 0x2;
                            _0x538cdb++
                          )
                            for (
                              var _0x36f93e = 0x0;
                              _0x36f93e < 0x2;
                              _0x36f93e++
                            )
                              !_0x3e18d9[_0x58460a(0x2ec)](
                                _0x5024a6[_0x538cdb] +
                                  this["prevValue"][_0x23d27a][_0x36f93e]
                              ) &&
                                _0x5024a6[_0x538cdb] +
                                  this[_0x58460a(0x3c8)][_0x23d27a][_0x36f93e] <
                                  0x16 &&
                                _0x3e18d9[_0x58460a(0x22a)](
                                  _0x5024a6[_0x538cdb] +
                                    this[_0x58460a(0x3c8)][_0x23d27a][_0x36f93e]
                                );
                        }
                      }
                    }
                  }
                  return (
                    _0x58460a(0x216) === Object(_0x4f5679["a"])(_0x3e18d9) &&
                      Math[_0x58460a(0x1fe)][_0x58460a(0x143)](
                        null,
                        _0x3e18d9
                      ) > 0x15 &&
                      (_0x3e18d9 = Math[_0x58460a(0x364)]["apply"](
                        null,
                        _0x3e18d9
                      )),
                    ((_0x3e18d9 =
                      _0x3e18d9[_0x58460a(0x199)]()[_0x58460a(0x2c7)]("21") >
                      -0x1
                        ? 0x15
                        : _0x3e18d9),
                    (this[_0x58460a(0x3c8)][_0x23d27a] = _0x3e18d9),
                    this[_0x58460a(0x2a9)](_0x3e18d9))
                  );
                },
                hit: function () {
                  var _0x3a405a = _0x137e9c,
                    _0x4101cf = this;
                  this[_0x3a405a(0x36c)](!0x0),
                    this[_0x3a405a(0x3e9)](!0x0),
                    this[_0x3a405a(0x2d9)](!0x0),
                    this[_0x3a405a(0x32c)][_0x3a405a(0x32d)][_0x3a405a(0x309)]
                      [_0x3a405a(0x1e0)]({
                        type: _0x3a405a(0x35a),
                        id: this["betId"],
                      })
                      ["then"](function (_0x314cfd) {
                        var _0x2284f9 = _0x3a405a,
                          _0x4244ea =
                            _0x314cfd[_0x2284f9(0x306)][_0x2284f9(0x38b)],
                          _0x456877 = _0x4244ea["state"],
                          _0x2fe8d2 = _0x4244ea["active"],
                          _0x1b6533 = _0x4244ea[_0x2284f9(0x225)],
                          _0x42e073 = _0x4244ea[_0x2284f9(0x3e6)];
                        (_0x4101cf[_0x2284f9(0x2c6)] = _0x2fe8d2),
                          (_0x4101cf[_0x2284f9(0x1e4)] = _0x1b6533),
                          (_0x4101cf[_0x2284f9(0x267)] =
                            _0x42e073[_0x2284f9(0x19b)]),
                          _0x4101cf[_0x2284f9(0x207)] < 0x2
                            ? ((_0x4101cf["playerCards"] = _0x456877[
                                "player"
                              ][0x0][_0x2284f9(0x333)]["map"](function (
                                _0x3d0d1d,
                                _0x1185f0
                              ) {
                                var _0x550c7f = _0x2284f9;
                                return {
                                  rank: _0x3d0d1d[_0x550c7f(0x3d7)] || "",
                                  value: _0x3d0d1d[_0x550c7f(0x2b2)],
                                  suit: _0x4101cf[_0x550c7f(0x12d)](
                                    _0x3d0d1d[_0x550c7f(0x148)]
                                  ),
                                  color: _0x4101cf[_0x550c7f(0x15e)](
                                    _0x3d0d1d[_0x550c7f(0x148)]
                                  ),
                                };
                              })),
                              (_0x4101cf[_0x2284f9(0x3ab)][_0x2284f9(0x3df)] =
                                _0x456877[_0x2284f9(0x3df)][0x0]["value"]),
                              (_0x4101cf[_0x2284f9(0x35c)][_0x2284f9(0x3df)] =
                                _0x456877[_0x2284f9(0x3df)][0x0][
                                  _0x2284f9(0x35c)
                                ]))
                            : ((_0x4101cf[_0x2284f9(0x339)] = _0x456877[
                                _0x2284f9(0x3df)
                              ][0x1]["cards"]["map"](function (
                                _0x48666a,
                                _0x34b2b6
                              ) {
                                var _0x33397a = _0x2284f9;
                                return {
                                  rank: _0x48666a[_0x33397a(0x3d7)] || "",
                                  value: _0x48666a["value"],
                                  suit: _0x4101cf[_0x33397a(0x12d)](
                                    _0x48666a[_0x33397a(0x148)]
                                  ),
                                  color: _0x4101cf[_0x33397a(0x15e)](
                                    _0x48666a[_0x33397a(0x148)]
                                  ),
                                };
                              })),
                              (_0x4101cf[_0x2284f9(0x3ab)][_0x2284f9(0x28c)] =
                                _0x456877[_0x2284f9(0x3df)][0x1]["value"]),
                              (_0x4101cf[_0x2284f9(0x35c)]["player1"] =
                                _0x456877[_0x2284f9(0x3df)][0x1]["actions"]),
                              (_0x4101cf["result"][_0x2284f9(0x28c)] =
                                _0x456877[_0x2284f9(0x3df)][0x1][
                                  _0x2284f9(0x2d0)
                                ])),
                          (_0x4101cf[_0x2284f9(0x2d0)][_0x2284f9(0x3df)] =
                            _0x456877[_0x2284f9(0x3df)][0x0][_0x2284f9(0x2d0)]),
                          _0x456877["dealer"][0x0][_0x2284f9(0x333)][
                            _0x2284f9(0x21a)
                          ] > 0x1 &&
                            ((_0x4101cf[_0x2284f9(0x392)] = _0x456877[
                              _0x2284f9(0x204)
                            ][0x0]["cards"][_0x2284f9(0x37c)](function (
                              _0x353052,
                              _0x1c0484
                            ) {
                              var _0x64e081 = _0x2284f9;
                              return {
                                rank: _0x353052["rank"] || "",
                                value: _0x353052[_0x64e081(0x2b2)],
                                suit: _0x4101cf["getIconName"](
                                  _0x353052[_0x64e081(0x148)]
                                ),
                                color: _0x4101cf[_0x64e081(0x15e)](
                                  _0x353052[_0x64e081(0x148)]
                                ),
                              };
                            })),
                            (_0x4101cf["values"]["dealer"] =
                              _0x456877[_0x2284f9(0x204)][0x0][
                                _0x2284f9(0x2b2)
                              ]),
                            (_0x4101cf[_0x2284f9(0x35c)]["dealer"] =
                              _0x456877[_0x2284f9(0x204)][0x0][
                                _0x2284f9(0x35c)
                              ])),
                          _0x4101cf[_0x2284f9(0x3d9)]("Hit");
                      })
                      ["catch"](function (_0x21ebd2) {
                        var _0x36db28 = _0x3a405a;
                        _0x4101cf[_0x36db28(0x36c)](!0x1),
                          _0x4101cf[_0x36db28(0x3ae)](_0x36db28(0x36e));
                      });
                },
                doHitOrDouble: function (_0x590535) {
                  var _0x4d7d53 = this;
                  setTimeout(function () {
                    var _0x1ca469 = a16_0x269f;
                    if (
                      Object[_0x1ca469(0x376)](_0x4d7d53["$refs"])[
                        _0x1ca469(0x21a)
                      ] > 0x3
                    ) {
                      var _0x5ccfb9 =
                        _0x4d7d53[_0x1ca469(0x207)] < 0x2
                          ? _0x4d7d53[_0x1ca469(0x3a2)][
                              _0x1ca469(0x334) +
                                (_0x4d7d53[_0x1ca469(0x246)][_0x1ca469(0x21a)] -
                                  0x1)
                            ]
                          : _0x4d7d53["$refs"][
                              _0x1ca469(0x270) +
                                (_0x4d7d53[_0x1ca469(0x339)][_0x1ca469(0x21a)] -
                                  0x1)
                            ];
                      if (_0x5ccfb9) {
                        var _0x1fac92 = _0x5ccfb9[0x0];
                        _0x1fac92 &&
                          (_0x4d7d53[_0x1ca469(0x3bb)](_0x1fac92),
                          _0x4d7d53[_0x1ca469(0x207)] > 0x0 &&
                            _0x1fac92[_0x1ca469(0x3f1)]("face")[0x0][
                              _0x1ca469(0x12f)
                            ][_0x1ca469(0x397)]("active")),
                          setTimeout(function () {
                            var _0x5b4132 = _0x1ca469;
                            _0x4d7d53[_0x5b4132(0x3cc)](_0x1fac92),
                              _0x4d7d53[_0x5b4132(0x207)] < 0x2
                                ? ((_0x4d7d53["$refs"][_0x5b4132(0x194)][
                                    _0x5b4132(0x224)
                                  ][_0x5b4132(0x328)] =
                                    0x5 +
                                    2.5 *
                                      (_0x4d7d53[_0x5b4132(0x246)]["length"] -
                                        0x1) +
                                    "em"),
                                  (_0x4d7d53[_0x5b4132(0x3a2)]["playerWrapper"][
                                    _0x5b4132(0x224)
                                  ]["height"] =
                                    7.9 +
                                    0x1 *
                                      (_0x4d7d53[_0x5b4132(0x246)][
                                        _0x5b4132(0x21a)
                                      ] -
                                        0x1) +
                                    "em"),
                                  (_0x4d7d53[_0x5b4132(0x2fe)]["player"] =
                                    _0x4d7d53[_0x5b4132(0x2a9)](
                                      _0x4d7d53["values"]["player"]
                                    )))
                                : ((_0x4d7d53["$refs"]["playerOtherWrapper"][
                                    _0x5b4132(0x224)
                                  ][_0x5b4132(0x328)] =
                                    0x5 +
                                    2.5 *
                                      (_0x4d7d53[_0x5b4132(0x339)][
                                        _0x5b4132(0x21a)
                                      ] -
                                        0x1) +
                                    "em"),
                                  (_0x4d7d53["$refs"][_0x5b4132(0x150)][
                                    _0x5b4132(0x224)
                                  ][_0x5b4132(0x1e5)] =
                                    7.9 +
                                    0x1 *
                                      (_0x4d7d53["playerOtherCards"]["length"] -
                                        0x1) +
                                    "em"),
                                  (_0x4d7d53[_0x5b4132(0x2fe)][
                                    _0x5b4132(0x28c)
                                  ] = _0x4d7d53[_0x5b4132(0x2a9)](
                                    _0x4d7d53["values"][_0x5b4132(0x28c)]
                                  ))),
                              setTimeout(function () {
                                var _0x2b8cf5 = _0x5b4132;
                                _0x4d7d53[_0x2b8cf5(0x24f)](_0x1fac92),
                                  setTimeout(function () {
                                    return _0x4d7d53["checkFinishedAfterHit"](
                                      _0x590535
                                    );
                                  }, 0x190);
                              }, 0x190);
                          }, 0x190);
                      }
                    }
                  });
                },
                moveCard: function (_0x4720b8) {
                  var _0x1f348f = _0x137e9c;
                  document[_0x1f348f(0x3c6)](_0x1f348f(0x180))[
                    _0x1f348f(0x2e6)
                  ](),
                    _0x4720b8 &&
                      (_0x4720b8[_0x1f348f(0x12f)]["add"](_0x1f348f(0x305)),
                      (_0x4720b8[_0x1f348f(0x224)][_0x1f348f(0x318)] =
                        "translate(0px,\x200px)"));
                },
                flipCard: function (_0x1ca0dc) {
                  var _0x143b62 = _0x137e9c;
                  (document[_0x143b62(0x3c6)](_0x143b62(0x156))[
                    _0x143b62(0x2e6)
                  ](),
                  _0x1ca0dc) &&
                    _0x1ca0dc[_0x143b62(0x3f1)](_0x143b62(0x22d))[0x0][
                      _0x143b62(0x12f)
                    ][_0x143b62(0x3cd)](_0x143b62(0x22d));
                },
                flipCardWithoutTransition: function (_0x2d43f6) {
                  var _0x5e01eb = _0x137e9c;
                  if (_0x2d43f6) {
                    var _0x230473 =
                      _0x2d43f6["getElementsByClassName"]("face-down")[0x0];
                    (_0x230473[_0x5e01eb(0x224)][_0x5e01eb(0x3fa)] =
                      _0x5e01eb(0x1c0)),
                      _0x230473[_0x5e01eb(0x12f)][_0x5e01eb(0x3cd)](
                        _0x5e01eb(0x22d)
                      );
                  }
                },
                moveCardToInitPosition: function (_0x4e33e6) {
                  var _0x3ac229 = _0x137e9c;
                  if (_0x4e33e6) {
                    var _0x3b6e51 =
                        this[_0x3ac229(0x178)]["left"] -
                        _0x4e33e6[_0x3ac229(0x1c6)]()[_0x3ac229(0x2bc)],
                      _0x45f299 =
                        this[_0x3ac229(0x178)]["top"] -
                        _0x4e33e6["getBoundingClientRect"]()[_0x3ac229(0x196)];
                    _0x4e33e6["style"]["transform"] = _0x3ac229(0x264)
                      [_0x3ac229(0x174)](_0x3b6e51, "px,\x20")
                      [_0x3ac229(0x174)](_0x45f299, _0x3ac229(0x36f));
                  }
                },
                stand: function () {
                  var _0x489897 = _0x137e9c,
                    _0x261b3a = this;
                  this["setSetdisabled"](!0x0),
                    this[_0x489897(0x3e9)](!0x0),
                    this[_0x489897(0x2d9)](!0x0),
                    this["$repositories"][_0x489897(0x32d)][_0x489897(0x309)]
                      [_0x489897(0x1e0)]({
                        type: _0x489897(0x3fd),
                        id: this[_0x489897(0x3bc)],
                      })
                      [_0x489897(0x190)](function (_0x455189) {
                        var _0x590052 = _0x489897,
                          _0xaf183e = _0x455189["data"][_0x590052(0x38b)],
                          _0xce59ad = _0xaf183e["state"],
                          _0x50ab43 = _0xaf183e[_0x590052(0x2c6)],
                          _0x9774cf = _0xaf183e[_0x590052(0x225)],
                          _0x3b0e06 = _0xaf183e["user"];
                        if (
                          ((_0x261b3a[_0x590052(0x2c6)] = _0x50ab43),
                          (_0x261b3a["firstPack"] = _0x9774cf),
                          (_0x261b3a["userMoney"] =
                            _0x3b0e06[_0x590052(0x19b)]),
                          _0xce59ad["dealer"][0x0][_0x590052(0x333)][
                            _0x590052(0x21a)
                          ] > 0x1 &&
                            (_0x261b3a["dealerCards"] = _0xce59ad[
                              _0x590052(0x204)
                            ][0x0]["cards"][_0x590052(0x37c)](function (
                              _0x5c4420
                            ) {
                              var _0x183627 = _0x590052;
                              return {
                                rank: _0x5c4420["rank"] || "",
                                suit: _0x261b3a[_0x183627(0x12d)](
                                  _0x5c4420[_0x183627(0x148)]
                                ),
                                color: _0x261b3a[_0x183627(0x15e)](
                                  _0x5c4420[_0x183627(0x148)]
                                ),
                                value: _0x5c4420[_0x183627(0x2b2)],
                              };
                            })),
                          (_0x261b3a[_0x590052(0x3ab)][_0x590052(0x204)] =
                            _0xce59ad[_0x590052(0x204)][0x0][_0x590052(0x2b2)]),
                          (_0x261b3a[_0x590052(0x3ab)][_0x590052(0x3df)] =
                            _0xce59ad[_0x590052(0x3df)][0x0][_0x590052(0x2b2)]),
                          (_0x261b3a["actions"][_0x590052(0x204)] =
                            _0xce59ad[_0x590052(0x204)][0x0][_0x590052(0x35c)]),
                          (_0x261b3a[_0x590052(0x35c)]["player"] =
                            _0xce59ad[_0x590052(0x3df)][0x0][_0x590052(0x35c)]),
                          (_0x261b3a[_0x590052(0x2d0)][_0x590052(0x3df)] =
                            _0xce59ad[_0x590052(0x3df)][0x0]["result"]),
                          _0x261b3a["activeHand"] > 0x0 &&
                            ((_0x261b3a[_0x590052(0x2d0)][_0x590052(0x28c)] =
                              _0xce59ad[_0x590052(0x3df)][0x1]["result"]),
                            0x1 == _0x261b3a[_0x590052(0x207)] &&
                              _0x261b3a[_0x590052(0x320)](),
                            0x1 === _0x261b3a[_0x590052(0x1e4)]))
                        )
                          return (
                            _0x261b3a[_0x590052(0x36c)](!0x1),
                            void _0x261b3a[_0x590052(0x3ae)](_0x590052(0x363))
                          );
                        _0x261b3a[_0x590052(0x170)](_0x590052(0x283));
                      })
                      [_0x489897(0x2a3)](function (_0x44676c) {
                        var _0x3e4b3f = _0x489897;
                        _0x261b3a[_0x3e4b3f(0x36c)](!0x1),
                          _0x261b3a["$emit"](_0x3e4b3f(0x363));
                      });
                },
                revealDealerCards: function (_0x1293c6) {
                  var _0x10484c = this;
                  setTimeout(function () {
                    var _0x2fc5e0 = a16_0x269f;
                    if (
                      Object["keys"](_0x10484c[_0x2fc5e0(0x3a2)])[
                        _0x2fc5e0(0x21a)
                      ] > 0x3 &&
                      _0x10484c[_0x2fc5e0(0x3a2)][_0x2fc5e0(0x30e)]
                    ) {
                      var _0x560869 =
                        _0x10484c[_0x2fc5e0(0x3a2)][_0x2fc5e0(0x30e)][0x0];
                      _0x10484c["flipCard"](_0x560869),
                        _0x10484c[_0x2fc5e0(0x392)]["length"] > 0x2
                          ? ((_0x10484c["currentValue"][_0x2fc5e0(0x204)] =
                              _0x10484c["getValueStep"](
                                _0x2fc5e0(0x204),
                                _0x10484c[_0x2fc5e0(0x392)][0x1][
                                  _0x2fc5e0(0x2b2)
                                ]
                              )),
                            _0x10484c[_0x2fc5e0(0x392)][_0x2fc5e0(0x37c)](
                              function (_0x2e9f3f, _0x293464) {
                                var _0x239c2c = _0x2fc5e0;
                                if (!(_0x293464 < 0x2)) {
                                  var _0x468377 =
                                    _0x10484c[_0x239c2c(0x3a2)][
                                      _0x239c2c(0x2e4) + _0x293464
                                    ][0x0];
                                  _0x10484c["moveCardToInitPosition"](
                                    _0x468377
                                  ),
                                    setTimeout(function () {
                                      var _0x128619 = _0x239c2c;
                                      _0x10484c[_0x128619(0x3cc)](_0x468377),
                                        (_0x10484c[_0x128619(0x3a2)][
                                          _0x128619(0x2df)
                                        ]["style"]["width"] =
                                          0x5 + 2.5 * _0x293464 + "em"),
                                        (_0x10484c["$refs"][_0x128619(0x2df)][
                                          "style"
                                        ][_0x128619(0x1e5)] =
                                          7.9 + 0x1 * _0x293464 + "em"),
                                        setTimeout(function () {
                                          var _0x494f91 = _0x128619;
                                          _0x10484c[_0x494f91(0x24f)](
                                            _0x468377
                                          );
                                          var _0x2297bb = _0x10484c[
                                            _0x494f91(0x3fe)
                                          ](
                                            _0x494f91(0x204),
                                            _0x2e9f3f[_0x494f91(0x2b2)]
                                          );
                                          _0x293464 ==
                                          _0x10484c["dealerCards"][
                                            _0x494f91(0x21a)
                                          ] -
                                            0x1
                                            ? ((_0x10484c[_0x494f91(0x2fe)][
                                                "dealer"
                                              ] = _0x10484c[
                                                "getRealValueForShow"
                                              ](
                                                _0x10484c[_0x494f91(0x3ab)][
                                                  "dealer"
                                                ]
                                              )),
                                              setTimeout(function () {
                                                var _0x3058b8 = _0x494f91;
                                                return _0x10484c[
                                                  _0x3058b8(0x377)
                                                ](_0x1293c6);
                                              }, 0x190))
                                            : (_0x10484c[_0x494f91(0x2fe)][
                                                _0x494f91(0x204)
                                              ] = _0x2297bb);
                                        }, 0x190);
                                    }, 0x190 + 0x320 * (_0x293464 - 0x2));
                                }
                              }
                            ))
                          : ((_0x10484c[_0x2fc5e0(0x2fe)]["dealer"] = _0x10484c[
                              _0x2fc5e0(0x2a9)
                            ](_0x10484c[_0x2fc5e0(0x3ab)][_0x2fc5e0(0x204)])),
                            setTimeout(function () {
                              var _0x1506a1 = _0x2fc5e0;
                              return _0x10484c[_0x1506a1(0x377)](_0x1293c6);
                            }, 0x190));
                    }
                  });
                },
                split: function () {
                  var _0xb762f1 = _0x137e9c,
                    _0xa189fa = this;
                  this[_0xb762f1(0x36c)](!0x0),
                    this[_0xb762f1(0x3e9)](!0x0),
                    this[_0xb762f1(0x2d9)](!0x0),
                    this[_0xb762f1(0x32c)][_0xb762f1(0x32d)][
                      "BlackjackRepository"
                    ]
                      ["create"]({
                        type: _0xb762f1(0x2f4),
                        id: this[_0xb762f1(0x3bc)],
                      })
                      [_0xb762f1(0x190)](function (_0x28f522) {
                        var _0xb43665 = _0xb762f1,
                          _0x8a1e8 = _0x28f522["data"][_0xb43665(0x38b)],
                          _0xfc8706 = _0x8a1e8["state"],
                          _0x39d1fa = _0x8a1e8[_0xb43665(0x2c6)],
                          _0x59bb02 = _0x8a1e8[_0xb43665(0x225)],
                          _0x3202eb = _0x8a1e8[_0xb43665(0x3e6)];
                        (_0xa189fa[_0xb43665(0x2c6)] = _0x39d1fa),
                          (_0xa189fa[_0xb43665(0x1e4)] = _0x59bb02),
                          (_0xa189fa[_0xb43665(0x267)] =
                            _0x3202eb[_0xb43665(0x19b)]),
                          (_0xa189fa["playerCards"] = _0xfc8706[
                            _0xb43665(0x3df)
                          ][0x0][_0xb43665(0x333)][_0xb43665(0x37c)](function (
                            _0x53a7c0
                          ) {
                            var _0x2d45cc = _0xb43665;
                            return {
                              rank: _0x53a7c0["rank"] || "",
                              suit: _0xa189fa[_0x2d45cc(0x12d)](
                                _0x53a7c0[_0x2d45cc(0x148)]
                              ),
                              color: _0xa189fa[_0x2d45cc(0x15e)](
                                _0x53a7c0[_0x2d45cc(0x148)]
                              ),
                              value: _0x53a7c0[_0x2d45cc(0x2b2)],
                            };
                          })),
                          (_0xa189fa[_0xb43665(0x339)] = _0xfc8706[
                            _0xb43665(0x3df)
                          ][0x1]["cards"]["map"](function (_0x1fb37a) {
                            var _0x5507c2 = _0xb43665;
                            return {
                              rank: _0x1fb37a[_0x5507c2(0x3d7)] || "",
                              suit: _0xa189fa[_0x5507c2(0x12d)](
                                _0x1fb37a[_0x5507c2(0x148)]
                              ),
                              color: _0xa189fa[_0x5507c2(0x15e)](
                                _0x1fb37a[_0x5507c2(0x148)]
                              ),
                              value: _0x1fb37a[_0x5507c2(0x2b2)],
                            };
                          })),
                          _0xfc8706[_0xb43665(0x204)][0x0][_0xb43665(0x333)][
                            _0xb43665(0x21a)
                          ] > 0x1 &&
                            ((_0xa189fa[_0xb43665(0x392)] = _0xfc8706[
                              _0xb43665(0x204)
                            ][0x0][_0xb43665(0x333)]["map"](function (
                              _0x4be7f2
                            ) {
                              var _0x2440ef = _0xb43665;
                              return {
                                rank: _0x4be7f2["rank"] || "",
                                suit: _0xa189fa[_0x2440ef(0x12d)](
                                  _0x4be7f2[_0x2440ef(0x148)]
                                ),
                                color: _0xa189fa[_0x2440ef(0x15e)](
                                  _0x4be7f2[_0x2440ef(0x148)]
                                ),
                                value: _0x4be7f2[_0x2440ef(0x2b2)],
                              };
                            })),
                            (_0xa189fa[_0xb43665(0x3ab)][_0xb43665(0x204)] =
                              _0xfc8706[_0xb43665(0x204)][0x0][
                                _0xb43665(0x2b2)
                              ]),
                            (_0xa189fa["actions"][_0xb43665(0x204)] =
                              _0xfc8706[_0xb43665(0x204)][0x0][
                                _0xb43665(0x35c)
                              ])),
                          (_0xa189fa[_0xb43665(0x3ab)][_0xb43665(0x3df)] =
                            _0xfc8706[_0xb43665(0x3df)][0x0]["value"]),
                          (_0xa189fa[_0xb43665(0x3ab)]["player1"] =
                            _0xfc8706[_0xb43665(0x3df)][0x1][_0xb43665(0x2b2)]),
                          (_0xa189fa[_0xb43665(0x35c)][_0xb43665(0x3df)] =
                            _0xfc8706[_0xb43665(0x3df)][0x0][_0xb43665(0x35c)]),
                          (_0xa189fa[_0xb43665(0x35c)]["player1"] =
                            _0xfc8706[_0xb43665(0x3df)][0x1]["actions"]),
                          (_0xa189fa["currentValue"][_0xb43665(0x3df)] =
                            _0xa189fa[_0xb43665(0x2a9)](
                              _0xfc8706[_0xb43665(0x3df)][0x0][_0xb43665(0x2b2)]
                            )),
                          (_0xa189fa["currentValue"]["player1"] = _0xa189fa[
                            _0xb43665(0x2a9)
                          ](
                            _0xfc8706["player"][0x1][_0xb43665(0x333)][0x0][
                              _0xb43665(0x2b2)
                            ]
                          )),
                          (_0xa189fa[_0xb43665(0x3c8)][_0xb43665(0x3df)] =
                            0xb ===
                            _0xfc8706["player"][0x0][_0xb43665(0x333)][0x0][
                              _0xb43665(0x2b2)
                            ]
                              ? [0x1, 0xb]
                              : _0xfc8706["player"][0x1][_0xb43665(0x333)][0x0][
                                  _0xb43665(0x2b2)
                                ]),
                          (_0xa189fa[_0xb43665(0x3c8)][_0xb43665(0x28c)] =
                            0xb ===
                            _0xfc8706[_0xb43665(0x3df)][0x1][
                              _0xb43665(0x333)
                            ][0x0][_0xb43665(0x2b2)]
                              ? [0x1, 0xb]
                              : _0xfc8706[_0xb43665(0x3df)][0x1][
                                  _0xb43665(0x333)
                                ][0x0]["value"]),
                          (_0xa189fa["result"][_0xb43665(0x3df)] =
                            _0xfc8706[_0xb43665(0x3df)][0x0]["result"]),
                          (_0xa189fa[_0xb43665(0x2d0)][_0xb43665(0x28c)] =
                            _0xfc8706["player"][0x1]["result"]),
                          _0xa189fa[_0xb43665(0x1b1)]();
                      })
                      [_0xb762f1(0x2a3)](function (_0x5b8e64) {
                        _0xa189fa["setSetdisabled"](!0x1);
                      });
                },
                doSplit: function () {
                  var _0x4f5b5b = this;
                  setTimeout(function () {
                    var _0x58b094 = a16_0x269f;
                    for (var _0x5f1869 in _0x4f5b5b["$refs"])
                      if (
                        _0x58b094(0x391) != _0x5f1869 &&
                        _0x58b094(0x2df) != _0x5f1869 &&
                        _0x58b094(0x194) != _0x5f1869 &&
                        _0x58b094(0x150) != _0x5f1869 &&
                        -0x1 !== _0x5f1869[_0x58b094(0x2c7)](_0x58b094(0x334))
                      ) {
                        var _0x2ea92f =
                          _0x4f5b5b[_0x58b094(0x3a2)][_0x5f1869][0x0];
                        _0x2ea92f &&
                          _0x2ea92f[_0x58b094(0x3f1)]("face")[0x0][
                            _0x58b094(0x12f)
                          ]["add"](_0x58b094(0x2c6));
                      }
                    (_0x4f5b5b["playerValueResult"] = _0x58b094(0x2c6)),
                      (_0x4f5b5b["activeHand"] = 0x1),
                      (_0x4f5b5b[_0x58b094(0x325)] = "none");
                    var _0x2ed5a3 =
                        _0x4f5b5b[_0x58b094(0x3a2)][_0x58b094(0x362)][0x0],
                      _0x459613 = _0x4f5b5b["$refs"][_0x58b094(0x25c)][0x0],
                      _0x4afa16 =
                        _0x4f5b5b[_0x58b094(0x3a2)][_0x58b094(0x353)][0x0];
                    if (_0x4afa16) {
                      var _0x8a654a =
                        _0x4afa16[_0x58b094(0x3f1)]("content")[0x0];
                      (_0x8a654a[_0x58b094(0x224)][_0x58b094(0x3fa)] =
                        _0x58b094(0x1c0)),
                        _0x8a654a[_0x58b094(0x12f)][_0x58b094(0x397)](
                          _0x58b094(0x22d)
                        ),
                        setTimeout(function () {
                          var _0x4aa7b0 = _0x58b094;
                          _0x8a654a[_0x4aa7b0(0x1c5)](
                            _0x4aa7b0(0x224),
                            "width:\x205em;\x20height:\x207.9em;\x20--transition-time:300ms;"
                          ),
                            _0x4f5b5b["flipCard"](_0x4afa16);
                        }, 0x12c);
                    }
                    _0x2ed5a3 &&
                      (_0x2ed5a3[_0x58b094(0x12f)][_0x58b094(0x397)](
                        _0x58b094(0x305)
                      ),
                      _0x4f5b5b[_0x58b094(0x1b3)](_0x2ed5a3)),
                      _0x459613 &&
                        (_0x4f5b5b["moveCardToInitPosition"](_0x459613),
                        setTimeout(function () {
                          var _0xb7120d = _0x58b094;
                          _0x4f5b5b[_0xb7120d(0x3cc)](_0x459613),
                            (_0x4f5b5b[_0xb7120d(0x3a2)]["playerOtherWrapper"][
                              _0xb7120d(0x224)
                            ]["width"] =
                              0x5 +
                              2.5 *
                                (_0x4f5b5b[_0xb7120d(0x339)]["length"] - 0x1) +
                              "em"),
                            (_0x4f5b5b[_0xb7120d(0x3a2)]["playerOtherWrapper"][
                              _0xb7120d(0x224)
                            ][_0xb7120d(0x1e5)] =
                              7.9 +
                              0x1 *
                                (_0x4f5b5b[_0xb7120d(0x339)]["length"] - 0x1) +
                              "em"),
                            setTimeout(function () {
                              var _0x380c92 = _0xb7120d;
                              _0x4f5b5b[_0x380c92(0x24f)](_0x459613),
                                _0x2ed5a3[_0x380c92(0x3f1)](
                                  _0x380c92(0x25d)
                                )[0x0][_0x380c92(0x1c5)](
                                  "style",
                                  _0x380c92(0x2b1)
                                ),
                                (_0x4f5b5b[_0x380c92(0x2fe)][_0x380c92(0x28c)] =
                                  _0x4f5b5b[_0x380c92(0x3fe)](
                                    "player1",
                                    _0x4f5b5b[_0x380c92(0x339)][0x1][
                                      _0x380c92(0x2b2)
                                    ]
                                  )),
                                _0x4f5b5b["checkFinishAfterSplit"]();
                            }, 0x190);
                        }, 0x190));
                  });
                },
                double: function () {
                  var _0x2be90e = _0x137e9c,
                    _0x5b4c16 = this;
                  this["setSetdisabled"](!0x0),
                    this[_0x2be90e(0x3e9)](!0x0),
                    this["setDoubledisabled"](!0x0),
                    this[_0x2be90e(0x32c)][_0x2be90e(0x32d)][
                      "BlackjackRepository"
                    ]
                      ["create"]({
                        type: _0x2be90e(0x259),
                        id: this[_0x2be90e(0x3bc)],
                      })
                      [_0x2be90e(0x190)](function (_0x5a250b) {
                        var _0x2b0528 = _0x2be90e,
                          _0x2246c3 =
                            _0x5a250b[_0x2b0528(0x306)][_0x2b0528(0x38b)],
                          _0xec9086 = _0x2246c3[_0x2b0528(0x311)],
                          _0x2e113f = _0x2246c3[_0x2b0528(0x2c6)],
                          _0x343cb4 = _0x2246c3[_0x2b0528(0x225)],
                          _0x51295b = _0x2246c3[_0x2b0528(0x3e6)];
                        (_0x5b4c16[_0x2b0528(0x2c6)] = _0x2e113f),
                          (_0x5b4c16[_0x2b0528(0x1e4)] = _0x343cb4),
                          (_0x5b4c16[_0x2b0528(0x267)] =
                            _0x51295b[_0x2b0528(0x19b)]),
                          (_0x5b4c16[_0x2b0528(0x246)] = _0xec9086[
                            _0x2b0528(0x3df)
                          ][0x0]["cards"]["map"](function (
                            _0x291eef,
                            _0xdb686b
                          ) {
                            var _0x301701 = _0x2b0528;
                            return {
                              rank: _0x291eef[_0x301701(0x3d7)] || "",
                              value: _0x291eef[_0x301701(0x2b2)],
                              suit: _0x5b4c16[_0x301701(0x12d)](
                                _0x291eef["suit"]
                              ),
                              color: _0x5b4c16[_0x301701(0x15e)](
                                _0x291eef["suit"]
                              ),
                            };
                          })),
                          (_0x5b4c16[_0x2b0528(0x2d0)]["player"] =
                            _0xec9086[_0x2b0528(0x3df)][0x0][_0x2b0528(0x2d0)]),
                          _0x5b4c16[_0x2b0528(0x207)] > 0x1 &&
                            ((_0x5b4c16[_0x2b0528(0x339)] = _0xec9086[
                              _0x2b0528(0x3df)
                            ][0x1][_0x2b0528(0x333)]["map"](function (
                              _0x2023b8,
                              _0x49c29b
                            ) {
                              var _0xa92be7 = _0x2b0528;
                              return {
                                rank: _0x2023b8[_0xa92be7(0x3d7)] || "",
                                value: _0x2023b8[_0xa92be7(0x2b2)],
                                suit: _0x5b4c16["getIconName"](
                                  _0x2023b8[_0xa92be7(0x148)]
                                ),
                                color: _0x5b4c16[_0xa92be7(0x15e)](
                                  _0x2023b8[_0xa92be7(0x148)]
                                ),
                              };
                            })),
                            (_0x5b4c16[_0x2b0528(0x2d0)][_0x2b0528(0x28c)] =
                              _0xec9086[_0x2b0528(0x3df)][0x1]["result"]),
                            (_0x5b4c16["values"]["player1"] =
                              _0xec9086[_0x2b0528(0x3df)][0x1][
                                _0x2b0528(0x2b2)
                              ]),
                            (_0x5b4c16[_0x2b0528(0x35c)][_0x2b0528(0x28c)] =
                              _0xec9086["player"][0x1][_0x2b0528(0x35c)])),
                          _0xec9086[_0x2b0528(0x204)][0x0][_0x2b0528(0x333)][
                            _0x2b0528(0x21a)
                          ] > 0x1 &&
                            ((_0x5b4c16[_0x2b0528(0x392)] = _0xec9086[
                              "dealer"
                            ][0x0]["cards"]["map"](function (
                              _0x52fae1,
                              _0x50080f
                            ) {
                              var _0x62f9cc = _0x2b0528;
                              return {
                                rank: _0x52fae1[_0x62f9cc(0x3d7)] || "",
                                value: _0x52fae1[_0x62f9cc(0x2b2)],
                                suit: _0x5b4c16[_0x62f9cc(0x12d)](
                                  _0x52fae1[_0x62f9cc(0x148)]
                                ),
                                color: _0x5b4c16["getFaceColor"](
                                  _0x52fae1[_0x62f9cc(0x148)]
                                ),
                              };
                            })),
                            (_0x5b4c16["values"]["dealer"] =
                              _0xec9086[_0x2b0528(0x204)][0x0][
                                _0x2b0528(0x2b2)
                              ]),
                            (_0x5b4c16[_0x2b0528(0x35c)]["dealer"] =
                              _0xec9086[_0x2b0528(0x204)][0x0][
                                _0x2b0528(0x35c)
                              ])),
                          (_0x5b4c16[_0x2b0528(0x3ab)][_0x2b0528(0x3df)] =
                            _0xec9086["player"][0x0][_0x2b0528(0x2b2)]),
                          (_0x5b4c16[_0x2b0528(0x35c)][_0x2b0528(0x3df)] =
                            _0xec9086[_0x2b0528(0x3df)][0x0][_0x2b0528(0x35c)]),
                          _0x5b4c16[_0x2b0528(0x3d9)]("Double");
                      });
                },
                sendInsurance: function (_0x5bb1f4) {
                  var _0x3a0f72 = _0x137e9c;
                  this[_0x3a0f72(0x32c)][_0x3a0f72(0x32d)][
                    "BlackjackRepository"
                  ]
                    [_0x3a0f72(0x1e0)]({
                      type: "insurance",
                      id: this[_0x3a0f72(0x3bc)],
                      answer: _0x5bb1f4,
                    })
                    [_0x3a0f72(0x190)](function (_0x30990e) {}),
                    this["$emit"](_0x3a0f72(0x11c));
                },
              }
            ),
            watch: {
              IsStartedBet: function (_0x1d7690) {
                var _0x2bf25c = _0x137e9c;
                _0x1d7690 && this[_0x2bf25c(0x40c)]();
              },
              IsHit: function (_0x3832f9) {
                var _0x410014 = _0x137e9c;
                _0x3832f9 && this[_0x410014(0x35a)]();
              },
              IsStand: function (_0x464fd0) {
                _0x464fd0 && this["stand"]();
              },
              IsSplit: function (_0x45d4f3) {
                var _0x2c6197 = _0x137e9c;
                _0x45d4f3 && this[_0x2c6197(0x2f4)]();
              },
              IsDouble: function (_0x5b6d72) {
                var _0x22cff0 = _0x137e9c;
                _0x5b6d72 && this[_0x22cff0(0x259)]();
              },
              IsInsurance: function (_0x4d06f0) {
                var _0x19d8a9 = _0x137e9c;
                if (!_0x4d06f0) {
                  var _0x59ba58 = Object(_0x117dee["a"])(
                      this[_0x19d8a9(0x35c)][_0x19d8a9(0x3df)]
                    )["pop"](),
                    _0x496910 = Object(_0x117dee["a"])(
                      this["actions"]["dealer"]
                    )[_0x19d8a9(0x242)]();
                  (_0x19d8a9(0x2d3) !== _0x59ba58 &&
                    _0x19d8a9(0x2d3) !== _0x496910) ||
                    this[_0x19d8a9(0x170)](),
                    this["checkFinishedAfterDeal"]();
                }
              },
              acceptInsurance: function (_0x12c6fb) {
                var _0x3e5f74 = _0x137e9c;
                "" != _0x12c6fb && this[_0x3e5f74(0x147)](_0x12c6fb);
              },
              changedAmount: function (_0x3e6044) {
                this["amount"] = _0x3e6044;
              },
            },
          },
          _0x3a7e2e = (_0x354788(0x3db), _0x354788(0x1)),
          _0x317688 = Object(_0x3a7e2e["a"])(
            _0x4e106a,
            function () {
              var _0x597240 = _0x137e9c,
                _0x1605ac,
                _0x80a7b2,
                _0x529f0c,
                _0x53e6e7 = this,
                _0x57554e = _0x53e6e7[_0x597240(0x396)]["_c"];
              return _0x57554e(
                _0x597240(0x393),
                {
                  staticClass: "game-content\x20svelte-1wfq6vq",
                  staticStyle: { "min-height": _0x597240(0x1b4) },
                },
                [
                  _0x57554e(
                    _0x597240(0x126),
                    {
                      staticStyle: {
                        "font-family": "brandon-grotesque",
                        visibility: _0x597240(0x14e),
                      },
                    },
                    [_0x53e6e7["_v"]("_")]
                  ),
                  _0x53e6e7["_v"]("\x20"),
                  _0x53e6e7["_m"](0x0),
                  _0x53e6e7["_v"]("\x20"),
                  _0x53e6e7["_m"](0x1),
                  _0x53e6e7["_v"]("\x20"),
                  _0x53e6e7["_m"](0x2),
                  _0x53e6e7["_v"]("\x20"),
                  _0x53e6e7["_m"](0x3),
                  _0x53e6e7["_v"]("\x20"),
                  _0x57554e(
                    _0x597240(0x393),
                    {
                      staticClass: _0x597240(0x3ce),
                      staticStyle: { "font-size": _0x597240(0x1b9) },
                    },
                    [
                      _0x57554e(
                        _0x597240(0x393),
                        { staticClass: _0x597240(0x27f) },
                        [
                          _0x57554e(
                            _0x597240(0x393),
                            { staticClass: "deck\x20svelte-s5ivtb" },
                            [
                              _0x53e6e7["_l"](0x4, function (_0x46230e) {
                                var _0x293d71 = _0x597240;
                                return _0x57554e(
                                  _0x293d71(0x22c),
                                  {
                                    staticClass: _0x293d71(0x211),
                                    style: {
                                      transform:
                                        _0x293d71(0x3b3) +
                                        (0xc - 0x2 * _0x46230e) +
                                        "%)",
                                    },
                                    attrs: { disabled: "" },
                                  },
                                  [_0x53e6e7["_m"](0x4, !0x0)]
                                );
                              }),
                              _0x53e6e7["_v"]("\x20"),
                              _0x57554e(
                                _0x597240(0x22c),
                                {
                                  ref: _0x597240(0x391),
                                  staticClass: _0x597240(0x211),
                                  staticStyle: { transform: _0x597240(0x389) },
                                  attrs: { disabled: "" },
                                },
                                [_0x53e6e7["_m"](0x5)]
                              ),
                            ],
                            0x2
                          ),
                        ]
                      ),
                      _0x53e6e7["_v"]("\x20"),
                      _0x57554e(
                        _0x597240(0x393),
                        { staticClass: _0x597240(0x19c) },
                        [
                          _0x57554e(
                            _0x597240(0x393),
                            { staticClass: _0x597240(0x330) },
                            [
                              _0x57554e(
                                _0x597240(0x393),
                                {
                                  ref: _0x597240(0x2df),
                                  staticClass: _0x597240(0x2c8),
                                },
                                [
                                  _0x53e6e7["_l"](
                                    _0x53e6e7["dealerCards"],
                                    function (_0x2ab63e, _0x5ca11b) {
                                      var _0x540d1f = _0x597240;
                                      return _0x57554e(
                                        "div",
                                        {
                                          ref: _0x540d1f(0x2e4) + _0x5ca11b,
                                          refInFor: !0x0,
                                          staticClass: _0x540d1f(0x23e),
                                          style: {
                                            marginTop: _0x5ca11b + "em",
                                            marginLeft:
                                              (0x0 == _0x5ca11b
                                                ? "0"
                                                : _0x540d1f(0x380)) + "em",
                                            animationDelay:
                                              0x64 * _0x5ca11b + "ms",
                                            "--muck-transition":
                                              _0x540d1f(0x3da),
                                            transition: _0x540d1f(0x1d6),
                                            transform: "translate(0px,\x200px)",
                                          },
                                        },
                                        [
                                          _0x57554e(_0x540d1f(0x393), [
                                            _0x57554e(
                                              _0x540d1f(0x22c),
                                              {
                                                staticClass:
                                                  "wrap\x20svelte-1wtyksp",
                                                attrs: { disabled: "" },
                                              },
                                              [
                                                _0x57554e(
                                                  _0x540d1f(0x393),
                                                  {
                                                    staticClass:
                                                      _0x540d1f(0x185),
                                                    staticStyle: {
                                                      "--transition-time":
                                                        "300ms",
                                                    },
                                                  },
                                                  [
                                                    _0x57554e(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          _0x540d1f(0x2da),
                                                        staticStyle: {
                                                          width:
                                                            _0x540d1f(0x299),
                                                          height:
                                                            _0x540d1f(0x28b),
                                                          "--transition-time":
                                                            _0x540d1f(0x3da),
                                                        },
                                                      },
                                                      [
                                                        _0x57554e(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "face\x20none\x20svelte-1wtyksp",
                                                          },
                                                          [
                                                            _0x57554e(
                                                              _0x540d1f(0x393),
                                                              {
                                                                staticClass:
                                                                  "face-content\x20svelte-soy9i6",
                                                                style: {
                                                                  color:
                                                                    _0x540d1f(
                                                                      0x41c
                                                                    ) ==
                                                                    _0x2ab63e[
                                                                      _0x540d1f(
                                                                        0x1f5
                                                                      )
                                                                    ]
                                                                      ? "#fe2247"
                                                                      : _0x540d1f(
                                                                          0x2ac
                                                                        ),
                                                                },
                                                              },
                                                              [
                                                                _0x57554e(
                                                                  _0x540d1f(
                                                                    0x126
                                                                  ),
                                                                  [
                                                                    _0x53e6e7[
                                                                      "_v"
                                                                    ](
                                                                      _0x53e6e7[
                                                                        "_s"
                                                                      ](
                                                                        _0x2ab63e[
                                                                          "rank"
                                                                        ]
                                                                      )
                                                                    ),
                                                                  ]
                                                                ),
                                                                _0x53e6e7["_v"](
                                                                  "\x20"
                                                                ),
                                                                _0x57554e(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      icon: _0x2ab63e[
                                                                        _0x540d1f(
                                                                          0x148
                                                                        )
                                                                      ],
                                                                    },
                                                                  }
                                                                ),
                                                              ],
                                                              0x1
                                                            ),
                                                          ]
                                                        ),
                                                        _0x53e6e7["_v"]("\x20"),
                                                        _0x57554e(
                                                          _0x540d1f(0x393),
                                                          {
                                                            staticClass:
                                                              _0x540d1f(0x3f6),
                                                          }
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]),
                                        ]
                                      );
                                    }
                                  ),
                                  _0x53e6e7["_v"]("\x20"),
                                  _0x57554e(
                                    _0x597240(0x393),
                                    {
                                      class:
                                        ((_0x1605ac = { value: !0x0 }),
                                        Object(_0x523c2e["a"])(
                                          _0x1605ac,
                                          _0x53e6e7[_0x597240(0x338)],
                                          !0x0
                                        ),
                                        Object(_0x523c2e["a"])(
                                          _0x1605ac,
                                          _0x597240(0x149),
                                          !0x0
                                        ),
                                        _0x1605ac),
                                    },
                                    [
                                      _0x53e6e7["_v"](
                                        _0x53e6e7["_s"](
                                          _0x53e6e7[_0x597240(0x2fe)]["dealer"]
                                        )
                                      ),
                                    ]
                                  ),
                                ],
                                0x2
                              ),
                            ]
                          ),
                          _0x53e6e7["_v"]("\x20"),
                          _0x57554e("div", { staticClass: _0x597240(0x16d) }, [
                            _0x57554e(
                              _0x597240(0x393),
                              { staticClass: _0x597240(0x406) },
                              [
                                _0x57554e(
                                  "div",
                                  {
                                    ref: _0x597240(0x194),
                                    staticClass: "wrap\x20svelte-n07u8e",
                                  },
                                  [
                                    _0x53e6e7["_l"](
                                      _0x53e6e7[_0x597240(0x246)],
                                      function (_0x49aef5, _0x4c7927) {
                                        var _0x1ed077 = _0x597240;
                                        return _0x57554e(
                                          _0x1ed077(0x393),
                                          {
                                            ref: _0x1ed077(0x334) + _0x4c7927,
                                            refInFor: !0x0,
                                            staticClass: _0x1ed077(0x23e),
                                            style: {
                                              marginTop: _0x4c7927 + "em",
                                              marginLeft:
                                                (0x0 == _0x4c7927
                                                  ? "0"
                                                  : "-2.5") + "em",
                                              animationDelay:
                                                0x64 * _0x4c7927 + "ms",
                                              "--muck-transition": "300ms",
                                              transition:
                                                "transform\x20400ms\x20ease\x200s",
                                              transform: _0x1ed077(0x352),
                                            },
                                          },
                                          [
                                            _0x57554e(_0x1ed077(0x393), [
                                              _0x57554e(
                                                _0x1ed077(0x22c),
                                                {
                                                  staticClass: _0x1ed077(0x211),
                                                  attrs: { disabled: "" },
                                                },
                                                [
                                                  _0x57554e(
                                                    _0x1ed077(0x393),
                                                    {
                                                      staticClass:
                                                        _0x1ed077(0x185),
                                                      staticStyle: {
                                                        "--transition-time":
                                                          _0x1ed077(0x3da),
                                                      },
                                                    },
                                                    [
                                                      _0x57554e(
                                                        _0x1ed077(0x393),
                                                        {
                                                          staticClass:
                                                            _0x1ed077(0x2da),
                                                          staticStyle: {
                                                            width:
                                                              _0x1ed077(0x299),
                                                            height:
                                                              _0x1ed077(0x28b),
                                                            "--transition-time":
                                                              _0x1ed077(0x3da),
                                                          },
                                                        },
                                                        [
                                                          _0x57554e(
                                                            _0x1ed077(0x393),
                                                            {
                                                              staticClass:
                                                                _0x1ed077(
                                                                  0x11d
                                                                ),
                                                            },
                                                            [
                                                              _0x57554e(
                                                                _0x1ed077(
                                                                  0x393
                                                                ),
                                                                {
                                                                  staticClass:
                                                                    _0x1ed077(
                                                                      0x332
                                                                    ),
                                                                  style: {
                                                                    color:
                                                                      _0x1ed077(
                                                                        0x41c
                                                                      ) ==
                                                                      _0x49aef5[
                                                                        _0x1ed077(
                                                                          0x1f5
                                                                        )
                                                                      ]
                                                                        ? _0x1ed077(
                                                                            0x2f9
                                                                          )
                                                                        : "#1a2c38",
                                                                  },
                                                                },
                                                                [
                                                                  _0x57554e(
                                                                    _0x1ed077(
                                                                      0x126
                                                                    ),
                                                                    [
                                                                      _0x53e6e7[
                                                                        "_v"
                                                                      ](
                                                                        _0x53e6e7[
                                                                          "_s"
                                                                        ](
                                                                          _0x49aef5[
                                                                            "rank"
                                                                          ]
                                                                        )
                                                                      ),
                                                                    ]
                                                                  ),
                                                                  _0x53e6e7[
                                                                    "_v"
                                                                  ]("\x20"),
                                                                  _0x57554e(
                                                                    _0x1ed077(
                                                                      0x3ba
                                                                    ),
                                                                    {
                                                                      attrs: {
                                                                        icon: _0x49aef5[
                                                                          _0x1ed077(
                                                                            0x148
                                                                          )
                                                                        ],
                                                                      },
                                                                    }
                                                                  ),
                                                                ],
                                                                0x1
                                                              ),
                                                            ]
                                                          ),
                                                          _0x53e6e7["_v"](
                                                            "\x20"
                                                          ),
                                                          _0x57554e(
                                                            _0x1ed077(0x393),
                                                            {
                                                              staticClass:
                                                                _0x1ed077(
                                                                  0x3f6
                                                                ),
                                                            }
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]),
                                          ]
                                        );
                                      }
                                    ),
                                    _0x53e6e7["_v"]("\x20"),
                                    _0x57554e(
                                      _0x597240(0x393),
                                      {
                                        class:
                                          ((_0x80a7b2 = { value: !0x0 }),
                                          Object(_0x523c2e["a"])(
                                            _0x80a7b2,
                                            _0x53e6e7[_0x597240(0x2e0)],
                                            !0x0
                                          ),
                                          Object(_0x523c2e["a"])(
                                            _0x80a7b2,
                                            _0x597240(0x149),
                                            !0x0
                                          ),
                                          _0x80a7b2),
                                      },
                                      [
                                        _0x53e6e7["_v"](
                                          _0x53e6e7["_s"](
                                            _0x53e6e7[_0x597240(0x2fe)][
                                              _0x597240(0x3df)
                                            ]
                                          )
                                        ),
                                      ]
                                    ),
                                  ],
                                  0x2
                                ),
                                _0x53e6e7["_v"]("\x20"),
                                0x1 === _0x53e6e7[_0x597240(0x207)]
                                  ? _0x57554e(_0x597240(0x3ba), {
                                      staticStyle: {
                                        "font-size": _0x597240(0x290),
                                        position: "absolute",
                                        left: _0x597240(0x357),
                                        color: _0x597240(0x286),
                                        padding: _0x597240(0x2f7),
                                      },
                                      attrs: { icon: _0x597240(0x1bf) },
                                    })
                                  : _0x53e6e7["_e"](),
                                _0x53e6e7["_v"]("\x20"),
                                0x1 === _0x53e6e7[_0x597240(0x207)]
                                  ? _0x57554e(_0x597240(0x3ba), {
                                      staticStyle: {
                                        "font-size": _0x597240(0x290),
                                        position: "absolute",
                                        right: "100%",
                                        color: _0x597240(0x286),
                                        padding: _0x597240(0x2f7),
                                      },
                                      attrs: { icon: _0x597240(0x2a6) },
                                    })
                                  : _0x53e6e7["_e"](),
                              ],
                              0x1
                            ),
                            _0x53e6e7["_v"]("\x20"),
                            _0x53e6e7[_0x597240(0x339)][_0x597240(0x21a)] > 0x0
                              ? _0x57554e(
                                  _0x597240(0x393),
                                  { staticClass: "hand-wrap\x20svelte-eq0hy3" },
                                  [
                                    _0x57554e(
                                      _0x597240(0x393),
                                      {
                                        ref: _0x597240(0x150),
                                        staticClass: "wrap\x20svelte-n07u8e",
                                      },
                                      [
                                        _0x53e6e7["_l"](
                                          _0x53e6e7[_0x597240(0x339)],
                                          function (_0x52c28d, _0xb89cfb) {
                                            var _0x467500 = _0x597240;
                                            return _0x57554e(
                                              _0x467500(0x393),
                                              {
                                                ref:
                                                  _0x467500(0x270) + _0xb89cfb,
                                                refInFor: !0x0,
                                                staticClass: _0x467500(0x23e),
                                                style: {
                                                  marginTop: _0xb89cfb + "em",
                                                  marginLeft:
                                                    (0x0 == _0xb89cfb
                                                      ? "0"
                                                      : "-2.5") + "em",
                                                  animationDelay:
                                                    0x64 * _0xb89cfb + "ms",
                                                  "--muck-transition": "300ms",
                                                  transition:
                                                    "transform\x20400ms\x20ease\x200s",
                                                  transform: _0x467500(0x352),
                                                },
                                              },
                                              [
                                                _0x57554e(_0x467500(0x393), [
                                                  _0x57554e(
                                                    _0x467500(0x22c),
                                                    {
                                                      staticClass:
                                                        _0x467500(0x211),
                                                      attrs: { disabled: "" },
                                                    },
                                                    [
                                                      _0x57554e(
                                                        _0x467500(0x393),
                                                        {
                                                          staticClass:
                                                            _0x467500(0x185),
                                                          staticStyle: {
                                                            "--transition-time":
                                                              _0x467500(0x3da),
                                                          },
                                                        },
                                                        [
                                                          _0x57554e(
                                                            _0x467500(0x393),
                                                            {
                                                              staticClass:
                                                                _0x467500(
                                                                  0x2da
                                                                ),
                                                              staticStyle: {
                                                                width:
                                                                  _0x467500(
                                                                    0x299
                                                                  ),
                                                                height: "7.9em",
                                                                "--transition-time":
                                                                  _0x467500(
                                                                    0x3da
                                                                  ),
                                                              },
                                                            },
                                                            [
                                                              _0x57554e(
                                                                _0x467500(
                                                                  0x393
                                                                ),
                                                                {
                                                                  staticClass:
                                                                    _0x467500(
                                                                      0x11d
                                                                    ),
                                                                },
                                                                [
                                                                  _0x57554e(
                                                                    _0x467500(
                                                                      0x393
                                                                    ),
                                                                    {
                                                                      staticClass:
                                                                        _0x467500(
                                                                          0x332
                                                                        ),
                                                                      style: {
                                                                        color:
                                                                          "red" ==
                                                                          _0x52c28d[
                                                                            _0x467500(
                                                                              0x1f5
                                                                            )
                                                                          ]
                                                                            ? _0x467500(
                                                                                0x2f9
                                                                              )
                                                                            : "#1a2c38",
                                                                      },
                                                                    },
                                                                    [
                                                                      _0x57554e(
                                                                        _0x467500(
                                                                          0x126
                                                                        ),
                                                                        [
                                                                          _0x53e6e7[
                                                                            "_v"
                                                                          ](
                                                                            _0x53e6e7[
                                                                              "_s"
                                                                            ](
                                                                              _0x52c28d[
                                                                                _0x467500(
                                                                                  0x3d7
                                                                                )
                                                                              ]
                                                                            )
                                                                          ),
                                                                        ]
                                                                      ),
                                                                      _0x53e6e7[
                                                                        "_v"
                                                                      ]("\x20"),
                                                                      _0x57554e(
                                                                        _0x467500(
                                                                          0x3ba
                                                                        ),
                                                                        {
                                                                          attrs:
                                                                            {
                                                                              icon: _0x52c28d[
                                                                                _0x467500(
                                                                                  0x148
                                                                                )
                                                                              ],
                                                                            },
                                                                        }
                                                                      ),
                                                                    ],
                                                                    0x1
                                                                  ),
                                                                ]
                                                              ),
                                                              _0x53e6e7["_v"](
                                                                "\x20"
                                                              ),
                                                              _0x57554e(
                                                                _0x467500(
                                                                  0x393
                                                                ),
                                                                {
                                                                  staticClass:
                                                                    "back\x20svelte-1wtyksp",
                                                                }
                                                              ),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ]
                                            );
                                          }
                                        ),
                                        _0x53e6e7["_v"]("\x20"),
                                        _0x57554e(
                                          "div",
                                          {
                                            class:
                                              ((_0x529f0c = { value: !0x0 }),
                                              Object(_0x523c2e["a"])(
                                                _0x529f0c,
                                                _0x53e6e7[_0x597240(0x325)],
                                                !0x0
                                              ),
                                              Object(_0x523c2e["a"])(
                                                _0x529f0c,
                                                _0x597240(0x149),
                                                !0x0
                                              ),
                                              _0x529f0c),
                                          },
                                          [
                                            _0x53e6e7["_v"](
                                              _0x53e6e7["_s"](
                                                _0x53e6e7[_0x597240(0x2fe)][
                                                  _0x597240(0x28c)
                                                ]
                                              )
                                            ),
                                          ]
                                        ),
                                      ],
                                      0x2
                                    ),
                                    _0x53e6e7["_v"]("\x20"),
                                    0x2 === _0x53e6e7["activeHand"]
                                      ? _0x57554e(_0x597240(0x3ba), {
                                          staticStyle: {
                                            "font-size": _0x597240(0x290),
                                            position: _0x597240(0x37d),
                                            left: _0x597240(0x357),
                                            color: _0x597240(0x286),
                                            padding: _0x597240(0x2f7),
                                          },
                                          attrs: { icon: _0x597240(0x1bf) },
                                        })
                                      : _0x53e6e7["_e"](),
                                    _0x53e6e7["_v"]("\x20"),
                                    0x2 === _0x53e6e7[_0x597240(0x207)]
                                      ? _0x57554e("v-icon", {
                                          staticStyle: {
                                            "font-size": "2em",
                                            position: _0x597240(0x37d),
                                            right: _0x597240(0x357),
                                            color: _0x597240(0x286),
                                            padding: _0x597240(0x2f7),
                                          },
                                          attrs: { icon: _0x597240(0x2a6) },
                                        })
                                      : _0x53e6e7["_e"](),
                                  ],
                                  0x1
                                )
                              : _0x53e6e7["_e"](),
                          ]),
                        ]
                      ),
                    ]
                  ),
                ]
              );
            },
            _0x4055a5,
            !0x1,
            null,
            _0x137e9c(0x3c3),
            null
          );
        _0x8033f4["a"] = _0x317688[_0x137e9c(0x13e)];
      },
      0x1fd: function (_0x506c14, _0x3afe39, _0x301b07) {
        "use strict";
        var _0x11effb = a16_0x295903;
        _0x301b07(0xc),
          _0x301b07(0xa),
          _0x301b07(0xb),
          _0x301b07(0x8),
          _0x301b07(0x10),
          _0x301b07(0xd),
          _0x301b07(0x11);
        var _0x1ed97c = _0x301b07(0x2),
          _0x2a951f = _0x301b07(0x3);
        function _0x1ee9ee(_0x961611, _0xcbde1f) {
          var _0x2250a7 = a16_0x269f,
            _0x2aa90e = Object["keys"](_0x961611);
          if (Object["getOwnPropertySymbols"]) {
            var _0x2ff258 = Object["getOwnPropertySymbols"](_0x961611);
            _0xcbde1f &&
              (_0x2ff258 = _0x2ff258[_0x2250a7(0x1db)](function (_0x436879) {
                return Object["getOwnPropertyDescriptor"](
                  _0x961611,
                  _0x436879
                )["enumerable"];
              })),
              _0x2aa90e[_0x2250a7(0x22a)][_0x2250a7(0x143)](
                _0x2aa90e,
                _0x2ff258
              );
          }
          return _0x2aa90e;
        }
        var _0x2f3b69 = {
            name: "VBetslipCard",
            props: {
              value: { type: Boolean },
              isStartedBet: { type: Boolean },
            },
            data: function () {
              return {
                settingForm: { amounts: null },
                active: "active",
                loading: !0x1,
                quickAmount: 0x2710,
              };
            },
            computed: (function (_0x3790ef) {
              var _0x180aef = a16_0x269f;
              for (
                var _0x35c26f = 0x1;
                _0x35c26f < arguments[_0x180aef(0x21a)];
                _0x35c26f++
              ) {
                var _0x1172f4 =
                  null != arguments[_0x35c26f] ? arguments[_0x35c26f] : {};
                _0x35c26f % 0x2
                  ? _0x1ee9ee(Object(_0x1172f4), !0x0)[_0x180aef(0x160)](
                      function (_0x37be38) {
                        Object(_0x1ed97c["a"])(
                          _0x3790ef,
                          _0x37be38,
                          _0x1172f4[_0x37be38]
                        );
                      }
                    )
                  : Object["getOwnPropertyDescriptors"]
                  ? Object["defineProperties"](
                      _0x3790ef,
                      Object["getOwnPropertyDescriptors"](_0x1172f4)
                    )
                  : _0x1ee9ee(Object(_0x1172f4))[_0x180aef(0x160)](function (
                      _0x4a2d68
                    ) {
                      Object["defineProperty"](
                        _0x3790ef,
                        _0x4a2d68,
                        Object["getOwnPropertyDescriptor"](_0x1172f4, _0x4a2d68)
                      );
                    });
              }
              return _0x3790ef;
            })(
              {},
              Object(_0x2a951f["c"])(_0x11effb(0x125), [
                _0x11effb(0x371),
                "getSetdisabled",
                _0x11effb(0x280),
                _0x11effb(0x346),
                _0x11effb(0x213),
                "getButtonInfo",
              ])
            ),
            methods: {
              clear: function () {
                var _0x35f25f = _0x11effb;
                (this[_0x35f25f(0x2e5)][_0x35f25f(0x191)] = null),
                  this[_0x35f25f(0x1f7)]();
              },
              up: function () {
                var _0x35af0d = _0x11effb;
                (this["settingForm"]["amounts"] += this[_0x35af0d(0x345)]),
                  this["changedAmount"]();
              },
              down: function () {
                var _0x58df39 = _0x11effb;
                this[_0x58df39(0x2e5)]["amounts"] > this[_0x58df39(0x345)]
                  ? (this[_0x58df39(0x2e5)][_0x58df39(0x191)] -=
                      this[_0x58df39(0x345)])
                  : (this[_0x58df39(0x2e5)]["amounts"] = null),
                  this["changedAmount"]();
              },
              startBet: function (_0x5e8314) {
                var _0x2f52cb = _0x11effb;
                _0x5e8314[_0x2f52cb(0x3e1)](),
                  this[_0x2f52cb(0x3ae)]("startBet");
              },
              skipCard: function () {
                var _0x3870b8 = _0x11effb;
                this[_0x3870b8(0x3ae)](_0x3870b8(0x133));
              },
              topGuess: function () {
                this["$emit"]("top");
              },
              bottomGuess: function () {
                var _0x3cb388 = _0x11effb;
                this[_0x3cb388(0x3ae)](_0x3cb388(0x3c2));
              },
              cashout: function () {
                var _0xe87f77 = _0x11effb;
                this["$emit"](_0xe87f77(0x291));
              },
              changedAmount: function () {
                var _0x5758f0 = _0x11effb;
                this["$emit"](
                  _0x5758f0(0x1f7),
                  this[_0x5758f0(0x2e5)][_0x5758f0(0x191)]
                );
              },
            },
          },
          _0x459900 = _0x2f3b69,
          _0x30bd8b = (_0x301b07(0x404), _0x301b07(0x1)),
          _0x8d848 = Object(_0x30bd8b["a"])(
            _0x459900,
            function () {
              var _0x53e971 = _0x11effb,
                _0x53da03 = this,
                _0x37a99f = _0x53da03["_self"]["_c"];
              return _0x37a99f(
                _0x53e971(0x1b8),
                { staticClass: _0x53e971(0x3cf) },
                [
                  _0x37a99f(
                    _0x53e971(0x1e2),
                    { staticClass: _0x53e971(0x25d) },
                    [
                      _0x53da03[_0x53e971(0x2d8)][_0x53e971(0x266)]
                        ? _0x37a99f(
                            _0x53e971(0x1b8),
                            { staticClass: _0x53e971(0x17b) },
                            [
                              _0x37a99f(_0x53e971(0x1da), {
                                scopedSlots: _0x53da03["_u"](
                                  [
                                    {
                                      key: _0x53e971(0x3fb),
                                      fn: function (_0x425d1c) {
                                        var _0x4e29f6 = _0x53e971,
                                          _0xf47656 = _0x425d1c["on"];
                                        return [
                                          _0x37a99f(
                                            _0x4e29f6(0x33d),
                                            _0x53da03["_g"](
                                              { attrs: { text: "" } },
                                              _0xf47656
                                            ),
                                            [
                                              _0x37a99f(_0x4e29f6(0x275), [
                                                _0x53da03["_v"](
                                                  _0x4e29f6(0x25f)
                                                ),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                        ];
                                      },
                                    },
                                  ],
                                  null,
                                  !0x1,
                                  0xc181b458
                                ),
                              }),
                            ],
                            0x1
                          )
                        : _0x53da03["_e"](),
                      _0x53da03["_v"]("\x20"),
                      _0x37a99f(
                        _0x53e971(0x1e2),
                        { staticClass: "betslip-form" },
                        [
                          _0x37a99f(
                            "v-column",
                            { staticClass: "amount" },
                            [
                              _0x53da03[_0x53e971(0x2d8)][_0x53e971(0x266)]
                                ? _0x37a99f(
                                    _0x53e971(0x1b8),
                                    { staticClass: _0x53e971(0x3c4) },
                                    [
                                      _0x37a99f(
                                        _0x53e971(0x1b8),
                                        { staticClass: _0x53e971(0x217) },
                                        [
                                          _0x37a99f(_0x53e971(0x275), [
                                            _0x53da03["_v"](_0x53e971(0x410)),
                                          ]),
                                        ],
                                        0x1
                                      ),
                                      _0x53da03["_v"]("\x20"),
                                      _0x37a99f(
                                        "v-row",
                                        { staticClass: "count" },
                                        [
                                          _0x37a99f(_0x53e971(0x275), [
                                            _0x53da03["_v"](
                                              _0x53da03["_s"](
                                                parseInt(
                                                  _0x53da03[_0x53e971(0x2d8)][
                                                    _0x53e971(0x3e6)
                                                  ][_0x53e971(0x15f)]
                                                )[_0x53e971(0x1fc)]()
                                              )
                                            ),
                                          ]),
                                        ],
                                        0x1
                                      ),
                                    ],
                                    0x1
                                  )
                                : _0x53da03["_e"](),
                              _0x53da03["_v"]("\x20"),
                              _0x37a99f(
                                _0x53e971(0x1b8),
                                [
                                  _0x37a99f("v-text", [
                                    _0x53da03["_v"](_0x53e971(0x1f4)),
                                  ]),
                                ],
                                0x1
                              ),
                              _0x53da03["_v"]("\x20"),
                              _0x37a99f(
                                _0x53e971(0x1b8),
                                { staticClass: _0x53e971(0x248) },
                                [
                                  _0x37a99f(
                                    _0x53e971(0x1b8),
                                    { staticClass: "cash-updown" },
                                    [
                                      _0x37a99f(
                                        _0x53e971(0x33d),
                                        {
                                          staticClass: _0x53e971(0x2ad),
                                          attrs: {
                                            disabled:
                                              _0x53da03["getBetdisabled"],
                                          },
                                          on: {
                                            click: function (_0x3333b1) {
                                              var _0x10bd32 = _0x53e971;
                                              return _0x53da03[
                                                _0x10bd32(0x2ad)
                                              ]();
                                            },
                                          },
                                        },
                                        [
                                          _0x37a99f(_0x53e971(0x3ba), {
                                            staticClass: _0x53e971(0x234),
                                            attrs: { icon: _0x53e971(0x1f6) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x53da03["_v"]("\x20"),
                                      _0x37a99f(
                                        _0x53e971(0x33d),
                                        {
                                          staticClass: "up",
                                          attrs: {
                                            disabled:
                                              _0x53da03[_0x53e971(0x280)],
                                          },
                                          on: {
                                            click: function (_0x1f7f2a) {
                                              return _0x53da03["up"]();
                                            },
                                          },
                                        },
                                        [
                                          _0x37a99f(_0x53e971(0x3ba), {
                                            staticClass: "margin-right-0",
                                            attrs: { icon: _0x53e971(0x223) },
                                          }),
                                        ],
                                        0x1
                                      ),
                                    ],
                                    0x1
                                  ),
                                  _0x53da03["_v"]("\x20"),
                                  _0x37a99f(_0x53e971(0x1c7), {
                                    attrs: {
                                      placeholder: _0x53e971(0x1ba),
                                      disabled: _0x53da03[_0x53e971(0x280)],
                                      "number-format": !0x0,
                                    },
                                    on: { input: _0x53da03[_0x53e971(0x1f7)] },
                                    model: {
                                      value:
                                        _0x53da03[_0x53e971(0x2e5)][
                                          _0x53e971(0x191)
                                        ],
                                      callback: function (_0x190e76) {
                                        var _0x29cd78 = _0x53e971;
                                        _0x53da03["$set"](
                                          _0x53da03[_0x29cd78(0x2e5)],
                                          _0x29cd78(0x191),
                                          _0x190e76
                                        );
                                      },
                                      expression: _0x53e971(0x3f4),
                                    },
                                  }),
                                  _0x53da03["_v"]("\x20"),
                                  _0x37a99f(
                                    _0x53e971(0x33d),
                                    {
                                      staticClass: _0x53e971(0x2ce),
                                      attrs: {
                                        disabled: _0x53da03[_0x53e971(0x280)],
                                      },
                                      on: {
                                        click: function (_0x3977d0) {
                                          var _0x52ce34 = _0x53e971;
                                          return _0x53da03[_0x52ce34(0x374)]();
                                        },
                                      },
                                    },
                                    [
                                      _0x37a99f(_0x53e971(0x3ba), {
                                        staticClass: _0x53e971(0x234),
                                        attrs: { icon: _0x53e971(0x384) },
                                      }),
                                    ],
                                    0x1
                                  ),
                                ],
                                0x1
                              ),
                            ],
                            0x1
                          ),
                        ],
                        0x1
                      ),
                      _0x53da03["_v"]("\x20"),
                      _0x37a99f(
                        "v-column",
                        { staticClass: _0x53e971(0x29a) },
                        [
                          _0x37a99f(
                            _0x53e971(0x33d),
                            {
                              attrs: { disabled: _0x53da03["getSetdisabled"] },
                              on: { click: _0x53da03["topGuess"] },
                            },
                            [
                              _0x37a99f("v-text", [
                                _0x53da03["_v"](
                                  _0x53da03["_s"](
                                    _0x53da03[_0x53e971(0x1b5)][
                                      _0x53e971(0x196)
                                    ][_0x53e971(0x12b)]
                                  )
                                ),
                              ]),
                              _0x53da03["_v"]("\x20"),
                              _0x37a99f(
                                "v-text",
                                { staticClass: _0x53e971(0x19e) },
                                [
                                  _0x37a99f(
                                    "v-text",
                                    { attrs: { color: _0x53e971(0x279) } },
                                    [
                                      _0x37a99f(_0x53e971(0x3ba), {
                                        staticClass: _0x53e971(0x13c),
                                        attrs: { icon: "fa-solid\x20fa-up" },
                                      }),
                                    ],
                                    0x1
                                  ),
                                  _0x53da03["_v"]("\x20"),
                                  _0x37a99f(_0x53e971(0x275), [
                                    _0x53da03["_v"](
                                      _0x53da03["_s"](
                                        _0x53da03[_0x53e971(0x1b5)][
                                          _0x53e971(0x196)
                                        ][_0x53e971(0x399)]
                                      )
                                    ),
                                  ]),
                                ],
                                0x1
                              ),
                            ],
                            0x1
                          ),
                          _0x53da03["_v"]("\x20"),
                          _0x37a99f(
                            "v-button",
                            {
                              attrs: { disabled: _0x53da03[_0x53e971(0x285)] },
                              on: { click: _0x53da03[_0x53e971(0x2b4)] },
                            },
                            [
                              _0x37a99f(_0x53e971(0x275), [
                                _0x53da03["_v"](
                                  _0x53da03["_s"](
                                    _0x53da03[_0x53e971(0x1b5)][
                                      _0x53e971(0x3c2)
                                    ][_0x53e971(0x12b)]
                                  )
                                ),
                              ]),
                              _0x53da03["_v"]("\x20"),
                              _0x37a99f(
                                _0x53e971(0x275),
                                { staticClass: _0x53e971(0x19e) },
                                [
                                  _0x37a99f(
                                    _0x53e971(0x275),
                                    { attrs: { color: "#4ca4ff" } },
                                    [
                                      _0x37a99f(_0x53e971(0x3ba), {
                                        staticClass: "margin-right-5",
                                        attrs: { icon: _0x53e971(0x26f) },
                                      }),
                                    ],
                                    0x1
                                  ),
                                  _0x53da03["_v"]("\x20"),
                                  _0x37a99f("v-text", [
                                    _0x53da03["_v"](
                                      _0x53da03["_s"](
                                        _0x53da03[_0x53e971(0x1b5)][
                                          _0x53e971(0x3c2)
                                        ][_0x53e971(0x399)]
                                      )
                                    ),
                                  ]),
                                ],
                                0x1
                              ),
                            ],
                            0x1
                          ),
                          _0x53da03["_v"]("\x20"),
                          _0x37a99f(
                            _0x53e971(0x33d),
                            {
                              attrs: { disabled: _0x53da03[_0x53e971(0x213)] },
                              on: { click: _0x53da03["skipCard"] },
                            },
                            [
                              _0x37a99f(_0x53e971(0x275), [
                                _0x53da03["_v"](_0x53e971(0x2cf)),
                              ]),
                              _0x53da03["_v"]("\x20"),
                              _0x37a99f(
                                "v-text",
                                { staticClass: _0x53e971(0x19e) },
                                [
                                  _0x37a99f(_0x53e971(0x3ba), {
                                    attrs: { icon: _0x53e971(0x3d0) },
                                  }),
                                ],
                                0x1
                              ),
                            ],
                            0x1
                          ),
                          _0x53da03["_v"]("\x20"),
                          _0x53da03[_0x53e971(0x2dd)]
                            ? _0x37a99f(
                                _0x53e971(0x33d),
                                {
                                  attrs: {
                                    disabled: _0x53da03[_0x53e971(0x346)],
                                  },
                                  on: { click: _0x53da03[_0x53e971(0x291)] },
                                },
                                [
                                  _0x37a99f("v-text", [
                                    _0x53da03["_v"](_0x53e971(0x179)),
                                  ]),
                                ],
                                0x1
                              )
                            : _0x53da03["_e"](),
                        ],
                        0x1
                      ),
                      _0x53da03["_v"]("\x20"),
                      _0x37a99f(
                        _0x53e971(0x1e2),
                        { staticClass: _0x53e971(0x17c) },
                        [
                          _0x37a99f(
                            _0x53e971(0x33d),
                            {
                              attrs: { disabled: _0x53da03[_0x53e971(0x280)] },
                              on: { click: _0x53da03[_0x53e971(0x1cc)] },
                            },
                            [
                              _0x37a99f(_0x53e971(0x275), [
                                _0x53da03["_v"]("베팅하기"),
                              ]),
                            ],
                            0x1
                          ),
                        ],
                        0x1
                      ),
                    ],
                    0x1
                  ),
                ],
                0x1
              );
            },
            [],
            !0x1,
            null,
            _0x11effb(0x251),
            null
          );
        _0x3afe39["a"] = _0x8d848[_0x11effb(0x13e)];
      },
      0x1fe: function (_0x4a2228, _0x2abb9c, _0x2f40a9) {
        "use strict";
        var _0x5b07a8 = a16_0x295903;
        var _0x29dcfc = _0x2f40a9(0x2),
          _0x2a4c30 =
            (_0x2f40a9(0x39),
            [
              function () {
                var _0x19b730 = a16_0x269f,
                  _0x2cace0 = this[_0x19b730(0x396)]["_c"];
                return _0x2cace0("audio", { attrs: { id: _0x19b730(0x40d) } }, [
                  _0x2cace0(_0x19b730(0x1d9), {
                    attrs: { src: _0x19b730(0x30b), type: "audio/mpeg" },
                  }),
                ]);
              },
              function () {
                var _0x4ef025 = a16_0x269f,
                  _0x37a88b = this[_0x4ef025(0x396)]["_c"];
                return _0x37a88b(
                  _0x4ef025(0x366),
                  { attrs: { id: "audio-flip" } },
                  [
                    _0x37a88b("source", {
                      attrs: { src: _0x2f40a9(0x406), type: _0x4ef025(0x35e) },
                    }),
                  ]
                );
              },
              function () {
                var _0x1e9846 = a16_0x269f,
                  _0x4a4ac0 = this[_0x1e9846(0x396)]["_c"];
                return _0x4a4ac0(
                  _0x1e9846(0x366),
                  { attrs: { id: "audio-click" } },
                  [
                    _0x4a4ac0(_0x1e9846(0x1d9), {
                      attrs: { src: _0x1e9846(0x20f), type: _0x1e9846(0x35e) },
                    }),
                  ]
                );
              },
              function () {
                var _0x4c07c9 = a16_0x269f,
                  _0x2a2e9c = this[_0x4c07c9(0x396)]["_c"];
                return _0x2a2e9c("audio", { attrs: { id: _0x4c07c9(0x1e3) } }, [
                  _0x2a2e9c("source", {
                    attrs: { src: _0x2f40a9(0x407), type: "audio/mpeg" },
                  }),
                ]);
              },
              function () {
                var _0x19b29c = a16_0x269f,
                  _0xc5961c = this["_self"]["_c"];
                return _0xc5961c(
                  _0x19b29c(0x366),
                  { attrs: { id: _0x19b29c(0x407) } },
                  [
                    _0xc5961c("source", {
                      attrs: { src: _0x2f40a9(0x408), type: "audio/mpeg" },
                    }),
                  ]
                );
              },
              function () {
                var _0x385f72 = a16_0x269f,
                  _0x41d3f6 = this[_0x385f72(0x396)]["_c"];
                return _0x41d3f6(
                  "div",
                  {
                    staticClass: "horizontal\x20stake-1wtyksp",
                    staticStyle: { "--transition-time": _0x385f72(0x3da) },
                  },
                  [
                    _0x41d3f6(
                      _0x385f72(0x393),
                      {
                        staticClass: _0x385f72(0x16b),
                        staticStyle: {
                          width: "5em",
                          height: _0x385f72(0x28b),
                          "--transition-time": _0x385f72(0x3da),
                        },
                      },
                      [
                        _0x41d3f6("div", { staticClass: _0x385f72(0x37b) }, [
                          _0x41d3f6(_0x385f72(0x393), {
                            staticClass: _0x385f72(0x165),
                          }),
                        ]),
                        this["_v"]("\x20"),
                        _0x41d3f6("div", { staticClass: _0x385f72(0x358) }),
                      ]
                    ),
                  ]
                );
              },
            ]),
          _0x37398b =
            (_0x2f40a9(0xa),
            _0x2f40a9(0xb),
            _0x2f40a9(0x8),
            _0x2f40a9(0x10),
            _0x2f40a9(0xd),
            _0x2f40a9(0x11),
            _0x2f40a9(0x1f)),
          _0x1dcb90 =
            (_0x2f40a9(0x5e), _0x2f40a9(0x40), _0x2f40a9(0xc), _0x2f40a9(0x3));
        function _0x1745ae(_0x1773ee, _0x3a1656) {
          var _0x3a5cee = a16_0x269f,
            _0x5e646e = Object[_0x3a5cee(0x376)](_0x1773ee);
          if (Object[_0x3a5cee(0x221)]) {
            var _0x46e2d1 = Object[_0x3a5cee(0x221)](_0x1773ee);
            _0x3a1656 &&
              (_0x46e2d1 = _0x46e2d1[_0x3a5cee(0x1db)](function (_0x58e68e) {
                var _0xd03e6d = _0x3a5cee;
                return Object[_0xd03e6d(0x39e)](
                  _0x1773ee,
                  _0x58e68e
                )[_0xd03e6d(0x25b)];
              })),
              _0x5e646e["push"]["apply"](_0x5e646e, _0x46e2d1);
          }
          return _0x5e646e;
        }
        function _0x4f96b2(_0x43cba4) {
          var _0x1b6708 = a16_0x269f;
          for (
            var _0x179b86 = 0x1;
            _0x179b86 < arguments[_0x1b6708(0x21a)];
            _0x179b86++
          ) {
            var _0x2d7069 =
              null != arguments[_0x179b86] ? arguments[_0x179b86] : {};
            _0x179b86 % 0x2
              ? _0x1745ae(Object(_0x2d7069), !0x0)[_0x1b6708(0x160)](function (
                  _0x2222aa
                ) {
                  Object(_0x29dcfc["a"])(
                    _0x43cba4,
                    _0x2222aa,
                    _0x2d7069[_0x2222aa]
                  );
                })
              : Object[_0x1b6708(0x2fb)]
              ? Object[_0x1b6708(0x2b5)](
                  _0x43cba4,
                  Object[_0x1b6708(0x2fb)](_0x2d7069)
                )
              : _0x1745ae(Object(_0x2d7069))[_0x1b6708(0x160)](function (
                  _0x4f7f45
                ) {
                  var _0x1028a1 = _0x1b6708;
                  Object["defineProperty"](
                    _0x43cba4,
                    _0x4f7f45,
                    Object[_0x1028a1(0x39e)](_0x2d7069, _0x4f7f45)
                  );
                });
          }
          return _0x43cba4;
        }
        var _0x2911c6 = {
            name: _0x5b07a8(0x27c),
            props: {
              isStartedBet: { type: Boolean },
              isSkip: { type: Boolean },
              isTop: { type: Boolean },
              isBottom: { type: Boolean },
              isCashout: { type: Boolean },
              changedAmount: { type: Number, default: 0x0 },
            },
            computed: _0x4f96b2(
              {},
              Object(_0x1dcb90["c"])(_0x5b07a8(0x125), [_0x5b07a8(0x213)])
            ),
            data: function () {
              var _0x5af7fb = _0x5b07a8;
              return {
                suits: ["D", "H", "S", "C"],
                ranks: [
                  "A",
                  "2",
                  "3",
                  "4",
                  "5",
                  "6",
                  "7",
                  "8",
                  "9",
                  "10",
                  "J",
                  "Q",
                  "K",
                ],
                prevCardFly: "",
                specialValues: { A: 0x1, J: 0xb, Q: 0xc, K: 0xd },
                currentCard: { suit: "", rank: "", icon: "", color: "" },
                prevCard: { suit: "", rank: "", icon: "", color: "" },
                startCard: { suit: "", rank: "", icon: "", color: "" },
                payout: { higher: 0x0, lower: 0x0, total: 0x0 },
                profitAmount: { higher: "", lower: "", total: "" },
                cardHistory: [],
                guessHistory: [],
                amount: 0x0,
                betId: "",
                active: !0x1,
                currentFaceDown: !0x0,
                prevFaceDown: !0x0,
                historyFaceDown: !0x0,
                currentCardFaceClass: _0x5af7fb(0x1c0),
                startCardSlide: !0x0,
                slideDown: !0x1,
                slide: !0x0,
                totalPayoutMultiplier: 0x0,
                resultShow: !0x1,
                currentCardDuration: "300ms",
                userMoney: 0x0,
              };
            },
            mounted: function () {
              var _0x4cfc93 = _0x5b07a8;
              window[_0x4cfc93(0x230)]
                ? window[_0x4cfc93(0x230)](
                    "resize",
                    this[_0x4cfc93(0x16f)],
                    !0x1
                  )
                : window[_0x4cfc93(0x16e)] &&
                  window["attachEvent"](_0x4cfc93(0x3b9), this["winsize"]),
                this[_0x4cfc93(0x1b7)]();
            },
            destroyed: function () {
              var _0x3ad5bd = _0x5b07a8;
              window[_0x3ad5bd(0x230)]
                ? window[_0x3ad5bd(0x202)](
                    _0x3ad5bd(0x1e1),
                    this["winsize"],
                    !0x1
                  )
                : window[_0x3ad5bd(0x2e9)] &&
                  window[_0x3ad5bd(0x2e9)]("onresize", this["winsize"]);
            },
            methods: _0x4f96b2(
              _0x4f96b2(
                {},
                Object(_0x1dcb90["b"])(_0x5b07a8(0x125), [
                  _0x5b07a8(0x21b),
                  _0x5b07a8(0x36c),
                  _0x5b07a8(0x2d2),
                  _0x5b07a8(0x197),
                  _0x5b07a8(0x30f),
                  _0x5b07a8(0x1d2),
                ])
              ),
              {},
              {
                getIconName: function (_0x1a1d08) {
                  var _0x2aca82 = _0x5b07a8;
                  switch (_0x1a1d08) {
                    case "S":
                      return "fa-solid\x20fa-spade";
                    case "H":
                      return _0x2aca82(0x1ca);
                    case "C":
                      return "fa-solid\x20fa-club";
                    case "D":
                      return _0x2aca82(0x2a1);
                    default:
                      return "";
                  }
                },
                getFaceColor: function (_0x2b8e89) {
                  var _0xb2aedc = _0x5b07a8;
                  return "S" == _0x2b8e89 || "C" == _0x2b8e89
                    ? "grey"
                    : "H" == _0x2b8e89 || "D" == _0x2b8e89
                    ? _0xb2aedc(0x41c)
                    : _0xb2aedc(0x169);
                },
                getRandomCard: function () {
                  var _0x279c5e = _0x5b07a8,
                    _0x27a2b2 =
                      this[_0x279c5e(0x322)][_0x279c5e(0x21a)] *
                      this[_0x279c5e(0x3d6)][_0x279c5e(0x21a)],
                    _0x156a62 =
                      Math[_0x279c5e(0x127)](
                        Math[_0x279c5e(0x1e9)]() * _0x27a2b2
                      ) % _0x27a2b2,
                    _0x13ecae = this[_0x279c5e(0x322)][_0x156a62 % 0x4];
                  return {
                    suit: _0x13ecae,
                    rank: this[_0x279c5e(0x3d6)][
                      Math["floor"](_0x156a62 / 0x4)
                    ],
                    icon: this[_0x279c5e(0x12d)](_0x13ecae),
                    color: this[_0x279c5e(0x15e)](_0x13ecae),
                  };
                },
                getPayout: function (_0x8a03f5) {
                  var _0x2a062c = _0x5b07a8,
                    _0x56b18d = 0x3e8 * _0x8a03f5;
                  return (
                    Math[_0x2a062c(0x127)]((0x182b8 / _0x56b18d) * 0x186a0) /
                    0x186a0
                  );
                },
                getCardValue: function (_0x295fe0) {
                  var _0xfe1b64 = _0x5b07a8;
                  return _0x295fe0 in this[_0xfe1b64(0x23b)]
                    ? this[_0xfe1b64(0x23b)][_0x295fe0]
                    : Number(_0x295fe0);
                },
                getChancePercent: function (_0x56fcd1) {
                  var _0x27ef87 = _0x56fcd1 * (0x1 / 0xd);
                  return {
                    lowerEqual: _0x27ef87,
                    lower: _0x27ef87 - 0x1 / 0xd,
                    higherEqual: 0x1 - _0x27ef87 + 0x1 / 0xd,
                    higher: 0x1 - _0x27ef87,
                  };
                },
                getGuessHighInfo: function (_0xcfc8a6) {
                  var _0x4fdbbf = _0x5b07a8,
                    _0x31d5a2 = this[_0x4fdbbf(0x1ec)](_0xcfc8a6),
                    _0x100cb6 =
                      0x64 *
                      this[_0x4fdbbf(0x145)](_0x31d5a2)[
                        "A" === _0xcfc8a6 ? "higher" : _0x4fdbbf(0x16c)
                      ];
                  return {
                    chance: _0x100cb6,
                    payout: this[_0x4fdbbf(0x281)](_0x100cb6),
                  };
                },
                getGuessLowInfo: function (_0x5e5bec) {
                  var _0x18976e = _0x5b07a8,
                    _0x22764e = this[_0x18976e(0x1ec)](_0x5e5bec),
                    _0x13982c =
                      0x64 *
                      this[_0x18976e(0x145)](_0x22764e)[
                        "K" === _0x5e5bec ? _0x18976e(0x33b) : _0x18976e(0x38e)
                      ];
                  return {
                    chance: _0x13982c,
                    payout: this["getPayout"](_0x13982c),
                  };
                },
                getButtonFlag: function (_0x5288ab) {
                  var _0x5090b9 = _0x5b07a8;
                  return "A" === _0x5288ab
                    ? {
                        top: {
                          label: _0x5090b9(0x1a7),
                          icon: _0x5090b9(0x385),
                        },
                        bottom: {
                          label: _0x5090b9(0x2a8),
                          icon: _0x5090b9(0x2a0),
                        },
                      }
                    : "K" === _0x5288ab
                    ? {
                        top: {
                          label: _0x5090b9(0x2a8),
                          icon: _0x5090b9(0x2a0),
                        },
                        bottom: {
                          label: _0x5090b9(0x361),
                          icon: _0x5090b9(0x177),
                        },
                      }
                    : {
                        top: {
                          label: "Higher\x20or\x20Same",
                          icon: _0x5090b9(0x385),
                        },
                        bottom: {
                          label: _0x5090b9(0x327),
                          icon: _0x5090b9(0x177),
                        },
                      };
                },
                setChanceAndPayout: function (_0x4d932e) {
                  var _0xca715a = _0x5b07a8,
                    _0x247476 = this[_0xca715a(0x3a8)](_0x4d932e),
                    _0x87aabc = this[_0xca715a(0x215)](_0x4d932e),
                    _0x375d7d = this[_0xca715a(0x17f)](_0x4d932e);
                  this["setButtonInfo"]({
                    top: {
                      label: _0x375d7d[_0xca715a(0x196)][_0xca715a(0x12b)],
                      icon: _0x375d7d[_0xca715a(0x196)][_0xca715a(0x228)],
                      percent:
                        _0x247476[_0xca715a(0x134)][_0xca715a(0x1fd)](0x2) +
                        "%",
                    },
                    bottom: {
                      label: _0x375d7d["bottom"]["label"],
                      icon: _0x375d7d[_0xca715a(0x3c2)][_0xca715a(0x228)],
                      percent:
                        _0x87aabc[_0xca715a(0x134)][_0xca715a(0x1fd)](0x2) +
                        "%",
                    },
                  }),
                    (this["payout"]["higher"] = _0x247476[_0xca715a(0x2bb)]),
                    (this[_0xca715a(0x2bb)][_0xca715a(0x33b)] =
                      _0x87aabc[_0xca715a(0x2bb)]),
                    (this[_0xca715a(0x2fc)][_0xca715a(0x240)] = Math[
                      _0xca715a(0x127)
                    ](
                      this[_0xca715a(0x2bf)] * _0x247476[_0xca715a(0x2bb)] -
                        this[_0xca715a(0x2bf)] || 0x0
                    )[_0xca715a(0x1fc)]()),
                    (this[_0xca715a(0x2fc)]["lower"] = Math[_0xca715a(0x127)](
                      this["amount"] * _0x87aabc[_0xca715a(0x2bb)] -
                        this[_0xca715a(0x2bf)] || 0x0
                    )[_0xca715a(0x1fc)]()),
                    (this["profitAmount"][_0xca715a(0x32f)] =
                      this["amount"] * this[_0xca715a(0x255)] -
                        this[_0xca715a(0x2bf)] >
                      0x0
                        ? Math[_0xca715a(0x127)](
                            this[_0xca715a(0x2bf)] * this[_0xca715a(0x255)] -
                              this[_0xca715a(0x2bf)]
                          )[_0xca715a(0x1fc)]()
                        : 0x0);
                },
                winsize: function () {},
                initialize: function () {
                  var _0x27f917 = _0x5b07a8,
                    _0x3043ea = this;
                  (this["currentCard"] = this[_0x27f917(0x152)]()),
                    (this[_0x27f917(0x3bd)] = _0x4f96b2(
                      {},
                      this[_0x27f917(0x2a2)]
                    )),
                    (this[_0x27f917(0x2de)] = _0x4f96b2(
                      {},
                      this[_0x27f917(0x2a2)]
                    )),
                    this[_0x27f917(0x3b8)](this[_0x27f917(0x2a2)]["rank"]),
                    (this[_0x27f917(0x2ee)] = !0x1),
                    setTimeout(function () {
                      var _0x23e1fc = _0x27f917;
                      _0x3043ea[_0x23e1fc(0x1fa)] = !0x1;
                    }, 0x190);
                },
                bet: function () {
                  var _0x24c687 = _0x5b07a8;
                  document[_0x24c687(0x3c6)]("audio-bet")["play"](),
                    this[_0x24c687(0x21b)](!0x0),
                    this["setBetdisabled"](!0x0),
                    this["setSetdisabled"](!0x0),
                    this[_0x24c687(0x2c1)]["length"] > 0x0 &&
                      this[_0x24c687(0x314)](!0x1),
                    this[_0x24c687(0x1d3)]();
                },
                prepareBet: function (_0x3099eb) {
                  var _0x3319a7 = _0x5b07a8,
                    _0x1c0b05 = this;
                  if (
                    ((this["resultShow"] = !0x1),
                    (this[_0x3319a7(0x13f)] = _0x3319a7(0x1c0)),
                    (this["totalPayoutMultiplier"] = 0x0),
                    (this[_0x3319a7(0x2bb)][_0x3319a7(0x32f)] = 0x0),
                    (this[_0x3319a7(0x267)] = 0x0),
                    this[_0x3319a7(0x3b8)](
                      this[_0x3319a7(0x2a2)][_0x3319a7(0x3d7)]
                    ),
                    Object[_0x3319a7(0x376)](this["$refs"])[_0x3319a7(0x21a)] >
                      0x1)
                  ) {
                    for (var _0x515145 in this[_0x3319a7(0x3a2)])
                      if ("startCard" != _0x515145) {
                        var _0x299106 = this["$refs"][_0x515145][0x0];
                        if (_0x299106) {
                          var _0x14b7d9 =
                            this[_0x3319a7(0x3a2)][_0x3319a7(0x2de)][
                              _0x3319a7(0x1c6)
                            ]()["x"] -
                            _0x299106["getBoundingClientRect"]()["x"];
                          (_0x299106[_0x3319a7(0x224)][_0x3319a7(0x3fa)] =
                            "transform\x200.5s\x20ease-out"),
                            (_0x299106[_0x3319a7(0x224)]["transform"] =
                              "translate("[_0x3319a7(0x174)](
                                _0x14b7d9,
                                _0x3319a7(0x3db)
                              ));
                        } else delete this[_0x3319a7(0x3a2)][_0x515145];
                      }
                    (this[_0x3319a7(0x15d)] = !0x0),
                      setTimeout(function () {
                        var _0x2959f7 = _0x3319a7;
                        if (
                          ((_0x1c0b05[_0x2959f7(0x15d)] = !0x1),
                          (_0x1c0b05["cardHistory"] = []),
                          (_0x1c0b05[_0x2959f7(0x15b)] = []),
                          _0x3099eb)
                        ) {
                          var _0x4b1ae0 = _0x1c0b05[_0x2959f7(0x152)]();
                          (_0x1c0b05["currentCard"] = _0x4b1ae0),
                            _0x1c0b05["setChanceAndPayout"](_0x4b1ae0["rank"]),
                            (_0x1c0b05["startCard"] = _0x4b1ae0),
                            _0x1c0b05[_0x2959f7(0x2d2)](!0x1),
                            _0x1c0b05[_0x2959f7(0x41e)](!0x0);
                        } else
                          (_0x1c0b05[_0x2959f7(0x2de)] = _0x4f96b2(
                            {},
                            _0x1c0b05[_0x2959f7(0x2a2)]
                          )),
                            (_0x1c0b05[_0x2959f7(0x1fa)] = !0x0),
                            setTimeout(function () {
                              _0x1c0b05["startCardSlide"] = !0x1;
                            }, 0x190);
                      }, 0x320);
                  }
                },
                start: function () {
                  var _0x3c8460 = _0x5b07a8,
                    _0x43ffcd = this;
                  this[_0x3c8460(0x32c)][_0x3c8460(0x32d)][_0x3c8460(0x1f2)]
                    [_0x3c8460(0x1e0)]({
                      type: _0x3c8460(0x40c),
                      amount: this[_0x3c8460(0x2bf)],
                      startCard: {
                        suit: this[_0x3c8460(0x2a2)]["suit"],
                        rank: this[_0x3c8460(0x2a2)][_0x3c8460(0x3d7)],
                      },
                    })
                    [_0x3c8460(0x190)](function (_0x1707ed) {
                      var _0x1ba5a9 = _0x3c8460,
                        _0x254023 =
                          _0x1707ed[_0x1ba5a9(0x306)][_0x1ba5a9(0x341)],
                        _0xb6d93b = _0x254023[_0x1ba5a9(0x2c6)],
                        _0x67b159 = _0x254023["id"];
                      _0x254023[_0x1ba5a9(0x3e6)],
                        ((_0x43ffcd[_0x1ba5a9(0x2c6)] = _0xb6d93b),
                        (_0x43ffcd[_0x1ba5a9(0x3bc)] = _0x67b159),
                        _0x43ffcd["setBetloading"](!0x1),
                        _0x43ffcd[_0x1ba5a9(0x36c)](!0x1));
                    })
                    ["catch"](function (_0x3b13f8) {
                      var _0x1ebd97 = _0x3c8460;
                      _0x43ffcd[_0x1ebd97(0x2a4)][_0x1ebd97(0x400)](_0x3b13f8),
                        _0x43ffcd[_0x1ebd97(0x36c)](!0x1),
                        _0x43ffcd["$emit"](_0x1ebd97(0x36e));
                    });
                },
                skipCard: function () {
                  var _0x29c227 = _0x5b07a8,
                    _0x54aad4 = this;
                  if (
                    (this[_0x29c227(0x197)](!0x0),
                    this[_0x29c227(0x2d2)](!0x0),
                    this[_0x29c227(0x2c6)])
                  )
                    document[_0x29c227(0x3c6)](_0x29c227(0x1ea))[
                      _0x29c227(0x2e6)
                    ](),
                      this[_0x29c227(0x32c)][_0x29c227(0x32d)][_0x29c227(0x1f2)]
                        [_0x29c227(0x1e0)]({ type: "skip", id: this["betId"] })
                        [_0x29c227(0x190)](function (_0x1e9df2) {
                          var _0x1da551 = _0x29c227,
                            _0x37efdc = _0x1e9df2[_0x1da551(0x306)]["hiloBet"],
                            _0x4ce53c = _0x37efdc[_0x1da551(0x311)],
                            _0x23426d = _0x37efdc[_0x1da551(0x2c6)],
                            _0x4b63c9 = _0x37efdc["user"],
                            _0x4af678 = _0x37efdc[_0x1da551(0x2bb)],
                            _0xf8da8f = _0x37efdc["payoutMultiplier"];
                          (_0x54aad4[_0x1da551(0x2c6)] = _0x23426d),
                            (_0x54aad4[_0x1da551(0x267)] =
                              _0x4b63c9[_0x1da551(0x19b)]),
                            _0x23426d ||
                              ((_0x54aad4[_0x1da551(0x2bb)]["total"] =
                                _0x4af678),
                              (_0x54aad4[_0x1da551(0x255)] = _0xf8da8f),
                              _0x54aad4[_0x1da551(0x197)](!0x1),
                              _0x54aad4["setSetdisabled"](!0x0));
                          var _0x7650d9 = Object(_0x37398b["a"])(
                            _0x4ce53c[_0x1da551(0x32e)]
                          )[_0x1da551(0x242)]();
                          (_0x54aad4[_0x1da551(0x2a2)] = _0x4f96b2(
                            _0x4f96b2({}, _0x7650d9[_0x1da551(0x278)]),
                            {},
                            {
                              icon: _0x54aad4[_0x1da551(0x12d)](
                                _0x7650d9[_0x1da551(0x278)]["suit"]
                              ),
                              color: _0x54aad4[_0x1da551(0x15e)](
                                _0x7650d9[_0x1da551(0x278)][_0x1da551(0x148)]
                              ),
                            }
                          )),
                            (_0x54aad4[_0x1da551(0x255)] =
                              _0x7650d9[_0x1da551(0x198)]),
                            _0x54aad4["setChanceAndPayout"](
                              _0x7650d9["card"]["rank"]
                            ),
                            _0x54aad4[_0x1da551(0x2c1)][_0x1da551(0x22a)](
                              _0x4f96b2(
                                _0x4f96b2({}, _0x54aad4["currentCard"]),
                                {},
                                { multiplier: 0x1, class: _0x1da551(0x1a9) }
                              )
                            ),
                            _0x54aad4[_0x1da551(0x15b)][_0x1da551(0x22a)]({
                              class: _0x1da551(0x3f7),
                              icon: _0x1da551(0x31d),
                              opacity: 0.5,
                            }),
                            _0x54aad4[_0x1da551(0x41e)](!0x1);
                        })
                        [_0x29c227(0x2a3)](function (_0x3096e7) {
                          var _0x1cdc60 = _0x29c227;
                          _0x54aad4[_0x1cdc60(0x197)](!0x1),
                            _0x54aad4["setSetdisabled"](!0x1),
                            _0x54aad4[_0x1cdc60(0x3ae)](_0x1cdc60(0x23c));
                        });
                  else {
                    if (this[_0x29c227(0x2c1)][_0x29c227(0x21a)] > 0x0)
                      this["prepareBet"](!0x0);
                    else {
                      var _0xed8ff7 = this["getRandomCard"]();
                      (this["currentCard"] = _0xed8ff7),
                        this["setChanceAndPayout"](_0xed8ff7[_0x29c227(0x3d7)]),
                        (this[_0x29c227(0x2de)] = _0xed8ff7),
                        this[_0x29c227(0x41e)](!0x0);
                    }
                  }
                },
                doSkipAnimation: function (_0x196f91) {
                  var _0x220faa = _0x5b07a8,
                    _0x170674 = this,
                    _0x487e94 = this["prevCardFly"];
                  (this[_0x220faa(0x163)] = ""),
                    (this[_0x220faa(0x23a)] = _0x220faa(0x11f)),
                    (this[_0x220faa(0x1e8)] = !_0x196f91),
                    setTimeout(function () {
                      var _0x5ad6f7 = _0x220faa;
                      _0x170674[_0x5ad6f7(0x163)] =
                        _0x5ad6f7(0x2bc) === _0x487e94
                          ? _0x5ad6f7(0x412)
                          : "left";
                    }),
                    setTimeout(function () {
                      var _0xa33b34 = _0x220faa;
                      (_0x170674["prevCard"] = _0x4f96b2(
                        {},
                        _0x170674[_0xa33b34(0x2a2)]
                      )),
                        _0x196f91 ||
                          (document["getElementById"]("audio-flip")[
                            _0xa33b34(0x2e6)
                          ](),
                          (_0x170674["currentCardDuration"] = _0xa33b34(0x3da)),
                          (_0x170674["currentFaceDown"] = !0x1));
                    }, 0x190),
                    _0x196f91
                      ? (this["startCardSlide"] = !0x0)
                      : ((this[_0x220faa(0x1e7)] = !0x0),
                        (this[_0x220faa(0x378)] = !0x0)),
                    setTimeout(function () {
                      var _0x475ac2 = _0x220faa;
                      _0x196f91
                        ? (_0x170674[_0x475ac2(0x1fa)] = !0x1)
                        : ((_0x170674[_0x475ac2(0x1e7)] = !0x1),
                          (_0x170674["historyFaceDown"] = !0x1),
                          _0x170674[_0x475ac2(0x1cd)]()),
                        (document[_0x475ac2(0x3c6)]("footer")[
                          "scrollLeft"
                        ] = 0x2540be400),
                        _0x170674["setSkipdisabled"](!0x1),
                        _0x170674[_0x475ac2(0x2c6)] ||
                          _0x170674[_0x475ac2(0x2d2)](!0x1),
                        _0x170674["$emit"]("resetSkip");
                    }, 0x190);
                },
                topGuess: function () {
                  var _0x1e1ac5 = _0x5b07a8;
                  document[_0x1e1ac5(0x3c6)](_0x1e1ac5(0x1ea))[
                    _0x1e1ac5(0x2e6)
                  ]();
                  var _0x4ef2e8 = "";
                  (_0x4ef2e8 =
                    "A" === this[_0x1e1ac5(0x2a2)][_0x1e1ac5(0x3d7)]
                      ? "higher"
                      : "K" === this[_0x1e1ac5(0x2a2)][_0x1e1ac5(0x3d7)]
                      ? _0x1e1ac5(0x31f)
                      : _0x1e1ac5(0x16c)),
                    this[_0x1e1ac5(0x310)](_0x1e1ac5(0x172), _0x4ef2e8);
                },
                bottomGuess: function () {
                  var _0x299df6 = _0x5b07a8;
                  document[_0x299df6(0x3c6)]("audio-click")[_0x299df6(0x2e6)]();
                  var _0x1b8da4 = "";
                  (_0x1b8da4 =
                    "A" === this[_0x299df6(0x2a2)][_0x299df6(0x3d7)]
                      ? _0x299df6(0x31f)
                      : "K" === this[_0x299df6(0x2a2)][_0x299df6(0x3d7)]
                      ? "lower"
                      : _0x299df6(0x38e)),
                    this["doGuess"](_0x299df6(0x200), _0x1b8da4);
                },
                doGuess: function (_0x5cb016, _0x14eb16) {
                  var _0x90a4a6 = _0x5b07a8,
                    _0x26ea07 = this;
                  this[_0x90a4a6(0x36c)](!0x0), this[_0x90a4a6(0x30f)](!0x1);
                  var _0x20759c = this["prevCardFly"];
                  (this["prevCardFly"] = ""),
                    (this["currentCardDuration"] = "0ms"),
                    (this["currentFaceDown"] = !0x0),
                    this["$repositories"][_0x90a4a6(0x32d)][_0x90a4a6(0x1f2)]
                      [_0x90a4a6(0x1e0)]({
                        type: _0x90a4a6(0x2e6),
                        id: this["betId"],
                        flag: _0x14eb16,
                      })
                      [_0x90a4a6(0x190)](function (_0x1815d8) {
                        var _0x4bfcd8 = _0x90a4a6,
                          _0x219bb2 =
                            _0x1815d8[_0x4bfcd8(0x306)][_0x4bfcd8(0x341)],
                          _0x1eb7b2 = _0x219bb2[_0x4bfcd8(0x311)],
                          _0x197be3 = _0x219bb2[_0x4bfcd8(0x2c6)],
                          _0x487d96 = _0x219bb2[_0x4bfcd8(0x3e6)],
                          _0x1cb175 = _0x219bb2[_0x4bfcd8(0x2bb)],
                          _0x3bb1ca = _0x219bb2["payoutMultiplier"];
                        (_0x26ea07[_0x4bfcd8(0x2c6)] = _0x197be3),
                          (_0x26ea07[_0x4bfcd8(0x267)] =
                            _0x487d96[_0x4bfcd8(0x19b)]),
                          _0x197be3 ||
                            ((_0x26ea07[_0x4bfcd8(0x2bb)][_0x4bfcd8(0x32f)] =
                              _0x1cb175),
                            (_0x26ea07[_0x4bfcd8(0x255)] = _0x3bb1ca));
                        var _0x1d7ddc = Object(_0x37398b["a"])(
                          _0x1eb7b2[_0x4bfcd8(0x32e)]
                        )["pop"]();
                        (_0x26ea07["currentCard"] = _0x4f96b2(
                          _0x4f96b2({}, _0x1d7ddc["card"]),
                          {},
                          {
                            icon: _0x26ea07[_0x4bfcd8(0x12d)](
                              _0x1d7ddc[_0x4bfcd8(0x278)][_0x4bfcd8(0x148)]
                            ),
                            color: _0x26ea07[_0x4bfcd8(0x15e)](
                              _0x1d7ddc[_0x4bfcd8(0x278)][_0x4bfcd8(0x148)]
                            ),
                          }
                        )),
                          (_0x26ea07[_0x4bfcd8(0x255)] =
                            _0x1d7ddc["payoutMultiplier"]),
                          _0x26ea07[_0x4bfcd8(0x3b8)](
                            _0x1d7ddc[_0x4bfcd8(0x278)]["rank"]
                          ),
                          (_0x26ea07[_0x4bfcd8(0x163)] =
                            _0x4bfcd8(0x2bc) === _0x20759c
                              ? "right"
                              : _0x4bfcd8(0x2bc)),
                          setTimeout(function () {
                            var _0x28c01b = _0x4bfcd8;
                            (_0x26ea07[_0x28c01b(0x3bd)] = _0x4f96b2(
                              {},
                              _0x26ea07[_0x28c01b(0x2a2)]
                            )),
                              (_0x26ea07[_0x28c01b(0x23a)] = "300ms"),
                              (_0x26ea07[_0x28c01b(0x1e8)] = !0x1),
                              document[_0x28c01b(0x3c6)]("audio-flip")[
                                _0x28c01b(0x2e6)
                              ]();
                          }, 0x190),
                          _0x26ea07[_0x4bfcd8(0x2c1)][_0x4bfcd8(0x22a)](
                            _0x4f96b2(
                              _0x4f96b2({}, _0x26ea07[_0x4bfcd8(0x2a2)]),
                              {},
                              {
                                multiplier: _0x1d7ddc[_0x4bfcd8(0x198)],
                                class:
                                  _0x26ea07["totalPayoutMultiplier"] > 0x0
                                    ? _0x4bfcd8(0x1a9)
                                    : _0x4bfcd8(0x369),
                              }
                            )
                          );
                        var _0x5c2f04 = null;
                        _0x4bfcd8(0x240) === _0x14eb16
                          ? (_0x5c2f04 = "fa-up")
                          : "equal" === _0x14eb16
                          ? (_0x5c2f04 = _0x4bfcd8(0x289))
                          : _0x4bfcd8(0x33b) === _0x14eb16
                          ? (_0x5c2f04 = _0x4bfcd8(0x276))
                          : _0x4bfcd8(0x16c) === _0x14eb16
                          ? (_0x5c2f04 = _0x4bfcd8(0x20c))
                          : _0x4bfcd8(0x38e) === _0x14eb16 &&
                            (_0x5c2f04 = "fa-down-from-line"),
                          _0x26ea07[_0x4bfcd8(0x15b)][_0x4bfcd8(0x22a)]({
                            class:
                              _0x26ea07[_0x4bfcd8(0x255)] > 0x0
                                ? _0x4bfcd8(0x1a9)
                                : _0x4bfcd8(0x369),
                            icon: _0x4bfcd8(0x2ba) + _0x5c2f04,
                            opacity: 0x1,
                          }),
                          (_0x26ea07[_0x4bfcd8(0x1e7)] = !0x0),
                          (_0x26ea07[_0x4bfcd8(0x378)] = !0x0),
                          setTimeout(function () {
                            var _0x13787c = _0x4bfcd8;
                            (_0x26ea07[_0x13787c(0x1e7)] = !0x1),
                              (_0x26ea07[_0x13787c(0x378)] = !0x1),
                              (document["getElementById"](_0x13787c(0x381))[
                                _0x13787c(0x214)
                              ] = 0x2540be400),
                              _0x26ea07[_0x13787c(0x255)] > 0x0 &&
                                setTimeout(function () {
                                  var _0x3cd1d5 = _0x13787c;
                                  document[_0x3cd1d5(0x3c6)]("audio-correct")[
                                    "load"
                                  ](),
                                    document[_0x3cd1d5(0x3c6)]("audio-correct")[
                                      "play"
                                    ]();
                                }, 0x12c),
                              _0x26ea07[_0x13787c(0x2c6)] &&
                                (_0x26ea07[_0x13787c(0x36c)](!0x1),
                                _0x26ea07["setCashoutdisabled"](!0x1)),
                              _0x26ea07["$emit"](_0x13787c(0x300) + _0x5cb016),
                              _0x26ea07[_0x13787c(0x1cd)]();
                          }, 0x190);
                      })
                      [_0x90a4a6(0x2a3)](function (_0x8978d7) {
                        var _0x362209 = _0x90a4a6;
                        _0x26ea07[_0x362209(0x36c)](!0x1),
                          _0x26ea07[_0x362209(0x30f)](!0x0),
                          _0x26ea07[_0x362209(0x3ae)](
                            _0x362209(0x300) + _0x5cb016
                          );
                      });
                },
                cashout: function () {
                  var _0x1152e8 = _0x5b07a8,
                    _0x5a2bdd = this;
                  this[_0x1152e8(0x36c)](!0x0),
                    this[_0x1152e8(0x30f)](!0x0),
                    this[_0x1152e8(0x32c)]["games"]["HiloRepository"]
                      [_0x1152e8(0x1e0)]({
                        type: _0x1152e8(0x2f2),
                        id: this["betId"],
                      })
                      [_0x1152e8(0x190)](function (_0x5b5a93) {
                        var _0x4f0865 = _0x1152e8,
                          _0x2ce143 =
                            _0x5b5a93[_0x4f0865(0x306)][_0x4f0865(0x341)],
                          _0x48dd63 = _0x2ce143[_0x4f0865(0x198)],
                          _0x13bf7a = _0x2ce143[_0x4f0865(0x3e6)],
                          _0x153479 = _0x2ce143["active"],
                          _0x597d76 = _0x2ce143[_0x4f0865(0x2bb)];
                        (_0x5a2bdd[_0x4f0865(0x2c6)] = _0x153479),
                          (_0x5a2bdd[_0x4f0865(0x267)] =
                            _0x13bf7a[_0x4f0865(0x19b)]),
                          (_0x5a2bdd["totalPayoutMultiplier"] = _0x48dd63),
                          (_0x5a2bdd[_0x4f0865(0x2bb)]["total"] = _0x597d76),
                          _0x5a2bdd[_0x4f0865(0x1cd)](),
                          _0x5a2bdd[_0x4f0865(0x3ae)]("resetCashout");
                      })
                      ["catch"](function (_0x4c7331) {
                        var _0x18ad7d = _0x1152e8;
                        _0x5a2bdd["setSetdisabled"](!0x1),
                          _0x5a2bdd["setCashoutdisabled"](!0x1),
                          _0x5a2bdd[_0x18ad7d(0x3ae)](_0x18ad7d(0x2fa));
                      });
                },
                checkOrFinish: function () {
                  var _0x5041da = _0x5b07a8;
                  this[_0x5041da(0x2c6)] ||
                    (this[_0x5041da(0x255)] > 0x0
                      ? ((this[_0x5041da(0x350)] = !0x0),
                        document[_0x5041da(0x3c6)]("audio-win")[
                          _0x5041da(0x2e6)
                        ](),
                        this["setBetdisabled"](!0x1),
                        this[_0x5041da(0x30f)](!0x0))
                      : ((this[_0x5041da(0x13f)] = _0x5041da(0x1a4)),
                        this["setSetdisabled"](!0x0),
                        this[_0x5041da(0x2d2)](!0x1),
                        this[_0x5041da(0x30f)](!0x0)),
                    this[_0x5041da(0x3ae)](_0x5041da(0x3f8)));
                },
              }
            ),
            watch: {
              isStartedBet: function (_0x2c2124) {
                var _0x27f1e6 = _0x5b07a8;
                _0x2c2124 && this[_0x27f1e6(0x40c)]();
              },
              isSkip: function (_0xe0ed6d) {
                var _0x2fdf3c = _0x5b07a8;
                _0xe0ed6d && this[_0x2fdf3c(0x3eb)]();
              },
              isTop: function (_0xaaf553) {
                var _0x12c3bb = _0x5b07a8;
                _0xaaf553 && this[_0x12c3bb(0x1a8)]();
              },
              isBottom: function (_0xd55da4) {
                var _0x44c424 = _0x5b07a8;
                _0xd55da4 && this[_0x44c424(0x2b4)]();
              },
              isCashout: function (_0x328ced) {
                var _0x514bc1 = _0x5b07a8;
                _0x328ced && this[_0x514bc1(0x291)]();
              },
              changedAmount: function (_0x3d6ff7) {
                var _0x4c1091 = _0x5b07a8;
                (this[_0x4c1091(0x2bf)] = _0x3d6ff7),
                  this[_0x4c1091(0x3b8)](
                    this[_0x4c1091(0x2a2)][_0x4c1091(0x3d7)]
                  );
              },
            },
          },
          _0x57c308 = (_0x2f40a9(0x409), _0x2f40a9(0x1)),
          _0x5cc73e = Object(_0x57c308["a"])(
            _0x2911c6,
            function () {
              var _0x388992 = _0x5b07a8,
                _0x39baad,
                _0x52ade6 = this,
                _0x388a84 = _0x52ade6[_0x388992(0x396)]["_c"];
              return _0x388a84(
                "div",
                {
                  staticClass: _0x388992(0x404),
                  staticStyle: { "min-height": _0x388992(0x1b4) },
                },
                [
                  _0x52ade6["_m"](0x0),
                  _0x52ade6["_v"]("\x20"),
                  _0x52ade6["_m"](0x1),
                  _0x52ade6["_v"]("\x20"),
                  _0x52ade6["_m"](0x2),
                  _0x52ade6["_v"]("\x20"),
                  _0x52ade6["_m"](0x3),
                  _0x52ade6["_v"]("\x20"),
                  _0x52ade6["_m"](0x4),
                  _0x52ade6["_v"]("\x20"),
                  _0x388a84(
                    _0x388992(0x393),
                    { staticClass: _0x388992(0x38f) },
                    [
                      _0x388a84(
                        _0x388992(0x393),
                        { staticClass: _0x388992(0x317) },
                        [
                          _0x388a84("div", { staticClass: _0x388992(0x354) }, [
                            _0x388a84(
                              "div",
                              { staticClass: _0x388992(0x383) },
                              [
                                _0x388a84(
                                  _0x388992(0x393),
                                  { staticClass: "deck\x20stake-s5ivtb" },
                                  _0x52ade6["_l"](0x5, function (_0x5115e9) {
                                    return _0x388a84(
                                      "button",
                                      {
                                        staticClass: "wrap\x20stake-1wtyksp",
                                        style: {
                                          transform:
                                            "translate(0,\x20" +
                                            (0xc - 0x2 * _0x5115e9) +
                                            "%)",
                                        },
                                        attrs: { disabled: "" },
                                      },
                                      [_0x52ade6["_m"](0x5, !0x0)]
                                    );
                                  }),
                                  0x0
                                ),
                                _0x52ade6["_v"]("\x20"),
                                _0x388a84(
                                  _0x388992(0x393),
                                  { staticClass: _0x388992(0x138) },
                                  [
                                    _0x388a84(
                                      "button",
                                      { staticClass: _0x388992(0x30a) },
                                      [
                                        _0x388a84(
                                          _0x388992(0x393),
                                          {
                                            staticClass: _0x388992(0x387),
                                            staticStyle: {
                                              "--transition-time": "300ms",
                                            },
                                          },
                                          [
                                            _0x388a84(
                                              _0x388992(0x393),
                                              {
                                                class: {
                                                  content: !0x0,
                                                  "stake-1wtyksp": !0x0,
                                                  "face-down":
                                                    _0x52ade6[
                                                      "currentFaceDown"
                                                    ],
                                                },
                                                style: {
                                                  width: _0x388992(0x299),
                                                  height: _0x388992(0x28b),
                                                  "--transition-time":
                                                    _0x52ade6[_0x388992(0x23a)],
                                                },
                                              },
                                              [
                                                _0x388a84(
                                                  _0x388992(0x393),
                                                  {
                                                    class:
                                                      ((_0x39baad = {
                                                        face: !0x0,
                                                      }),
                                                      Object(_0x29dcfc["a"])(
                                                        _0x39baad,
                                                        _0x52ade6[
                                                          _0x388992(0x13f)
                                                        ],
                                                        !0x0
                                                      ),
                                                      Object(_0x29dcfc["a"])(
                                                        _0x39baad,
                                                        _0x388992(0x1d7),
                                                        !0x0
                                                      ),
                                                      _0x39baad),
                                                  },
                                                  [
                                                    _0x388a84(
                                                      _0x388992(0x393),
                                                      {
                                                        staticClass:
                                                          _0x388992(0x165),
                                                        style: {
                                                          color:
                                                            "red" ==
                                                            _0x52ade6[
                                                              _0x388992(0x2a2)
                                                            ][_0x388992(0x1f5)]
                                                              ? _0x388992(0x2f9)
                                                              : "#252e48",
                                                        },
                                                      },
                                                      [
                                                        _0x388a84(
                                                          _0x388992(0x126),
                                                          [
                                                            _0x52ade6["_v"](
                                                              _0x52ade6["_s"](
                                                                _0x52ade6[
                                                                  "currentCard"
                                                                ]["rank"]
                                                              )
                                                            ),
                                                          ]
                                                        ),
                                                        _0x52ade6["_v"]("\x20"),
                                                        _0x388a84("v-icon", {
                                                          attrs: {
                                                            icon: _0x52ade6[
                                                              _0x388992(0x2a2)
                                                            ][_0x388992(0x228)],
                                                          },
                                                        }),
                                                      ],
                                                      0x1
                                                    ),
                                                  ]
                                                ),
                                                _0x52ade6["_v"]("\x20"),
                                                _0x388a84(_0x388992(0x393), {
                                                  staticClass: _0x388992(0x21f),
                                                }),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _0x52ade6["_v"]("\x20"),
                                _0x388a84(
                                  _0x388992(0x393),
                                  {
                                    class: Object(_0x29dcfc["a"])(
                                      {
                                        "prev-card": !0x0,
                                        "stake-1xp6zc8": !0x0,
                                      },
                                      _0x52ade6[_0x388992(0x163)],
                                      !0x0
                                    ),
                                    staticStyle: {
                                      "--duration": _0x388992(0x137),
                                    },
                                  },
                                  [
                                    _0x388a84(
                                      _0x388992(0x22c),
                                      {
                                        staticClass: _0x388992(0x30a),
                                        attrs: { disabled: "" },
                                      },
                                      [
                                        _0x388a84(
                                          _0x388992(0x393),
                                          {
                                            staticClass:
                                              "horizontal\x20stake-1wtyksp",
                                            staticStyle: {
                                              "--transition-time":
                                                _0x388992(0x3da),
                                            },
                                          },
                                          [
                                            _0x388a84(
                                              "div",
                                              {
                                                class: {
                                                  content: !0x0,
                                                  "stake-1wtyksp": !0x0,
                                                  "face-down":
                                                    _0x52ade6[_0x388992(0x2ee)],
                                                },
                                                staticStyle: {
                                                  width: _0x388992(0x299),
                                                  height: _0x388992(0x28b),
                                                  "--transition-time":
                                                    _0x388992(0x3da),
                                                },
                                              },
                                              [
                                                _0x388a84(
                                                  _0x388992(0x393),
                                                  {
                                                    staticClass:
                                                      _0x388992(0x37b),
                                                  },
                                                  [
                                                    _0x388a84(
                                                      _0x388992(0x393),
                                                      {
                                                        staticClass:
                                                          _0x388992(0x165),
                                                        style: {
                                                          color:
                                                            _0x388992(0x41c) ==
                                                            _0x52ade6[
                                                              _0x388992(0x3bd)
                                                            ][_0x388992(0x1f5)]
                                                              ? "#fe2247"
                                                              : _0x388992(
                                                                  0x244
                                                                ),
                                                        },
                                                      },
                                                      [
                                                        _0x388a84("span", [
                                                          _0x52ade6["_v"](
                                                            _0x52ade6["_s"](
                                                              _0x52ade6[
                                                                _0x388992(0x3bd)
                                                              ]["rank"]
                                                            )
                                                          ),
                                                        ]),
                                                        _0x52ade6["_v"]("\x20"),
                                                        _0x388a84(
                                                          _0x388992(0x3ba),
                                                          {
                                                            attrs: {
                                                              icon: _0x52ade6[
                                                                "prevCard"
                                                              ][
                                                                _0x388992(0x228)
                                                              ],
                                                            },
                                                          }
                                                        ),
                                                      ],
                                                      0x1
                                                    ),
                                                  ]
                                                ),
                                                _0x52ade6["_v"]("\x20"),
                                                _0x388a84(_0x388992(0x393), {
                                                  staticClass: _0x388992(0x21f),
                                                }),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                                _0x52ade6["_v"]("\x20"),
                                _0x388a84(
                                  "div",
                                  { staticClass: _0x388992(0x297) },
                                  [
                                    _0x388a84(
                                      _0x388992(0x22c),
                                      {
                                        staticClass: _0x388992(0x31c),
                                        attrs: {
                                          disabled: _0x52ade6[_0x388992(0x213)],
                                        },
                                        on: {
                                          click: _0x52ade6[_0x388992(0x3eb)],
                                        },
                                      },
                                      [
                                        _0x388a84(
                                          _0x388992(0x126),
                                          {
                                            staticClass:
                                              "content-or-loader\x20stake-1uofbko",
                                          },
                                          [
                                            _0x388a84(_0x388992(0x3ba), {
                                              attrs: {
                                                icon: "fa-solid\x20fa-chevrons-right\x20fa-sm",
                                              },
                                            }),
                                          ],
                                          0x1
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]),
                        ]
                      ),
                      _0x52ade6["_v"]("\x20"),
                      _0x388a84(
                        _0x388992(0x393),
                        { staticClass: _0x388992(0x3d4) },
                        [
                          _0x388a84(
                            _0x388992(0x393),
                            { staticClass: _0x388992(0x3c0) },
                            [
                              _0x388a84(
                                "label",
                                { staticClass: _0x388992(0x218) },
                                [
                                  _0x388a84(
                                    _0x388992(0x393),
                                    {
                                      staticClass:
                                        "input-wrap\x20stake-17q8hbc",
                                    },
                                    [
                                      _0x388a84(
                                        _0x388992(0x393),
                                        { staticClass: _0x388992(0x39d) },
                                        [
                                          _0x388a84(
                                            "div",
                                            { staticClass: _0x388992(0x14f) },
                                            [
                                              _0x388a84(_0x388992(0x3ba), {
                                                style: {
                                                  color: _0x388992(0x279),
                                                },
                                                attrs: {
                                                  icon: _0x388992(0x1c4),
                                                },
                                              }),
                                            ],
                                            0x1
                                          ),
                                          _0x52ade6["_v"]("\x20"),
                                          _0x388a84(
                                            _0x388992(0x393),
                                            { staticClass: _0x388992(0x151) },
                                            [
                                              _0x388a84(_0x388992(0x275), [
                                                _0x52ade6["_v"]("원"),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x52ade6["_v"]("\x20"),
                                          _0x388a84(_0x388992(0x3d5), {
                                            staticClass: _0x388992(0x33c),
                                            attrs: {
                                              autocomplete: "off",
                                              readonly: "",
                                              type: _0x388992(0x11a),
                                            },
                                            domProps: {
                                              value:
                                                _0x52ade6["profitAmount"][
                                                  _0x388992(0x240)
                                                ],
                                            },
                                          }),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(
                                    _0x388992(0x393),
                                    {
                                      staticClass: _0x388992(0x2e7),
                                      attrs: { slot: _0x388992(0x1be) },
                                      slot: _0x388992(0x1be),
                                    },
                                    [
                                      _0x388a84(
                                        "span",
                                        { staticClass: _0x388992(0x231) },
                                        [
                                          _0x388a84(
                                            "span",
                                            {
                                              attrs: { slot: _0x388992(0x12b) },
                                              slot: _0x388992(0x12b),
                                            },
                                            [
                                              _0x52ade6["_v"](
                                                _0x388992(0x1b2) +
                                                  _0x52ade6["_s"](
                                                    _0x52ade6["payout"][
                                                      _0x388992(0x240)
                                                    ][_0x388992(0x1fd)](0x2)
                                                  ) +
                                                  "×)"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                          _0x52ade6["_v"]("\x20"),
                          _0x388a84(
                            _0x388992(0x393),
                            { staticClass: "profit\x20stake-5v1hdl" },
                            [
                              _0x388a84(
                                _0x388992(0x12b),
                                { staticClass: _0x388992(0x218) },
                                [
                                  _0x388a84(
                                    _0x388992(0x393),
                                    {
                                      staticClass:
                                        "input-wrap\x20stake-17q8hbc",
                                    },
                                    [
                                      _0x388a84(
                                        _0x388992(0x393),
                                        { staticClass: _0x388992(0x39d) },
                                        [
                                          _0x388a84(
                                            "div",
                                            {
                                              staticClass:
                                                "before-icon\x20stake-17q8hbc",
                                            },
                                            [
                                              _0x388a84(_0x388992(0x3ba), {
                                                style: {
                                                  color: _0x388992(0x1df),
                                                },
                                                attrs: {
                                                  icon: _0x388992(0x26f),
                                                },
                                              }),
                                            ],
                                            0x1
                                          ),
                                          _0x52ade6["_v"]("\x20"),
                                          _0x388a84(
                                            "div",
                                            { staticClass: _0x388992(0x151) },
                                            [
                                              _0x388a84(_0x388992(0x275), [
                                                _0x52ade6["_v"]("원"),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x52ade6["_v"]("\x20"),
                                          _0x388a84(_0x388992(0x3d5), {
                                            staticClass: _0x388992(0x33c),
                                            attrs: {
                                              autocomplete: "off",
                                              readonly: "",
                                              type: _0x388992(0x11a),
                                            },
                                            domProps: {
                                              value:
                                                _0x52ade6[_0x388992(0x2fc)][
                                                  _0x388992(0x33b)
                                                ],
                                            },
                                          }),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(
                                    "div",
                                    {
                                      staticClass: _0x388992(0x2e7),
                                      attrs: { slot: _0x388992(0x1be) },
                                      slot: _0x388992(0x1be),
                                    },
                                    [
                                      _0x388a84(
                                        "span",
                                        {
                                          staticClass:
                                            "label-content\x20full-width\x20stake-5ecfln",
                                        },
                                        [
                                          _0x388a84(
                                            _0x388992(0x126),
                                            {
                                              attrs: { slot: _0x388992(0x12b) },
                                              slot: "label",
                                            },
                                            [
                                              _0x52ade6["_v"](
                                                _0x388992(0x365) +
                                                  _0x52ade6["_s"](
                                                    _0x52ade6["payout"][
                                                      _0x388992(0x33b)
                                                    ]["toFixed"](0x2)
                                                  ) +
                                                  "×)"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                          _0x52ade6["_v"]("\x20"),
                          _0x388a84(
                            _0x388992(0x393),
                            { staticClass: _0x388992(0x3c0) },
                            [
                              _0x388a84(
                                "label",
                                { staticClass: _0x388992(0x218) },
                                [
                                  _0x388a84(
                                    _0x388992(0x393),
                                    { staticClass: _0x388992(0x3b1) },
                                    [
                                      _0x388a84(
                                        _0x388992(0x393),
                                        {
                                          staticClass:
                                            "input-content\x20stake-17q8hbc",
                                        },
                                        [
                                          _0x388a84(
                                            _0x388992(0x393),
                                            { staticClass: _0x388992(0x151) },
                                            [
                                              _0x388a84("v-text", [
                                                _0x52ade6["_v"]("원"),
                                              ]),
                                            ],
                                            0x1
                                          ),
                                          _0x52ade6["_v"]("\x20"),
                                          _0x388a84(_0x388992(0x3d5), {
                                            staticClass: _0x388992(0x2c0),
                                            attrs: {
                                              autocomplete: _0x388992(0x164),
                                              readonly: "",
                                              type: _0x388992(0x11a),
                                            },
                                            domProps: {
                                              value:
                                                _0x52ade6[_0x388992(0x2fc)][
                                                  _0x388992(0x32f)
                                                ],
                                            },
                                          }),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(
                                    _0x388992(0x393),
                                    {
                                      staticClass: _0x388992(0x2e7),
                                      attrs: { slot: "label-content" },
                                      slot: _0x388992(0x1be),
                                    },
                                    [
                                      _0x388a84(
                                        _0x388992(0x126),
                                        { staticClass: _0x388992(0x231) },
                                        [
                                          _0x388a84(
                                            _0x388992(0x126),
                                            {
                                              attrs: { slot: "label" },
                                              slot: _0x388992(0x12b),
                                            },
                                            [
                                              _0x52ade6["_v"](
                                                _0x388992(0x26b) +
                                                  _0x52ade6["_s"](
                                                    _0x52ade6[
                                                      "totalPayoutMultiplier"
                                                    ][_0x388992(0x1fd)](0x2)
                                                  ) +
                                                  "×)"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                      _0x52ade6["_v"]("\x20"),
                      _0x388a84(
                        _0x388992(0x393),
                        {
                          staticClass: _0x388992(0x189),
                          staticStyle: { "font-size": _0x388992(0x1b9) },
                          attrs: { id: _0x388992(0x381) },
                        },
                        [
                          _0x388a84(
                            _0x388992(0x393),
                            {
                              class: {
                                "slide-down": !0x0,
                                "stake-q9yg42": !0x0,
                                down: _0x52ade6["slideDown"],
                              },
                              staticStyle: {
                                "--slide-down-duration": _0x388992(0x3da),
                              },
                            },
                            [
                              _0x388a84(
                                _0x388992(0x393),
                                {
                                  ref: _0x388992(0x2de),
                                  class: {
                                    "slide-in": !0x0,
                                    "stake-1nq5h7m": !0x0,
                                    slide: _0x52ade6[_0x388992(0x1fa)],
                                  },
                                },
                                [
                                  _0x388a84(
                                    "button",
                                    {
                                      staticClass: _0x388992(0x30a),
                                      attrs: { disabled: "" },
                                    },
                                    [
                                      _0x388a84(
                                        _0x388992(0x393),
                                        {
                                          staticClass: _0x388992(0x387),
                                          staticStyle: {
                                            "--transition-time":
                                              _0x388992(0x3da),
                                          },
                                        },
                                        [
                                          _0x388a84(
                                            _0x388992(0x393),
                                            {
                                              staticClass: _0x388992(0x408),
                                              staticStyle: {
                                                width: "5em",
                                                height: "7.9em",
                                                "--transition-time": "300ms",
                                              },
                                            },
                                            [
                                              _0x388a84(
                                                "div",
                                                {
                                                  staticClass: _0x388992(0x37b),
                                                },
                                                [
                                                  _0x388a84(
                                                    _0x388992(0x393),
                                                    {
                                                      staticClass:
                                                        _0x388992(0x165),
                                                      style: {
                                                        color:
                                                          "red" ==
                                                          _0x52ade6[
                                                            _0x388992(0x2de)
                                                          ]["color"]
                                                            ? "#fe2247"
                                                            : _0x388992(0x244),
                                                      },
                                                    },
                                                    [
                                                      _0x388a84("span", [
                                                        _0x52ade6["_v"](
                                                          _0x52ade6["_s"](
                                                            _0x52ade6[
                                                              _0x388992(0x2de)
                                                            ]["rank"]
                                                          )
                                                        ),
                                                      ]),
                                                      _0x52ade6["_v"]("\x20"),
                                                      _0x388a84(
                                                        _0x388992(0x3ba),
                                                        {
                                                          attrs: {
                                                            icon: _0x52ade6[
                                                              _0x388992(0x2de)
                                                            ][_0x388992(0x228)],
                                                          },
                                                        }
                                                      ),
                                                    ],
                                                    0x1
                                                  ),
                                                ]
                                              ),
                                              _0x52ade6["_v"]("\x20"),
                                              _0x388a84(_0x388992(0x393), {
                                                staticClass: _0x388992(0x21f),
                                              }),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(
                                    _0x388992(0x393),
                                    { staticClass: _0x388992(0x21e) },
                                    [_0x52ade6["_v"](_0x388992(0x247))]
                                  ),
                                ]
                              ),
                              _0x52ade6["_v"]("\x20"),
                              _0x52ade6["_l"](
                                _0x52ade6[_0x388992(0x2c1)],
                                function (_0x33e4bc, _0x592dc6) {
                                  var _0x808b2d = _0x388992,
                                    _0x37a55f,
                                    _0xd97a79;
                                  return _0x388a84(
                                    _0x808b2d(0x393),
                                    {
                                      ref: "historyCard-" + _0x592dc6,
                                      refInFor: !0x0,
                                      class: {
                                        "slide-in": !0x0,
                                        "stake-1nq5h7m": !0x0,
                                        slide:
                                          _0x592dc6 ==
                                            _0x52ade6[_0x808b2d(0x2c1)][
                                              _0x808b2d(0x21a)
                                            ] -
                                              0x1 &&
                                          _0x52ade6[_0x808b2d(0x1e7)],
                                      },
                                    },
                                    [
                                      _0x388a84(
                                        _0x808b2d(0x22c),
                                        {
                                          staticClass: _0x808b2d(0x30a),
                                          style: {
                                            opacity:
                                              _0x52ade6[_0x808b2d(0x15b)][
                                                _0x592dc6
                                              ][_0x808b2d(0x26c)],
                                          },
                                          attrs: { disabled: "" },
                                        },
                                        [
                                          _0x388a84(
                                            "div",
                                            {
                                              staticClass: _0x808b2d(0x387),
                                              staticStyle: {
                                                "--transition-time": "300ms",
                                              },
                                            },
                                            [
                                              _0x388a84(
                                                _0x808b2d(0x393),
                                                {
                                                  class: {
                                                    content: !0x0,
                                                    "stake-1wtyksp": !0x0,
                                                    "face-down":
                                                      _0x592dc6 ==
                                                        _0x52ade6[
                                                          "cardHistory"
                                                        ]["length"] -
                                                          0x1 &&
                                                      _0x52ade6[
                                                        _0x808b2d(0x378)
                                                      ],
                                                  },
                                                  staticStyle: {
                                                    width: _0x808b2d(0x299),
                                                    height: _0x808b2d(0x28b),
                                                    "--transition-time":
                                                      _0x808b2d(0x3da),
                                                  },
                                                },
                                                [
                                                  _0x388a84(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        _0x808b2d(0x37b),
                                                    },
                                                    [
                                                      _0x388a84(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "face-content\x20stake-soy9i6",
                                                          style: {
                                                            color:
                                                              _0x808b2d(
                                                                0x41c
                                                              ) ==
                                                              _0x33e4bc[
                                                                _0x808b2d(0x1f5)
                                                              ]
                                                                ? _0x808b2d(
                                                                    0x2f9
                                                                  )
                                                                : "#252e48",
                                                          },
                                                        },
                                                        [
                                                          _0x388a84("span", [
                                                            _0x52ade6["_v"](
                                                              _0x52ade6["_s"](
                                                                _0x33e4bc[
                                                                  _0x808b2d(
                                                                    0x3d7
                                                                  )
                                                                ]
                                                              )
                                                            ),
                                                          ]),
                                                          _0x52ade6["_v"](
                                                            "\x20"
                                                          ),
                                                          _0x388a84(
                                                            _0x808b2d(0x3ba),
                                                            {
                                                              attrs: {
                                                                icon: _0x33e4bc[
                                                                  "icon"
                                                                ],
                                                              },
                                                            }
                                                          ),
                                                        ],
                                                        0x1
                                                      ),
                                                    ]
                                                  ),
                                                  _0x52ade6["_v"]("\x20"),
                                                  _0x388a84(_0x808b2d(0x393), {
                                                    staticClass:
                                                      _0x808b2d(0x21f),
                                                  }),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _0x52ade6["_v"]("\x20"),
                                      _0x388a84(
                                        "div",
                                        {
                                          class:
                                            ((_0x37a55f = { guess: !0x0 }),
                                            Object(_0x29dcfc["a"])(
                                              _0x37a55f,
                                              _0x52ade6[_0x808b2d(0x15b)][
                                                _0x592dc6
                                              ][_0x808b2d(0x155)],
                                              !0x0
                                            ),
                                            Object(_0x29dcfc["a"])(
                                              _0x37a55f,
                                              _0x808b2d(0x245),
                                              !0x0
                                            ),
                                            _0x37a55f),
                                        },
                                        [
                                          _0x388a84(_0x808b2d(0x3ba), {
                                            attrs: {
                                              icon: _0x52ade6[_0x808b2d(0x15b)][
                                                _0x592dc6
                                              ][_0x808b2d(0x228)],
                                            },
                                          }),
                                        ],
                                        0x1
                                      ),
                                      _0x52ade6["_v"]("\x20"),
                                      _0x388a84(
                                        "div",
                                        {
                                          class:
                                            ((_0xd97a79 = {
                                              "payout-multiplier": !0x0,
                                            }),
                                            Object(_0x29dcfc["a"])(
                                              _0xd97a79,
                                              _0x33e4bc["class"],
                                              !0x0
                                            ),
                                            Object(_0x29dcfc["a"])(
                                              _0xd97a79,
                                              "stake-1nq5h7m",
                                              !0x0
                                            ),
                                            _0xd97a79),
                                        },
                                        [
                                          _0x52ade6["_v"](
                                            "\x0a\x09\x09\x09\x09\x09\x09" +
                                              _0x52ade6["_s"](
                                                _0x33e4bc["multiplier"][
                                                  _0x808b2d(0x1fd)
                                                ](0x2) + "x"
                                              )
                                          ),
                                        ]
                                      ),
                                    ]
                                  );
                                }
                              ),
                            ],
                            0x2
                          ),
                        ]
                      ),
                      _0x52ade6["_v"]("\x20"),
                      _0x52ade6[_0x388992(0x350)]
                        ? _0x388a84(
                            "div",
                            {
                              staticClass: _0x388992(0x135),
                              staticStyle: { "--duration": "300ms" },
                            },
                            [
                              _0x388a84(
                                _0x388992(0x393),
                                { staticClass: _0x388992(0x3e2) },
                                [
                                  _0x388a84(
                                    "span",
                                    { staticClass: _0x388992(0x2c9) },
                                    [
                                      _0x388a84(
                                        _0x388992(0x126),
                                        {
                                          staticClass:
                                            "weight-bold\x20line-height-default\x20align-left\x20size-default\x20text-size-default\x20variant-success\x20numeric\x20with-icon-space\x20stake-129khay",
                                        },
                                        [
                                          _0x52ade6["_v"](
                                            _0x52ade6["_s"](
                                              _0x52ade6[_0x388992(0x255)][
                                                "toFixed"
                                              ](0x2)
                                            ) + "×"
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(_0x388992(0x393), {
                                    staticClass: _0x388992(0x27b),
                                  }),
                                  _0x52ade6["_v"]("\x20"),
                                  _0x388a84(
                                    _0x388992(0x393),
                                    { staticClass: "currency\x20stake-z4ax21" },
                                    [
                                      _0x388a84(
                                        "span",
                                        { staticClass: _0x388992(0x22b) },
                                        [
                                          _0x388a84(
                                            _0x388992(0x126),
                                            {
                                              staticClass: _0x388992(0x3b7),
                                              staticStyle: {
                                                "max-width": _0x388992(0x3de),
                                              },
                                            },
                                            [
                                              _0x52ade6["_v"](
                                                _0x52ade6["_s"](
                                                  Math[_0x388992(0x127)](
                                                    _0x52ade6[_0x388992(0x2bb)][
                                                      "total"
                                                    ] || 0x0
                                                  )[_0x388992(0x1fc)]()
                                                ) + "원"
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _0x52ade6["_v"]("\x20"),
                                      _0x388a84(_0x388992(0x126), {
                                        staticClass: _0x388992(0x3e8),
                                        staticStyle: { "max-width": "12ch" },
                                      }),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          )
                        : _0x52ade6["_e"](),
                    ]
                  ),
                ]
              );
            },
            _0x2a4c30,
            !0x1,
            null,
            _0x5b07a8(0x3a4),
            null
          );
        _0x2abb9c["a"] = _0x5cc73e[_0x5b07a8(0x13e)];
      },
      0x1ff: function (_0x428ec7, _0x5dcbe0, _0x1f71c7) {
        "use strict";
        var _0x2917c6 = a16_0x295903;
        _0x1f71c7(0xc),
          _0x1f71c7(0xa),
          _0x1f71c7(0xb),
          _0x1f71c7(0x10),
          _0x1f71c7(0xd),
          _0x1f71c7(0x11);
        var _0x315b41 = _0x1f71c7(0x2),
          _0xa808ea =
            (_0x1f71c7(0xac),
            _0x1f71c7(0x8),
            _0x1f71c7(0xd8),
            _0x1f71c7(0xd9),
            _0x1f71c7(0xda),
            _0x1f71c7(0xdb),
            _0x1f71c7(0xdc),
            _0x1f71c7(0xdd),
            _0x1f71c7(0xde),
            _0x1f71c7(0xdf),
            _0x1f71c7(0xe0),
            _0x1f71c7(0xe1),
            _0x1f71c7(0xe2),
            _0x1f71c7(0xe3),
            _0x1f71c7(0xe4),
            _0x1f71c7(0xe5),
            _0x1f71c7(0xe6),
            _0x1f71c7(0xe7),
            _0x1f71c7(0xe8),
            _0x1f71c7(0xe9),
            _0x1f71c7(0xea),
            _0x1f71c7(0xeb),
            _0x1f71c7(0xec),
            _0x1f71c7(0xed),
            _0x1f71c7(0xee),
            _0x1f71c7(0xef),
            _0x1f71c7(0x3)),
          _0x1fd0d0 = _0x1f71c7(0x93);
        function _0x3c590b(_0x2601ef, _0x538dcb) {
          var _0x1103f0 = a16_0x269f,
            _0x230eea = Object[_0x1103f0(0x376)](_0x2601ef);
          if (Object[_0x1103f0(0x221)]) {
            var _0x44c269 = Object["getOwnPropertySymbols"](_0x2601ef);
            _0x538dcb &&
              (_0x44c269 = _0x44c269["filter"](function (_0x3192a5) {
                var _0x46f2d3 = _0x1103f0;
                return Object[_0x46f2d3(0x39e)](
                  _0x2601ef,
                  _0x3192a5
                )[_0x46f2d3(0x25b)];
              })),
              _0x230eea[_0x1103f0(0x22a)][_0x1103f0(0x143)](
                _0x230eea,
                _0x44c269
              );
          }
          return _0x230eea;
        }
        function _0x3696e7(_0x4ecd2b) {
          var _0x1843a9 = a16_0x269f;
          for (
            var _0x33a8d5 = 0x1;
            _0x33a8d5 < arguments[_0x1843a9(0x21a)];
            _0x33a8d5++
          ) {
            var _0x2f9dd7 =
              null != arguments[_0x33a8d5] ? arguments[_0x33a8d5] : {};
            _0x33a8d5 % 0x2
              ? _0x3c590b(Object(_0x2f9dd7), !0x0)[_0x1843a9(0x160)](function (
                  _0x211583
                ) {
                  Object(_0x315b41["a"])(
                    _0x4ecd2b,
                    _0x211583,
                    _0x2f9dd7[_0x211583]
                  );
                })
              : Object[_0x1843a9(0x2fb)]
              ? Object[_0x1843a9(0x2b5)](
                  _0x4ecd2b,
                  Object["getOwnPropertyDescriptors"](_0x2f9dd7)
                )
              : _0x3c590b(Object(_0x2f9dd7))[_0x1843a9(0x160)](function (
                  _0x5adb98
                ) {
                  var _0x3f9ae4 = _0x1843a9;
                  Object[_0x3f9ae4(0x418)](
                    _0x4ecd2b,
                    _0x5adb98,
                    Object[_0x3f9ae4(0x39e)](_0x2f9dd7, _0x5adb98)
                  );
                });
          }
          return _0x4ecd2b;
        }
        var _0x3abebd = {
            name: _0x2917c6(0x411),
            data: function () {
              var _0x5be756 = _0x2917c6;
              return {
                isManual: !0x0,
                isControl: !0x0,
                isDisabled: !0x1,
                isAutobet: !0x1,
                isNextbet: !0x1,
                isCurrentBet: !0x1,
                isAutobetFinsihing: !0x1,
                bet_label: _0x5be756(0x173),
                cancel_label: _0x5be756(0x1f8),
                autobet_label: "Start\x20Autobet",
                profit: 0x0,
                loss: 0x0,
                autobetcount: 0x0,
                multiplier: 0x2,
                isCashout: !0x1,
              };
            },
            computed: _0x3696e7(
              {},
              Object(_0xa808ea["c"])(_0x2917c6(0x30d), [
                "getCrashGameState",
                _0x2917c6(0x415),
                "getCrashNextBet",
                _0x2917c6(0x18e),
                _0x2917c6(0x36a),
                _0x2917c6(0x3e0),
                "getCrashLeaderboard",
                _0x2917c6(0x31e),
              ])
            ),
            mounted: function () {},
            filters: {
              formatNumber: function (_0x18bd60) {
                var _0x2117dc = _0x2917c6;
                if (null === _0x18bd60) return _0x2117dc(0x24a);
                var _0x406a87 = _0x18bd60 + "";
                if (_0x406a87[_0x2117dc(0x2c7)]("e") < 0x0) {
                  var _0x1a9853 = _0x406a87[_0x2117dc(0x2f4)](".");
                  0x1 == _0x1a9853[_0x2117dc(0x21a)]
                    ? (_0x406a87 += _0x2117dc(0x41b))
                    : 0x2 == _0x1a9853[_0x2117dc(0x21a)] &&
                      0x1 == _0x1a9853[0x1]["length"] &&
                      (_0x406a87 += "0");
                }
                return _0x406a87;
              },
              formatBetNumber: function (_0x234828) {
                var _0x1b14fa = _0x2917c6;
                if (null === _0x234828) return "-";
                var _0x1468bd = _0x234828 + "";
                if (_0x1468bd[_0x1b14fa(0x2c7)]("e") < 0x0) {
                  var _0x56e6ee = _0x1468bd["split"](".");
                  0x1 == _0x56e6ee[_0x1b14fa(0x21a)]
                    ? (_0x1468bd += _0x1b14fa(0x41b))
                    : 0x2 == _0x56e6ee[_0x1b14fa(0x21a)] &&
                      0x1 == _0x56e6ee[0x1]["length"] &&
                      (_0x1468bd += "0");
                }
                return _0x1468bd + "x";
              },
            },
            watch: {
              getCurrentMultiplier: function (_0x3cbb1d) {
                var _0x392075 = _0x2917c6,
                  _0x567d19 = Math[_0x392075(0x3ed)](_0x3cbb1d);
                this[_0x392075(0x3a2)][_0x392075(0x2c3)]["$refs"]["v"][
                  _0x392075(0x2b2)
                ] =
                  _0x567d19 *
                  this[_0x392075(0x3a2)][_0x392075(0x2bf)][_0x392075(0x3a2)][
                    "v"
                  ][_0x392075(0x2b2)];
              },
              getCrashGameState: function (_0x47053a) {
                var _0x642c01 = _0x2917c6;
                switch (_0x47053a) {
                  case "waiting":
                    (!0x0 !== this["isAutobet"] &&
                      !0x0 !== this[_0x642c01(0x414)]) ||
                      this[_0x642c01(0x40c)]();
                    break;
                  case _0x642c01(0x12e):
                    (this[_0x642c01(0x195)] = !0x1),
                      !0x0 === this[_0x642c01(0x375)] &&
                        (this["$refs"][_0x642c01(0x27a)]["$refs"]["v"][
                          _0x642c01(0x2b2)
                        ] > 0x0 &&
                          this[_0x642c01(0x2ef)] >=
                            this["$refs"][_0x642c01(0x27a)][_0x642c01(0x3a2)][
                              "v"
                            ]["value"] &&
                          (this[_0x642c01(0x375)] = !0x1),
                        this[_0x642c01(0x3a2)][_0x642c01(0x416)][
                          _0x642c01(0x3a2)
                        ]["v"][_0x642c01(0x2b2)] > 0x0 &&
                          this[_0x642c01(0x1f1)] - this[_0x642c01(0x3dd)] >=
                            this[_0x642c01(0x3a2)]["stopProfit"][
                              _0x642c01(0x3a2)
                            ]["v"][_0x642c01(0x2b2)] &&
                          (this[_0x642c01(0x375)] = !0x1),
                        this[_0x642c01(0x3a2)][_0x642c01(0x132)][
                          _0x642c01(0x3a2)
                        ]["v"][_0x642c01(0x2b2)] > 0x0 &&
                          this[_0x642c01(0x3dd)] - this[_0x642c01(0x1f1)] >=
                            this[_0x642c01(0x3a2)][_0x642c01(0x132)][
                              _0x642c01(0x3a2)
                            ]["v"][_0x642c01(0x2b2)] &&
                          (this[_0x642c01(0x375)] = !0x1),
                        this["autobetcount"]++,
                        !0x0 === this[_0x642c01(0x232)] &&
                        this[_0x642c01(0x1bb)] >= this[_0x642c01(0x31e)] &&
                        Math[_0x642c01(0x3ed)](this[_0x642c01(0x31e)]) ===
                          Math[_0x642c01(0x3ed)](
                            this["getCurrentMultiplier"] - 0.5
                          )
                          ? ((this[_0x642c01(0x1f1)] +=
                              (Math["round"](this[_0x642c01(0x31e)]) - 0x1) *
                              this[_0x642c01(0x3a2)][_0x642c01(0x2bf)][
                                _0x642c01(0x3a2)
                              ]["v"]["value"]),
                            (this[_0x642c01(0x232)] = !0x1))
                          : this[_0x642c01(0x31e)] >= this[_0x642c01(0x1bb)]
                          ? (this["profit"] +=
                              (this[_0x642c01(0x1bb)] - 0x1) *
                              this["$refs"][_0x642c01(0x2bf)][_0x642c01(0x3a2)][
                                "v"
                              ][_0x642c01(0x2b2)])
                          : (this[_0x642c01(0x3dd)] -=
                              this[_0x642c01(0x3a2)][_0x642c01(0x2bf)][
                                _0x642c01(0x3a2)
                              ]["v"]["value"])),
                      !0x1 === this[_0x642c01(0x375)] &&
                        (this["autocount"] = 0x0);
                }
              },
            },
            methods: _0x3696e7(
              _0x3696e7(
                {},
                Object(_0xa808ea["b"])("crash", [
                  _0x2917c6(0x1fb),
                  _0x2917c6(0x2b7),
                  _0x2917c6(0x394),
                  _0x2917c6(0x265),
                  "setCrashNumbers",
                  "setCrashLeaderboard",
                  _0x2917c6(0x2ab),
                  _0x2917c6(0x3f3),
                  "setCrashAutoBet",
                  _0x2917c6(0x11b),
                  _0x2917c6(0x30c),
                  _0x2917c6(0x1eb),
                  _0x2917c6(0x166),
                  _0x2917c6(0x3b4),
                  _0x2917c6(0x34d),
                ])
              ),
              {},
              {
                halfAmount: function () {
                  var _0x50ffac = _0x2917c6;
                  this["$refs"][_0x50ffac(0x2bf)]["$refs"]["v"][
                    _0x50ffac(0x2b2)
                  ] =
                    this["$refs"][_0x50ffac(0x2bf)][_0x50ffac(0x3a2)]["v"][
                      "value"
                    ] / 0x2;
                },
                multipleAmount: function () {
                  var _0x1b648d = _0x2917c6;
                  this[_0x1b648d(0x3a2)][_0x1b648d(0x2bf)][_0x1b648d(0x3a2)][
                    "v"
                  ][_0x1b648d(0x2b2)] =
                    0x2 *
                    this[_0x1b648d(0x3a2)]["amount"][_0x1b648d(0x3a2)]["v"][
                      "value"
                    ];
                },
                toggleMaunal: function (_0x415e5a) {
                  var _0xf78e24 = _0x2917c6;
                  (this[_0xf78e24(0x3a9)] = _0x415e5a),
                    this["reorderBetlist"]();
                },
                toggleControl: function (_0x557872) {
                  var _0x5d533a = _0x2917c6;
                  (this[_0x5d533a(0x2ea)] = _0x557872),
                    this[_0x5d533a(0x335)]();
                },
                reorderBetlist: function () {
                  var _0x2eb80a = _0x2917c6;
                  this[_0x2eb80a(0x3a2)][_0x2eb80a(0x146)][_0x2eb80a(0x224)][
                    "removeProperty"
                  ]("order"),
                    0x1 == this["isManual"] || 0x1 == this[_0x2eb80a(0x2ea)]
                      ? this[_0x2eb80a(0x3a2)][_0x2eb80a(0x146)][
                          _0x2eb80a(0x224)
                        ][_0x2eb80a(0x3d1)](_0x2eb80a(0x154), "19")
                      : this[_0x2eb80a(0x3a2)][_0x2eb80a(0x146)][
                          _0x2eb80a(0x224)
                        ][_0x2eb80a(0x3d1)](_0x2eb80a(0x154), "15");
                },
                bet: function () {},
                betNextRound: function () {
                  this["isNextbet"] = !0x0;
                },
                cancel: function () {
                  var _0x589b2b = _0x2917c6;
                  this[_0x589b2b(0x414)] = !0x1;
                },
                startAutobet: function () {
                  var _0x5a19f1 = _0x2917c6;
                  (this[_0x5a19f1(0x1f1)] = 0x0),
                    (this[_0x5a19f1(0x3dd)] = 0x0),
                    (this["autobetcount"] = 0x0),
                    this[_0x5a19f1(0x2ab)](
                      this[_0x5a19f1(0x3a2)]["amount"][_0x5a19f1(0x3a2)]["v"][
                        "value"
                      ]
                    ),
                    this[_0x5a19f1(0x32a)](!0x0),
                    (this[_0x5a19f1(0x375)] = !0x0);
                },
                stopAutobet: function () {
                  var _0x57bb51 = _0x2917c6;
                  this["setCrashAutoBet"](!0x1),
                    (this[_0x57bb51(0x375)] = !0x1);
                },
                cashout: function () {
                  var _0x577786 = _0x2917c6;
                  (this[_0x577786(0x232)] = !0x0),
                    this[_0x577786(0x1fb)](_0x577786(0x291));
                },
                playBetSound: function () {
                  var _0x5e1c73 = _0x2917c6;
                  for (
                    var _0x3f7659 = Object(_0x1fd0d0["a"])(),
                      _0x57a654 = new (window["AudioContext"] ||
                        window[_0x5e1c73(0x2cb)])(),
                      _0x1ae41c = _0x57a654[_0x5e1c73(0x20d)](),
                      _0x13836c = atob(_0x3f7659[_0x5e1c73(0x2f4)](",")[0x1]),
                      _0x4823e7 = new Uint8Array(_0x13836c[_0x5e1c73(0x21a)]),
                      _0x17b01e = 0x0;
                    _0x17b01e < _0x13836c[_0x5e1c73(0x21a)];
                    ++_0x17b01e
                  )
                    _0x4823e7[_0x17b01e] =
                      _0x13836c[_0x5e1c73(0x402)](_0x17b01e);
                  _0x57a654[_0x5e1c73(0x3f2)](_0x4823e7[_0x5e1c73(0x19d)])[
                    _0x5e1c73(0x190)
                  ](function (_0x39015b) {
                    var _0x27d8e4 = _0x5e1c73;
                    (_0x1ae41c[_0x27d8e4(0x19d)] = _0x39015b),
                      _0x1ae41c[_0x27d8e4(0x181)](_0x57a654["destination"]),
                      (_0x1ae41c["loop"] = !0x1),
                      _0x1ae41c[_0x27d8e4(0x1d3)](0x0);
                  });
                },
              }
            ),
          },
          _0xef9f76 = _0x1f71c7(0x1),
          _0x97c340 = Object(_0xef9f76["a"])(
            _0x3abebd,
            function () {
              var _0x48f2c0 = _0x2917c6,
                _0x5d0301 = this,
                _0x3a2485 = _0x5d0301[_0x48f2c0(0x396)]["_c"];
              return _0x3a2485(
                "div",
                { staticClass: "game-sidebar\x20svelte-1rbkmr5" },
                [
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      staticClass:
                        "tabs-wrapper\x20scrollX\x20fullWidth\x20svelte-17cnp9o",
                      staticStyle: { order: "1" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x393),
                        { staticClass: _0x48f2c0(0x367) },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x393),
                            { staticClass: _0x48f2c0(0x21d) },
                            [
                              _0x3a2485(
                                "button",
                                {
                                  staticClass: _0x48f2c0(0x23d),
                                  class: _0x5d0301["isManual"] ? "active" : "",
                                  staticStyle: { flex: _0x48f2c0(0x12a) },
                                  attrs: {
                                    "data-analytics": "manual-bet-button",
                                  },
                                  on: {
                                    click: function (_0x442cd4) {
                                      var _0x44a49b = _0x48f2c0;
                                      return _0x5d0301[_0x44a49b(0x1f9)](!0x0);
                                    },
                                  },
                                },
                                [
                                  _0x3a2485(
                                    _0x48f2c0(0x126),
                                    { staticClass: _0x48f2c0(0x41a) },
                                    [_0x5d0301["_v"](_0x48f2c0(0x39a))]
                                  ),
                                ]
                              ),
                              _0x5d0301["_v"]("\x20"),
                              _0x3a2485(
                                _0x48f2c0(0x22c),
                                {
                                  staticClass: _0x48f2c0(0x23d),
                                  class: _0x5d0301["isManual"]
                                    ? ""
                                    : _0x48f2c0(0x2c6),
                                  staticStyle: { flex: _0x48f2c0(0x12a) },
                                  attrs: { "data-analytics": _0x48f2c0(0x340) },
                                  on: {
                                    click: function (_0xf23d4b) {
                                      var _0x28221f = _0x48f2c0;
                                      return _0x5d0301[_0x28221f(0x1f9)](!0x1);
                                    },
                                  },
                                },
                                [
                                  _0x3a2485(
                                    _0x48f2c0(0x126),
                                    {
                                      staticClass:
                                        "content-or-loader\x20svelte-1uofbko",
                                    },
                                    [_0x5d0301["_v"](_0x48f2c0(0x14a))]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value: !_0x5d0301["isManual"],
                          expression: _0x48f2c0(0x16a),
                        },
                      ],
                      staticClass: _0x48f2c0(0x139),
                      staticStyle: { order: "2" },
                    },
                    [
                      _0x3a2485(
                        "button",
                        {
                          staticClass: _0x48f2c0(0x3be),
                          class: _0x5d0301["isControl"] ? _0x48f2c0(0x2c6) : "",
                          on: {
                            click: function (_0x37074f) {
                              var _0x1cf360 = _0x48f2c0;
                              return _0x5d0301[_0x1cf360(0x17d)](!0x0);
                            },
                          },
                        },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x126),
                            { staticClass: _0x48f2c0(0x41a) },
                            [_0x5d0301["_v"](_0x48f2c0(0x28d))]
                          ),
                        ]
                      ),
                      _0x5d0301["_v"]("\x20"),
                      _0x3a2485(
                        _0x48f2c0(0x22c),
                        {
                          staticClass: _0x48f2c0(0x3be),
                          class: _0x5d0301["isControl"] ? "" : _0x48f2c0(0x2c6),
                          on: {
                            click: function (_0x7f813b) {
                              var _0x3cc46e = _0x48f2c0;
                              return _0x5d0301[_0x3cc46e(0x17d)](!0x1);
                            },
                          },
                        },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x126),
                            { staticClass: _0x48f2c0(0x41a) },
                            [_0x5d0301["_v"]("Leaderboard")]
                          ),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x12b),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301["isControl"] ||
                            _0x5d0301[_0x48f2c0(0x3a9)],
                          expression: _0x48f2c0(0x1a1),
                        },
                      ],
                      staticClass: _0x48f2c0(0x136),
                      staticStyle: { order: "3" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x393),
                        { staticClass: _0x48f2c0(0x401) },
                        [
                          _0x3a2485(_0x48f2c0(0x3d5), {
                            ref: _0x48f2c0(0x2bf),
                            attrs: {
                              disabled:
                                _0x5d0301[_0x48f2c0(0x271)] ||
                                _0x5d0301[_0x48f2c0(0x375)],
                            },
                          }),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(
                            _0x48f2c0(0x393),
                            { staticClass: _0x48f2c0(0x159) },
                            [
                              _0x3a2485(
                                _0x48f2c0(0x22c),
                                {
                                  staticClass:
                                    "variant-game\x20lineHeight-none\x20size-medium\x20spacing-input\x20weight-semibold\x20align-left\x20no-shadow\x20square\x20svelte-oho9kj",
                                  attrs: {
                                    disabled:
                                      _0x5d0301[_0x48f2c0(0x271)] ||
                                      _0x5d0301[_0x48f2c0(0x375)],
                                  },
                                  on: { click: _0x5d0301[_0x48f2c0(0x3bf)] },
                                },
                                [
                                  _0x3a2485(
                                    "span",
                                    { staticClass: _0x48f2c0(0x41a) },
                                    [_0x5d0301["_v"]("½")]
                                  ),
                                ]
                              ),
                              _0x5d0301["_v"]("\x20"),
                              _0x3a2485(
                                _0x48f2c0(0x22c),
                                {
                                  staticClass:
                                    "variant-game\x20lineHeight-none\x20size-medium\x20spacing-input\x20weight-semibold\x20align-left\x20no-shadow\x20square\x20svelte-oho9kj",
                                  attrs: {
                                    disabled:
                                      _0x5d0301[_0x48f2c0(0x271)] ||
                                      _0x5d0301[_0x48f2c0(0x375)],
                                  },
                                  on: { click: _0x5d0301[_0x48f2c0(0x227)] },
                                },
                                [
                                  _0x3a2485(
                                    "span",
                                    { staticClass: _0x48f2c0(0x41a) },
                                    [_0x5d0301["_v"]("2×")]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                      _0x5d0301["_v"]("\x20"),
                      _0x3a2485(
                        _0x48f2c0(0x126),
                        { staticClass: _0x48f2c0(0x2f6) },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x393),
                            {
                              staticClass:
                                "label-left-wrapper\x20svelte-1vu9of",
                            },
                            [
                              _0x3a2485(
                                "span",
                                {
                                  attrs: { slot: _0x48f2c0(0x12b) },
                                  slot: _0x48f2c0(0x12b),
                                },
                                [_0x5d0301["_v"](_0x48f2c0(0x324))]
                              ),
                            ]
                          ),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(
                            _0x48f2c0(0x393),
                            {
                              staticClass:
                                "currency-conversion\x20svelte-7wwe9d",
                            },
                            [_0x5d0301["_v"](_0x48f2c0(0x252))]
                          ),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301["isControl"] ||
                            _0x5d0301[_0x48f2c0(0x3a9)],
                          expression: _0x48f2c0(0x1a1),
                        },
                      ],
                      staticClass: "grid-row\x20svelte-ggem1w",
                      staticStyle: { order: "4" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x12b),
                        { staticClass: _0x48f2c0(0x136) },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x393),
                            { staticClass: _0x48f2c0(0x401) },
                            [
                              _0x3a2485(
                                "div",
                                { staticClass: _0x48f2c0(0x1ae) },
                                [
                                  _0x3a2485(
                                    _0x48f2c0(0x393),
                                    {
                                      staticClass:
                                        "after-icon\x20svelte-1vu9of",
                                    },
                                    [
                                      _0x3a2485(
                                        _0x48f2c0(0x3dc),
                                        { staticClass: _0x48f2c0(0x282) },
                                        [
                                          _0x3a2485(_0x48f2c0(0x1ef), {
                                            attrs: {
                                              "xlink:href": _0x48f2c0(0x22e),
                                            },
                                          }),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _0x5d0301["_v"]("\x20"),
                                  _0x3a2485(_0x48f2c0(0x3d5), {
                                    directives: [
                                      {
                                        name: _0x48f2c0(0x184),
                                        rawName: _0x48f2c0(0x18c),
                                        value: _0x5d0301[_0x48f2c0(0x1bb)],
                                        expression: _0x48f2c0(0x1bb),
                                      },
                                    ],
                                    staticClass:
                                      "input\x20spacing-expanded\x20input-icon-after\x20svelte-1vu9of",
                                    attrs: {
                                      disabled:
                                        _0x5d0301["isDisabled"] ||
                                        _0x5d0301[_0x48f2c0(0x375)],
                                      autocomplete: _0x48f2c0(0x164),
                                      type: _0x48f2c0(0x26a),
                                      min: "1.01",
                                      max: _0x48f2c0(0x41f),
                                    },
                                    domProps: {
                                      value: _0x5d0301[_0x48f2c0(0x1bb)],
                                    },
                                    on: {
                                      input: function (_0x3d8615) {
                                        var _0x10c31e = _0x48f2c0;
                                        _0x3d8615["target"]["composing"] ||
                                          (_0x5d0301[_0x10c31e(0x1bb)] =
                                            _0x3d8615[_0x10c31e(0x249)][
                                              _0x10c31e(0x2b2)
                                            ]);
                                      },
                                    },
                                  }),
                                ]
                              ),
                            ]
                          ),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(
                            _0x48f2c0(0x126),
                            { staticClass: _0x48f2c0(0x262) },
                            [
                              _0x3a2485(
                                _0x48f2c0(0x393),
                                {
                                  staticClass:
                                    "label-left-wrapper\x20svelte-1vu9of",
                                },
                                [
                                  _0x3a2485(
                                    _0x48f2c0(0x126),
                                    {
                                      attrs: { slot: _0x48f2c0(0x12b) },
                                      slot: _0x48f2c0(0x12b),
                                    },
                                    [_0x5d0301["_v"](_0x48f2c0(0x39b))]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                      _0x5d0301["_v"]("\x20"),
                      _0x3a2485(
                        _0x48f2c0(0x12b),
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: !_0x5d0301[_0x48f2c0(0x3a9)],
                              expression: _0x48f2c0(0x16a),
                            },
                          ],
                          staticClass: _0x48f2c0(0x136),
                        },
                        [
                          _0x3a2485(_0x48f2c0(0x3d5), {
                            ref: _0x48f2c0(0x27a),
                            attrs: {
                              disabled:
                                _0x5d0301[_0x48f2c0(0x271)] ||
                                _0x5d0301["isAutobet"],
                            },
                          }),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(
                            _0x48f2c0(0x126),
                            { staticClass: _0x48f2c0(0x262) },
                            [
                              _0x3a2485(
                                _0x48f2c0(0x393),
                                { staticClass: _0x48f2c0(0x1f3) },
                                [
                                  _0x3a2485(
                                    _0x48f2c0(0x393),
                                    { attrs: { slot: "label" }, slot: "label" },
                                    [
                                      _0x3a2485(_0x48f2c0(0x126), [
                                        _0x5d0301["_v"](_0x48f2c0(0x40b)),
                                      ]),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value:
                            !_0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x5d0301["isControl"],
                          expression: _0x48f2c0(0x413),
                        },
                      ],
                      staticClass: _0x48f2c0(0x122),
                      staticStyle: { order: "5" },
                    },
                    [
                      _0x3a2485(_0x48f2c0(0x3d5), {
                        attrs: {
                          disabled:
                            _0x5d0301[_0x48f2c0(0x271)] ||
                            _0x5d0301["isAutobet"],
                        },
                      }),
                      _0x5d0301["_v"]("\x20"),
                      _0x3a2485(
                        _0x48f2c0(0x126),
                        { staticClass: _0x48f2c0(0x3a3) },
                        [_0x5d0301["_v"](_0x48f2c0(0x1bd))]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            !_0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x5d0301["isControl"],
                          expression: _0x48f2c0(0x413),
                        },
                      ],
                      staticClass: _0x48f2c0(0x122),
                      staticStyle: { order: "6" },
                    },
                    [
                      _0x3a2485(_0x48f2c0(0x3d5), {
                        attrs: {
                          disabled:
                            _0x5d0301["isDisabled"] ||
                            _0x5d0301[_0x48f2c0(0x375)],
                        },
                      }),
                      _0x5d0301["_v"]("\x20"),
                      _0x3a2485(
                        _0x48f2c0(0x126),
                        { staticClass: _0x48f2c0(0x3a3) },
                        [_0x5d0301["_v"](_0x48f2c0(0x2f3))]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    "div",
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: "v-show",
                          value:
                            !_0x5d0301["isManual"] &&
                            _0x5d0301[_0x48f2c0(0x2ea)],
                          expression: _0x48f2c0(0x413),
                        },
                      ],
                      staticClass: _0x48f2c0(0x1c8),
                      staticStyle: { order: "7" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x12b),
                        { staticClass: _0x48f2c0(0x136) },
                        [
                          _0x3a2485("input", {
                            ref: _0x48f2c0(0x416),
                            attrs: {
                              disabled:
                                _0x5d0301["isDisabled"] ||
                                _0x5d0301[_0x48f2c0(0x375)],
                            },
                          }),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(_0x48f2c0(0x3d5), {
                            attrs: {
                              labeldesc: _0x48f2c0(0x316),
                              currencydesc: "0.00",
                            },
                          }),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            !_0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x5d0301[_0x48f2c0(0x2ea)],
                          expression: _0x48f2c0(0x413),
                        },
                      ],
                      staticClass: _0x48f2c0(0x1c8),
                      staticStyle: { order: "8" },
                    },
                    [
                      _0x3a2485("label", { staticClass: _0x48f2c0(0x136) }, [
                        _0x3a2485(_0x48f2c0(0x3d5), {
                          ref: _0x48f2c0(0x132),
                          attrs: {
                            disabled:
                              _0x5d0301["isDisabled"] ||
                              _0x5d0301[_0x48f2c0(0x375)],
                          },
                        }),
                        _0x5d0301["_v"]("\x20"),
                        _0x3a2485(_0x48f2c0(0x3d5), {
                          attrs: {
                            labeldesc: _0x48f2c0(0x39c),
                            currencydesc: _0x48f2c0(0x351),
                          },
                        }),
                      ]),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301[_0x48f2c0(0x2ea)] ||
                            _0x5d0301[_0x48f2c0(0x3a9)],
                          expression: _0x48f2c0(0x1a1),
                        },
                      ],
                      staticClass: _0x48f2c0(0x1c8),
                      staticStyle: { order: "9" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x12b),
                        { staticClass: _0x48f2c0(0x136) },
                        [
                          _0x3a2485(_0x48f2c0(0x3d5), {
                            ref: _0x48f2c0(0x2c3),
                            attrs: {
                              disabled:
                                _0x5d0301[_0x48f2c0(0x271)] ||
                                _0x5d0301[_0x48f2c0(0x375)],
                              readonly: !0x0,
                            },
                          }),
                          _0x5d0301["_v"]("\x20"),
                          _0x3a2485(_0x48f2c0(0x3d5), {
                            attrs: {
                              labeldesc: _0x48f2c0(0x326),
                              currencydesc: _0x48f2c0(0x351),
                            },
                          }),
                        ]
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    "v-button",
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301["isManual"] &&
                            (_0x48f2c0(0x355) == _0x5d0301[_0x48f2c0(0x29b)] ||
                              _0x48f2c0(0x36b) == _0x5d0301[_0x48f2c0(0x29b)] ||
                              "end" == _0x5d0301[_0x48f2c0(0x29b)]),
                          expression: _0x48f2c0(0x2cd),
                        },
                      ],
                      staticClass: _0x48f2c0(0x187),
                      staticStyle: {
                        width: "100%",
                        "margin-bottom": _0x48f2c0(0x121),
                        "margin-top": "12px",
                        order: "10",
                      },
                      attrs: {
                        loading:
                          _0x5d0301[_0x48f2c0(0x195)] || _0x5d0301["isNextbet"],
                        disabled:
                          _0x5d0301[_0x48f2c0(0x375)] ||
                          _0x5d0301[_0x48f2c0(0x271)] ||
                          _0x5d0301[_0x48f2c0(0x195)],
                      },
                      nativeOn: {
                        click: function (_0x8392b8) {
                          var _0x8980ba = _0x48f2c0;
                          return (
                            _0x8392b8[_0x8980ba(0x3e1)](),
                            _0x5d0301[_0x8980ba(0x40c)][_0x8980ba(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"]("\x0a\x09\x09Bet\x0a\x09")]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    "v-button",
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x48f2c0(0x2d7) == _0x5d0301[_0x48f2c0(0x29b)],
                          expression: _0x48f2c0(0x161),
                        },
                      ],
                      staticClass:
                        "variant-success\x20lineHeight-base\x20size-medium\x20spacing-mega\x20weight-semibold\x20align-center\x20min-width\x20fullWidth\x20square\x20svelte-1e6i4pv",
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": _0x48f2c0(0x121),
                        "margin-top": _0x48f2c0(0x3b2),
                        "margin-left": "0",
                        order: "11",
                      },
                      attrs: { disabled: !0x0 },
                    },
                    [_0x5d0301["_v"](_0x48f2c0(0x38d))]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x33d),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: "v-show",
                          value:
                            _0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x48f2c0(0x263) == _0x5d0301[_0x48f2c0(0x29b)] &&
                            0x1 == _0x5d0301["isCurrentBet"] &&
                            this[_0x48f2c0(0x1bb)] > this[_0x48f2c0(0x31e)],
                          expression: _0x48f2c0(0x1d0),
                        },
                      ],
                      staticClass:
                        "variant-success\x20lineHeight-base\x20size-medium\x20spacing-mega\x20weight-semibold\x20align-center\x20min-width\x20fullWidth\x20square\x20svelte-1e6i4pv",
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": "0px",
                        "margin-top": _0x48f2c0(0x3b2),
                        "margin-left": "0",
                        order: "12",
                      },
                      attrs: {
                        disabled:
                          _0x5d0301["isAutobet"] || _0x5d0301[_0x48f2c0(0x271)],
                      },
                      nativeOn: {
                        click: function (_0xc89f46) {
                          var _0x57640f = _0x48f2c0;
                          return (
                            _0xc89f46[_0x57640f(0x3e1)](),
                            _0x5d0301[_0x57640f(0x291)][_0x57640f(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"](_0x48f2c0(0x372))]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    "v-button",
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301["isManual"] &&
                            _0x48f2c0(0x263) == _0x5d0301[_0x48f2c0(0x29b)] &&
                            ((0x0 == _0x5d0301[_0x48f2c0(0x195)] &&
                              0x0 == _0x5d0301[_0x48f2c0(0x414)]) ||
                              (0x1 == _0x5d0301[_0x48f2c0(0x195)] &&
                                this["multiplier"] <= this[_0x48f2c0(0x31e)])),
                          expression: _0x48f2c0(0x35b),
                        },
                      ],
                      staticClass:
                        "variant-success\x20lineHeight-base\x20size-medium\x20spacing-mega\x20weight-semibold\x20align-center\x20min-width\x20fullWidth\x20square\x20svelte-1e6i4pv",
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": _0x48f2c0(0x121),
                        "margin-top": "12px",
                        "margin-left": "0",
                        order: "13",
                      },
                      attrs: {
                        disabled:
                          _0x5d0301[_0x48f2c0(0x375)] ||
                          _0x5d0301[_0x48f2c0(0x271)],
                      },
                      nativeOn: {
                        click: function (_0x11b02a) {
                          var _0x333688 = _0x48f2c0;
                          return (
                            _0x11b02a[_0x333688(0x3e1)](),
                            _0x5d0301[_0x333688(0x1dc)][_0x333688(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [
                      _0x5d0301["_v"](
                        "\x0a\x09\x09Bet\x20(Next\x20round)\x0a\x09"
                      ),
                    ]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x33d),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            _0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x48f2c0(0x263) == _0x5d0301[_0x48f2c0(0x29b)] &&
                            0x0 == _0x5d0301["isCurrentBet"] &&
                            0x1 == _0x5d0301[_0x48f2c0(0x414)],
                          expression: _0x48f2c0(0x233),
                        },
                      ],
                      staticClass: _0x48f2c0(0x187),
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": "0px",
                        "margin-top": _0x48f2c0(0x3b2),
                        "margin-left": "0",
                        order: "14",
                      },
                      attrs: {
                        loading: _0x5d0301[_0x48f2c0(0x195)],
                        disabled:
                          _0x5d0301[_0x48f2c0(0x375)] ||
                          _0x5d0301["isDisabled"],
                      },
                      nativeOn: {
                        click: function (_0x3bc616) {
                          var _0x39bf9d = _0x48f2c0;
                          return (
                            _0x3bc616[_0x39bf9d(0x3e1)](),
                            _0x5d0301[_0x39bf9d(0x3c5)][_0x39bf9d(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"](_0x48f2c0(0x3e5))]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x33d),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            !_0x5d0301["isManual"] &&
                            !_0x5d0301[_0x48f2c0(0x375)],
                          expression: _0x48f2c0(0x2c5),
                        },
                      ],
                      staticClass: _0x48f2c0(0x187),
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": "0px",
                        "margin-top": "12px",
                        "margin-left": "0px",
                        order: "16",
                      },
                      attrs: { loading: _0x5d0301[_0x48f2c0(0x15c)] },
                      nativeOn: {
                        click: function (_0x4d9d14) {
                          var _0x5ea8d4 = _0x48f2c0;
                          return (
                            _0x4d9d14["preventDefault"](),
                            _0x5d0301[_0x5ea8d4(0x373)]["apply"](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"](_0x48f2c0(0x3ee))]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    "v-button",
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value:
                            !_0x5d0301[_0x48f2c0(0x3a9)] &&
                            _0x5d0301[_0x48f2c0(0x375)] &&
                            _0x48f2c0(0x263) == _0x5d0301[_0x48f2c0(0x29b)],
                          expression:
                            "!isManual\x20&&\x20isAutobet\x20&&\x20(getCrashGameState\x20==\x20\x27in_progress\x27)",
                        },
                      ],
                      staticClass:
                        "variant-success\x20lineHeight-base\x20size-medium\x20spacing-mega\x20weight-semibold\x20align-center\x20min-width\x20fullWidth\x20square\x20svelte-1e6i4pv",
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": _0x48f2c0(0x121),
                        "margin-top": _0x48f2c0(0x3b2),
                        "margin-left": _0x48f2c0(0x121),
                        order: "17",
                      },
                      attrs: { loading: _0x5d0301[_0x48f2c0(0x15c)] },
                      nativeOn: {
                        click: function (_0xf719e1) {
                          var _0x2d481a = _0x48f2c0;
                          return (
                            _0xf719e1[_0x2d481a(0x3e1)](),
                            _0x5d0301["cashout"][_0x2d481a(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"](_0x48f2c0(0x372))]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x33d),
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value:
                            !_0x5d0301["isManual"] &&
                            _0x5d0301[_0x48f2c0(0x375)] &&
                            "in_progress" !== _0x5d0301[_0x48f2c0(0x29b)],
                          expression: _0x48f2c0(0x347),
                        },
                      ],
                      staticClass: _0x48f2c0(0x187),
                      staticStyle: {
                        width: _0x48f2c0(0x357),
                        "margin-bottom": _0x48f2c0(0x121),
                        "margin-top": _0x48f2c0(0x3b2),
                        "margin-left": _0x48f2c0(0x121),
                        order: "18",
                      },
                      attrs: { loading: _0x5d0301[_0x48f2c0(0x15c)] },
                      nativeOn: {
                        click: function (_0x194941) {
                          var _0x148aae = _0x48f2c0;
                          return (
                            _0x194941["preventDefault"](),
                            _0x5d0301["stopAutobet"][_0x148aae(0x143)](
                              null,
                              arguments
                            )
                          );
                        },
                      },
                    },
                    [_0x5d0301["_v"]("\x0a\x09\x09Stop\x20AutoBet\x0a\x09")]
                  ),
                  _0x5d0301["_v"]("\x20"),
                  _0x3a2485(
                    _0x48f2c0(0x393),
                    {
                      directives: [
                        {
                          name: _0x48f2c0(0x273),
                          rawName: _0x48f2c0(0x253),
                          value: !(
                            _0x5d0301[_0x48f2c0(0x2ea)] &&
                            !_0x5d0301[_0x48f2c0(0x3a9)]
                          ),
                          expression: _0x48f2c0(0x13b),
                        },
                      ],
                      ref: "betlist",
                      staticClass: _0x48f2c0(0x11e),
                      staticStyle: { order: "19" },
                    },
                    [
                      _0x3a2485(
                        _0x48f2c0(0x393),
                        {
                          staticClass:
                            "scroll-wrapper\x20scrollY\x20svelte-1ulh9na",
                        },
                        [
                          _0x3a2485(
                            _0x48f2c0(0x19f),
                            { staticClass: _0x48f2c0(0x205) },
                            _0x5d0301["_l"](
                              _0x5d0301[_0x48f2c0(0x229)],
                              function (_0x4c6a6f) {
                                var _0x4dbdc9 = _0x48f2c0;
                                return _0x3a2485(
                                  "tr",
                                  {
                                    key: _0x4c6a6f["id"],
                                    staticClass: _0x4dbdc9(0x34b),
                                  },
                                  [
                                    _0x3a2485(
                                      "td",
                                      { staticClass: _0x4dbdc9(0x21c) },
                                      [
                                        _0x3a2485(
                                          _0x4dbdc9(0x393),
                                          {
                                            directives: [
                                              {
                                                name: _0x4dbdc9(0x273),
                                                rawName: _0x4dbdc9(0x253),
                                                value: _0x4c6a6f["ai"] > 0x0,
                                                expression: "item.ai\x20>\x200",
                                              },
                                            ],
                                            staticClass:
                                              "hoverable\x20svelte-bbyuql",
                                          },
                                          [
                                            _0x3a2485(
                                              _0x4dbdc9(0x393),
                                              {
                                                staticClass:
                                                  "wrap\x20ghost\x20svelte-13td3s2",
                                              },
                                              [
                                                _0x3a2485(
                                                  _0x4dbdc9(0x3dc),
                                                  {
                                                    staticClass:
                                                      _0x4dbdc9(0x282),
                                                    staticStyle: {
                                                      color: _0x4dbdc9(0x2d6),
                                                    },
                                                  },
                                                  [
                                                    _0x3a2485(
                                                      _0x4dbdc9(0x1ef),
                                                      {
                                                        attrs: {
                                                          "xlink:href":
                                                            _0x4dbdc9(0x360),
                                                        },
                                                      }
                                                    ),
                                                  ]
                                                ),
                                                _0x5d0301["_v"]("\x20"),
                                                _0x5d0301["_m"](0x0, !0x0),
                                              ]
                                            ),
                                          ]
                                        ),
                                        _0x5d0301["_v"]("\x20"),
                                        _0x3a2485(
                                          _0x4dbdc9(0x393),
                                          {
                                            directives: [
                                              {
                                                name: _0x4dbdc9(0x273),
                                                rawName: _0x4dbdc9(0x253),
                                                value: 0x0 == _0x4c6a6f["ai"],
                                                expression:
                                                  "item.ai\x20==\x200",
                                              },
                                            ],
                                            staticClass: _0x4dbdc9(0x349),
                                          },
                                          [
                                            _0x3a2485(
                                              _0x4dbdc9(0x22c),
                                              { staticClass: _0x4dbdc9(0x167) },
                                              [
                                                _0x3a2485(
                                                  _0x4dbdc9(0x126),
                                                  {
                                                    staticClass:
                                                      _0x4dbdc9(0x23f),
                                                    staticStyle: {
                                                      "max-width":
                                                        _0x4dbdc9(0x3a6),
                                                    },
                                                  },
                                                  [
                                                    _0x3a2485(
                                                      "span",
                                                      {
                                                        staticClass:
                                                          "svelte-1k0lzek\x20truncate",
                                                        staticStyle: {
                                                          "max-width": "10ch",
                                                        },
                                                      },
                                                      [
                                                        _0x5d0301["_v"](
                                                          _0x4dbdc9(0x292) +
                                                            _0x5d0301["_s"](
                                                              _0x4c6a6f[
                                                                "username"
                                                              ]
                                                            ) +
                                                            _0x4dbdc9(0x302)
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _0x5d0301["_v"]("\x20"),
                                    _0x3a2485(
                                      "td",
                                      { staticClass: _0x4dbdc9(0x21c) },
                                      [
                                        _0x3a2485(
                                          _0x4dbdc9(0x126),
                                          {
                                            staticClass: _0x4dbdc9(0x33e),
                                            staticStyle: {
                                              "max-width": _0x4dbdc9(0x24b),
                                            },
                                          },
                                          [
                                            _0x5d0301["_v"](
                                              _0x4dbdc9(0x142) +
                                                _0x5d0301["_s"](
                                                  _0x5d0301["_f"](
                                                    _0x4dbdc9(0x2fd)
                                                  )(_0x4c6a6f["cashoutAt"])
                                                ) +
                                                _0x4dbdc9(0x209)
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _0x5d0301["_v"]("\x20"),
                                    _0x3a2485(
                                      "td",
                                      { staticClass: _0x4dbdc9(0x34b) },
                                      [
                                        _0x3a2485(
                                          _0x4dbdc9(0x393),
                                          { staticClass: _0x4dbdc9(0x403) },
                                          [
                                            _0x3a2485(
                                              "svg",
                                              { staticClass: _0x4dbdc9(0x282) },
                                              [
                                                _0x3a2485(_0x4dbdc9(0x1ef), {
                                                  attrs: {
                                                    "xlink:href":
                                                      _0x4dbdc9(0x2eb),
                                                  },
                                                }),
                                              ]
                                            ),
                                            _0x5d0301["_v"]("\x20"),
                                            _0x3a2485(
                                              _0x4dbdc9(0x126),
                                              { staticClass: _0x4dbdc9(0x386) },
                                              [
                                                _0x3a2485(
                                                  _0x4dbdc9(0x126),
                                                  {
                                                    staticClass:
                                                      _0x4dbdc9(0x3b6),
                                                    staticStyle: {
                                                      "max-width": "10ch",
                                                    },
                                                  },
                                                  [
                                                    _0x5d0301["_v"](
                                                      _0x4dbdc9(0x302) +
                                                        _0x5d0301["_s"](
                                                          _0x5d0301["_f"](
                                                            _0x4dbdc9(0x2b8)
                                                          )(
                                                            _0x4c6a6f[
                                                              _0x4dbdc9(0x409)
                                                            ]
                                                          )
                                                        ) +
                                                        _0x4dbdc9(0x29d)
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                );
                              }
                            ),
                            0x0
                          ),
                        ]
                      ),
                    ]
                  ),
                ],
                0x1
              );
            },
            [
              function () {
                var _0x4b1fca = _0x2917c6,
                  _0x35ab84 = this[_0x4b1fca(0x396)]["_c"];
                return _0x35ab84(
                  _0x4b1fca(0x126),
                  {
                    staticClass: _0x4b1fca(0x14c),
                    staticStyle: { "max-width": _0x4b1fca(0x24b) },
                  },
                  [
                    _0x35ab84(
                      "span",
                      {
                        staticClass: _0x4b1fca(0x250),
                        staticStyle: { "max-width": _0x4b1fca(0x24b) },
                      },
                      [
                        _0x35ab84(_0x4b1fca(0x126), [
                          this["_v"](_0x4b1fca(0x2ed)),
                        ]),
                      ]
                    ),
                  ]
                );
              },
            ],
            !0x1,
            null,
            null,
            null
          );
        _0x5dcbe0["a"] = _0x97c340[_0x2917c6(0x13e)];
      },
      0x200: function (_0x2574a6, _0x4a8ddc, _0x219fcd) {
        "use strict";
        var _0x469ee8 = a16_0x295903;
        _0x219fcd(0xc), _0x219fcd(0xa), _0x219fcd(0x10), _0x219fcd(0x11);
        var _0x293aaf = _0x219fcd(0x1f),
          _0x30e781 = _0x219fcd(0x0),
          _0x300806 = _0x219fcd(0x2),
          _0x3b57dd =
            (_0x219fcd(0x7),
            _0x219fcd(0x75),
            _0x219fcd(0x40),
            _0x219fcd(0x8),
            _0x219fcd(0xd),
            _0x219fcd(0x39),
            _0x219fcd(0x8f),
            _0x219fcd(0xe),
            _0x219fcd(0x29),
            _0x219fcd(0x26),
            _0x219fcd(0x43),
            _0x219fcd(0xb),
            _0x219fcd(0x3)),
          _0x5988b2 = _0x219fcd(0x63),
          _0x4be3ea = _0x219fcd(0x62);
        function _0x45a3ab(_0x294efd, _0x4065bf) {
          var _0x526694 = a16_0x269f,
            _0x356f19 = Object[_0x526694(0x376)](_0x294efd);
          if (Object["getOwnPropertySymbols"]) {
            var _0x55ee60 = Object[_0x526694(0x221)](_0x294efd);
            _0x4065bf &&
              (_0x55ee60 = _0x55ee60[_0x526694(0x1db)](function (_0x4159fc) {
                var _0x565300 = _0x526694;
                return Object[_0x565300(0x39e)](
                  _0x294efd,
                  _0x4159fc
                )[_0x565300(0x25b)];
              })),
              _0x356f19["push"][_0x526694(0x143)](_0x356f19, _0x55ee60);
          }
          return _0x356f19;
        }
        function _0x3bb579(_0x4d7761) {
          var _0x57d865 = a16_0x269f;
          for (
            var _0x4ea355 = 0x1;
            _0x4ea355 < arguments[_0x57d865(0x21a)];
            _0x4ea355++
          ) {
            var _0x42a707 =
              null != arguments[_0x4ea355] ? arguments[_0x4ea355] : {};
            _0x4ea355 % 0x2
              ? _0x45a3ab(Object(_0x42a707), !0x0)[_0x57d865(0x160)](function (
                  _0x46327d
                ) {
                  Object(_0x300806["a"])(
                    _0x4d7761,
                    _0x46327d,
                    _0x42a707[_0x46327d]
                  );
                })
              : Object[_0x57d865(0x2fb)]
              ? Object[_0x57d865(0x2b5)](
                  _0x4d7761,
                  Object[_0x57d865(0x2fb)](_0x42a707)
                )
              : _0x45a3ab(Object(_0x42a707))[_0x57d865(0x160)](function (
                  _0x3b2860
                ) {
                  var _0x27c722 = _0x57d865;
                  Object[_0x27c722(0x418)](
                    _0x4d7761,
                    _0x3b2860,
                    Object[_0x27c722(0x39e)](_0x42a707, _0x3b2860)
                  );
                });
          }
          return _0x4d7761;
        }
        var _0x520e01 = {
            name: _0x469ee8(0x2e1),
            components: {},
            data: function () {
              var _0x428041 = _0x469ee8;
              return {
                canvas: null,
                ctx: null,
                crashboard: {
                  width: 0x0,
                  height: 0x0,
                  minX: 0x0,
                  minY: 0x0,
                  rangeX: 0x0,
                  rangeY: 0x0,
                  graphWidth: 0x0,
                  graphHeight: 0x0,
                  datalist: [],
                  firstCoordinate: {},
                  progressElapse: 0x0,
                  crashElapse: 0x0,
                  multiplier: 0x1,
                },
                gamestate_label: "\x20",
                eplasedtime_label: "\x20",
                players: 0x0,
                info: {
                  offsetX: 0x5a,
                  offsetY: 0x3c,
                  lineWidth: 0x3,
                  graphLineWidth: 0x6,
                  arcOffset: 0x7,
                  interval: 0x5,
                  multiplierFontSize: 0x78,
                  fontSize: 0x12,
                  initX: 0xa,
                  initY: Object(_0x5988b2["b"])(0x2710),
                  es: 0x7d0,
                  _t: 0xa,
                  ns: 0x5,
                  ss: 0xc,
                  rs: 0x32,
                  upperX: 2.5,
                  upperY: 0.25,
                  color: {
                    positive: _0x428041(0x417),
                    negative: "#F10260",
                    warn: _0x428041(0x1de),
                    game: _0x428041(0x1a6),
                  },
                },
              };
            },
            mounted: function () {
              var _0x566c95 = _0x469ee8;
              (this["ctx"] =
                this[_0x566c95(0x3a2)][_0x566c95(0x3a1)][_0x566c95(0x3a0)](
                  "2d"
                )),
                (this[_0x566c95(0x298)] =
                  this[_0x566c95(0x3a2)][_0x566c95(0x3a1)]),
                window["addEventListener"]
                  ? window[_0x566c95(0x230)](
                      _0x566c95(0x1e1),
                      this[_0x566c95(0x16f)],
                      !0x1
                    )
                  : window[_0x566c95(0x16e)] &&
                    window[_0x566c95(0x16e)](
                      _0x566c95(0x3b9),
                      this[_0x566c95(0x16f)]
                    ),
                this[_0x566c95(0x27e)]();
            },
            computed: _0x3bb579(
              _0x3bb579(
                {},
                Object(_0x3b57dd["c"])("crash", [
                  _0x469ee8(0x3e0),
                  _0x469ee8(0x3d8),
                  _0x469ee8(0x3c7),
                  _0x469ee8(0x130),
                  _0x469ee8(0x229),
                  _0x469ee8(0x415),
                  _0x469ee8(0x2e3),
                  "getCrashCashOut",
                  _0x469ee8(0x2f8),
                  "getCrashGameState",
                  _0x469ee8(0x36a),
                ])
              ),
              {},
              {
                gamestate: function () {
                  var _0x281039 = _0x469ee8;
                  return this[_0x281039(0x29b)];
                },
              }
            ),
            watch: {
              ctx: function (_0x2d6504) {},
              getCrashGameState: function (_0x2938a5, _0x4ada75) {
                var _0x4d4522 = _0x469ee8;
                switch (_0x2938a5) {
                  case "join":
                    this["join"]();
                    break;
                  case _0x4d4522(0x36b):
                    this[_0x4d4522(0x28f)]();
                    break;
                  case _0x4d4522(0x2d7):
                    this[_0x4d4522(0x2d7)]();
                    break;
                  case "in_progress":
                    this["crash"]();
                    break;
                  case _0x4d4522(0x12e):
                    this[_0x4d4522(0x12e)]();
                }
              },
            },
            methods: _0x3bb579(
              _0x3bb579(
                {},
                Object(_0x3b57dd["b"])(_0x469ee8(0x30d), [
                  "setCrashGameState",
                  _0x469ee8(0x2b7),
                  _0x469ee8(0x394),
                  _0x469ee8(0x265),
                  _0x469ee8(0x3f9),
                  "setCrashLeaderboard",
                  "setCrashBet",
                  _0x469ee8(0x3f3),
                  _0x469ee8(0x32a),
                  _0x469ee8(0x11b),
                  _0x469ee8(0x30c),
                  "setCrashBetId",
                  _0x469ee8(0x166),
                  "setAutoBet",
                  _0x469ee8(0x34d),
                ])
              ),
              {},
              {
                init: function () {
                  var _0x313cdd = _0x469ee8,
                    _0x155891 = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x313cdd(0x2bd)](function _0x33544b() {
                      var _0x1d5f5d, _0x4f18b5, _0x59e041, _0x1f4712;
                      return regeneratorRuntime["wrap"](function (_0x492cba) {
                        var _0x520c15 = a16_0x269f;
                        for (;;)
                          switch (
                            (_0x492cba[_0x520c15(0x256)] =
                              _0x492cba[_0x520c15(0x220)])
                          ) {
                            case 0x0:
                              _0x155891[_0x520c15(0x16f)](),
                                (_0x1d5f5d = _0x155891),
                                _0x155891[_0x520c15(0x307)](),
                                (_0x4f18b5 = window["localStorage"])[
                                  _0x520c15(0x237)
                                ]("betId")
                                  ? ((_0x59e041 =
                                      _0x4f18b5["getItem"]("betId")),
                                    (_0x1f4712 =
                                      _0x4f18b5[_0x520c15(0x237)]("gameId")),
                                    (_0x155891[_0x520c15(0x3a1)][
                                      _0x520c15(0x1ce)
                                    ] = +_0x4f18b5["getItem"]("elapse")),
                                    _0x155891[_0x520c15(0x265)](
                                      +_0x4f18b5[_0x520c15(0x237)]("multiplier")
                                    ),
                                    _0x155891[_0x520c15(0x2b7)](+_0x1f4712),
                                    _0x155891["setCrashBetId"](+_0x59e041),
                                    _0x155891["crash"]())
                                  : setTimeout(function () {
                                      var _0x5cdaa8 = _0x520c15;
                                      return _0x1d5f5d[_0x5cdaa8(0x1fb)](
                                        _0x5cdaa8(0x355)
                                      );
                                    }, 0xa),
                                _0x155891["schedule"]();
                            case 0x6:
                            case _0x520c15(0x12e):
                              return _0x492cba[_0x520c15(0x395)]();
                          }
                      }, _0x33544b);
                    })
                  )();
                },
                getLogs: function () {
                  var _0x5e7f65 = _0x469ee8,
                    _0x26129b = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x5e7f65(0x2bd)](function _0x83ccba() {
                      var _0x29a2df = _0x5e7f65,
                        _0x5cad6d,
                        _0x5228d2;
                      return regeneratorRuntime[_0x29a2df(0x203)](function (
                        _0x58aad3
                      ) {
                        var _0x1ddf64 = _0x29a2df;
                        for (;;)
                          switch (
                            (_0x58aad3["prev"] = _0x58aad3[_0x1ddf64(0x220)])
                          ) {
                            case 0x0:
                              return (
                                (_0x58aad3[_0x1ddf64(0x220)] = 0x2),
                                log(_0x26129b[_0x1ddf64(0x344)])
                              );
                            case 0x2:
                              (_0x5cad6d = _0x58aad3["sent"]),
                                (_0x5228d2 =
                                  _0x5cad6d[_0x1ddf64(0x306)][
                                    _0x1ddf64(0x1e6)
                                  ])[_0x1ddf64(0x21a)] &&
                                  _0x5228d2[_0x1ddf64(0x160)](function (
                                    _0x4cd59b
                                  ) {
                                    var _0x16b50a = _0x1ddf64,
                                      _0x257a4c =
                                        _0x4cd59b["multipier"] ||
                                        0x2 * Math[_0x16b50a(0x1e9)]() + 0x1,
                                      _0x41123d = Object(_0x4be3ea["a"])(
                                        _0x257a4c[_0x16b50a(0x1fd)](0x2),
                                        0x2
                                      );
                                    0x0 ==
                                    _0x26129b[_0x16b50a(0x3a2)][
                                      _0x16b50a(0x277)
                                    ][_0x16b50a(0x176)][_0x16b50a(0x21a)]
                                      ? _0x26129b[_0x16b50a(0x3a2)][
                                          _0x16b50a(0x277)
                                        ][_0x16b50a(0x331)](_0x41123d)
                                      : _0x26129b[_0x16b50a(0x3a2)]["pastBets"][
                                          _0x16b50a(0x20a)
                                        ](
                                          _0x41123d,
                                          _0x26129b[_0x16b50a(0x3a2)][
                                            _0x16b50a(0x277)
                                          ][_0x16b50a(0x176)][0x0]
                                        ),
                                      _0x26129b[_0x16b50a(0x3a2)][
                                        _0x16b50a(0x277)
                                      ][_0x16b50a(0x176)][_0x16b50a(0x21a)] >
                                        0x5 &&
                                        _0x26129b[_0x16b50a(0x3a2)][
                                          _0x16b50a(0x277)
                                        ]["classList"]["add"](_0x16b50a(0x390)),
                                      _0x26129b[_0x16b50a(0x3a2)][
                                        _0x16b50a(0x277)
                                      ][_0x16b50a(0x176)][_0x16b50a(0x21a)] >
                                        0x6 &&
                                        _0x26129b[_0x16b50a(0x3a2)][
                                          _0x16b50a(0x277)
                                        ][_0x16b50a(0x296)](
                                          _0x26129b[_0x16b50a(0x3a2)][
                                            _0x16b50a(0x277)
                                          ]["children"][0x6]
                                        );
                                  });
                            case 0x5:
                            case "end":
                              return _0x58aad3[_0x1ddf64(0x395)]();
                          }
                      },
                      _0x83ccba);
                    })
                  )();
                },
                addBetItem: function () {
                  var _0x1f6938 = _0x469ee8,
                    _0x8f182c = Object(_0x4be3ea["a"])(
                      this[_0x1f6938(0x3c7)][_0x1f6938(0x1fd)](0x2),
                      0x2
                    );
                  0x0 ==
                  this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][_0x1f6938(0x176)][
                    _0x1f6938(0x21a)
                  ]
                    ? this["$refs"]["pastBets"]["appendChild"](_0x8f182c)
                    : this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][
                        _0x1f6938(0x20a)
                      ](
                        _0x8f182c,
                        this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][
                          "children"
                        ][0x0]
                      ),
                    this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][_0x1f6938(0x176)][
                      _0x1f6938(0x21a)
                    ] > 0x5 &&
                      this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][
                        _0x1f6938(0x12f)
                      ][_0x1f6938(0x397)](_0x1f6938(0x390)),
                    this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][_0x1f6938(0x176)][
                      _0x1f6938(0x21a)
                    ] > 0x6 &&
                      this["$refs"][_0x1f6938(0x277)][_0x1f6938(0x296)](
                        this[_0x1f6938(0x3a2)][_0x1f6938(0x277)][
                          "children"
                        ][0x6]
                      );
                },
                winsize: function () {
                  var _0x5324ae = _0x469ee8;
                  if (void 0x0 !== this[_0x5324ae(0x3a2)]["crashboard"]) {
                    var _0xec2149 =
                      (0x1 * this["$refs"]["crashboard"][_0x5324ae(0x206)]) /
                      0x384;
                    this[_0x5324ae(0x3a2)][_0x5324ae(0x3a1)][_0x5324ae(0x224)][
                      _0x5324ae(0x368)
                    ] = _0xec2149 + "em";
                    var _0x4644c7 = 0x258 * _0xec2149;
                    (this[_0x5324ae(0x3a2)]["gameboard"]["style"][
                      _0x5324ae(0x18b)
                    ] = _0x4644c7 + "px"),
                      (this[_0x5324ae(0x3a1)]["width"] =
                        this[_0x5324ae(0x3a2)][_0x5324ae(0x3a1)][
                          _0x5324ae(0x206)
                        ]),
                      (this[_0x5324ae(0x3a1)][_0x5324ae(0x1e5)] =
                        this["$refs"][_0x5324ae(0x3a1)][_0x5324ae(0x192)]),
                      console[_0x5324ae(0x329)](
                        this[_0x5324ae(0x3a1)]["width"]
                      ),
                      console[_0x5324ae(0x329)](
                        this[_0x5324ae(0x3a1)][_0x5324ae(0x1e5)]
                      );
                  }
                },
                roundRect: function (
                  _0x478e63,
                  _0x1211c9,
                  _0x4d215b,
                  _0x5a8826,
                  _0x443e25
                ) {
                  var _0x3af30f = _0x469ee8;
                  this[_0x3af30f(0x1d1)][_0x3af30f(0x3c9)](),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x39f)](
                      _0x478e63 + _0x4d215b,
                      _0x1211c9
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x13a)](
                      _0x478e63 + _0x4d215b - _0x443e25,
                      _0x1211c9
                    ),
                    this["ctx"]["quadraticCurveTo"](
                      _0x478e63 + _0x4d215b,
                      _0x1211c9,
                      _0x478e63 + _0x4d215b,
                      _0x1211c9 + _0x443e25
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x13a)](
                      _0x478e63 + _0x4d215b,
                      _0x1211c9 + _0x5a8826 - _0x443e25
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x419)](
                      _0x478e63 + _0x4d215b,
                      _0x1211c9 + _0x5a8826,
                      _0x478e63 + _0x4d215b - _0x443e25,
                      _0x1211c9 + _0x5a8826
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x13a)](
                      _0x478e63 + _0x443e25,
                      _0x1211c9 + _0x5a8826
                    ),
                    this[_0x3af30f(0x1d1)]["quadraticCurveTo"](
                      _0x478e63,
                      _0x1211c9 + _0x5a8826,
                      _0x478e63,
                      _0x1211c9 + _0x5a8826 - _0x443e25
                    ),
                    this["ctx"][_0x3af30f(0x13a)](
                      _0x478e63,
                      _0x1211c9 + _0x443e25
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x419)](
                      _0x478e63,
                      _0x1211c9,
                      _0x478e63 + _0x443e25,
                      _0x1211c9
                    ),
                    this[_0x3af30f(0x1d1)][_0x3af30f(0x269)]();
                },
                cleanUp: function () {
                  var _0x4abe7f = _0x469ee8;
                  this[_0x4abe7f(0x1d1)][_0x4abe7f(0x144)](
                    0x0,
                    0x0,
                    this[_0x4abe7f(0x3a1)][_0x4abe7f(0x328)],
                    this[_0x4abe7f(0x3a1)][_0x4abe7f(0x1e5)]
                  );
                },
                drawAxis: function () {
                  var _0x2806ed = _0x469ee8,
                    _0x4ff6ac = this["ctx"],
                    _0x22e208 = this[_0x2806ed(0x186)],
                    _0x44a603 = _0x22e208["lineWidth"],
                    _0x154c05 = _0x22e208[_0x2806ed(0x1f5)],
                    _0x385c13 = _0x22e208["offsetX"],
                    _0xa581cd = _0x22e208[_0x2806ed(0x308)],
                    _0x410039 = _0x22e208[_0x2806ed(0x18f)],
                    _0x258de9 = _0x22e208[_0x2806ed(0x368)],
                    _0x7092be =
                      (_0x22e208["arcOffset"], this[_0x2806ed(0x3a1)]),
                    _0x442d92 = _0x7092be[_0x2806ed(0x328)],
                    _0x370fef = _0x7092be[_0x2806ed(0x1e5)],
                    _0x4d608b = _0x7092be[_0x2806ed(0x313)],
                    _0x47c27d = _0x7092be["rangeY"],
                    _0x2bf291 = _0x7092be[_0x2806ed(0x2dc)],
                    _0x415bc6 = _0x7092be[_0x2806ed(0x1d4)];
                  _0x4ff6ac[_0x2806ed(0x3c9)](),
                    (_0x4ff6ac[_0x2806ed(0x2a5)] = _0x44a603),
                    (_0x4ff6ac[_0x2806ed(0x319)] = _0x154c05[_0x2806ed(0x1af)]),
                    (_0x4ff6ac[_0x2806ed(0x3af)] = _0x2806ed(0x3ed)),
                    _0x4ff6ac[_0x2806ed(0x39f)](_0x385c13, _0xa581cd),
                    _0x4ff6ac[_0x2806ed(0x13a)](
                      _0x385c13,
                      _0x370fef - _0xa581cd
                    ),
                    _0x4ff6ac["lineTo"](
                      _0x442d92 - _0x385c13,
                      _0x370fef - _0xa581cd
                    ),
                    _0x4ff6ac[_0x2806ed(0x3e7)]();
                  var _0xcacc39 = _0x4d608b / _0x410039,
                    _0x25a9f4 = _0x47c27d / _0x410039;
                  (_0x4ff6ac[_0x2806ed(0x40f)] = _0x154c05[_0x2806ed(0x1af)]),
                    (_0x4ff6ac["font"] = _0x2806ed(0x323)[_0x2806ed(0x174)](
                      _0x258de9,
                      "px\x20proxima-nova"
                    ));
                  for (var _0x511821 = 0x0; _0x511821 <= _0x410039; _0x511821++)
                    (_0x4ff6ac[_0x2806ed(0x20b)] = "end"),
                      (_0x4ff6ac["textBaseline"] = _0x2806ed(0x2ca)),
                      _0x4ff6ac[_0x2806ed(0x2b0)](
                        ""["concat"](
                          (_0x25a9f4 * _0x511821 + 0x1)["toFixed"](0x1),
                          "×"
                        ),
                        _0x385c13 - 0xa,
                        _0x370fef -
                          _0xa581cd -
                          (_0x511821 / _0x410039) * _0x2bf291
                      ),
                      (_0x4ff6ac[_0x2806ed(0x20b)] = _0x2806ed(0x398)),
                      (_0x4ff6ac[_0x2806ed(0x304)] = "top"),
                      _0x511821 > 0x0 &&
                        _0x4ff6ac["fillText"](
                          ""["concat"](
                            (_0xcacc39 * _0x511821)[_0x2806ed(0x1fd)](0x0),
                            "s"
                          ),
                          _0x385c13 + (_0x511821 / _0x410039) * _0x415bc6,
                          _0x370fef - _0xa581cd + 0xa
                        );
                },
                drawLine: function () {
                  var _0x1f0b58 = _0x469ee8,
                    _0x283c70 = this[_0x1f0b58(0x268)],
                    _0x1625bb = this[_0x1f0b58(0x1d1)],
                    _0x3e025d = this["crashboard"][_0x1f0b58(0x1cb)],
                    _0x1c4df1 = _0x3e025d[_0x3e025d[_0x1f0b58(0x21a)] - 0x1],
                    _0x355efc = this[_0x1f0b58(0x186)],
                    _0x22c07b = _0x355efc[_0x1f0b58(0x183)],
                    _0x5b0d4d = _0x355efc[_0x1f0b58(0x1f5)],
                    _0x1c1a4c = _0x355efc["arcOffset"],
                    _0x3a02d5 = _0x355efc[_0x1f0b58(0x3a7)],
                    _0x1f9dd2 = _0x355efc[_0x1f0b58(0x308)],
                    _0x986ee = this[_0x1f0b58(0x3a1)],
                    _0xaa73af =
                      (_0x986ee[_0x1f0b58(0x328)], _0x986ee[_0x1f0b58(0x1e5)]),
                    _0x3f660e = _0x986ee[_0x1f0b58(0x313)],
                    _0x7d9084 = _0x986ee[_0x1f0b58(0x2be)],
                    _0x1e180f = _0x986ee["graphWidth"],
                    _0x2dba04 = _0x986ee[_0x1f0b58(0x2dc)],
                    _0x450103 = _0x986ee[_0x1f0b58(0x32b)];
                  _0x1625bb[_0x1f0b58(0x3c9)](),
                    (_0x1625bb["lineWidth"] = _0x22c07b),
                    (_0x1625bb[_0x1f0b58(0x319)] =
                      _0x1f0b58(0x30d) === _0x283c70
                        ? _0x5b0d4d[_0x1f0b58(0x1af)]
                        : _0x5b0d4d[_0x1f0b58(0x1ee)]),
                    (_0x1625bb[_0x1f0b58(0x3af)] = _0x1f0b58(0x3ed)),
                    _0x1625bb[_0x1f0b58(0x39f)](
                      _0x3a02d5,
                      _0xaa73af - _0x1f9dd2
                    ),
                    _0x3e025d["forEach"](function (_0x27282b) {
                      var _0x26bece = _0x1f0b58;
                      _0x1625bb[_0x26bece(0x13a)](
                        _0x3a02d5 + (_0x27282b["x"] / _0x3f660e) * _0x1e180f,
                        _0xaa73af -
                          _0x1f9dd2 -
                          ((_0x27282b["y"] - _0x450103) / _0x7d9084) * _0x2dba04
                      );
                    }),
                    _0x1625bb[_0x1f0b58(0x3e7)](),
                    _0x1625bb[_0x1f0b58(0x3c9)](),
                    (_0x1625bb[_0x1f0b58(0x40f)] =
                      _0x1f0b58(0x30d) === _0x283c70
                        ? _0x5b0d4d[_0x1f0b58(0x1af)]
                        : _0x5b0d4d[_0x1f0b58(0x1ee)]),
                    _0x1625bb["arc"](
                      _0x3a02d5 + (_0x1c4df1["x"] / _0x3f660e) * _0x1e180f,
                      _0xaa73af -
                        _0x1f9dd2 -
                        ((_0x1c4df1["y"] - _0x450103) / _0x7d9084) * _0x2dba04,
                      _0x1c1a4c,
                      0x0,
                      0x2 * Math["PI"]
                    ),
                    _0x1625bb["fill"]();
                },
                drawCashedOut: function () {
                  var _0xcce586 = _0x469ee8,
                    _0x28d980 = this,
                    _0x217dbc = this[_0xcce586(0x1d1)],
                    _0x4fe126 = this["crashboard"],
                    _0x2f525a = _0x4fe126[_0xcce586(0x313)],
                    _0xc6ad64 = _0x4fe126[_0xcce586(0x2be)],
                    _0x488a23 = _0x4fe126[_0xcce586(0x32b)],
                    _0x936b14 = _0x4fe126[_0xcce586(0x1d4)],
                    _0x9f3c7e = _0x4fe126[_0xcce586(0x2dc)],
                    _0x1f9adc = _0x4fe126["height"],
                    _0x28e02e = this[_0xcce586(0x1a2)],
                    _0x261f1b = this[_0xcce586(0x186)],
                    _0xa84ea7 = _0x261f1b[_0xcce586(0x3a7)],
                    _0x5c37f0 = _0x261f1b["offsetY"],
                    _0x1d2d8f = _0x261f1b["es"],
                    _0x552936 = _0x261f1b["rs"],
                    _0x27b302 = _0x261f1b["_t"],
                    _0x1c6b93 = _0x261f1b["ss"],
                    _0x5afebe = _0x261f1b["ns"],
                    _0x3b06e0 = _0x261f1b[_0xcce586(0x368)];
                  _0x28e02e[_0xcce586(0x160)](function (_0x32b2c0) {
                    var _0x354b3e = _0xcce586,
                      _0x5ea2be = _0x32b2c0["name"],
                      _0x10b5a4 = _0x32b2c0["multiplier"],
                      _0x1c9e1f = _0x32b2c0[_0x354b3e(0x201)],
                      _0x14b7e1 = _0x32b2c0[_0x354b3e(0x14b)];
                    _0x217dbc[_0x354b3e(0x2ff)]();
                    var _0x36f5e4 =
                        _0xa84ea7 + (_0x1c9e1f / _0x2f525a) * _0x936b14,
                      _0x523f24 =
                        _0x1f9adc -
                        _0x5c37f0 -
                        ((_0x10b5a4 - _0x488a23) / _0xc6ad64) * _0x9f3c7e,
                      _0x6d1f0b = Math[_0x354b3e(0x364)](
                        _0x936b14,
                        (performance["now"]() - _0x14b7e1) / _0x1d2d8f
                      ),
                      _0x545133 = _0x552936 * _0x6d1f0b;
                    _0x217dbc[_0x354b3e(0x2b6)] = 0x1 - _0x6d1f0b;
                    var _0x1447e7 =
                        _0x217dbc[_0x354b3e(0x175)](_0x5ea2be)[
                          _0x354b3e(0x328)
                        ] +
                        0x2 * _0x27b302,
                      _0x293017 = _0x1c6b93 + 0x2 * _0x27b302;
                    _0x217dbc[_0x354b3e(0x295)](
                      _0x36f5e4,
                      _0x523f24 + _0x545133
                    ),
                      _0x28d980["roundRect"](
                        0x0,
                        0x0,
                        _0x1447e7,
                        _0x293017,
                        _0x5afebe
                      ),
                      (_0x217dbc[_0x354b3e(0x40f)] = _0x354b3e(0x41d)),
                      _0x217dbc[_0x354b3e(0x193)](),
                      (_0x217dbc[_0x354b3e(0x40f)] = _0x354b3e(0x2d4)),
                      (_0x217dbc[_0x354b3e(0x304)] = "middle"),
                      (_0x217dbc[_0x354b3e(0x20b)] = _0x354b3e(0x1d3)),
                      (_0x217dbc[_0x354b3e(0x35f)] = "600\x20"[
                        _0x354b3e(0x174)
                      ](_0x3b06e0, _0x354b3e(0x1cf))),
                      _0x217dbc[_0x354b3e(0x2b0)](
                        _0x5ea2be,
                        _0x27b302,
                        _0x293017 / 0x2
                      ),
                      _0x217dbc["restore"]();
                  });
                },
                drawStats: function () {
                  var _0x32ccf9 = _0x469ee8,
                    _0x211376 = this[_0x32ccf9(0x268)],
                    _0xd3444 = this["info"],
                    _0x26d2a0 = _0xd3444[_0x32ccf9(0x1f5)],
                    _0x39bd4e = _0xd3444[_0x32ccf9(0x3a7)],
                    _0x5b98c9 = _0xd3444[_0x32ccf9(0x308)],
                    _0x4485f9 = this[_0x32ccf9(0x3a1)],
                    _0x43a916 = _0x4485f9["width"],
                    _0x1b4734 = _0x4485f9[_0x32ccf9(0x1e5)],
                    _0x28b79e = this[_0x32ccf9(0x1d1)],
                    _0x2a7ab8 = this[_0x32ccf9(0x3d8)],
                    _0xc8a927 = performance[_0x32ccf9(0x29e)]() - _0x2a7ab8,
                    _0x5362a5 = Math[_0x32ccf9(0x364)](
                      0x1,
                      _0xc8a927 / _0x5988b2["a"]
                    );
                  _0x28b79e[_0x32ccf9(0x2ff)](),
                    (_0x28b79e[_0x32ccf9(0x40f)] = _0x26d2a0[_0x32ccf9(0x1af)]),
                    (_0x28b79e["font"] = _0x32ccf9(0x1ab)),
                    _0x28b79e[_0x32ccf9(0x295)](
                      _0x43a916 - _0x39bd4e,
                      _0x1b4734 - _0x5b98c9
                    ),
                    (_0x28b79e["textAlign"] = _0x32ccf9(0x412)),
                    (_0x28b79e[_0x32ccf9(0x304)] = _0x32ccf9(0x2ca)),
                    _0x28b79e["fillText"](_0x32ccf9(0x38c), -0xf, -0x14),
                    _0x28b79e[_0x32ccf9(0x3c9)](),
                    (_0x28b79e[_0x32ccf9(0x40f)] =
                      (_0x32ccf9(0x263) === _0x211376 && _0x5988b2["a"],
                      _0x26d2a0["positive"])),
                    _0x28b79e["arc"](0x0, -0x14, 0x5, 0x0, 0x2 * Math["PI"]),
                    _0x28b79e[_0x32ccf9(0x193)](),
                    _0x28b79e["beginPath"](),
                    (_0x28b79e[_0x32ccf9(0x2b6)] = 0x1 - _0x5362a5),
                    _0x28b79e["arc"](
                      0x0,
                      -0x14,
                      0xf * _0x5362a5,
                      0x0,
                      0x2 * Math["PI"]
                    ),
                    _0x28b79e[_0x32ccf9(0x193)](),
                    _0x28b79e[_0x32ccf9(0x1a0)]();
                },
                drawMultiplier: function () {
                  var _0x3ba81c = _0x469ee8,
                    _0x2451e2 = this[_0x3ba81c(0x268)],
                    _0x182171 = this[_0x3ba81c(0x1d1)],
                    _0x2d3b92 = this[_0x3ba81c(0x3a1)][_0x3ba81c(0x1bb)],
                    _0x59f796 = ""[_0x3ba81c(0x174)](
                      (Math["floor"](0x64 * _0x2d3b92) / 0x64)[
                        _0x3ba81c(0x1fd)
                      ](0x2),
                      "×"
                    ),
                    _0xe65831 = this[_0x3ba81c(0x186)][_0x3ba81c(0x188)],
                    _0xdd722a = this["crashboard"],
                    _0x3a190c = _0xdd722a[_0x3ba81c(0x328)],
                    _0x3f560a = _0xdd722a[_0x3ba81c(0x1e5)];
                  (_0x182171[_0x3ba81c(0x35f)] = "600\x20"[_0x3ba81c(0x174)](
                    _0xe65831 * devicePixelRatio,
                    _0x3ba81c(0x1cf)
                  )),
                    (_0x182171[_0x3ba81c(0x304)] = _0x3ba81c(0x2ca)),
                    (_0x182171[_0x3ba81c(0x20b)] = _0x3ba81c(0x1d3)),
                    (_0x182171["fillStyle"] =
                      _0x3ba81c(0x30d) === _0x2451e2
                        ? color[_0x3ba81c(0x369)]
                        : "#ffffff");
                  var _0x24822a =
                      _0x182171[_0x3ba81c(0x175)]("0")[_0x3ba81c(0x328)],
                    _0x568ab4 = _0x182171["measureText"](".")[_0x3ba81c(0x328)],
                    _0x31b486 =
                      (_0x3a190c -
                        (_0x59f796["length"] - 0x1) * _0x24822a -
                        _0x568ab4) /
                      0x2,
                    _0x39ba79 = _0x3f560a / 0x2,
                    _0x31dceb = 0x0;
                  _0x59f796[_0x3ba81c(0x2f4)]("")[_0x3ba81c(0x160)](function (
                    _0x4e30ec
                  ) {
                    var _0x4bc128 = _0x3ba81c;
                    _0x182171[_0x4bc128(0x2b0)](
                      _0x4e30ec,
                      _0x31b486 + _0x31dceb,
                      _0x39ba79
                    ),
                      (_0x31dceb += "." === _0x4e30ec ? _0x568ab4 : _0x24822a);
                  });
                },
                updateState: function () {
                  var _0x3ea7c3 = _0x469ee8,
                    _0xbb510a = this,
                    _0x1e8c23 =
                      (this[_0x3ea7c3(0x29b)],
                      Math[_0x3ea7c3(0x1fe)](
                        0x0,
                        performance[_0x3ea7c3(0x29e)]() - this[_0x3ea7c3(0x3d8)]
                      ));
                  this[_0x3ea7c3(0x272)] = Math[_0x3ea7c3(0x364)](
                    this[_0x3ea7c3(0x2f8)] - _0x5988b2["a"] + _0x1e8c23,
                    this["getElapsed"]
                  );
                  var _0x2a0d85,
                    _0x26cf29 = this["crashboard"],
                    _0x119097 = _0x26cf29["width"],
                    _0x3bc0a2 = _0x26cf29[_0x3ea7c3(0x1e5)],
                    _0x3c0fd5 = Object(_0x5988b2["c"])(
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x1bb)]
                    );
                  (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x1cb)] = _0x3c0fd5),
                    (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x34a)] = _0x3c0fd5[0x0]),
                    (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x3f5)] =
                      this["crashboard"][_0x3ea7c3(0x34a)]["x"]),
                    (this["crashboard"][_0x3ea7c3(0x258)] = Math[
                      _0x3ea7c3(0x1fe)
                    ][_0x3ea7c3(0x143)](
                      Math,
                      [this[_0x3ea7c3(0x186)]["initX"]][_0x3ea7c3(0x174)](
                        Object(_0x293aaf["a"])(
                          _0x3c0fd5[_0x3ea7c3(0x37c)](function (_0x4fa040) {
                            var _0x7b9632 = _0x3ea7c3;
                            return (
                              _0x4fa040["x"] +
                              _0xbb510a[_0x7b9632(0x186)][_0x7b9632(0x35d)]
                            );
                          })
                        )
                      )
                    )),
                    (this[_0x3ea7c3(0x3a1)]["minY"] =
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x34a)]["y"]),
                    (this["crashboard"]["maxY"] = Math[_0x3ea7c3(0x1fe)][
                      _0x3ea7c3(0x143)
                    ](
                      Math,
                      [this[_0x3ea7c3(0x186)][_0x3ea7c3(0x37f)]][
                        _0x3ea7c3(0x174)
                      ](
                        Object(_0x293aaf["a"])(
                          _0x3c0fd5[_0x3ea7c3(0x37c)](function (_0x414f09) {
                            var _0x9e1fe6 = _0x3ea7c3;
                            return (
                              _0x414f09["y"] +
                              _0xbb510a[_0x9e1fe6(0x186)][_0x9e1fe6(0x33f)]
                            );
                          })
                        )
                      )
                    )),
                    (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x313)] =
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x258)] -
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x3f5)]),
                    (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x2be)] =
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x2d1)] -
                      this["crashboard"][_0x3ea7c3(0x32b)]),
                    (this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x1d4)] =
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x328)] -
                      0x2 * this[_0x3ea7c3(0x186)]["offsetX"]),
                    (this["crashboard"]["graphHeight"] =
                      this[_0x3ea7c3(0x3a1)][_0x3ea7c3(0x1e5)] -
                      0x2 * this[_0x3ea7c3(0x186)][_0x3ea7c3(0x308)]),
                    null == this["ctx"] ||
                      this[_0x3ea7c3(0x1d1)][_0x3ea7c3(0x144)](
                        0x0,
                        0x0,
                        _0x119097,
                        _0x3bc0a2
                      ),
                    this["canvas"] &&
                      ((this[_0x3ea7c3(0x1d1)] =
                        this["canvas"]["getContext"]("2d")),
                      (this["canvas"][_0x3ea7c3(0x328)] = Math[
                        _0x3ea7c3(0x127)
                      ](devicePixelRatio * _0x119097)),
                      (this[_0x3ea7c3(0x298)][_0x3ea7c3(0x1e5)] = Math["floor"](
                        devicePixelRatio * _0x3bc0a2
                      )),
                      this[_0x3ea7c3(0x1d1)][_0x3ea7c3(0x243)](
                        devicePixelRatio,
                        devicePixelRatio
                      ),
                      null == (_0x2a0d85 = this[_0x3ea7c3(0x1d1)]) ||
                        _0x2a0d85["clearRect"](0x0, 0x0, _0x119097, _0x3bc0a2),
                      this["ctx"][_0x3ea7c3(0x2ff)]()),
                    this[_0x3ea7c3(0x24e)]();
                },
                render: function () {
                  var _0x4e99e7 = _0x469ee8;
                  this[_0x4e99e7(0x1d1)] &&
                    (this["cleanUp"](),
                    this[_0x4e99e7(0x25e)](),
                    this["drawCashedOut"](),
                    this[_0x4e99e7(0x22f)](),
                    this[_0x4e99e7(0x1c3)](),
                    this["drawMultiplier"]());
                },
                join: function () {
                  var _0x3de42a = _0x469ee8,
                    _0x2a102f = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x3de42a(0x2bd)](function _0x49ece4() {
                      return regeneratorRuntime["wrap"](function (_0x301d96) {
                        var _0x39a803 = a16_0x269f;
                        for (;;)
                          switch (
                            (_0x301d96[_0x39a803(0x256)] =
                              _0x301d96[_0x39a803(0x220)])
                          ) {
                            case 0x0:
                              (_0x2a102f["crashboard"][_0x39a803(0x15a)] = 0x0),
                                _0x2a102f[_0x39a803(0x2b7)](
                                  data[_0x39a803(0x1aa)]
                                ),
                                _0x2a102f[_0x39a803(0x1eb)](
                                  data[_0x39a803(0x3bc)]
                                ),
                                _0x2a102f[_0x39a803(0x1fb)](_0x39a803(0x36b));
                            case 0x4:
                            case _0x39a803(0x12e):
                              return _0x301d96[_0x39a803(0x395)]();
                          }
                      }, _0x49ece4);
                    })
                  )();
                },
                fire: (function (_0x365d1f) {
                  function _0x487dcb() {
                    return _0x365d1f["apply"](this, arguments);
                  }
                  return (
                    (_0x487dcb["toString"] = function () {
                      var _0x2249f1 = a16_0x269f;
                      return _0x365d1f[_0x2249f1(0x199)]();
                    }),
                    _0x487dcb
                  );
                })(function () {
                  var _0x5c2611 = _0x469ee8,
                    _0x50e696 = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x5c2611(0x2bd)](function _0x2823f5() {
                      var _0x117072 = _0x5c2611,
                        _0xdd510a,
                        _0x3c4e7b;
                      return regeneratorRuntime[_0x117072(0x203)](function (
                        _0x48572d
                      ) {
                        var _0x4d3a98 = _0x117072;
                        for (;;)
                          switch (
                            (_0x48572d[_0x4d3a98(0x256)] = _0x48572d["next"])
                          ) {
                            case 0x0:
                              return (
                                (_0x48572d["next"] = 0x2),
                                fire(
                                  _0x50e696[_0x4d3a98(0x36a)],
                                  _0x50e696[_0x4d3a98(0x3e0)]
                                )
                              );
                            case 0x2:
                              (_0xdd510a = _0x48572d["sent"]),
                                (_0x3c4e7b = _0xdd510a[_0x4d3a98(0x306)]),
                                (_0x50e696["crashboard"][
                                  _0x4d3a98(0x1ce)
                                ] = 0x0),
                                (_0x50e696[_0x4d3a98(0x3a1)][
                                  _0x4d3a98(0x1bb)
                                ] = 0x1),
                                (null !== _0x3c4e7b[_0x4d3a98(0x1bb)] &&
                                  0x0 !== _0x3c4e7b[_0x4d3a98(0x1bb)]) ||
                                  (_0x3c4e7b[_0x4d3a98(0x1bb)] =
                                    0x2 * Math[_0x4d3a98(0x1e9)]() + 0x1),
                                _0x3c4e7b[_0x4d3a98(0x19b)],
                                _0x50e696[_0x4d3a98(0x265)](
                                  _0x3c4e7b[_0x4d3a98(0x1bb)]
                                ),
                                _0x50e696[_0x4d3a98(0x1fb)](_0x4d3a98(0x263));
                            case 0xa:
                            case _0x4d3a98(0x12e):
                              return _0x48572d["stop"]();
                          }
                      },
                      _0x2823f5);
                    })
                  )();
                }),
                end: function () {
                  var _0x1df8ab = _0x469ee8,
                    _0x45a7b3 = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x1df8ab(0x2bd)](function _0x410903() {
                      var _0x813f32 = _0x1df8ab,
                        _0xdcba5b,
                        _0x1a2333;
                      return regeneratorRuntime[_0x813f32(0x203)](function (
                        _0xba2e61
                      ) {
                        var _0xd212ea = _0x813f32;
                        for (;;)
                          switch (
                            (_0xba2e61[_0xd212ea(0x256)] =
                              _0xba2e61[_0xd212ea(0x220)])
                          ) {
                            case 0x0:
                              return (
                                (_0xdcba5b =
                                  _0x45a7b3[_0xd212ea(0x3a1)]["multiplier"]),
                                (_0x45a7b3[_0xd212ea(0x3a1)][
                                  "multiplier"
                                ] = 0x1),
                                _0x45a7b3[_0xd212ea(0x307)](),
                                window[_0xd212ea(0x1ad)][_0xd212ea(0x274)](
                                  _0xd212ea(0x3bc)
                                ),
                                (_0xba2e61[_0xd212ea(0x220)] = 0x7),
                                result(
                                  _0x45a7b3[_0xd212ea(0x36a)],
                                  _0xdcba5b === _0x45a7b3[_0xd212ea(0x3c7)]
                                    ? 0x0
                                    : _0xdcba5b
                                )
                              );
                            case 0x7:
                              (_0x1a2333 = _0xba2e61["sent"]),
                                _0x1a2333["data"]["success"],
                                _0x45a7b3[_0xd212ea(0x26d)](),
                                _0x45a7b3[_0xd212ea(0x1fb)]("join");
                            case 0xc:
                            case _0xd212ea(0x12e):
                              return _0xba2e61[_0xd212ea(0x395)]();
                          }
                      },
                      _0x410903);
                    })
                  )();
                },
                crash: function () {
                  var _0x2aadbd = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime["mark"](function _0x585332() {
                      var _0x2a1cd6 = a16_0x269f,
                        _0x3d3e04,
                        _0x2496f5,
                        _0x459a48,
                        _0x24d8d3;
                      return regeneratorRuntime[_0x2a1cd6(0x203)](function (
                        _0xbaf392
                      ) {
                        var _0x17e010 = _0x2a1cd6;
                        for (;;)
                          switch (
                            (_0xbaf392[_0x17e010(0x256)] =
                              _0xbaf392[_0x17e010(0x220)])
                          ) {
                            case 0x0:
                              (_0x3d3e04 =
                                _0x2aadbd[_0x17e010(0x3a1)][_0x17e010(0x1ce)]),
                                _0x2aadbd["crashboard"][_0x17e010(0x1bb)] >
                                _0x2aadbd[_0x17e010(0x3c7)]
                                  ? ((_0x3d3e04 =
                                      _0x2aadbd[_0x17e010(0x3a1)][
                                        _0x17e010(0x258)
                                      ]),
                                    (_0x2aadbd["crashboard"][_0x17e010(0x1bb)] =
                                      _0x2aadbd[_0x17e010(0x3c7)]),
                                    _0x2aadbd["updateState"](),
                                    _0x2aadbd[_0x17e010(0x1fb)]("end"))
                                  : _0x17e010(0x291) ===
                                    _0x2aadbd[_0x17e010(0x29b)]
                                  ? _0x2aadbd[_0x17e010(0x1fb)](
                                      _0x17e010(0x12e)
                                    )
                                  : ((_0x2496f5 = Object(_0x5988b2["b"])(
                                      _0x3d3e04
                                    )),
                                    (_0x2aadbd[_0x17e010(0x3a1)][
                                      _0x17e010(0x1bb)
                                    ] = _0x2496f5),
                                    _0x2aadbd[_0x17e010(0x34d)](_0x2496f5),
                                    (_0x459a48 = window[_0x17e010(0x1ad)]),
                                    _0x2aadbd[_0x17e010(0x307)](),
                                    (_0x24d8d3 =
                                      0x3e8 * Math[_0x17e010(0x1e9)]()),
                                    _0x459a48[_0x17e010(0x238)](
                                      _0x17e010(0x3bc),
                                      _0x2aadbd[_0x17e010(0x36a)]
                                    ),
                                    _0x459a48[_0x17e010(0x238)](
                                      _0x17e010(0x1aa),
                                      _0x2aadbd[_0x17e010(0x3e0)]
                                    ),
                                    _0x459a48["setItem"](
                                      _0x17e010(0x34e),
                                      _0x3d3e04
                                    ),
                                    _0x459a48[_0x17e010(0x238)](
                                      _0x17e010(0x1bb),
                                      _0x2aadbd[_0x17e010(0x3c7)]
                                    ),
                                    (_0x2aadbd[_0x17e010(0x3a1)][
                                      _0x17e010(0x1ce)
                                    ] = _0x3d3e04 + _0x24d8d3),
                                    setTimeout(
                                      _0x2aadbd[_0x17e010(0x30d)],
                                      0x1f4
                                    ));
                            case 0x2:
                            case _0x17e010(0x12e):
                              return _0xbaf392["stop"]();
                          }
                      },
                      _0x585332);
                    })
                  )();
                },
                toggleProgressBar: function () {
                  var _0xac0c33 = _0x469ee8,
                    _0x282a14 = this[_0xac0c33(0x3a1)][_0xac0c33(0x15a)];
                  (this[_0xac0c33(0x3a2)][_0xac0c33(0x388)][_0xac0c33(0x224)][
                    _0xac0c33(0x328)
                  ] = ""["concat"](0x64 - _0x282a14, "%")),
                    (this[_0xac0c33(0x3a1)][_0xac0c33(0x15a)] =
                      _0x282a14 + 0x1),
                    0x64 === _0x282a14
                      ? ((this["gamestate_label"] = ""),
                        (this[_0xac0c33(0x288)] = ""),
                        this[_0xac0c33(0x1fb)](_0xac0c33(0x2d7)),
                        (this[_0xac0c33(0x30d)][_0xac0c33(0x15a)] = 0x0))
                      : ((this[_0xac0c33(0x153)] = _0xac0c33(0x370)),
                        (this["eplasedtime_label"] = ""[_0xac0c33(0x174)](
                          (0x5 - _0x282a14 / 0x14)[_0xac0c33(0x1fd)](0x1),
                          "s"
                        )),
                        setTimeout(this[_0xac0c33(0x28f)], 0x32));
                },
                schedule: function () {
                  var _0x4dba80 = _0x469ee8,
                    _0x291624 = this;
                  return Object(_0x30e781["a"])(
                    regeneratorRuntime[_0x4dba80(0x2bd)](function _0x3ef2b9() {
                      var _0x39365f = _0x4dba80,
                        _0x2399fc,
                        _0x19b2ad;
                      return regeneratorRuntime[_0x39365f(0x203)](
                        function (_0xb25288) {
                          var _0x28a0bf = _0x39365f;
                          for (;;)
                            switch (
                              (_0xb25288["prev"] = _0xb25288[_0x28a0bf(0x220)])
                            ) {
                              case 0x0:
                                if (
                                  ((_0xb25288[_0x28a0bf(0x256)] = 0x0),
                                  "waiting" !== _0x291624[_0x28a0bf(0x29b)])
                                ) {
                                  _0xb25288[_0x28a0bf(0x220)] = 0x9;
                                  break;
                                }
                                return (
                                  (_0xb25288[_0x28a0bf(0x220)] = 0x4),
                                  players(_0x291624[_0x28a0bf(0x3e0)])
                                );
                              case 0x4:
                                (_0x2399fc = _0xb25288["sent"]),
                                  (_0x19b2ad = _0x2399fc[_0x28a0bf(0x306)]),
                                  (_0x291624[_0x28a0bf(0x2db)] =
                                    _0x19b2ad["players"]),
                                  _0x291624[_0x28a0bf(0x2b3)](
                                    _0x19b2ad["info"]
                                  ),
                                  _0x291624[_0x28a0bf(0x166)](
                                    _0x19b2ad[_0x28a0bf(0x186)]
                                      ["filter"](function (_0x529d75) {
                                        var _0x319b0a = _0x28a0bf;
                                        return (
                                          _0x529d75[_0x319b0a(0x1bb)] > 0x0 &&
                                          _0x529d75[_0x319b0a(0x1bb)] <
                                            _0x291624[_0x319b0a(0x3a1)][
                                              "multiplier"
                                            ]
                                        );
                                      })
                                      [_0x28a0bf(0x37c)](function (_0x544185) {
                                        var _0x105d46 = _0x28a0bf;
                                        return {
                                          name: _0x544185[_0x105d46(0x2f5)],
                                          multiplier:
                                            _0x544185[_0x105d46(0x1bb)],
                                          elapsed:
                                            Object(_0x5988b2["d"])(
                                              _0x544185[_0x105d46(0x1bb)]
                                            ) / 0x3e8,
                                          timestamp:
                                            performance[_0x105d46(0x29e)](),
                                        };
                                      })
                                  );
                              case 0x9:
                                _0xb25288[_0x28a0bf(0x220)] = 0xd;
                                break;
                              case 0xb:
                                (_0xb25288[_0x28a0bf(0x256)] = 0xb),
                                  (_0xb25288["t0"] = _0xb25288["catch"](0x0));
                              case 0xd:
                                setTimeout(_0x291624[_0x28a0bf(0x3ef)], 0x3e8);
                              case 0xe:
                              case _0x28a0bf(0x12e):
                                return _0xb25288["stop"]();
                            }
                        },
                        _0x3ef2b9,
                        null,
                        [[0x0, 0xb]]
                      );
                    })
                  )();
                },
              }
            ),
          },
          _0x322adc = _0x520e01,
          _0x3abe75 = (_0x219fcd(0x410), _0x219fcd(0x1)),
          _0x544bcf = Object(_0x3abe75["a"])(
            _0x322adc,
            function () {
              var _0x1b7033 = _0x469ee8,
                _0x1cc53f = this,
                _0x15c0a6 = _0x1cc53f["_self"]["_c"];
              return _0x15c0a6(
                _0x1b7033(0x393),
                {
                  ref: _0x1b7033(0x239),
                  staticClass: "game-content\x20svelte-crash",
                },
                [
                  _0x15c0a6(
                    _0x1b7033(0x393),
                    { staticClass: "wrap\x20svelte-crash" },
                    [
                      _0x15c0a6(_0x1b7033(0x393), {
                        ref: "pastBets",
                        staticClass: _0x1b7033(0x1b0),
                      }),
                      _0x1cc53f["_v"]("\x20"),
                      _0x15c0a6(
                        _0x1b7033(0x22c),
                        {
                          staticClass:
                            "variant-game\x20lineHeight-base\x20size-medium\x20spacing-normal\x20weight-semibold\x20align-center\x20svelte-oho9kj",
                        },
                        [
                          _0x15c0a6("span", { staticClass: _0x1b7033(0x41a) }, [
                            _0x15c0a6(
                              _0x1b7033(0x3dc),
                              { staticClass: _0x1b7033(0x282) },
                              [
                                _0x15c0a6(_0x1b7033(0x1ef), {
                                  attrs: { "xlink:href": _0x1b7033(0x3ca) },
                                }),
                              ]
                            ),
                          ]),
                        ]
                      ),
                    ]
                  ),
                  _0x1cc53f["_v"]("\x20"),
                  _0x15c0a6("div", { staticClass: _0x1b7033(0x212) }, [
                    _0x15c0a6(
                      "div",
                      {
                        staticClass: _0x1b7033(0x27d),
                        staticStyle: { width: _0x1b7033(0x357) },
                      },
                      [
                        _0x15c0a6("canvas", {
                          ref: "crashboard",
                          staticStyle: { width: _0x1b7033(0x357) },
                          attrs: {
                            width: _0x1b7033(0x158),
                            height: _0x1b7033(0x254),
                          },
                        }),
                      ]
                    ),
                    _0x1cc53f["_v"]("\x20"),
                    _0x15c0a6(
                      _0x1b7033(0x393),
                      { staticClass: "wrap\x20svelte-progressbar" },
                      [
                        _0x15c0a6(
                          "span",
                          { staticClass: "svelte-progressbar" },
                          [
                            _0x15c0a6(_0x1b7033(0x126), [
                              _0x1cc53f["_v"](
                                _0x1cc53f["_s"](_0x1cc53f[_0x1b7033(0x153)]) +
                                  "\x20"
                              ),
                            ]),
                            _0x1cc53f["_v"]("\x20"),
                            _0x15c0a6(_0x1b7033(0x126), [
                              _0x1cc53f["_v"](
                                _0x1cc53f["_s"](_0x1cc53f[_0x1b7033(0x288)])
                              ),
                            ]),
                          ]
                        ),
                        _0x1cc53f["_v"]("\x20"),
                        _0x15c0a6(_0x1b7033(0x393), {
                          ref: "readyProgress",
                          staticClass: _0x1b7033(0x2cc),
                          staticStyle: { width: "0%" },
                        }),
                      ]
                    ),
                  ]),
                  _0x1cc53f["_v"]("\x20"),
                  _0x15c0a6(
                    _0x1b7033(0x393),
                    { staticClass: _0x1b7033(0x2c4) },
                    [
                      _0x15c0a6(_0x1b7033(0x393), {
                        staticClass: _0x1b7033(0x2f0),
                      }),
                      _0x1cc53f["_v"]("\x20"),
                      _0x15c0a6(
                        _0x1b7033(0x126),
                        { staticClass: _0x1b7033(0x2a7) },
                        [
                          _0x1cc53f["_v"](
                            _0x1b7033(0x17a) +
                              _0x1cc53f["_s"](_0x1cc53f[_0x1b7033(0x2db)]) +
                              _0x1b7033(0x294)
                          ),
                        ]
                      ),
                    ]
                  ),
                ]
              );
            },
            [],
            !0x1,
            null,
            null,
            null
          );
        _0x4a8ddc["a"] = _0x544bcf[_0x469ee8(0x13e)];
      },
      0x3d5: function (_0x4768a0, _0x4fe6b1, _0x5b187e) {
        "use strict";
        _0x5b187e(0x174);
      },
      0x3d6: function (_0x5dc811, _0x92865b, _0x1f619) {
        var _0x2a9a18 = a16_0x295903,
          _0xc92f9 = _0x1f619(0x4)(!0x1);
        _0xc92f9[_0x2a9a18(0x22a)]([_0x5dc811["i"], _0x2a9a18(0x321), ""]),
          (_0x5dc811["exports"] = _0xc92f9);
      },
      0x3d7: function (_0x15b3a7, _0x11b78e, _0x40583) {
        "use strict";
        _0x40583(0x175);
      },
      0x3d8: function (_0x253bdc, _0xc673dd, _0x1a6ecc) {
        var _0x263a99 = a16_0x295903,
          _0x312db1 = _0x1a6ecc(0x4)(!0x1);
        _0x312db1[_0x263a99(0x22a)]([
          _0x253bdc["i"],
          ".blackjack-betslip\x20.content[data-v-e5d87aea]{width:100%}.blackjack-betslip\x20.content\x20.insurance-btn[data-v-e5d87aea]{margin-bottom:10px}.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-e5d87aea]{width:100%;height:40px;background-color:#313e60;margin-right:10px}.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-e5d87aea]:last-child{margin-right:0}@media(hover:hover){.blackjack-betslip\x20.content\x20.insurance-btn>button[data-v-e5d87aea]:hover{background-color:#37456a}}.blackjack-betslip\x20.content\x20.history-btn[data-v-e5d87aea]{margin-bottom:10px;justify-content:flex-end;padding:0\x2010px;transition:.2s\x20ease}.blackjack-betslip\x20.content\x20.history-btn\x20button[data-v-e5d87aea]{opacity:.6}@media(hover:hover){.blackjack-betslip\x20.content\x20.history-btn\x20button[data-v-e5d87aea]:hover{opacity:1}.blackjack-betslip\x20.content\x20.history-btn\x20button:hover\x20span[data-v-e5d87aea]{color:#ffe588}}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount>div[data-v-e5d87aea]{margin-bottom:10px;flex-shrink:0}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20button[data-v-e5d87aea]{flex-shrink:0;background-color:#313e60}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.cash-updown[data-v-e5d87aea]{border-right:1px\x20solid\x20#252e48}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.input[data-v-e5d87aea]{transition:.2s\x20ease;width:100%;background-color:#313e60;text-align:right;border-right:1px\x20solid\x20#252e48;border-left:1px\x20solid\x20#445174}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.amount-input\x20.amount-init[data-v-e5d87aea]{border-left:1px\x20solid\x20#445174}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance[data-v-e5d87aea]{height:40px}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance>div[data-v-e5d87aea]{height:100%;align-items:center;justify-content:center}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.title[data-v-e5d87aea]{width:40%;background-color:#313e60}.blackjack-betslip\x20.content\x20.betslip-form\x20.amount\x20.balance\x20.count[data-v-e5d87aea]{width:60%;background-color:#2b3654}.blackjack-betslip\x20.content\x20.bet-select-btn[data-v-e5d87aea]{display:grid;grid-gap:10px;gap:10px;grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:10px}.blackjack-betslip\x20.content\x20.bet-select-btn>button[data-v-e5d87aea]{height:40px;background-color:#313e60}@media(hover:hover){.blackjack-betslip\x20.content\x20.bet-select-btn>button[data-v-e5d87aea]:hover{background-color:#37456a}}.blackjack-betslip\x20.content\x20.submit[data-v-e5d87aea]{flex-shrink:0}.blackjack-betslip\x20.content\x20.submit\x20button[data-v-e5d87aea]{background-color:#ffe588;height:40px}.blackjack-betslip\x20.content\x20.submit\x20button>span[data-v-e5d87aea]{color:#000}@media(hover:hover){.blackjack-betslip\x20.content\x20.submit\x20button[data-v-e5d87aea]:hover{background-color:#ffdc60}}",
          "",
        ]),
          (_0x253bdc[_0x263a99(0x13e)] = _0x312db1);
      },
      0x3db: function (_0x24d144, _0x144140, _0x3d4079) {
        "use strict";
        _0x3d4079(0x176);
      },
      0x3dc: function (_0x5c6f09, _0x19a1b4, _0xf9d691) {
        var _0x55a77c = a16_0x295903,
          _0x4b4aaf = _0xf9d691(0x4),
          _0x2cc986 = _0xf9d691(0x5d),
          _0x219d02 = _0xf9d691(0x3dd),
          _0x4c551f = _0xf9d691(0x3de),
          _0x3e3a27 = _0xf9d691(0x3df),
          _0x45a968 = _0x4b4aaf(!0x1),
          _0x2b8698 = _0x2cc986(_0x219d02),
          _0x244290 = _0x2cc986(_0x4c551f),
          _0xc5f51e = _0x2cc986(_0x3e3a27);
        _0x45a968[_0x55a77c(0x22a)]([
          _0x5c6f09["i"],
          _0x55a77c(0x336) +
            _0x2b8698 +
            _0x55a77c(0x3f0) +
            _0x244290 +
            ")}.deck.svelte-s5ivtb[data-v-108ffd82]{position:relative}.wrap.svelte-1wtyksp[data-v-108ffd82]:disabled{pointer-events:none;background-color:unset!important}.horizontal.svelte-1wtyksp[data-v-108ffd82]{transition:.3s;transition-timing-function:ease-out;transition-property:transform}.content.svelte-1wtyksp[data-v-108ffd82]{position:relative;font-family:brandon-grotesque,sans-serif;-webkit-user-select:none;-moz-user-select:none;user-select:none;perspective:700px;transition:.3s;transform-style:preserve-3d;transition-timing-function:ease-out;transition-property:transform,box-shadow;box-shadow:0\x200\x20.25em\x20rgba(7,16,23,.3019607843);border-radius:.25em}.face.svelte-1wtyksp[data-v-108ffd82]{transform:scaleX(-1)}.back.svelte-1wtyksp[data-v-108ffd82],.face.svelte-1wtyksp[data-v-108ffd82]{position:absolute;width:100%;height:100%;border-radius:.25em;background:#fff}.back.svelte-1wtyksp[data-v-108ffd82]{background-image:url(" +
            _0xc5f51e +
            _0x55a77c(0x24c),
          "",
        ]),
          (_0x5c6f09["exports"] = _0x45a968);
      },
    },
  ]);
