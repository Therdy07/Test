import { Routes, Route } from "react-router-dom";
import "./assets/css/Style.css"
import Navbar from "./components/Navbar";
import Prematch from "./pages/Prematch";
import Mainpage from "./pages/Mainpage";
import Inplay from "./pages/Inplay";
import Esports from "./pages/Esports";
import Casino from "./pages/Casino";
import Live from "./components/Casino/Live";
import Minigames from "./pages/Minigames";


function App() {
  return (
    <div id="app">
      <div id="__layout">
        <div data-v-5fa80d04="" className="fill-height">
          <div data-v-5fa80d04="" className="fill-height">
            <div data-v-5fa80d04="" className="fill-height">
              <div data-v-5fa80d04="" className="layout column">
                <div data-v-46c9dc4f="" data-v-5fa80d04="" className="column">
                  <Navbar />
                </div>
                    
                        <Routes>
                          <Route path="/" element={<Mainpage />} />
                          <Route path="/sports/prematch" element={<Prematch />} />
                          <Route path="/sports/inplay" element={<Inplay />} />
                          <Route path="/esports/prematch" element={<Esports />} />
                          <Route path="/casino" element={<Casino />} />
                            <Route path="/casino/live/1" element={<Live />} />
                          <Route path="/games" element={<Minigames />} />
                        </Routes>

                <div
                  data-v-f226d6e6=""
                  data-v-5fa80d04=""
                  className="row"
                  style={{ flexDirection: "row" }}
                >
                  <div
                    className="row"
                    style={{ width: "100%", flexDirection: "row" }}
                  ></div>
                </div>
                <div data-v-5fa80d04="" className="slideout-panel clearfix">
                  <div className="slideout-wrapper"></div>
                </div>
                <div data-v-5fa80d04="" className="vue-portal-target"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
